<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

$me = current_user();
$postId = (int)($_POST['id'] ?? 0);
$back = $_SERVER['HTTP_REFERER'] ?? url('index.php');

if ($postId <= 0) {
  redirect($back);
}

$pdo = db();
$pfx = table_prefix();

$stmt = $pdo->prepare("SELECT id, user_id, author_user_id FROM {$pfx}xf_profile_posts WHERE id=? LIMIT 1");
$stmt->execute([$postId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) {
  redirect($back);
}

$profileUserId = (int)($row['user_id'] ?? 0);
$authorUserId = (int)($row['author_user_id'] ?? 0);
$meId = (int)($me['id'] ?? 0);

if ($meId !== $authorUserId && $meId !== $profileUserId && !is_admin()) {
  http_response_code(403);
  exit('Forbidden');
}

try {
  $pdo->prepare("UPDATE {$pfx}xf_profile_posts SET is_deleted=1, updated_at=NOW() WHERE id=?")
    ->execute([$postId]);
} catch (Throwable $e) {}

redirect(url('user.php?id=' . $profileUserId));
