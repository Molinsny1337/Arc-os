<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/init.php';
require_installed();

$u = current_user();
if (!$u) redirect(url('login.php?next=' . urlencode(url('forum_new.php'))));
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($u, 'post_thread');
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';
require_once __DIR__ . '/includes/services/DiscordWebhookService.php';

$requireV = get_setting('require_email_verification', '1') === '1';
$requireA = get_setting('require_admin_approval', '1') === '1';
$okV = !$requireV || ((int)($u['is_verified'] ?? 0) === 1);
$okA = !$requireA || is_admin() || ((int)($u['can_post'] ?? 0) === 1);
if (!($okV && $okA)) {
  redirect(url('forum.php'));
}

$pdo = db();
$pfx = table_prefix();

$fid = isset($_GET['fid']) ? (int)$_GET['fid'] : 0;
$forums = [];
try {
  $stmt = $pdo->prepare("SELECT id, title FROM {$pfx}forums ORDER BY display_order ASC, id ASC");
  $stmt->execute();
  $forums = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $forums = [];
}

$title = t('new_topic') . ' - ' . site_name();
$err = '';
$formTitle = '';
$formContent = '';
$draftKey = 'thread_new_' . (int)$u['id'] . ($fid > 0 ? '_' . $fid : '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  require_not_banned();

  $fid = isset($_POST['fid']) ? (int)$_POST['fid'] : $fid;
  $formTitle = trim((string)($_POST['title'] ?? ''));
  $formContent = ArcOS\Services\BbCode::normalize((string)($_POST['content'] ?? ''));

  if (turnstile_required('post') && !turnstile_verify_request()) {
    $err = t('captcha_failed');
  } else {
    arc_rate_limit('new_forum_topic', 3, 60);
    arc_rate_limit('new_forum_topic_hour', 30, 3600);

    try {
      if ($formTitle === '') throw new RuntimeException(t('title_required'));
      if (trim(strip_tags($formContent)) === '') throw new RuntimeException(t('content_required'));

      $slug = unique_post_slug($formTitle, 'forum');
      $plain = ArcOS\Services\BbCode::plainText($formContent);
      $plain = trim(preg_replace('/\\s+/', ' ', $plain) ?? '');
      $ex = mb_substr($plain, 0, 80, 'UTF-8');

      // Non-admins default to draft; admins publish immediately.
      $status = is_admin() ? 'published' : 'draft';
      $reviewState = ($status === 'published') ? 'approved' : 'pending';

      $stmt = $pdo->prepare("INSERT INTO {$pfx}posts (author_id, type, forum_id, title, slug, excerpt, content, status, review_state, created_at, updated_at)
        VALUES (?, 'forum', ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
      $stmt->execute([(int)$u['id'], $fid > 0 ? $fid : null, $formTitle, $slug, $ex, $formContent, $status, $reviewState]);

      $newId = (int)$pdo->lastInsertId();
      $draftKey = trim((string)($_POST['draft_key'] ?? $draftKey));
      ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$u['id'], $draftKey, 'thread', $newId);
      ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$u['id'], 'thread', $newId, $formContent);
      $tags = ArcOS\Services\MentionService::extractTags($formContent);
      ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'thread', $newId, $tags);
      if ($fid > 0) {
        try {
          $pdo->prepare("UPDATE {$pfx}forums
            SET thread_count = thread_count + 1,
                last_post_at = NOW(),
                last_post_id = ?,
                last_post_user_id = ?
            WHERE id=?")->execute([$newId, (int)$u['id'], $fid]);
        } catch (Throwable $e) {}
      }

      try {
        $forumTitle = '';
        if ($fid > 0) {
          $stmt = $pdo->prepare("SELECT title FROM {$pfx}forums WHERE id=? LIMIT 1");
          $stmt->execute([$fid]);
          $forumTitle = (string)($stmt->fetchColumn() ?: '');
        }
        $event = $status === 'published' ? 'new_thread' : 'moderation_queue';
        ArcOS\Services\DiscordWebhookService::send($event, [
          'title' => $formTitle,
          'author' => (string)($u['username'] ?? 'user'),
          'summary' => $ex,
          'url' => site_url('forum_post.php?slug=' . urlencode($slug)),
          'thread_id' => $newId,
          'channel' => $forumTitle,
        ]);
      } catch (Throwable $e) {}

      $hello = $u['username'] ?? 'User';
      redirect(url('transition.php') . '?hello=' . urlencode((string)$hello) . '&msg=' . urlencode(t('topic_submitted')) . '&to=' . urlencode(url('forum_post.php?slug=' . urlencode($slug))));
    } catch (Throwable $e) {
      $err = $e->getMessage();
    }
  }
}

$__need_editor = true;
$__need_glass = true;
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap">
    <header class="hero xf-hero reveal-group">
      <div>
        <h1 class="reveal"><?= e(t('new_topic')) ?></h1>
        <p class="reveal"><?= e(t('topic_draft_notice')) ?></p>
      </div>
      <div class="card glass xf-hero-card reveal">
        <div class="xf-meta"><?= e(t('forum_nodes')) ?>: <?= count($forums) ?></div>
      </div>
    </header>

    <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>

    <section class="reveal-group">
      <form class="form glass reveal" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="field">
          <label class="label"><?= e(t('title')) ?></label>
          <input class="input" name="title" value="<?= e($formTitle) ?>" placeholder="<?= e(t('title_placeholder')) ?>" required />
        </div>

        <div class="field">
          <label class="label"><?= e(t('forum_nodes')) ?></label>
          <select class="input" name="fid">
            <option value="0"><?= e(t('not_selected')) ?></option>
            <?php foreach ($forums as $f): ?>
              <option value="<?= (int)$f['id'] ?>" <?= ($fid === (int)$f['id']) ? 'selected' : '' ?>><?= e((string)$f['title']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="field">
          <label class="label"><?= e(t('content')) ?></label>
          <?php
            $content_name = 'content';
            $initial_value = $formContent;
            $mode = 'thread';
            $attachments_enabled = true;
            $placeholder = t('content_placeholder');
            $content_id = 0;
            $draft_key = $draftKey;
            include __DIR__ . '/partials/editor/editor_widget.php';
          ?>
        </div>

        <?php if (turnstile_required('post')): ?>
          <div style="margin:10px 0;display:flex;justify-content:flex-end">
            <?= turnstile_widget('post', 'light') ?>
          </div>
        <?php endif; ?>

        <button class="btn" type="submit"><?= e(t('submit')) ?></button>
      </form>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
