<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/SearchService.php';
require_once __DIR__ . '/includes/services/BbCode.php';

$pdo = db();
$pfx = table_prefix();
$me = current_user();
(new ArcOS\Services\Permission())->requirePerm($me, 'view_search');

$title = site_name() . ' - ' . t('search');
$q = trim((string)($_GET['q'] ?? ''));
$user = trim((string)($_GET['user'] ?? ''));
$type = (string)($_GET['type'] ?? 'threads');
if (!in_array($type, ['threads','posts','users'], true)) $type = 'threads';
$forumId = (int)($_GET['forum_id'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

$forums = [];
try {
  $stmt = $pdo->prepare("SELECT id, title FROM {$pfx}forums WHERE status='active' ORDER BY sort_order ASC, title ASC");
  $stmt->execute();
  $forums = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $forums = [];
}

$result = ['total' => 0, 'rows' => []];
if ($q !== '' || $user !== '' || $type === 'users') {
  if ($type === 'threads') {
    $result = ArcOS\Services\SearchService::searchThreads($pdo, $pfx, $q, $user, $forumId, $page, $perPage);
  } elseif ($type === 'posts') {
    $result = ArcOS\Services\SearchService::searchPosts($pdo, $pfx, $q, $user, $forumId, $page, $perPage);
  } else {
    $result = ArcOS\Services\SearchService::searchUsers($pdo, $pfx, $q, $page, $perPage);
  }
  arc_log('search', null, null, ['q' => $q, 'user' => $user, 'type' => $type, 'forum_id' => $forumId]);
}

$rows = $result['rows'] ?? [];
$total = (int)($result['total'] ?? 0);
$base_url = url('search.php');
$query = ['q' => $q, 'user' => $user, 'type' => $type, 'forum_id' => $forumId];
$total_pages = (int)ceil(max(1, $total) / $perPage);
$__need_glass = true;
$__need_density = true;
$__need_tooltip = true;

function avatar_url(?string $a): string {
  if (!$a) return base_path().'/assets/avatar.png';
  if (preg_match('#^https?://#i', $a)) return $a;
  if (str_starts_with($a, base_path())) return $a;
  return base_path().'/'.ltrim($a,'/');
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
<?php include __DIR__ . '/partials/nav.php'; ?>

<main class="wrap xf-apple">
  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e(t('search')) ?></h1>
      <p class="reveal"><?= e(t('search_placeholder')) ?></p>
    </div>
    <div class="card glass xf-hero-card reveal">
      <div class="xf-meta"><?= e(t('results')) ?>: <?= (int)$total ?></div>
    </div>
  </header>

  <div class="xf-toolbar reveal" style="justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <div class="xf-filters">
      <a class="xf-filter<?= $type === 'threads' ? ' active' : '' ?>" href="<?= e(url('search.php?type=threads&q=' . urlencode($q) . '&user=' . urlencode($user) . '&forum_id=' . $forumId)) ?>"><?= e(t('threads')) ?></a>
      <a class="xf-filter<?= $type === 'posts' ? ' active' : '' ?>" href="<?= e(url('search.php?type=posts&q=' . urlencode($q) . '&user=' . urlencode($user) . '&forum_id=' . $forumId)) ?>"><?= e(t('posts')) ?></a>
      <a class="xf-filter<?= $type === 'users' ? ' active' : '' ?>" href="<?= e(url('search.php?type=users&q=' . urlencode($q))) ?>"><?= e(t('members')) ?></a>
    </div>
    <form method="get" action="<?= e(url('search.php')) ?>" class="xf-search" style="margin:0;min-width:320px;">
      <input type="hidden" name="type" value="<?= e($type) ?>" />
      <input class="input" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search_placeholder')) ?>" />
      <input class="input" name="user" value="<?= e($user) ?>" placeholder="<?= e(t('user')) ?>" style="max-width:180px;" />
      <select class="input" name="forum_id" style="max-width:220px;">
        <option value="0"><?= e(t('all')) ?> <?= e(t('forum')) ?></option>
        <?php foreach ($forums as $f): ?>
          <option value="<?= (int)($f['id'] ?? 0) ?>" <?= $forumId === (int)($f['id'] ?? 0) ? 'selected' : '' ?>><?= e((string)($f['title'] ?? '')) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn" type="submit"><?= e(t('search')) ?></button>
    </form>
  </div>

  <section class="section reveal-group">
    <div class="card glass reveal">
      <?php if (!$rows): ?>
        <div class="muted"><?= e(t('no_data')) ?></div>
      <?php else: ?>
        <?php if ($type === 'threads'): ?>
          <div class="xf-stack">
            <?php foreach ($rows as $r): ?>
              <?php
                $href = url('forum_post.php?slug=' . urlencode((string)($r['slug'] ?? '')));
                $forumTitle = (string)($r['forum_title'] ?? '');
                if ($forumTitle === '') $forumTitle = t('forum');
              ?>
              <a class="xf-thread-row" href="<?= e($href) ?>">
                <span class="xf-avatar" aria-hidden="true">#</span>
                <div style="min-width:0">
                  <div class="xf-thread-title"><?= e((string)($r['title'] ?? '')) ?></div>
                  <div class="xf-meta">
                    <span><?= e($forumTitle) ?></span>
                    <span><?= e((string)($r['author_display'] ?? $r['author_username'] ?? '')) ?></span>
                    <span><?= e((string)($r['last_post_at'] ?? $r['created_at'] ?? '')) ?></span>
                  </div>
                </div>
                <div class="xf-thread-stats">
                  <div><strong><?= (int)($r['reply_count'] ?? 0) ?></strong> <?= e(t('replies')) ?></div>
                  <div><strong><?= (int)($r['view_count'] ?? 0) ?></strong> <?= e(t('views')) ?></div>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php elseif ($type === 'posts'): ?>
          <div class="xf-stack">
            <?php foreach ($rows as $r): ?>
              <?php
                $href = url('forum_post.php?slug=' . urlencode((string)($r['slug'] ?? '')));
                $snippet = ArcOS\Services\BbCode::render((string)($r['content'] ?? ''), $pdo, $pfx);
              ?>
              <div class="card glass" style="padding:12px;border-radius:14px;">
                <div class="xf-meta"><?= e((string)($r['author_display'] ?? $r['author_username'] ?? '')) ?> &middot; <a href="<?= e($href) ?>"><?= e((string)($r['title'] ?? '')) ?></a></div>
                <div style="margin-top:8px;">
                  <?= $snippet ?>
                </div>
                <div class="xf-meta" style="margin-top:8px;">
                  <?= e((string)($r['created_at'] ?? '')) ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="xf-stack">
            <?php foreach ($rows as $u): ?>
              <?php $user = $u; include __DIR__ . '/partials/xf/user_card.php'; ?>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </section>

  <?php
    if ($total > $perPage) {
      $total_pages = (int)ceil($total / $perPage);
      include __DIR__ . '/partials/xf/pager.php';
    }
  ?>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
