<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_once __DIR__ . '/../includes/services/MailService.php';

$limit = 20;
if (PHP_SAPI === 'cli') {
  foreach ($argv as $arg) {
    if (preg_match('/^--limit=(\d+)$/', (string)$arg, $m)) {
      $limit = (int)$m[1];
    }
  }
}

$pdo = db();
$pfx = table_prefix();
$res = ArcOS\Services\MailService::sendQueued($pdo, $pfx, $limit);

if (PHP_SAPI === 'cli') {
  echo "sent={$res['sent']} failed={$res['failed']}\n";
} else {
  echo 'sent=' . (int)$res['sent'] . ' failed=' . (int)$res['failed'];
}
