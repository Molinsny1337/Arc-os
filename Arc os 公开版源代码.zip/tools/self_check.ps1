$ErrorActionPreference = "Stop"

function Write-Section($title) {
  Write-Output ""
  Write-Output ("==== {0} ====" -f $title)
}

$repoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repoRoot

Write-Section "Find PHP"
$phpExe = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "find_php.ps1")
if ($phpExe -eq "PHP_NOT_FOUND") {
  Write-Output "php.exe not found. Install PHP, or re-run with a new shell so PATH updates."
  exit 2
}
Write-Output ("php.exe: {0}" -f $phpExe)
& $phpExe -v

Write-Section "PHP lint"
$failed = @()
Get-ChildItem -Recurse -File -Filter *.php | ForEach-Object {
  $out = & $phpExe -l $_.FullName 2>&1
  if ($LASTEXITCODE -ne 0) { $failed += ("FAIL {0}: {1}" -f $_.FullName, $out) }
}
if ($failed.Count -gt 0) {
  $failed | Select-Object -First 50 | ForEach-Object { Write-Output $_ }
  exit 1
}
Write-Output "PHP_LINT_OK"

Write-Section "HTTP smoke"
$urls = @(
  "http://127.0.0.1:8000/index.php?lang=en",
  "http://127.0.0.1:8000/forum.php?lang=en",
  "http://127.0.0.1:8000/members.php?lang=en",
  "http://127.0.0.1:8000/whats_new.php?lang=en",
  "http://127.0.0.1:8000/page.php?slug=not-exist&lang=en",
  "http://127.0.0.1:8000/api.php"
)

foreach ($u in $urls) {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 10
    Write-Output ("OK {0} {1}" -f $r.StatusCode, $u)
  } catch {
    $resp = $_.Exception.Response
    if ($resp) {
      $status = [int]$resp.StatusCode
      $expected = $false
      if ($u -like "*page.php?slug=not-exist*") { $expected = ($status -eq 404) }
      if ($u -like "*api.php") { $expected = ($status -eq 404 -or $status -eq 401 -or $status -eq 403) } # depends on settings
      $tag = "ERR"
      if ($expected) { $tag = "OK_EXPECTED" }
      Write-Output (("{0} {1} {2}" -f $tag, $status, $u))
      try {
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $body = $sr.ReadToEnd()
        if ($body) { Write-Output ($body.Substring(0, [Math]::Min(200, $body.Length))) }
      } catch {}
    } else {
      Write-Output ("ERR {0} {1}" -f $_.Exception.Message, $u)
    }
  }
}

Write-Section "Basic security grep (best-effort)"
$patterns = @(
  '\beval\s*\(',
  '\bassert\s*\(',
  '\bshell_exec\s*\(',
  '\bpassthru\s*\(',
  '\bsystem\s*\(',
  '\bpopen\s*\(',
  '\bproc_open\s*\('
)
foreach ($p in $patterns) {
  $hits = rg -n -S -g '!tools/**' -g '!vendor/**' -e $p . 2>$null
  if ($hits) {
    Write-Output ("HIT {0}" -f $p)
    $hits | Select-Object -First 20 | ForEach-Object { Write-Output $_ }
  } else {
    Write-Output ("OK  {0}" -f $p)
  }
}

Write-Output ""
Write-Output "SELF_CHECK_DONE"
