<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$isCli = (PHP_SAPI === 'cli');
if (!$isCli) {
  require_admin();
  require_post();
  require_csrf();
}

$pdo = db();
$pfx = table_prefix();

$stmtThreads = $pdo->prepare("SELECT id, forum_id, author_id, created_at FROM {$pfx}posts WHERE type='forum'");
$stmtThreads->execute();
$threads = $stmtThreads->fetchAll(PDO::FETCH_ASSOC) ?: [];

$stmtComments = $pdo->prepare("SELECT id FROM {$pfx}post_comments WHERE post_id=? ORDER BY created_at ASC, id ASC");
$stmtCommentCount = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE post_id=? AND is_deleted=0");
$stmtLastComment = $pdo->prepare("SELECT author_id, created_at FROM {$pfx}post_comments WHERE post_id=? AND is_deleted=0 ORDER BY created_at DESC, id DESC LIMIT 1");
$stmtUpdateCommentPos = $pdo->prepare("UPDATE {$pfx}post_comments SET position=? WHERE id=?");
$stmtUpdateThread = $pdo->prepare("UPDATE {$pfx}posts
  SET reply_count=?, last_post_at=?, last_post_user_id=?, updated_at=NOW()
  WHERE id=?");

$updated = 0;
foreach ($threads as $t) {
  $threadId = (int)($t['id'] ?? 0);
  if ($threadId <= 0) continue;

  $stmtComments->execute([$threadId]);
  $rows = $stmtComments->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
  $pos = 1;
  foreach ($rows as $cid) {
    $cid = (int)$cid;
    if ($cid <= 0) continue;
    $stmtUpdateCommentPos->execute([$pos, $cid]);
    $pos++;
  }

  $stmtCommentCount->execute([$threadId]);
  $replyCount = (int)($stmtCommentCount->fetchColumn() ?: 0);

  $lastPostAt = (string)($t['created_at'] ?? '');
  $lastPostUserId = (int)($t['author_id'] ?? 0);
  $stmtLastComment->execute([$threadId]);
  $last = $stmtLastComment->fetch(PDO::FETCH_ASSOC);
  if ($last) {
    $lastPostAt = (string)($last['created_at'] ?? $lastPostAt);
    $lastPostUserId = (int)($last['author_id'] ?? $lastPostUserId);
  }

  $stmtUpdateThread->execute([$replyCount, $lastPostAt ?: null, $lastPostUserId ?: null, $threadId]);
  $updated++;
}

// Forum aggregate stats
$forums = $pdo->query("SELECT id FROM {$pfx}forums")->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
$stmtForumCounts = $pdo->prepare("SELECT COUNT(*), COALESCE(SUM(reply_count),0), MAX(last_post_at) FROM {$pfx}posts WHERE type='forum' AND forum_id=? AND is_deleted=0");
$stmtForumLast = $pdo->prepare("SELECT last_post_user_id, last_post_at, id FROM {$pfx}posts WHERE type='forum' AND forum_id=? AND is_deleted=0 ORDER BY COALESCE(last_post_at, created_at) DESC LIMIT 1");
$stmtUpdateForum = $pdo->prepare("UPDATE {$pfx}forums
  SET thread_count=?, message_count=?, last_post_at=?, last_post_id=?, last_post_user_id=?
  WHERE id=?");

foreach ($forums as $fid) {
  $fid = (int)$fid;
  if ($fid <= 0) continue;
  $stmtForumCounts->execute([$fid]);
  $row = $stmtForumCounts->fetch(PDO::FETCH_NUM);
  $threadCount = (int)($row[0] ?? 0);
  $replyCount = (int)($row[1] ?? 0);
  $lastPostAt = (string)($row[2] ?? '');
  $lastPostUserId = null;
  $lastPostId = null;
  $stmtForumLast->execute([$fid]);
  $last = $stmtForumLast->fetch(PDO::FETCH_ASSOC);
  if ($last) {
    $lastPostUserId = (int)($last['last_post_user_id'] ?? 0) ?: null;
    $lastPostAt = (string)($last['last_post_at'] ?? $lastPostAt);
    $lastPostId = (int)($last['id'] ?? 0) ?: null;
  }
  $stmtUpdateForum->execute([$threadCount, $replyCount, $lastPostAt ?: null, $lastPostId, $lastPostUserId, $fid]);
}

// Normalize comment status
$pdo->exec("UPDATE {$pfx}post_comments SET status='visible' WHERE status='' OR status IS NULL");
$pdo->exec("UPDATE {$pfx}post_comments SET status='deleted' WHERE is_deleted=1 AND status='visible'");

if ($isCli) {
  echo "threads updated: {$updated}\n";
} else {
  echo "threads updated: {$updated}";
}
