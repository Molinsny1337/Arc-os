$ErrorActionPreference = "Stop"

Write-Output "Running self-check..."
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "self_check.ps1")
if ($LASTEXITCODE -ne 0) {
  Write-Output ""
  Write-Output "Self-check failed; not shutting down."
  exit $LASTEXITCODE
}

Write-Output ""
Write-Output "Self-check passed."
Write-Output "For safety, shutdown requires explicit confirmation."
$confirm = Read-Host "Type SHUTDOWN to power off now"
if ($confirm -ne "SHUTDOWN") {
  Write-Output "Canceled."
  exit 0
}

shutdown /s /t 0

