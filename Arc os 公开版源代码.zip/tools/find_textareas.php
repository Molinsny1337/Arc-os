<?php
declare(strict_types=1);
// Admin-only utility to scan templates for text inputs (textarea/contenteditable/fields likely needing editor_widget).
require_once __DIR__ . '/../includes/init.php';
require_installed();
$me = current_user();
if (!$me || !is_admin()) { http_response_code(403); exit('Forbidden'); }
if (get_setting('find_textareas_enabled', '0') !== '1') { http_response_code(404); exit('Disabled'); }

$root = realpath(__DIR__ . '/..');
$names = ['content','message','body','comment','reason','notes','signature','about','description'];
$result = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $file) {
  if (!$file->isFile()) continue;
  $path = (string)$file->getPathname();
  $lower = strtolower($path);
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR)) continue;
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'node_modules' . DIRECTORY_SEPARATOR)) continue;
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR)) continue;
  $ext = strtolower((string)$file->getExtension());
  if ($ext !== 'php' && $ext !== 'html') continue;
  $lines = @file($path);
  if (!$lines) continue;
  foreach ($lines as $idx => $line) {
    $lineNo = $idx + 1;
    if (stripos($line, '<textarea') !== false || stripos($line, 'contenteditable') !== false) {
      $match = true;
    } else {
      $match = false;
      foreach ($names as $n) {
        if (stripos($line, 'name="' . $n) !== false) { $match = true; break; }
      }
    }
    if ($match) {
      $result[] = [$path, $lineNo, trim($line)];
    }
  }
}
header('Content-Type: text/plain; charset=utf-8');
foreach ($result as [$f,$ln,$line]) {
  echo $f . ':' . $ln . ' ' . $line . "\n";
}
