<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me || !is_admin()) { http_response_code(403); exit('Forbidden'); }
if (get_setting('audit_enabled', '0') !== '1') { http_response_code(404); exit('Disabled'); }

$root = realpath(__DIR__ . '/..');
$strictIssues = [];
$queryLines = [];
$csrfIssues = [];
$escapedFixes = [];
$csrfFixes = [];
$strictFixes = [];
$sqlFixes = [];
$uploadIssues = [];

function audit_fix_strict_types(string $raw): array {
  $data = $raw;
  $changed = false;
  if (strncmp($data, "\xEF\xBB\xBF", 3) === 0) {
    $data = substr($data, 3);
    $changed = true;
  }
  $lines = preg_split('/\R/', $data);
  if (!$lines) return [$raw, false];
  $first = isset($lines[0]) ? trim((string)$lines[0]) : '';
  $second = isset($lines[1]) ? trim((string)$lines[1]) : '';
  if ($first !== '<?php') return [$raw, false];
  if ($second === 'declare(strict_types=1);') return [$data, $changed];
  array_splice($lines, 1, 0, ['declare(strict_types=1);']);
  return [implode("\n", $lines), true];
}

function audit_insert_csrf(array $lines): array {
  foreach ($lines as $line) {
    if (strpos($line, 'require_csrf') !== false) return [$lines, false];
  }

  $anchors = ['require_post', 'require_login', 'require_admin', 'require_mod', 'require_installed'];
  $insertAt = null;
  foreach ($anchors as $anchor) {
    foreach ($lines as $idx => $line) {
      if (strpos($line, $anchor) !== false) { $insertAt = $idx + 1; break 2; }
    }
  }
  if ($insertAt === null) return [$lines, false];
  array_splice($lines, $insertAt, 0, ['require_csrf();']);
  return [$lines, true];
}

function audit_escape_output(array $lines): array {
  $changed = false;
  foreach ($lines as $idx => $line) {
    if (strpos($line, '<?=') === false) continue;
    if (strpos($line, '<?= e(') !== false) continue;
    if (strpos($line, 'BbCode::render') !== false) continue;
    if (strpos($line, 'SafeHtml::') !== false) continue;
    if (strpos($line, 'htmlspecialchars') !== false) continue;
    if (strpos($line, 'csrf_field') !== false) continue;

    $count = 0;
    $pattern = '/<\?=\s*(\$[A-Za-z_][A-Za-z0-9_]*(?:->\w+|\[[^\]]+\])*)\s*\?>/';
    $newLine = preg_replace($pattern, '<?= e($1) ?>', $line, -1, $count);
    if ($count > 0 && is_string($newLine)) {
      $lines[$idx] = $newLine;
      $changed = true;
    }
  }
  return [$lines, $changed];
}

function audit_sanitize_input_inline(string $line, bool &$changed): string {
  $line = preg_replace_callback('/\$_GET\[["\']([A-Za-z0-9_]+)["\']\]/', function(array $m) use (&$changed): string {
    $key = $m[1];
    $changed = true;
    if (str_ends_with(strtolower($key), 'id') || strtolower($key) === 'id') {
      return '(int)($_GET[\'' . $key . '\'] ?? 0)';
    }
    return 'trim((string)($_GET[\'' . $key . '\'] ?? \'\'))';
  }, $line);
  $line = preg_replace_callback('/\$_POST\[["\']([A-Za-z0-9_]+)["\']\]/', function(array $m) use (&$changed): string {
    $key = $m[1];
    $changed = true;
    if (str_ends_with(strtolower($key), 'id') || strtolower($key) === 'id') {
      return '(int)($_POST[\'' . $key . '\'] ?? 0)';
    }
    return 'trim((string)($_POST[\'' . $key . '\'] ?? \'\'))';
  }, $line);
  $line = preg_replace_callback('/\$_REQUEST\[["\']([A-Za-z0-9_]+)["\']\]/', function(array $m) use (&$changed): string {
    $key = $m[1];
    $changed = true;
    if (str_ends_with(strtolower($key), 'id') || strtolower($key) === 'id') {
      return '(int)($_REQUEST[\'' . $key . '\'] ?? 0)';
    }
    return 'trim((string)($_REQUEST[\'' . $key . '\'] ?? \'\'))';
  }, $line);
  return $line;
}

$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $file) {
  if (!$file->isFile()) continue;
  $path = (string)$file->getPathname();
  $lower = strtolower($path);
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR)) continue;
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'node_modules' . DIRECTORY_SEPARATOR)) continue;
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR)) continue;
  if (str_contains($lower, DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR)) continue;
  if (strtolower((string)$file->getExtension()) !== 'php') continue;

  $raw = @file_get_contents($path);
  if ($raw === false) continue;
  $data = $raw;
  $changed = false;

  [$fixed, $fixedStrict] = audit_fix_strict_types($data);
  if ($fixed !== $data) {
    $data = $fixed;
    $changed = true;
    if ($fixedStrict) $strictFixes[] = $path;
  }

  $lines = preg_split('/\R/', $data);
  if (!$lines) continue;

  $first = isset($lines[0]) ? trim((string)$lines[0]) : '';
  $second = isset($lines[1]) ? trim((string)$lines[1]) : '';
  if ($first !== '<?php' || $second !== 'declare(strict_types=1);') {
    $strictIssues[] = $path;
  }

  $hasPost = false;
  $hasCsrf = false;
  $hasUpload = false;
  $hasUploadChecks = false;

  foreach ($lines as $idx => $line) {
    $lineNo = $idx + 1;
    if (strpos($line, '->query(') !== false || strpos($line, '->exec(') !== false) {
      $queryLines[] = $path . ':' . $lineNo . ' ' . trim($line);
    }
    if (strpos($line, '$_POST') !== false || strpos($line, '$_REQUEST') !== false || strpos($line, '$_FILES') !== false) {
      $hasPost = true;
    }
    if (strpos($line, 'require_csrf') !== false) $hasCsrf = true;
    if (strpos($line, '$_FILES') !== false) $hasUpload = true;
    if (strpos($line, 'detect_upload_image_ext') !== false || strpos($line, 'mime_to_image_ext') !== false) {
      $hasUploadChecks = true;
    }
  }

  if ($hasPost && !$hasCsrf) {
    [$lines, $csrfAdded] = audit_insert_csrf($lines);
    if ($csrfAdded) {
      $csrfFixes[] = $path;
      $changed = true;
    } else {
      $csrfIssues[] = $path;
    }
  }

  [$lines, $escaped] = audit_escape_output($lines);
  if ($escaped) {
    $escapedFixes[] = $path;
    $changed = true;
  }

  foreach ($lines as $i => $line) {
    if (strpos($line, '->query(') === false && strpos($line, '->exec(') === false) continue;
    if (strpos($line, '$_GET') === false && strpos($line, '$_POST') === false && strpos($line, '$_REQUEST') === false) continue;
    $lineChanged = false;
    $newLine = audit_sanitize_input_inline($line, $lineChanged);
    if ($lineChanged) {
      $lines[$i] = $newLine;
      $sqlFixes[] = $path . ':' . ($i + 1);
      $changed = true;
    }
  }

  if ($hasUpload && !$hasUploadChecks) {
    $uploadIssues[] = $path;
  }

  if ($changed) {
    @file_put_contents($path, implode("\n", $lines));
  }
}

header('Content-Type: text/plain; charset=utf-8');
echo "STRICT_TYPES_ISSUES=" . count($strictIssues) . "\n";
foreach ($strictIssues as $p) echo $p . "\n";
echo "\nSTRICT_TYPES_FIXED=" . count($strictFixes) . "\n";
foreach ($strictFixes as $p) echo $p . "\n";

echo "\nQUERY_CALLS=" . count($queryLines) . "\n";
foreach ($queryLines as $l) echo $l . "\n";

echo "\nCSRF_MISSING=" . count($csrfIssues) . "\n";
foreach ($csrfIssues as $p) echo $p . "\n";

echo "\nCSRF_FIXED=" . count($csrfFixes) . "\n";
foreach ($csrfFixes as $p) echo $p . "\n";

echo "\nESCAPE_FIXED=" . count($escapedFixes) . "\n";
foreach ($escapedFixes as $p) echo $p . "\n";

echo "\nINPUT_SANITIZED=" . count($sqlFixes) . "\n";
foreach ($sqlFixes as $p) echo $p . "\n";

echo "\nUPLOAD_REVIEW=" . count($uploadIssues) . "\n";
foreach ($uploadIssues as $p) echo $p . "\n";
