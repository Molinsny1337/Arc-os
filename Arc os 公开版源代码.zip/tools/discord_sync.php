<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

if (php_sapi_name() !== 'cli') {
  http_response_code(403);
  exit('CLI only');
}

require_once __DIR__ . '/../includes/services/DiscordRoleSyncService.php';

$pdo = db();
$pfx = table_prefix();

$limit = 50;
global $argv;
if (isset($argv[1]) && is_numeric($argv[1])) {
  $limit = (int)$argv[1];
}
if ($limit < 1) $limit = 1;
if ($limit > 200) $limit = 200;

$stmt = $pdo->prepare("SELECT user_id FROM {$pfx}xf_user_discord ORDER BY last_sync_at ASC, user_id ASC LIMIT ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();
$ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];

foreach ($ids as $uid) {
  $uid = (int)$uid;
  if ($uid <= 0) continue;
  ArcOS\Services\DiscordRoleSyncService::syncUser($pdo, $pfx, $uid);
  usleep(350000);
}

echo "Synced " . count($ids) . " users\n";
