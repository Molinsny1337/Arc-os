<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';

use ArcOS\Services\LicenseService;

if (!class_exists(LicenseService::class)) {
  require_once __DIR__ . '/../includes/services/Crypto.php';
  require_once __DIR__ . '/../includes/services/LicenseApiClient.php';
  require_once __DIR__ . '/../includes/services/LicenseService.php';
}

echo "License self-test\n";

$siteId = LicenseService::getSiteId();
echo "site_id: " . ($siteId !== '' ? $siteId : '(missing)') . "\n";

$host = (string)($_SERVER['HTTP_HOST'] ?? 'Example.COM:8080');
$normalized = LicenseService::normalizeDomain($host);
echo "normalize_domain(\"{$host}\") => " . ($normalized !== '' ? $normalized : '(invalid)') . "\n";

$domainForTest = $normalized !== '' ? $normalized : 'example.com';
$payload = [
  'domain' => $domainForTest,
  'site_id' => $siteId !== '' ? $siteId : '00000000-0000-4000-8000-000000000000',
  'tier' => 'pro',
  'features' => ['mail', 'custom_css', 'favicon'],
  'expires_at' => gmdate('Y-m-d H:i:s', time() + 3600),
  'grace_days' => 7,
];

$now = time();
$valid = LicenseService::testEvaluate($payload, $now, $now);
$grace = LicenseService::testEvaluate($payload, $now - (13 * 3600), $now);
$invalid = LicenseService::testEvaluate($payload, $now - (9 * 24 * 3600), $now);

echo "state(valid): " . $valid['status'] . "\n";
echo "state(grace): " . $grace['status'] . "\n";
echo "state(invalid): " . $invalid['status'] . "\n";

if ($valid['status'] !== 'valid' || $grace['status'] !== 'grace' || $invalid['status'] !== 'invalid') {
  echo "Self-test result: FAILED\n";
  exit(1);
}

echo "Self-test result: OK\n";
