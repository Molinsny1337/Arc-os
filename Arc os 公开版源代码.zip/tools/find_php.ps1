$ErrorActionPreference = "Stop"

function Find-PHPExe {
  # Try PATH first
  $cmd = Get-Command php -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source) { return $cmd.Source }

  # WinGet installs portable PHP into Packages
  $pkgRoot = Join-Path $env:LOCALAPPDATA "Microsoft\\WinGet\\Packages"
  if (Test-Path $pkgRoot) {
    $candidates = Get-ChildItem $pkgRoot -Directory -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -like "PHP.PHP.*_Microsoft.Winget.Source_*" } |
      ForEach-Object {
        $exe = Join-Path $_.FullName "php.exe"
        if (Test-Path $exe) { $exe }
      }

    if ($candidates) {
      # Prefer latest version by folder name (good enough)
      return ($candidates | Sort-Object -Descending | Select-Object -First 1)
    }
  }

  return $null
}

$phpExe = Find-PHPExe
if (-not $phpExe) {
  Write-Output "PHP_NOT_FOUND"
  exit 2
}

Write-Output $phpExe

