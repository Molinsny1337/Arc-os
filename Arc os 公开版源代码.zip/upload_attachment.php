<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok'=>false,'error'=>'LOGIN_REQUIRED']);
  exit;
}
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'upload_attachment', ['json' => true, 'status' => 403]);
require_not_banned();
require_post();
require_csrf();
arc_rate_limit('upload_attachment', 30, 60);

$pdo = db();
$pfx = table_prefix();

$postId = (int)($_POST['post_id'] ?? 0);
if ($postId <= 0) {
  http_response_code(400);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok'=>false,'error'=>'BAD_POST']);
  exit;
}

require_once __DIR__ . '/includes/attachments.php';
$items = arc_handle_attachments_upload($pdo, $pfx, $me, $postId, 'file');

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
