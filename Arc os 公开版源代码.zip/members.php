<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/Permission.php';

$pdo = db();
$pfx = table_prefix();
$me = current_user();
(new ArcOS\Services\Permission())->requirePerm($me, 'view_members');

$q = trim((string)($_GET['q'] ?? ''));
$sort = (string)($_GET['sort'] ?? 'newest');
if (!in_array($sort, ['newest','posts','reactions','active'], true)) $sort = 'newest';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 24;
$offset = ($page - 1) * $perPage;

$showDiscord = get_setting('discord_show_in_members', '0') === '1';
$discordSelect = $showDiscord ? ", d.discord_username, d.discord_discriminator" : '';
$discordJoin = $showDiscord ? " LEFT JOIN {$pfx}xf_user_discord d ON d.user_id=u.id" : '';

$where = '';
$params = [];
if ($q !== '') {
  $where = "WHERE u.username LIKE ? OR u.display_name LIKE ?";
  $like = '%' . $q . '%';
  $params = [$like, $like];
}

$joinStats = '';
$orderBy = 'u.id DESC';
if ($sort === 'posts') {
  $joinStats = "LEFT JOIN (SELECT author_id, COUNT(*) AS post_count FROM {$pfx}posts WHERE type='forum' AND status='published' GROUP BY author_id) pc ON pc.author_id=u.id";
  $orderBy = 'COALESCE(pc.post_count,0) DESC, u.id DESC';
} elseif ($sort === 'reactions') {
  $joinStats = "LEFT JOIN (SELECT p.author_id, COUNT(*) AS reaction_score FROM {$pfx}post_reactions r JOIN {$pfx}posts p ON p.id=r.post_id GROUP BY p.author_id) pr ON pr.author_id=u.id";
  $orderBy = 'COALESCE(pr.reaction_score,0) DESC, u.id DESC';
} elseif ($sort === 'active') {
  $orderBy = 'u.last_active DESC, u.id DESC';
}

$total = 0;
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users u {$where}");
  $stmt->execute($params);
  $total = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {
  $total = 0;
}

$rows = [];
try {
  $sql = "SELECT u.id, u.username, u.display_name, u.avatar, u.created_at{$discordSelect}
    FROM {$pfx}users u
    {$joinStats}
    {$discordJoin}
    {$where}
    ORDER BY {$orderBy}
    LIMIT ? OFFSET ?";
  $stmt = $pdo->prepare($sql);
  $i = 1;
  foreach ($params as $param) {
    $stmt->bindValue($i++, $param, PDO::PARAM_STR);
  }
  $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
  $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $rows = [];
}

$title = site_name() . ' - ' . t('members');
$layoutItems = arc_get_layout_setting_items('members_layout', arc_members_layout_default_items(), arc_members_layout_allowed_ids());
$__need_ui_layout = is_admin();
$__need_glass = true;
$__need_density = true;
$__need_tooltip = true;
$langCode = function_exists('lang') ? lang() : 'zh-CN';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

<?php
  $layoutCanEdit = is_admin() ? '1' : '0';
  $layoutDefault = json_encode(arc_members_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutDefault)) $layoutDefault = '[]';
  $layoutLabels = [];
  foreach (arc_members_layout_allowed_ids() as $id) $layoutLabels[$id] = t('block_' . $id);
  $layoutLabelsJson = json_encode($layoutLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutLabelsJson)) $layoutLabelsJson = '{}';
  $layoutUi = [
    'edit' => t('layout_edit'),
    'done' => t('layout_done'),
    'reset' => t('reset'),
    'blocks' => t('layout_blocks'),
    'saved' => t('layout_saved'),
    'save_failed' => t('layout_save_failed'),
    'hide' => t('hide'),
    'show' => t('show'),
  ];
  $layoutUiJson = json_encode($layoutUi, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutUiJson)) $layoutUiJson = '{}';
?>

<main class="wrap xf-apple xf-members-page"
  data-arc-layout-root="1"
  data-arc-can-edit="<?= e($layoutCanEdit) ?>"
  data-arc-layout-scope="members_global"
  data-arc-save-url="<?= e(url('layout_save.php')) ?>"
  data-arc-csrf="<?= e(csrf_token()) ?>"
  data-arc-default="<?= e($layoutDefault) ?>"
  data-arc-labels="<?= e($layoutLabelsJson) ?>"
  data-arc-ui="<?= e($layoutUiJson) ?>"
>
  <?php foreach ($layoutItems as $it):
    $sid = (string)($it['id'] ?? '');
    $enabled = (bool)($it['enabled'] ?? true);
    if ($sid === '') continue;
  ?>
    <?php if ($sid === 'hero'): ?>
      <header class="hero xf-hero reveal-group" data-arc-layout-item="1" data-id="hero" <?= $enabled ? '' : 'hidden' ?>>
        <div>
          <h1 class="reveal"><?= e(t('members')) ?></h1>
          <p class="reveal"><?= e(t('members_sub')) ?></p>
        </div>
        <div class="card glass xf-hero-card reveal">
          <form method="get" action="<?= e(url('members.php')) ?>" class="xf-search" style="margin:0">
            <input class="input" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search_placeholder')) ?>" />
            <input type="hidden" name="sort" value="<?= e($sort) ?>" />
            <button class="btn" type="submit"><?= e(t('search')) ?></button>
          </form>
        </div>
      </header>
      <div class="xf-toolbar reveal">
        <div class="xf-filters">
          <a class="xf-filter<?= $sort === 'newest' ? ' active' : '' ?>" href="<?= e(url('members.php?sort=newest')) ?>"><?= e(t('sort_newest')) ?></a>
          <a class="xf-filter<?= $sort === 'posts' ? ' active' : '' ?>" href="<?= e(url('members.php?sort=posts')) ?>"><?= e(t('sort_posts')) ?></a>
          <a class="xf-filter<?= $sort === 'reactions' ? ' active' : '' ?>" href="<?= e(url('members.php?sort=reactions')) ?>"><?= e(t('sort_reactions')) ?></a>
          <a class="xf-filter<?= $sort === 'active' ? ' active' : '' ?>" href="<?= e(url('members.php?sort=active')) ?>"><?= e(t('sort_active')) ?></a>
        </div>
      </div>
    <?php elseif ($sid === 'members_list'): ?>
      <section class="section reveal-group" data-arc-layout-item="1" data-id="members_list" <?= $enabled ? '' : 'hidden' ?>>
        <div class="card glass reveal">
          <?php if (!$rows): ?>
            <div class="xf-topic-meta"><?= e(t('no_data')) ?></div>
          <?php else: ?>
            <div class="xf-stack">
              <?php foreach ($rows as $u): ?>
                <?php $user = $u; include __DIR__ . '/partials/xf/user_card.php'; ?>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
        <?php
          if ($total > $perPage) {
            $base_url = url('members.php');
            $query = ['q' => $q, 'sort' => $sort];
            $total_pages = (int)ceil($total / $perPage);
            $page = $page;
            include __DIR__ . '/partials/xf/pager.php';
          }
        ?>
      </section>
    <?php endif; ?>
  <?php endforeach; ?>
</main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
