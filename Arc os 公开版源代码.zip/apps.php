<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$title = site_name() . ' · ' . t('apps');
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>
  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('apps_title')) ?></h1>
      <p class="reveal"><?= e(t('apps_sub')) ?></p>
    </header>

    <section class="section reveal-group">
      <div class="grid">
        <a class="card reveal" href="https://apps.apple.com/" target="_blank" rel="noopener">
          <h2><?= e(t('app_store')) ?></h2>
          <p><?= e(t('apps_external_link_note')) ?></p>
        </a>
      </div>
    </section>
  </main>
  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>

