<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();

require_not_banned();
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm(current_user(), 'react');
// 只允许 POST，且必须带 CSRF token（否则就是给人绕过/钓鱼的入口）
require_post();
require_csrf();
arc_rate_limit('like', 40, 60);

$me = current_user();
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
$back = $_SERVER['HTTP_REFERER'] ?? (base_path() . '/');

if ($post_id <= 0) { header('Location: ' . $back); exit; }

$pdo = db();
$pfx = table_prefix();

// fetch post + author
$stmt = $pdo->prepare("SELECT p.id, p.title, p.slug, p.type, p.author_id, u.username AS author_username, u.email AS author_email, u.notify_likes, u.avatar AS author_avatar
  FROM {$pfx}posts p
  LEFT JOIN {$pfx}users u ON u.id = p.author_id
  WHERE p.id=? LIMIT 1");
$stmt->execute([$post_id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) { header('Location: ' . $back); exit; }

// toggle
$stmt = $pdo->prepare("SELECT id FROM {$pfx}post_likes WHERE post_id=? AND user_id=? LIMIT 1");
$stmt->execute([$post_id, (int)$me['id']]);

// [ADDON] alert author (best-effort)
try {
  $st2 = $pdo->prepare("SELECT author_id, type FROM {$pfx}posts WHERE id=? LIMIT 1");
  $st2->execute([$post_id]);
  $row = $st2->fetch(PDO::FETCH_ASSOC);
  if ($row && function_exists('arc_create_alert')) {
    $ot = ((string)($row['type'] ?? 'forum') === 'forum') ? 'thread' : 'post';
    arc_create_alert((int)$row['author_id'], (int)$me['id'], 'like', $ot, (int)$post_id, []);
  }
} catch (Throwable $e) {}

$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
  $pdo->prepare("DELETE FROM {$pfx}post_likes WHERE id=?")->execute([(int)$existing['id']]);
} else {
  $pdo->prepare("INSERT IGNORE INTO {$pfx}post_likes (post_id, user_id, created_at) VALUES (?,?,NOW())")->execute([$post_id, (int)$me['id']]);

  // notify author by email (opt-in)
  if ((int)$post['author_id'] > 0 && (int)$post['author_id'] !== (int)$me['id']) {
    require_once __DIR__ . '/includes/notify.php';
    $target = [
      'id' => (int)$post['author_id'],
      'username' => (string)($post['author_username'] ?? ''),
      'email' => (string)($post['author_email'] ?? ''),
      'notify_likes' => (int)($post['notify_likes'] ?? 0),
    ];
    $actor = $me;
    $url = ($post['type'] === 'page')
      ? site_url('page.php?slug=' . urlencode((string)$post['slug']))
      : site_url('forum_post.php?slug=' . urlencode((string)$post['slug']));

    user_notify_like($target, $actor, ['title' => (string)$post['title'], 'url' => $url]);
  }
}

header('Location: ' . $back);
exit;
