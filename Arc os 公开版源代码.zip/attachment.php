<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();
$me = current_user();
$meId = (int)($me['id'] ?? 0);

require_once __DIR__ . '/includes/services/Permission.php';
$perm = new ArcOS\Services\Permission();

$id = (int)($_GET['id'] ?? 0);
$thumb = isset($_GET['thumb']) && (int)($_GET['thumb'] ?? 0) === 1;
if ($id <= 0) {
  http_response_code(404);
  exit('Not found');
}

try {
  $stmt = $pdo->prepare("SELECT a.id, a.data_id, a.content_type, a.content_id, d.file_name, d.file_path, d.thumb_path, d.mime, d.size_bytes
    FROM {$pfx}xf_attachments a
    JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
    WHERE a.id=? LIMIT 1");
  $stmt->execute([$id]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) { http_response_code(404); exit('Not found'); }

  $contentType = (string)($row['content_type'] ?? '');
  $contentId = (int)($row['content_id'] ?? 0);

  $allow = false;
  if (is_admin()) {
    $allow = true;
  } elseif ($contentType === 'thread') {
    $stmt = $pdo->prepare("SELECT status, is_deleted FROM {$pfx}posts WHERE id=? AND type='forum' LIMIT 1");
    $stmt->execute([$contentId]);
    $p = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($p && (string)($p['status'] ?? '') === 'published' && (int)($p['is_deleted'] ?? 0) === 0) {
      $allow = $perm->can($me, 'view_threads');
    }
  } elseif ($contentType === 'post_comment') {
    $stmt = $pdo->prepare("SELECT c.is_deleted AS c_del, p.status AS p_status, p.is_deleted AS p_del
      FROM {$pfx}post_comments c JOIN {$pfx}posts p ON p.id=c.post_id WHERE c.id=? LIMIT 1");
    $stmt->execute([$contentId]);
    $c = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($c && (string)($c['p_status'] ?? '') === 'published' && (int)($c['p_del'] ?? 0) === 0) {
      if ((int)($c['c_del'] ?? 0) === 0) $allow = true;
    }
  } elseif ($contentType === 'profile_post') {
    $stmt = $pdo->prepare("SELECT is_deleted FROM {$pfx}xf_profile_posts WHERE id=? LIMIT 1");
    $stmt->execute([$contentId]);
    $p = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($p && (int)($p['is_deleted'] ?? 0) === 0) $allow = true;
  } elseif ($contentType === 'profile_post_comment') {
    $stmt = $pdo->prepare("SELECT c.is_deleted AS c_del, p.is_deleted AS p_del
      FROM {$pfx}xf_profile_post_comments c JOIN {$pfx}xf_profile_posts p ON p.id=c.profile_post_id WHERE c.id=? LIMIT 1");
    $stmt->execute([$contentId]);
    $c = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($c && (int)($c['c_del'] ?? 0) === 0 && (int)($c['p_del'] ?? 0) === 0) $allow = true;
  } elseif ($contentType === 'conversation') {
    if ($meId > 0) {
      $stmt = $pdo->prepare("SELECT conversation_id FROM {$pfx}conversation_messages WHERE id=? LIMIT 1");
      $stmt->execute([$contentId]);
      $cid = (int)($stmt->fetchColumn() ?: 0);
      if ($cid > 0) {
        $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}conversation_participants WHERE conversation_id=? AND user_id=? AND is_left=0 LIMIT 1");
        $stmt->execute([$cid, $meId]);
        $allow = (bool)$stmt->fetchColumn();
      }
    }
  }

  if (!$allow) {
    http_response_code(403);
    exit('Forbidden');
  }

  $pathRel = $thumb ? (string)($row['thumb_path'] ?? '') : (string)($row['file_path'] ?? '');
  if ($pathRel === '' || str_contains($pathRel, '..')) { http_response_code(404); exit('Not found'); }
  $path = __DIR__ . '/' . ltrim($pathRel, '/');
  if (!is_file($path)) { http_response_code(404); exit('Not found'); }

  $mime = (string)($row['mime'] ?? 'application/octet-stream');
  header('X-Content-Type-Options: nosniff');
  header('Content-Type: ' . $mime);
  header('Content-Length: ' . (string)filesize($path));
  header('Content-Disposition: inline; filename="' . rawurlencode((string)($row['file_name'] ?? ('file-' . $id))) . '"');
  readfile($path);
  exit;
} catch (Throwable $e) {
  http_response_code(500);
  exit('Error');
}
