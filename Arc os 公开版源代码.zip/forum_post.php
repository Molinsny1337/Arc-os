<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();
$__need_glass = true;
$__need_editor = true;
$__need_tooltip = true;

require_once __DIR__ . '/includes/modules/forum/PostRepository.php';
require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';
require_once __DIR__ . '/includes/services/DiscordWebhookService.php';
require_once __DIR__ . '/includes/services/ReadStateService.php';
require_once __DIR__ . '/includes/services/WatchService.php';

$postRepo = new ArcOS\Modules\Forum\PostRepository($pdo, $pfx);
$perm = new ArcOS\Services\Permission();

$slug = trim((string)($_GET['slug'] ?? ''));
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Back-compat: allow ?id=123 then redirect to canonical slug URL.
if ($slug === '' && $id > 0) {
  $st = $pdo->prepare("SELECT slug FROM {$pfx}posts WHERE id=? AND type='forum' AND status='published' LIMIT 1");
  $st->execute([$id]);
  $rowSlug = (string)($st->fetchColumn() ?: '');
  if ($rowSlug !== '') redirect(url('forum_post.php?slug=' . urlencode($rowSlug)));
}

$post = $postRepo->fetchThreadBySlug($slug);
if (!$post) {
  http_response_code(404);
  $title = t('not_found');
  $langCode = function_exists('lang') ? lang() : 'en';
  ?>
  <!doctype html>
  <html lang="<?= e($langCode) ?>">
  <head>
    <?php include __DIR__ . '/partials/head.php'; ?>
  </head>
  <body>
    <?php include __DIR__ . '/partials/nav.php'; ?>
    <main class="wrap xf-apple xf-forum-post">
      <header class="hero xf-hero reveal-group">
        <h1 class="reveal"><?= e(t('not_found')) ?></h1>
      </header>
    </main>
    <?php include __DIR__ . '/partials/footer.php'; ?>
  </body>
  </html>
  <?php
  exit;
}

try { $pdo->prepare("UPDATE {$pfx}posts SET view_count = view_count + 1 WHERE id=?")->execute([(int)$post['id']]); } catch (Throwable $e) {}

$me = current_user();
$meId = (int)($me['id'] ?? 0);
$canModerate = $perm->can($me, 'soft_delete') || (function_exists('is_admin') && is_admin());
$canReply = $perm->can($me, 'reply_thread');

$threadId = (int)($post['id'] ?? 0);
$forumId = (int)($post['forum_id'] ?? 0);
$threadLocked = (int)($post['is_locked'] ?? 0) === 1;

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
  $perm->requirePerm($me, 'reply_thread');
  require_post();
  require_csrf();
  require_not_banned();
  arc_rate_limit('comment', 6, 60);
  arc_rate_limit('comment_hour', 60, 3600);

  if (!$me) {
    $error = t('login_required');
  } elseif ($threadLocked && !is_admin()) {
    $error = t('thread_locked');
  } elseif (turnstile_required('comment') && !turnstile_verify_request()) {
    $error = t('captcha_failed');
  } else {
    $requireV = get_setting('require_email_verification', '1') === '1';
    if ($requireV && (int)($me['is_verified'] ?? 0) !== 1) {
      $error = t('not_verified');
    } else {
      $content = ArcOS\Services\BbCode::normalize((string)($_POST['content'] ?? ''));
      if ($content === '') {
        $error = t('empty');
      } else {
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        $ipHash = defined('APP_KEY') && APP_KEY !== '' ? hash_hmac('sha256', $ip, APP_KEY) : hash('sha256', $ip);
        $stmtPos = $pdo->prepare("SELECT COALESCE(MAX(position), 0) FROM {$pfx}post_comments WHERE post_id=?");
        $stmtPos->execute([$threadId]);
        $nextPos = (int)($stmtPos->fetchColumn() ?: 0) + 1;

        $status = 'visible';
        $stmt = $pdo->prepare("INSERT INTO {$pfx}post_comments (post_id, author_id, content, created_at, updated_at, status, ip_hash, position)
          VALUES (?,?,?,NOW(),NOW(),?,?,?)");
        $stmt->execute([$threadId, $meId, $content, $status, $ipHash, $nextPos]);
        $commentId = (int)$pdo->lastInsertId();

        $draftKey = trim((string)($_POST['draft_key'] ?? ''));
        if ($draftKey !== '') {
          ArcOS\Services\UploadService::attachDraft($pdo, $pfx, $meId, $draftKey, 'post_comment', $commentId);
        }

        ArcOS\Services\MentionService::syncMentions($pdo, $pfx, $meId, 'post_comment', $commentId, $content);
        $tags = ArcOS\Services\MentionService::extractTags($content);
        ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'post_comment', $commentId, $tags);

        try {
          $pdo->prepare("UPDATE {$pfx}posts
            SET reply_count = (SELECT COUNT(*) FROM {$pfx}post_comments WHERE post_id=? AND is_deleted=0 AND status='visible'),
                last_post_at = NOW(),
                last_post_user_id = ?
            WHERE id=?")->execute([$threadId, $meId, $threadId]);
        } catch (Throwable $e) {}

        try {
          if ($forumId > 0) {
            $pdo->prepare("UPDATE {$pfx}forums
              SET message_count = message_count + 1,
                  last_post_at = NOW(),
                  last_post_id = ?,
                  last_post_user_id = ?
              WHERE id = ?")->execute([$threadId, $meId, $forumId]);
          }
        } catch (Throwable $e) {}

        if (function_exists('arc_create_alert')) {
          arc_create_alert((int)$post['author_id'], $meId, 'reply', 'thread', $threadId, []);
        }

        try {
          $plain = ArcOS\Services\BbCode::plainText($content);
          $plain = trim(preg_replace('/\s+/', ' ', $plain) ?? '');
          $summary = mb_substr($plain, 0, 120, 'UTF-8');
          ArcOS\Services\DiscordWebhookService::send('new_post', [
            'title' => (string)($post['title'] ?? 'New reply'),
            'author' => (string)($me['username'] ?? 'user'),
            'summary' => $summary,
            'url' => site_url('forum_post.php?slug=' . urlencode((string)($post['slug'] ?? ''))),
            'thread_id' => $threadId,
            'channel' => (string)($post['forum_title'] ?? ''),
          ]);
        } catch (Throwable $e) {}

        $success = t('saved');
      }
    }
  }
}

// Reply count + pagination
$stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE post_id=? AND is_deleted=0 AND status='visible'");
$stmt->execute([$threadId]);
$replyCount = (int)($stmt->fetchColumn() ?: 0);
$totalPages = max(1, (int)ceil($replyCount / $perPage));
if ($page > $totalPages) $page = $totalPages;

$comments = $postRepo->fetchComments($threadId, $page, $perPage, $canModerate);

// Build unified posts list
$posts = [];
if ($page === 1) {
  $op = $post;
  $op['post_type'] = 'thread';
  $op['position'] = 0;
  $posts[] = $op;
}
foreach ($comments as $c) {
  $c['post_type'] = 'comment';
  $posts[] = $c;
}

// Author stats (message count + reaction score)
$userIds = [];
foreach ($posts as $p) {
  $uid = (int)($p['author_id'] ?? 0);
  if ($uid > 0) $userIds[$uid] = true;
}
$userIds = array_keys($userIds);
$authorStats = [];
if ($userIds) {
  $in = implode(',', array_fill(0, count($userIds), '?'));
  try {
    $stmt = $pdo->prepare("SELECT author_id, COUNT(*) c FROM {$pfx}posts WHERE type='forum' AND status='published' AND author_id IN ({$in}) GROUP BY author_id");
    $stmt->execute($userIds);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
      $authorStats[(int)$r['author_id']]['threads'] = (int)$r['c'];
    }
  } catch (Throwable $e) {}
  try {
    $stmt = $pdo->prepare("SELECT author_id, COUNT(*) c FROM {$pfx}post_comments WHERE is_deleted=0 AND status='visible' AND author_id IN ({$in}) GROUP BY author_id");
    $stmt->execute($userIds);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
      $authorStats[(int)$r['author_id']]['replies'] = (int)$r['c'];
    }
  } catch (Throwable $e) {}
  try {
    $stmt = $pdo->prepare("SELECT p.author_id, COUNT(*) c FROM {$pfx}post_reactions r JOIN {$pfx}posts p ON p.id=r.post_id WHERE p.author_id IN ({$in}) GROUP BY p.author_id");
    $stmt->execute($userIds);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
      $authorStats[(int)$r['author_id']]['reactions'] = (int)$r['c'];
    }
  } catch (Throwable $e) {}
}

foreach ($posts as $k => $p) {
  $uid = (int)($p['author_id'] ?? 0);
  $stats = $authorStats[$uid] ?? [];
  $posts[$k]['author_message_count'] = (int)($stats['threads'] ?? 0) + (int)($stats['replies'] ?? 0);
  $posts[$k]['author_reaction_score'] = (int)($stats['reactions'] ?? 0);
}

// Thread tags
$threadTags = [];
try {
  $stmt = $pdo->prepare("SELECT t.tag FROM {$pfx}xf_content_tags ct JOIN {$pfx}xf_tags t ON t.id=ct.tag_id WHERE ct.content_type='thread' AND ct.content_id=? ORDER BY t.tag ASC");
  $stmt->execute([$threadId]);
  $threadTags = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
} catch (Throwable $e) {}

// Read state
if ($meId > 0) {
  ArcOS\Services\ReadStateService::markThread($pdo, $pfx, $meId, $threadId, (string)($post['last_post_at'] ?? ''));
  if ($forumId > 0) {
    ArcOS\Services\ReadStateService::markForum($pdo, $pfx, $meId, $forumId, (string)($post['last_post_at'] ?? ''));
  }
}

$liked = false;
$likeCount = 0;
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_likes WHERE post_id=?");
  $stmt->execute([$threadId]);
  $likeCount = (int)($stmt->fetchColumn() ?: 0);
  if ($meId > 0) {
    $stmt = $pdo->prepare("SELECT id FROM {$pfx}post_likes WHERE post_id=? AND user_id=? LIMIT 1");
    $stmt->execute([$threadId, $meId]);
    $liked = (bool)$stmt->fetchColumn();
  }
} catch (Throwable $e) {}

$isWatching = false;
if ($meId > 0) {
  $isWatching = ArcOS\Services\WatchService::isWatchingThread($pdo, $pfx, $meId, $threadId);
}

$staff = staff_online(5);

if ($post) {
  arc_log('view_forum_post', 'post', (int)$post['id']);
}

$title = (string)($post['title'] ?? '') . ' - ' . site_name();
$langCode = function_exists('lang') ? lang() : 'en';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap xf-apple xf-forum-post">
    <?php $crumbs = [
      ['label' => t('forum'), 'url' => url('forum.php')],
      ['label' => (string)($post['forum_title'] ?? ''), 'url' => $forumId > 0 ? url('forum_view.php?fid=' . $forumId) : url('forum.php')],
      ['label' => (string)($post['title'] ?? '')],
    ]; ?>
    <?php include __DIR__ . '/partials/xf/breadcrumb.php'; ?>

    <header class="hero xf-hero reveal-group">
      <div>
        <h1 class="reveal"><?= e((string)($post['title'] ?? '')) ?></h1>
        <div class="xf-meta reveal">
          <span><?= e((string)($post['created_at'] ?? '')) ?></span>
          <span>
            <a data-transition="1" href="<?= e(base_path()) ?>/user.php?id=<?= (int)($post['author_user_id'] ?? 0) ?>" style="font-weight:700">
              <?= e((string)($post['author_username'] ?? t('user'))) ?>
            </a>
          </span>
          <?php if (!empty($post['prefix_title'])): ?>
            <span class="xf-prefix <?= e((string)($post['prefix_css'] ?? '')) ?>"><?= e((string)$post['prefix_title']) ?></span>
          <?php endif; ?>
          <?php foreach ($threadTags as $tag): ?>
            <span class="xf-tag">#<?= e((string)$tag) ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="card glass xf-hero-card reveal">
        <div class="xf-stack">
          <a class="btn primary" href="#reply"><?= e(t('reply')) ?></a>
          <a class="btn" href="<?= e(url('forum_view.php?fid=' . $forumId)) ?>"><?= e(t('back_forum')) ?></a>
          <?php if ($meId > 0): ?>
            <form method="post" action="<?= e(url('watch_thread.php')) ?>" style="margin:0">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$threadId ?>">
              <button class="btn" type="submit"><?= $isWatching ? e(t('unwatch')) : e(t('watch')) ?></button>
            </form>
          <?php endif; ?>
        </div>

        <form method="post" action="<?= e(base_path()) ?>/like.php" style="margin:10px 0 0 0">
          <?= csrf_field() ?>
          <input type="hidden" name="post_id" value="<?= (int)$threadId ?>" />
          <button class="btn" type="submit" style="width:100%;display:flex;gap:8px;align-items:center;justify-content:center">
            <span><?= e($liked ? t('liked') : t('like')) ?></span>
            <span class="xf-pill" style="padding:2px 8px"><?= (int)$likeCount ?></span>
          </button>
        </form>

        <?php if ($canModerate): ?>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
            <form method="post" action="<?= e(function_exists('admin_url') ? admin_url('thread_tools') : (base_path() . '/admin/thread_tools.php')) ?>" style="margin:0">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$threadId ?>">
              <input type="hidden" name="action" value="toggle_sticky">
              <button class="btn" type="submit"><?= ((int)($post['is_sticky'] ?? 0)===1) ? e(t('unpin')) : e(t('pin')) ?></button>
            </form>
            <form method="post" action="<?= e(function_exists('admin_url') ? admin_url('thread_tools') : (base_path() . '/admin/thread_tools.php')) ?>" style="margin:0">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$threadId ?>">
              <input type="hidden" name="action" value="toggle_lock">
              <button class="btn" type="submit"><?= $threadLocked ? e(t('unlock')) : e(t('lock')) ?></button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </header>

    <?php if ($post && $staff): ?>
      <div class="xf-staff-online reveal" style="margin:-6px 0 18px">
        <span class="xf-staff-label"><?= e(t('staff_online')) ?></span>
        <?php foreach ($staff as $s): ?>
          <a data-transition="1" href="<?= e(url('user.php?id=' . (int)$s['id'])) ?>" class="xf-staff-pill">
            <span class="xf-dot"></span>
            <span><?= e($s['username']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="xf-toolbar reveal">
      <div class="xf-filters">
        <span class="xf-filter active"><?= e(t('posts')) ?>: <?= (int)$replyCount + 1 ?></span>
        <span class="xf-filter"><?= e(t('views')) ?>: <?= (int)($post['view_count'] ?? 0) ?></span>
      </div>
      <div class="xf-actions">
        <?php if ($threadLocked): ?>
          <span class="xf-pill"><?= e(t('locked')) ?></span>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($totalPages > 1): ?>
      <?php
        $base_url = url('forum_post.php');
        $query = ['slug' => (string)($post['slug'] ?? '')];
        $total_pages = $totalPages;
        include __DIR__ . '/partials/xf/pager.php';
      ?>
    <?php endif; ?>

    <section class="section reveal-group">
      <?php
        $posts = $posts;
        $meId = $meId;
        $canModerate = $canModerate;
        $threadId = $threadId;
        include __DIR__ . '/partials/xf/post_stream.php';
      ?>
    </section>

    <?php if ($totalPages > 1): ?>
      <?php
        $base_url = url('forum_post.php');
        $query = ['slug' => (string)($post['slug'] ?? '')];
        $total_pages = $totalPages;
        include __DIR__ . '/partials/xf/pager.php';
      ?>
    <?php endif; ?>

    <section class="section reveal" id="reply" style="margin-top:10px">
      <div class="card glass">
        <div class="xf-section-head">
          <h2 class="section-title" style="margin:0"><?= e(t('reply')) ?></h2>
        </div>

        <?php if ($success): ?><div class="notice success"><?= e($success) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="notice danger"><?= e($error) ?></div><?php endif; ?>

        <?php if ($me && !$threadLocked): ?>
          <form method="post" class="xf-activity-form">
            <input type="hidden" name="add_comment" value="1" />
            <?= csrf_field() ?>
            <?php
              $draftKey = 'thread_reply_' . (int)($post['id'] ?? 0) . '_' . (int)($me['id'] ?? 0);
              $content_name = 'content';
              $initial_value = '';
              $mode = 'post';
              $attachments_enabled = true;
              $placeholder = t('comment');
              $content_id = (int)($post['id'] ?? 0);
              $draft_key = $draftKey;
              include __DIR__ . '/partials/editor/editor_widget.php';
            ?>
            <?php if (turnstile_required('comment')): ?>
              <div style="margin-top:10px;display:flex;justify-content:flex-end">
                <?= turnstile_widget('comment', 'light') ?>
              </div>
            <?php endif; ?>
            <div style="display:flex;justify-content:flex-end;margin-top:10px">
              <button class="btn primary" type="submit"><?= e(t('comment')) ?></button>
            </div>
          </form>
        <?php elseif ($threadLocked): ?>
          <div style="color:var(--muted)"><?= e(t('thread_locked')) ?></div>
        <?php else: ?>
          <div style="color:var(--muted)"><?= e(t('login_to_comment')) ?></div>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
