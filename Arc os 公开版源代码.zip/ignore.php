<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

require_once __DIR__ . '/includes/services/IgnoreService.php';

$me = current_user();
$targetId = (int)($_POST['user_id'] ?? 0);
$action = (string)($_POST['action'] ?? 'toggle');
$back = $_SERVER['HTTP_REFERER'] ?? url('index.php');

if ($targetId <= 0 || $targetId === (int)$me['id']) {
  redirect($back);
}

$pdo = db();
$pfx = table_prefix();

if ($action === 'ignore') {
  ArcOS\Services\IgnoreService::ignore($pdo, $pfx, (int)$me['id'], $targetId);
} elseif ($action === 'unignore') {
  ArcOS\Services\IgnoreService::unignore($pdo, $pfx, (int)$me['id'], $targetId);
} else {
  if (ArcOS\Services\IgnoreService::isIgnored($pdo, $pfx, (int)$me['id'], $targetId)) {
    ArcOS\Services\IgnoreService::unignore($pdo, $pfx, (int)$me['id'], $targetId);
  } else {
    ArcOS\Services\IgnoreService::ignore($pdo, $pfx, (int)$me['id'], $targetId);
  }
}

redirect($back);
