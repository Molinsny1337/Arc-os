<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
$me = current_user();
if (!$me) redirect(url('login.php'));
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'post_profile');
require_not_banned();

require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';
require_once __DIR__ . '/includes/services/ProfileService.php';

$pdo = db();
$pfx = table_prefix();

$profileId = (int)($_POST['profile_user_id'] ?? ($_GET['profile_user_id'] ?? ($_GET['id'] ?? 0)));

if (function_exists('get_setting') && get_setting('profile_posts_enabled', '1') !== '1') {
  http_response_code(403);
  exit('Profile posts disabled');
}

if ($profileId > 0 && !ArcOS\Services\ProfileService::canPostOnProfile($pdo, $pfx, (int)$me['id'], $profileId)) {
  redirect(url('user.php?id=' . $profileId));
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  $title = site_name() . ' - ' . t('activity');
  $__need_glass = true;
  $__need_editor = true;
  include __DIR__ . '/partials/page_top.php';
  ?>
  <main class="wrap">
    <header class="hero xf-hero reveal-group">
      <div>
        <h1 class="reveal"><?= e(t('activity')) ?></h1>
        <p class="reveal"><?= e(t('comment')) ?></p>
      </div>
    </header>

    <section class="section reveal-group">
      <form class="form glass reveal" method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="profile_user_id" value="<?= (int)$profileId ?>">
        <?php
          $draftKey = 'profile_post_' . (int)$profileId . '_' . (int)($me['id'] ?? 0);
          $content_name = 'message';
          $initial_value = '';
          $mode = 'profile_post';
          $attachments_enabled = true;
          $placeholder = t('comment');
          $content_id = $profileId;
          $draft_key = $draftKey;
          include __DIR__ . '/partials/editor/editor_widget.php';
        ?>
        <button class="btn" type="submit"><?= e(t('submit')) ?></button>
      </form>
    </section>
  </main>
  <?php include __DIR__ . '/partials/page_bottom.php'; ?>
  <?php
  exit;
}

require_post();
require_csrf();
arc_rate_limit('profile_post_new', 60, 60);

$msg = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
if ($profileId <= 0 || $msg === '') redirect($_SERVER['HTTP_REFERER'] ?? url('index.php'));

try {
  $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_posts (user_id, author_user_id, message_bbcode, is_deleted, created_at, updated_at)
    VALUES (?,?,?,?,NOW(),NOW())");
  $stmt->execute([$profileId, (int)$me['id'], $msg, 0]);
  $ppid = (int)$pdo->lastInsertId();

  $draftKey = trim((string)($_POST['draft_key'] ?? ''));
  if ($draftKey !== '') {
    ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'profile_post', $ppid);
  }
  ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'profile_post', $ppid, $msg);
  $tags = ArcOS\Services\MentionService::extractTags($msg);
  ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'profile_post', $ppid, $tags);

  // alert the profile owner if not self
  if ($profileId !== (int)$me['id']) {
    if (function_exists('arc_create_alert')) {
      arc_create_alert($profileId, (int)$me['id'], 'profile_post', 'profile_post', $ppid, []);
    } else {
      arc_add_alert($profileId, 'profile_post', $ppid, (string)$me['username'], null);
    }
  }
} catch (Throwable $e) {}

redirect($_SERVER['HTTP_REFERER'] ?? url('user.php?id=' . $profileId));
