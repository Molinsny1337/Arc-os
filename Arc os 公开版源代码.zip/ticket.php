<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();

$me = current_user();
$ticketId = (int)($_GET['id'] ?? 0);
if ($ticketId <= 0) {
  http_response_code(404);
  exit(e(t('ticket_not_found')));
}

$ticket = arc_ticket_get($ticketId);
if (!$ticket) {
  http_response_code(404);
  exit(e(t('ticket_not_found')));
}

if (!arc_ticket_user_can_view($ticket, $me)) {
  http_response_code(403);
  exit('Forbidden');
}

$title = t('ticket') . ' #' . $ticketId;
$__need_editor = true;
$__need_glass = true;
require_once __DIR__ . '/includes/services/BbCode.php';

$err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  require_csrf();
  arc_rate_limit('ticket_' . $ticketId . '_' . (int)$me['id'], 80, 300);
  try {
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'reply') {
      $message = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
      if (($ticket['status'] ?? 'open') === 'closed') {
        arc_ticket_set_status($ticketId, 'open', null);
        arc_log('ticket_reopen', 'ticket', $ticketId, ['by' => 'user']);
      }
      arc_ticket_add_message($ticketId, (int)$me['id'], false, $message);
      arc_log('ticket_reply', 'ticket', $ticketId, ['by' => 'user']);
      redirect(url('ticket.php?id=' . $ticketId));
    }

    if ($action === 'close') {
      arc_ticket_set_status($ticketId, 'closed', null);
      arc_log('ticket_close', 'ticket', $ticketId, ['by' => 'user']);
      redirect(url('ticket.php?id=' . $ticketId));
    }

    throw new RuntimeException('Bad action.');
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

// reload after mutations
$ticket = arc_ticket_get($ticketId) ?: $ticket;
$messages = arc_ticket_messages($ticketId);
$status = (string)($ticket['status'] ?? 'open');
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap" style="padding-top:28px;padding-bottom:80px;">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
      <div>
        <h1 style="margin:0;"><?= e(t('ticket')) ?> #<?= (int)$ticketId ?></h1>
        <div style="margin-top:6px;color:var(--muted);"><?= e((string)($ticket['subject'] ?? '')) ?></div>
      </div>
      <div style="display:flex;gap:10px;align-items:center;">
        <span class="<?= e($status === 'closed' ? 'badge closed' : 'badge open') ?>">
          <?= e($status === 'closed' ? t('status_closed') : t('status_open')) ?>
        </span>
        <a class="btn" href="<?= e(url('tickets.php')) ?>"><?= e(t('back')) ?></a>
      </div>
    </div>

    <?php if ($err): ?>
      <div class="alert reveal" style="margin-top:12px;"><?= e($err) ?></div>
    <?php endif; ?>

    <section style="margin-top:12px;display:grid;gap:10px;">
      <?php foreach ($messages as $m): ?>
        <?php
          $isStaff = (int)($m['is_staff'] ?? 0) === 1;
          $author = (string)($m['author_username'] ?? '');
          if ($isStaff && $author === '') $author = t('staff');
          if (!$isStaff && $author === '') $author = t('user');
        ?>
        <div class="card" style="padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:16px;background:rgba(255,255,255,.7);">
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
            <div style="font-weight:750;"><?= e($author) ?><?= $isStaff ? ' · ' . e(t('admin')) : '' ?></div>
            <div style="color:var(--muted);font-size:13px;"><?= e((string)($m['created_at'] ?? '')) ?></div>
          </div>
          <div class="rte-content" style="margin-top:10px;"><?= ArcOS\Services\BbCode::render((string)($m['message'] ?? ''), db(), table_prefix()) ?></div>
        </div>
      <?php endforeach; ?>
    </section>

    <section style="margin-top:12px;">
      <?php if ($status === 'open'): ?>
        <div class="card" style="padding:16px;">
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;">
            <div style="font-weight:800;"><?= e(t('reply')) ?></div>
            <form method="post" data-overlay="1" style="margin:0;">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="close" />
              <button class="btn" type="submit"><?= e(t('close_ticket')) ?></button>
            </form>
          </div>
          <form method="post" data-overlay="1" style="margin-top:12px;display:grid;gap:10px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reply" />
            <?php
              $content_name = 'message';
              $initial_value = '';
              $mode = 'ticket_reply';
              $attachments_enabled = true;
              $placeholder = t('ticket_reply_placeholder');
              $draft_key = 'ticket_reply_' . (int)$ticketId . '_' . (int)$me['id'];
              $content_type = 'ticket';
              $content_id = (int)$ticketId;
              include __DIR__ . '/partials/editor/editor_widget.php';
            ?>
            <div style="display:flex;justify-content:flex-end;gap:10px;">
              <button class="btn primary" type="submit"><?= e(t('send')) ?></button>
            </div>
          </form>
        </div>
      <?php else: ?>
        <div class="card" style="padding:16px;">
          <div style="font-weight:800;"><?= e(t('ticket_closed')) ?></div>
          <div style="margin-top:6px;color:var(--muted);font-size:13px;"><?= e(t('ticket_closed_tip')) ?></div>
          <form method="post" data-overlay="1" style="margin-top:12px;display:grid;gap:10px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reply" />
            <?php
              $content_name = 'message';
              $initial_value = '';
              $mode = 'ticket_reply';
              $attachments_enabled = true;
              $placeholder = t('ticket_reopen_placeholder');
              $draft_key = 'ticket_reopen_' . (int)$ticketId . '_' . (int)$me['id'];
              $content_type = 'ticket';
              $content_id = (int)$ticketId;
              include __DIR__ . '/partials/editor/editor_widget.php';
            ?>
            <div style="display:flex;justify-content:flex-end;gap:10px;">
              <button class="btn primary" type="submit"><?= e(t('reopen_and_send')) ?></button>
            </div>
          </form>
        </div>
      <?php endif; ?>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
