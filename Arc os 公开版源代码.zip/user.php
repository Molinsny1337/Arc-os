<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/ProfileService.php';
require_once __DIR__ . '/includes/services/IgnoreService.php';
require_once __DIR__ . '/includes/services/TrophyService.php';
require_once __DIR__ . '/includes/trophies.php';

$pdo = db();
$pfx = table_prefix();
$me = current_user();
(new ArcOS\Services\Permission())->requirePerm($me, 'view_profiles');

$userId = (int)($_GET['id'] ?? 0);
if ($userId <= 0) {
  http_response_code(404);
  $title = t('not_found');
  include __DIR__ . '/partials/page_top.php';
  echo '<main class="wrap"><header class="hero xf-hero reveal-group"><h1 class="reveal">' . e(t('not_found')) . '</h1></header></main>';
  include __DIR__ . '/partials/page_bottom.php';
  exit;
}

$stmt = $pdo->prepare("SELECT u.id, u.username, u.display_name, u.avatar, u.role, u.user_title, u.created_at, u.last_active,
    u.is_banned, u.banned_until, u.allow_profile_posts,
    u.location AS legacy_location, u.website AS legacy_website, u.about_text AS legacy_about,
    u.signature AS legacy_signature, u.cover_url AS legacy_cover,
    up.location AS profile_location, up.website AS profile_website, up.about_me_bbcode, up.signature_bbcode,
    up.cover_path, up.privacy_json,
    du.discord_user_id, du.discord_username, du.discord_discriminator, du.discord_avatar
  FROM {$pfx}users u
  LEFT JOIN {$pfx}xf_user_profile up ON up.user_id = u.id
  LEFT JOIN {$pfx}xf_user_discord du ON du.user_id = u.id
  WHERE u.id=? LIMIT 1");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
  http_response_code(404);
  $title = t('not_found');
  include __DIR__ . '/partials/page_top.php';
  echo '<main class="wrap"><header class="hero xf-hero reveal-group"><h1 class="reveal">' . e(t('not_found')) . '</h1></header></main>';
  include __DIR__ . '/partials/page_bottom.php';
  exit;
}

try {
  ArcOS\Services\TrophyService::syncUser($pdo, $pfx, (int)$user['id']);
} catch (Throwable $e) {}

$displayName = display_name_of($user);
$role = (string)($user['role'] ?? 'user');
$userTitle = trim((string)($user['user_title'] ?? ''));
if ($userTitle === '') {
  $userTitle = ($role === 'admin' || $role === 'superadmin') ? 'Administrator' : 'Member';
}

$profile = [
  'privacy_json' => (string)($user['privacy_json'] ?? ''),
];
$privacy = ArcOS\Services\ProfileService::privacy($profile);

$profilePostsEnabled = get_setting('profile_posts_enabled', '1') === '1';
$profileVisitorsEnabled = get_setting('profile_visitors_enabled', '1') === '1';
$profileMediaEnabled = get_setting('profile_media_enabled', '1') === '1';
$profileSignaturesEnabled = get_setting('profile_signatures_enabled', '1') === '1';
$profileFieldsEnabled = get_setting('profile_fields_enabled', '1') === '1';

$location = (string)($user['profile_location'] ?? '');
if ($location === '') $location = (string)($user['legacy_location'] ?? '');
$website = (string)($user['profile_website'] ?? '');
if ($website === '') $website = (string)($user['legacy_website'] ?? '');
$aboutBbcode = (string)($user['about_me_bbcode'] ?? '');
if ($aboutBbcode === '') $aboutBbcode = (string)($user['legacy_about'] ?? '');
$signatureBbcode = (string)($user['signature_bbcode'] ?? '');
if ($signatureBbcode === '') $signatureBbcode = (string)($user['legacy_signature'] ?? '');

$coverPath = (string)($user['cover_path'] ?? '');
if ($coverPath === '') $coverPath = (string)($user['legacy_cover'] ?? '');
$coverUrl = '';
if ($coverPath !== '') {
  if (preg_match('~^https?://~i', $coverPath)) {
    $coverUrl = $coverPath;
  } elseif (str_starts_with($coverPath, '/')) {
    $coverUrl = $coverPath;
  } else {
    $coverUrl = url($coverPath);
  }
}

$discordLabel = '';
$discordAvatarUrl = '';
if (!empty($user['discord_username'])) {
  $discordLabel = (string)$user['discord_username'];
  $disc = (string)($user['discord_discriminator'] ?? '');
  if ($disc !== '' && $disc !== '0') $discordLabel .= '#' . $disc;
  $did = (string)($user['discord_user_id'] ?? '');
  $dav = (string)($user['discord_avatar'] ?? '');
  if ($did !== '' && $dav !== '') {
    $discordAvatarUrl = 'https://cdn.discordapp.com/avatars/' . rawurlencode($did) . '/' . rawurlencode($dav) . '.png?size=64';
  }
}
$discordVisible = $discordLabel !== '' && !empty($privacy['show_discord']);

$meId = (int)($me['id'] ?? 0);
$isSelf = $meId > 0 && $meId === (int)$user['id'];
$isFollowing = false;
$isIgnored = false;
$ignoredIds = [];

if ($meId > 0 && !$isSelf) {
  $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=? LIMIT 1");
  $stmt->execute([$meId, (int)$user['id']]);
  $isFollowing = (bool)$stmt->fetchColumn();
  $isIgnored = ArcOS\Services\IgnoreService::isIgnored($pdo, $pfx, $meId, (int)$user['id']);
}

if ($meId > 0) {
  $stmt = $pdo->prepare("SELECT ignored_user_id FROM {$pfx}xf_user_ignore WHERE user_id=?");
  $stmt->execute([$meId]);
  $rows = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
  foreach ($rows as $rid) {
    $ignoredIds[(int)$rid] = true;
  }
}

$showFollowers = !empty($privacy['show_followers']);
$canPostOnProfile = $meId > 0 && $profilePostsEnabled
  ? ArcOS\Services\ProfileService::canPostOnProfile($pdo, $pfx, $meId, (int)$user['id'])
  : false;

// Stats
$threadCount = 0;
$replyCount = 0;
$profilePostCount = 0;
$profileCommentCount = 0;
$reactionScore = 0;
$trophyPoints = 0;
$followersCount = 0;
$followingCount = 0;
$mediaCount = 0;

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE author_id=? AND type='forum' AND status='published'");
  $stmt->execute([(int)$user['id']]);
  $threadCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE author_id=? AND is_deleted=0");
  $stmt->execute([(int)$user['id']]);
  $replyCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_profile_posts WHERE author_user_id=? AND is_deleted=0");
  $stmt->execute([(int)$user['id']]);
  $profilePostCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_profile_post_comments WHERE user_id=? AND is_deleted=0");
  $stmt->execute([(int)$user['id']]);
  $profileCommentCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_reactions pr JOIN {$pfx}posts p ON p.id=pr.post_id WHERE p.author_id=?");
  $stmt->execute([(int)$user['id']]);
  $reactionScore = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $trophyPoints = trophy_total_points($pdo, $pfx, (int)$user['id']);
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_user_follow WHERE followed_id=?");
  $stmt->execute([(int)$user['id']]);
  $followersCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_user_follow WHERE follower_id=?");
  $stmt->execute([(int)$user['id']]);
  $followingCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_attachments WHERE user_id=?");
  $stmt->execute([(int)$user['id']]);
  $mediaCount = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

$messagesCount = $threadCount + $replyCount + $profilePostCount + $profileCommentCount;

// Groups/badges
$groups = [];
try {
  $stmt = $pdo->prepare("SELECT g.id, g.name, g.slug FROM {$pfx}user_groups ug JOIN {$pfx}groups g ON g.id=ug.group_id WHERE ug.user_id=? ORDER BY g.is_paid DESC, g.name ASC");
  $stmt->execute([(int)$user['id']]);
  $groups = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $groups = [];
}

// Tabs
$tabs = [];
$tab = (string)($_GET['tab'] ?? '');
$allowedTabs = [];
if ($profilePostsEnabled) $allowedTabs[] = 'profile_posts';
$allowedTabs[] = 'threads';
$allowedTabs[] = 'posts';
$allowedTabs[] = 'about';
$allowedTabs[] = 'trophies';
if ($profileMediaEnabled) $allowedTabs[] = 'media';
if ($showFollowers) {
  $allowedTabs[] = 'followers';
  $allowedTabs[] = 'following';
}
if ($tab === '' || !in_array($tab, $allowedTabs, true)) {
  $tab = $allowedTabs[0] ?? 'about';
}

$tabLabel = function(string $key, string $fallback): string {
  $v = t($key);
  return $v === $key ? $fallback : $v;
};

if ($profilePostsEnabled) {
  $tabs[] = ['id' => 'profile_posts', 'label' => $tabLabel('profile_posts', 'Profile posts'), 'href' => url('user.php?id=' . $userId . '&tab=profile_posts')];
}
$tabs[] = ['id' => 'threads', 'label' => $tabLabel('threads', 'Threads'), 'href' => url('user.php?id=' . $userId . '&tab=threads')];
$tabs[] = ['id' => 'posts', 'label' => $tabLabel('posts', 'Posts'), 'href' => url('user.php?id=' . $userId . '&tab=posts')];
$tabs[] = ['id' => 'about', 'label' => $tabLabel('about', 'About'), 'href' => url('user.php?id=' . $userId . '&tab=about')];
$tabs[] = ['id' => 'trophies', 'label' => $tabLabel('trophies', 'Trophies'), 'href' => url('user.php?id=' . $userId . '&tab=trophies')];
if ($profileMediaEnabled) {
  $tabs[] = ['id' => 'media', 'label' => $tabLabel('media', 'Media'), 'href' => url('user.php?id=' . $userId . '&tab=media')];
}
if ($showFollowers) {
  $tabs[] = ['id' => 'followers', 'label' => $tabLabel('followers', 'Followers'), 'href' => url('user.php?id=' . $userId . '&tab=followers')];
  $tabs[] = ['id' => 'following', 'label' => $tabLabel('following', 'Following'), 'href' => url('user.php?id=' . $userId . '&tab=following')];
}

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Profile posts
$profilePosts = [];
$profileComments = [];
$profilePostsTotal = 0;
if ($tab === 'profile_posts' && $profilePostsEnabled) {
  try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_profile_posts WHERE user_id=? AND is_deleted=0");
    $stmt->execute([(int)$user['id']]);
    $profilePostsTotal = (int)$stmt->fetchColumn();
  } catch (Throwable $e) {}

  try {
    $stmt = $pdo->prepare("SELECT p.id, p.user_id, p.author_user_id, p.message_bbcode, p.created_at,
        u.username, u.display_name, u.avatar,
        du.discord_username, du.discord_discriminator
      FROM {$pfx}xf_profile_posts p
      JOIN {$pfx}users u ON u.id=p.author_user_id
      LEFT JOIN {$pfx}xf_user_discord du ON du.user_id=u.id
      WHERE p.user_id=? AND p.is_deleted=0
      ORDER BY p.created_at DESC
      LIMIT ? OFFSET ?");
    $stmt->bindValue(1, (int)$user['id'], PDO::PARAM_INT);
    $stmt->bindValue(2, $perPage, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $profilePosts = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {
    $profilePosts = [];
  }

  $ids = array_map(fn($r) => (int)($r['id'] ?? 0), $profilePosts);
  $ids = array_values(array_filter($ids, fn($v) => $v > 0));
  if ($ids) {
    $in = implode(',', array_fill(0, count($ids), '?'));
    try {
      $stmt = $pdo->prepare("SELECT c.id, c.profile_post_id, c.user_id, c.message_bbcode, c.created_at,
          u.username, u.display_name, u.avatar,
          du.discord_username, du.discord_discriminator
        FROM {$pfx}xf_profile_post_comments c
        JOIN {$pfx}users u ON u.id=c.user_id
        LEFT JOIN {$pfx}xf_user_discord du ON du.user_id=u.id
        WHERE c.profile_post_id IN ({$in}) AND c.is_deleted=0
        ORDER BY c.created_at ASC");
      $stmt->execute($ids);
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      foreach ($rows as $row) {
        $pid = (int)($row['profile_post_id'] ?? 0);
        if (!isset($profileComments[$pid])) $profileComments[$pid] = [];
        $profileComments[$pid][] = $row;
      }
    } catch (Throwable $e) {}
  }
}

// Threads tab
$threadRows = [];
$threadTotal = 0;
if ($tab === 'threads') {
  try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE author_id=? AND type='forum' AND status='published'");
    $stmt->execute([(int)$user['id']]);
    $threadTotal = (int)$stmt->fetchColumn();
  } catch (Throwable $e) {}

  try {
    $stmt = $pdo->prepare("SELECT p.id, p.title, p.slug, p.created_at, p.reply_count, p.view_count, p.last_post_at,
        u.username AS author_username, u.avatar AS author_avatar,
        lu.username AS last_post_username
      FROM {$pfx}posts p
      JOIN {$pfx}users u ON u.id=p.author_id
      LEFT JOIN {$pfx}users lu ON lu.id=p.last_post_user_id
      WHERE p.author_id=? AND p.type='forum' AND p.status='published'
      ORDER BY p.created_at DESC
      LIMIT ? OFFSET ?");
    $stmt->bindValue(1, (int)$user['id'], PDO::PARAM_INT);
    $stmt->bindValue(2, $perPage, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $threadRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {
    $threadRows = [];
  }
}

// Posts tab (replies)
$replyRows = [];
$replyTotal = 0;
if ($tab === 'posts') {
  try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments c JOIN {$pfx}posts p ON p.id=c.post_id WHERE c.author_id=? AND c.is_deleted=0 AND p.type='forum' AND p.status='published'");
    $stmt->execute([(int)$user['id']]);
    $replyTotal = (int)$stmt->fetchColumn();
  } catch (Throwable $e) {}

  try {
    $stmt = $pdo->prepare("SELECT c.id, c.post_id, c.content, c.created_at,
        p.title, p.slug
      FROM {$pfx}post_comments c
      JOIN {$pfx}posts p ON p.id=c.post_id
      WHERE c.author_id=? AND c.is_deleted=0 AND p.type='forum' AND p.status='published'
      ORDER BY c.created_at DESC
      LIMIT ? OFFSET ?");
    $stmt->bindValue(1, (int)$user['id'], PDO::PARAM_INT);
    $stmt->bindValue(2, $perPage, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $replyRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {
    $replyRows = [];
  }
}

// About tab data (custom fields)
$customFields = [];
$customFieldValues = [];
if ($tab === 'about' && $profileFieldsEnabled) {
  try {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_profile_fields WHERE show_on_profile=1 ORDER BY display_order ASC, field_id ASC");
    $stmt->execute();
    $customFields = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if ($customFields) {
      $ids = array_map(fn($r) => (int)($r['field_id'] ?? 0), $customFields);
      $ids = array_values(array_filter($ids, fn($v) => $v > 0));
      if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT field_id, value FROM {$pfx}xf_user_field_values WHERE user_id=? AND field_id IN ({$in})");
        $params = array_merge([(int)$user['id']], $ids);
        $stmt->execute($params);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $customFieldValues[(int)$row['field_id']] = (string)($row['value'] ?? '');
        }
      }
    }
  } catch (Throwable $e) {
    $customFields = [];
    $customFieldValues = [];
  }
}

// Trophies tab data
$trophies = [];
if ($tab === 'trophies') {
  $trophies = trophy_list_for_user($pdo, $pfx, (int)$user['id'], 50);
}

  // Media tab data
  $mediaRows = [];
  $mediaTotal = 0;
  if ($tab === 'media' && $profileMediaEnabled) {
    $filter = (string)($_GET['media'] ?? 'all');
    if (!in_array($filter, ['all','images','files'], true)) $filter = 'all';
    $mimeParam = null;
    $countSql = "SELECT COUNT(*) FROM {$pfx}xf_attachments a JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id WHERE a.user_id=?";
    $listSql = "SELECT a.id, a.content_type, a.content_id, d.file_name, d.file_path, d.mime, d.size_bytes, d.width, d.height, d.created_at
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.user_id=?
        ORDER BY d.created_at DESC
        LIMIT ? OFFSET ?";

    if ($filter === 'images') {
      $mimeParam = 'image/%';
      $countSql = "SELECT COUNT(*) FROM {$pfx}xf_attachments a JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id WHERE a.user_id=? AND d.mime LIKE ?";
      $listSql = "SELECT a.id, a.content_type, a.content_id, d.file_name, d.file_path, d.mime, d.size_bytes, d.width, d.height, d.created_at
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.user_id=? AND d.mime LIKE ?
        ORDER BY d.created_at DESC
        LIMIT ? OFFSET ?";
    } elseif ($filter === 'files') {
      $mimeParam = 'image/%';
      $countSql = "SELECT COUNT(*) FROM {$pfx}xf_attachments a JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id WHERE a.user_id=? AND d.mime NOT LIKE ?";
      $listSql = "SELECT a.id, a.content_type, a.content_id, d.file_name, d.file_path, d.mime, d.size_bytes, d.width, d.height, d.created_at
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.user_id=? AND d.mime NOT LIKE ?
        ORDER BY d.created_at DESC
        LIMIT ? OFFSET ?";
    }

    try {
      $stmt = $pdo->prepare($countSql);
      $params = [(int)$user['id']];
      if ($mimeParam !== null) $params[] = $mimeParam;
      $stmt->execute($params);
      $mediaTotal = (int)$stmt->fetchColumn();
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare($listSql);
      $idx = 1;
      $stmt->bindValue($idx++, (int)$user['id'], PDO::PARAM_INT);
      if ($mimeParam !== null) {
        $stmt->bindValue($idx++, $mimeParam, PDO::PARAM_STR);
      }
      $stmt->bindValue($idx++, $perPage, PDO::PARAM_INT);
      $stmt->bindValue($idx++, $offset, PDO::PARAM_INT);
      $stmt->execute();
      $mediaRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      $mediaRows = [];
    }
  }

// Followers / Following tabs
$followersRows = [];
$followingRows = [];
if ($tab === 'followers' && $showFollowers) {
  try {
    $stmt = $pdo->prepare("SELECT u.id, u.username, u.display_name, u.avatar
      FROM {$pfx}xf_user_follow f
      JOIN {$pfx}users u ON u.id=f.follower_id
      WHERE f.followed_id=?
      ORDER BY f.created_at DESC
      LIMIT 60");
    $stmt->execute([(int)$user['id']]);
    $followersRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}
}
if ($tab === 'following' && $showFollowers) {
  try {
    $stmt = $pdo->prepare("SELECT u.id, u.username, u.display_name, u.avatar
      FROM {$pfx}xf_user_follow f
      JOIN {$pfx}users u ON u.id=f.followed_id
      WHERE f.follower_id=?
      ORDER BY f.created_at DESC
      LIMIT 60");
    $stmt->execute([(int)$user['id']]);
    $followingRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}
}

// Sidebar: visitors
$visitors = [];
if ($profileVisitorsEnabled && !empty($privacy['show_visitors'])) {
  try {
    $stmt = $pdo->prepare("SELECT v.visitor_user_id, v.visited_at, u.username, u.display_name, u.avatar
      FROM {$pfx}xf_profile_visitors v
      JOIN {$pfx}users u ON u.id=v.visitor_user_id
      WHERE v.user_id=?
      ORDER BY v.visited_at DESC
      LIMIT 10");
    $stmt->execute([(int)$user['id']]);
    $visitors = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {}
}

// Sidebar: latest activity
$activities = [];
try {
  $stmt = $pdo->prepare("SELECT id, title, slug, created_at FROM {$pfx}posts WHERE author_id=? AND type='forum' AND status='published' ORDER BY created_at DESC LIMIT 1");
  $stmt->execute([(int)$user['id']]);
  if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activities[] = [
      'label' => 'Thread',
      'title' => (string)($row['title'] ?? ''),
      'url' => url('forum_post.php?slug=' . urlencode((string)($row['slug'] ?? ''))),
      'time' => (string)($row['created_at'] ?? ''),
    ];
  }
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT c.created_at, p.title, p.slug FROM {$pfx}post_comments c JOIN {$pfx}posts p ON p.id=c.post_id WHERE c.author_id=? AND c.is_deleted=0 AND p.type='forum' AND p.status='published' ORDER BY c.created_at DESC LIMIT 1");
  $stmt->execute([(int)$user['id']]);
  if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activities[] = [
      'label' => 'Reply',
      'title' => (string)($row['title'] ?? ''),
      'url' => url('forum_post.php?slug=' . urlencode((string)($row['slug'] ?? ''))),
      'time' => (string)($row['created_at'] ?? ''),
    ];
  }
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT id, created_at FROM {$pfx}xf_profile_posts WHERE author_user_id=? AND is_deleted=0 ORDER BY created_at DESC LIMIT 1");
  $stmt->execute([(int)$user['id']]);
  if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $activities[] = [
      'label' => 'Profile post',
      'title' => 'Profile post #' . (int)$row['id'],
      'url' => url('user.php?id=' . $userId . '#profile-post-' . (int)$row['id']),
      'time' => (string)($row['created_at'] ?? ''),
    ];
  }
} catch (Throwable $e) {}

usort($activities, function(array $a, array $b): int {
  return strcmp((string)($b['time'] ?? ''), (string)($a['time'] ?? ''));
});
$activities = array_slice($activities, 0, 3);

$lastActive = (string)($user['last_active'] ?? '');
$isOnline = false;
if ($lastActive !== '') {
  $ts = strtotime($lastActive);
  $isOnline = $ts !== false && (time() - $ts) < 300;
}

$title = $displayName . ' - ' . site_name();
$__need_glass = true;
$__need_density = true;
$__need_editor = $profilePostsEnabled && $meId > 0;
$__need_tooltip = true;
$langCode = function_exists('lang') ? lang() : 'zh-CN';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap xf-profile xf-apple" data-tabs-scope>
    <section class="xf-cover-banner<?= $coverUrl !== '' ? ' has-image' : '' ?>">
      <?php if ($coverUrl !== ''): ?>
        <div class="xf-cover-image" style="background-image:url('<?= e($coverUrl) ?>');"></div>
      <?php endif; ?>
      <div class="xf-cover-blur"></div>
      <div class="xf-cover-inner">
        <div class="xf-avatar">
          <?php if (!empty($user['avatar'])): ?>
            <img src="<?= e(arc_avatar_url((string)$user['avatar'])) ?>" alt="" />
          <?php else: ?>
            <span><?= e(mb_strtoupper(mb_substr($displayName, 0, 1))) ?></span>
          <?php endif; ?>
        </div>
        <div class="xf-cover-meta">
          <h1><?= e($displayName) ?><?php if ($isOnline): ?> <span class="xf-pill" style="margin-left:8px;">Online</span><?php endif; ?></h1>
          <div class="xf-user-title"><?= e($userTitle) ?></div>
          <div class="xf-stats">
            <a class="xf-stat-link" href="<?= e(url('user.php?id=' . $userId . '&tab=threads')) ?>"><b><?= (int)$threadCount ?></b><span>Threads</span></a>
            <a class="xf-stat-link" href="<?= e(url('user.php?id=' . $userId . '&tab=posts')) ?>"><b><?= (int)$replyCount ?></b><span>Posts</span></a>
            <span><b><?= (int)$messagesCount ?></b><span>Messages</span></span>
            <span><b><?= (int)$reactionScore ?></b><span>Reactions</span></span>
            <span><b><?= (int)$trophyPoints ?></b><span>Trophy points</span></span>
            <?php if ($showFollowers): ?>
              <a class="xf-stat-link" href="<?= e(url('user.php?id=' . $userId . '&tab=followers')) ?>"><b><?= (int)$followersCount ?></b><span>Followers</span></a>
              <a class="xf-stat-link" href="<?= e(url('user.php?id=' . $userId . '&tab=following')) ?>"><b><?= (int)$followingCount ?></b><span>Following</span></a>
            <?php endif; ?>
          </div>
          <?php if ($groups): ?>
            <div class="xf-stats" style="margin-top:8px;">
              <?php foreach ($groups as $g): ?>
                <span class="xf-pill"><?= e((string)($g['name'] ?? '')) ?></span>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
        <div class="xf-cover-actions">
          <?php if (!$isSelf && $meId > 0): ?>
            <form method="post" action="<?= e(url('follow.php')) ?>" class="xf-follow-form">
              <?= csrf_field() ?>
              <input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>" />
              <input type="hidden" name="action" value="<?= $isFollowing ? 'unfollow' : 'follow' ?>" />
              <button class="btn xf-follow-btn<?= $isFollowing ? ' is-following' : '' ?>" type="submit"><?= $isFollowing ? 'Following' : 'Follow' ?></button>
            </form>
            <a class="btn" href="<?= e(url('conversation_new.php?to=' . urlencode((string)($user['username'] ?? '')))) ?>">Message</a>
            <form method="post" action="<?= e(url('ignore.php')) ?>" class="xf-follow-form">
              <?= csrf_field() ?>
              <input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>" />
              <input type="hidden" name="action" value="<?= $isIgnored ? 'unignore' : 'ignore' ?>" />
              <button class="btn" type="submit"><?= $isIgnored ? 'Unignore' : 'Ignore' ?></button>
            </form>
          <?php endif; ?>
          <?php if ($meId > 0 && !$isSelf): ?>
            <details>
              <summary class="btn">Report</summary>
              <form method="post" action="<?= e(url('report.php')) ?>" style="margin-top:8px;">
                <?= csrf_field() ?>
                <input type="hidden" name="content_type" value="user">
                <input type="hidden" name="content_id" value="<?= (int)$user['id'] ?>">
                <div class="field" style="margin:8px 0 0;">
                  <input class="input" name="reason" placeholder="Reason" required />
                </div>
                <div class="field" style="margin:8px 0 0;">
                  <textarea class="input" name="details" rows="3" placeholder="Details (optional)"></textarea>
                </div>
                <button class="btn" type="submit" style="margin-top:8px;">Submit</button>
              </form>
            </details>
          <?php endif; ?>
          <?php if (is_admin()): ?>
            <a class="btn" href="<?= e(function_exists('admin_url') ? admin_url('user_edit', ['id' => (int)$user['id']]) : url('admin/user_edit.php?id=' . (int)$user['id'])) ?>">Admin</a>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <?php include __DIR__ . '/partials/xf/tabs.php'; ?>

    <div class="xf-grid">
      <aside class="xf-side">
        <div class="card glass reveal">
          <h3>About</h3>
          <?php if ($location !== ''): ?>
            <div class="xf-kv"><div class="k">Location</div><div class="v"><?= e($location) ?></div></div>
          <?php endif; ?>
          <?php if ($website !== ''): ?>
            <div class="xf-kv"><div class="k">Website</div><div class="v"><a href="<?= e($website) ?>" target="_blank" rel="nofollow ugc noopener"><?= e($website) ?></a></div></div>
          <?php endif; ?>
          <div class="xf-kv"><div class="k">Joined</div><div class="v"><?= e((string)($user['created_at'] ?? '')) ?></div></div>
          <?php if ($lastActive !== ''): ?>
            <div class="xf-kv"><div class="k">Last active</div><div class="v"><?= e($lastActive) ?></div></div>
          <?php endif; ?>
          <?php if ($discordVisible): ?>
            <div class="xf-kv"><div class="k">Discord</div><div class="v"><?= e($discordLabel) ?></div></div>
          <?php endif; ?>
        </div>

        <?php if ($activities): ?>
          <div class="card glass xf-side-block reveal">
            <h4>Latest activity</h4>
            <?php foreach ($activities as $a): ?>
              <div class="xf-side-item-row">
                <div class="t"><?= e((string)$a['label']) ?>: <a href="<?= e((string)$a['url']) ?>"><?= e((string)$a['title']) ?></a></div>
                <div class="d"><?= e((string)$a['time']) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if ($profileVisitorsEnabled && !empty($privacy['show_visitors'])): ?>
          <div class="card glass xf-side-block reveal">
            <h4>Visitors</h4>
            <?php if ($visitors): ?>
              <div class="xf-visit-list">
                <?php foreach ($visitors as $v): ?>
                  <a class="xf-visit-item" href="<?= e(url('user.php?id=' . (int)($v['visitor_user_id'] ?? 0))) ?>">
                    <span class="xf-visit-avatar">
                      <?php if (!empty($v['avatar'])): ?>
                        <img src="<?= e(arc_avatar_url((string)$v['avatar'])) ?>" alt="" />
                      <?php else: ?>
                        <span class="t"><?= e(mb_strtoupper(mb_substr(display_name_of($v), 0, 1))) ?></span>
                      <?php endif; ?>
                    </span>
                    <span class="t"><?= e(display_name_of($v)) ?></span>
                    <span class="d"><?= e((string)($v['visited_at'] ?? '')) ?></span>
                  </a>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="xf-side-muted"><?= e(t('no_data')) ?></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </aside>

      <section class="xf-main">
        <div data-panel="profile_posts"<?= $tab === 'profile_posts' ? '' : ' style="display:none"' ?>>
          <?php if (!$profilePostsEnabled): ?>
            <div class="card glass reveal">Profile posts are disabled.</div>
          <?php else: ?>
            <?php if ($canPostOnProfile): ?>
              <div class="card glass reveal">
                <div class="xf-composer">
                  <div class="xf-composer-avatar">
                    <?php if (!empty($me['avatar'])): ?>
                      <img src="<?= e(arc_avatar_url((string)$me['avatar'])) ?>" alt="" />
                    <?php else: ?>
                      <span><?= e(mb_strtoupper(mb_substr(display_name_of($me), 0, 1))) ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="xf-composer-body">
                    <form method="post" action="<?= e(url('profile_post_new.php')) ?>" data-profile-ajax="<?= e(url('ajax/profile_post_create.php')) ?>">
                      <?= csrf_field() ?>
                      <input type="hidden" name="profile_user_id" value="<?= (int)$user['id'] ?>">
                      <?php
                        $draftKey = 'profile_post_' . (int)$user['id'] . '_' . $meId;
                        $content_name = 'message';
                        $initial_value = '';
                        $mode = 'profile_post';
                        $attachments_enabled = true;
                        $placeholder = 'Write something...';
                        $content_id = (int)$user['id'];
                        $draft_key = $draftKey;
                        include __DIR__ . '/partials/editor/editor_widget.php';
                      ?>
                      <button class="btn" type="submit" style="margin-top:10px;">Post</button>
                    </form>
                  </div>
                </div>
              </div>
            <?php endif; ?>

            <div class="xf-stack" style="margin-top:12px;">
              <?php foreach ($profilePosts as $pp): ?>
                <?php
                  $ppId = (int)($pp['id'] ?? 0);
                  $ppAuthorId = (int)($pp['author_user_id'] ?? 0);
                  $ppAuthorName = display_name_of($pp);
                  $ppAvatar = (string)($pp['avatar'] ?? '');
                  $ppDiscord = (string)($pp['discord_username'] ?? '');
                  $ppDisc = (string)($pp['discord_discriminator'] ?? '');
                  if ($ppDiscord !== '' && $ppDisc !== '' && $ppDisc !== '0') $ppDiscord .= '#' . $ppDisc;
                  $ppIgnored = isset($ignoredIds[$ppAuthorId]);
                ?>
                <article class="card glass reveal" id="profile-post-<?= $ppId ?>">
                  <div style="display:flex;gap:12px;align-items:center;">
                    <div class="xf-avatar" style="width:56px;height:56px;border-radius:16px;">
                      <?php if ($ppAvatar !== ''): ?>
                        <img src="<?= e(arc_avatar_url($ppAvatar)) ?>" alt="" />
                      <?php else: ?>
                        <span><?= e(mb_strtoupper(mb_substr($ppAuthorName, 0, 1))) ?></span>
                      <?php endif; ?>
                    </div>
                    <div style="min-width:0;">
                      <div style="font-weight:700;">
                        <a class="js-user-tooltip" data-user-id="<?= (int)$ppAuthorId ?>" href="<?= e(url('user.php?id=' . $ppAuthorId)) ?>"><?= e($ppAuthorName) ?></a>
                      </div>
                      <?php if ($ppDiscord !== ''): ?><div class="xf-meta xf-discord-label">Discord: <?= e($ppDiscord) ?></div><?php endif; ?>
                      <div class="xf-meta"><?= e((string)($pp['created_at'] ?? '')) ?></div>
                    </div>
                    <div style="margin-left:auto;display:flex;gap:8px;">
                      <?php if ($meId > 0 && ($meId === $ppAuthorId || $meId === (int)$user['id'] || is_admin())): ?>
                        <form method="post" action="<?= e(url('profile_post_delete.php')) ?>" style="margin:0;">
                          <?= csrf_field() ?>
                          <input type="hidden" name="id" value="<?= $ppId ?>">
                          <button class="btn" type="submit">Delete</button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div style="margin-top:12px;">
                    <?php if ($ppIgnored): ?>
                      <div class="xf-meta">Ignored content.</div>
                    <?php else: ?>
                      <?= ArcOS\Services\BbCode::render((string)($pp['message_bbcode'] ?? ''), $pdo, $pfx) ?>
                    <?php endif; ?>
                  </div>

                  <?php $comments = $profileComments[$ppId] ?? []; ?>
                  <?php if ($comments): ?>
                    <div style="margin-top:12px;display:grid;gap:10px;">
                      <?php foreach ($comments as $c): ?>
                        <?php
                          $cAuthorId = (int)($c['user_id'] ?? 0);
                          $cAuthorName = display_name_of($c);
                          $cAvatar = (string)($c['avatar'] ?? '');
                          $cDiscord = (string)($c['discord_username'] ?? '');
                          $cDisc = (string)($c['discord_discriminator'] ?? '');
                          if ($cDiscord !== '' && $cDisc !== '' && $cDisc !== '0') $cDiscord .= '#' . $cDisc;
                          $cIgnored = isset($ignoredIds[$cAuthorId]);
                        ?>
                        <div class="card" style="padding:12px;border-radius:14px;">
                          <div style="display:flex;gap:10px;align-items:center;">
                            <div class="xf-avatar" style="width:40px;height:40px;border-radius:12px;">
                              <?php if ($cAvatar !== ''): ?>
                                <img src="<?= e(arc_avatar_url($cAvatar)) ?>" alt="" />
                              <?php else: ?>
                                <span><?= e(mb_strtoupper(mb_substr($cAuthorName, 0, 1))) ?></span>
                              <?php endif; ?>
                            </div>
                            <div>
                              <div style="font-weight:700;">
                                <a class="js-user-tooltip" data-user-id="<?= (int)$cAuthorId ?>" href="<?= e(url('user.php?id=' . $cAuthorId)) ?>"><?= e($cAuthorName) ?></a>
                              </div>
                              <?php if ($cDiscord !== ''): ?><div class="xf-meta xf-discord-label">Discord: <?= e($cDiscord) ?></div><?php endif; ?>
                              <div class="xf-meta"><?= e((string)($c['created_at'] ?? '')) ?></div>
                            </div>
                            <div style="margin-left:auto;">
                              <?php if ($meId > 0 && ($meId === $cAuthorId || $meId === (int)$user['id'] || is_admin())): ?>
                                <form method="post" action="<?= e(url('profile_post_comment_delete.php')) ?>" style="margin:0;">
                                  <?= csrf_field() ?>
                                  <input type="hidden" name="id" value="<?= (int)($c['id'] ?? 0) ?>">
                                  <button class="btn" type="submit">Delete</button>
                                </form>
                              <?php endif; ?>
                            </div>
                          </div>
                          <div style="margin-top:8px;">
                            <?php if ($cIgnored): ?>
                              <div class="xf-meta">Ignored content.</div>
                            <?php else: ?>
                              <?= ArcOS\Services\BbCode::render((string)($c['message_bbcode'] ?? ''), $pdo, $pfx) ?>
                            <?php endif; ?>
                          </div>
                        </div>
                      <?php endforeach; ?>
                    </div>
                  <?php endif; ?>

                  <?php if ($canPostOnProfile): ?>
                    <details style="margin-top:12px;">
                      <summary class="btn">Comment</summary>
                      <form method="post" action="<?= e(url('profile_post_comment.php')) ?>" data-profile-ajax="<?= e(url('ajax/profile_post_comment.php')) ?>" style="margin-top:10px;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="profile_post_id" value="<?= $ppId ?>">
                        <?php
                          $draftKey = 'profile_post_comment_' . $ppId . '_' . $meId;
                          $content_name = 'message';
                          $initial_value = '';
                          $mode = 'profile_post_comment';
                          $attachments_enabled = true;
                          $placeholder = 'Write a comment...';
                          $content_id = $ppId;
                          $draft_key = $draftKey;
                          $min_height = 120;
                          include __DIR__ . '/partials/editor/editor_widget.php';
                        ?>
                        <button class="btn" type="submit" style="margin-top:10px;">Send</button>
                      </form>
                    </details>
                  <?php endif; ?>
                </article>
              <?php endforeach; ?>

              <?php if (!$profilePosts): ?>
                <div class="card glass reveal"><?= e(t('no_data')) ?></div>
              <?php endif; ?>
            </div>

            <?php
              if ($profilePostsTotal > $perPage) {
                $base_url = url('user.php');
                $query = ['id' => $userId, 'tab' => 'profile_posts'];
                $total_pages = (int)ceil($profilePostsTotal / $perPage);
                $page = $page;
                include __DIR__ . '/partials/xf/pager.php';
              }
            ?>
          <?php endif; ?>
        </div>

        <div data-panel="threads"<?= $tab === 'threads' ? '' : ' style="display:none"' ?>>
          <div class="card glass reveal">
            <?php $threads = $threadRows; include __DIR__ . '/partials/xf/thread_list.php'; ?>
          </div>
          <?php
            if ($threadTotal > $perPage) {
              $base_url = url('user.php');
              $query = ['id' => $userId, 'tab' => 'threads'];
              $total_pages = (int)ceil($threadTotal / $perPage);
              $page = $page;
              include __DIR__ . '/partials/xf/pager.php';
            }
          ?>
        </div>

        <div data-panel="posts"<?= $tab === 'posts' ? '' : ' style="display:none"' ?>>
          <div class="xf-stack">
            <?php foreach ($replyRows as $r): ?>
              <div class="card glass reveal">
                <div class="xf-meta">Reply in <a href="<?= e(url('forum_post.php?slug=' . urlencode((string)($r['slug'] ?? '')))) ?>"><?= e((string)($r['title'] ?? '')) ?></a></div>
                <div style="margin-top:8px;">
                  <?= ArcOS\Services\BbCode::render((string)($r['content'] ?? ''), $pdo, $pfx) ?>
                </div>
                <div class="xf-meta" style="margin-top:8px;"><?= e((string)($r['created_at'] ?? '')) ?></div>
              </div>
            <?php endforeach; ?>
            <?php if (!$replyRows): ?>
              <div class="card glass reveal"><?= e(t('no_data')) ?></div>
            <?php endif; ?>
          </div>
          <?php
            if ($replyTotal > $perPage) {
              $base_url = url('user.php');
              $query = ['id' => $userId, 'tab' => 'posts'];
              $total_pages = (int)ceil($replyTotal / $perPage);
              $page = $page;
              include __DIR__ . '/partials/xf/pager.php';
            }
          ?>
        </div>

        <div data-panel="about"<?= $tab === 'about' ? '' : ' style="display:none"' ?>>
          <div class="card glass reveal">
            <div class="xf-about-grid">
              <div class="xf-about-box">
                <div style="font-weight:700;margin-bottom:6px;">About</div>
                <?php if ($aboutBbcode !== ''): ?>
                  <?= ArcOS\Services\BbCode::render($aboutBbcode, $pdo, $pfx) ?>
                <?php else: ?>
                  <div class="xf-meta"><?= e(t('no_data')) ?></div>
                <?php endif; ?>
              </div>
              <div class="xf-about-box">
                <div style="font-weight:700;margin-bottom:6px;">Details</div>
                <?php if ($location !== ''): ?><div class="xf-kv"><div class="k">Location</div><div class="v"><?= e($location) ?></div></div><?php endif; ?>
                <?php if ($website !== ''): ?><div class="xf-kv"><div class="k">Website</div><div class="v"><a href="<?= e($website) ?>" target="_blank" rel="nofollow ugc noopener"><?= e($website) ?></a></div></div><?php endif; ?>
                <?php if ($discordVisible): ?><div class="xf-kv"><div class="k">Discord</div><div class="v"><?= e($discordLabel) ?></div></div><?php endif; ?>
                <div class="xf-kv"><div class="k">Reactions</div><div class="v"><?= (int)$reactionScore ?></div></div>
              </div>
            </div>
            <?php if ($profileFieldsEnabled && $customFields): ?>
              <div class="xf-about-box" style="margin-top:12px;">
                <div style="font-weight:700;margin-bottom:6px;">Custom fields</div>
                <?php foreach ($customFields as $f): ?>
                  <?php
                    $fid = (int)($f['field_id'] ?? 0);
                    $val = (string)($customFieldValues[$fid] ?? '');
                    if ($val === '') continue;
                  ?>
                  <div class="xf-kv">
                    <div class="k"><?= e((string)($f['title'] ?? '')) ?></div>
                    <div class="v"><?= e($val) ?></div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <div data-panel="trophies"<?= $tab === 'trophies' ? '' : ' style="display:none"' ?>>
          <div class="card glass reveal">
            <?php if ($trophies): ?>
              <div class="trophy-grid">
                <?php foreach ($trophies as $tr): ?>
                  <div class="trophy">
                    <div class="trophy-title"><?= e((string)($tr['title'] ?? '')) ?></div>
                    <div class="trophy-desc"><?= e((string)($tr['description'] ?? '')) ?></div>
                    <div class="xf-meta" style="margin-top:6px;"><?= (int)($tr['points'] ?? 0) ?> pts</div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="xf-meta"><?= e(t('no_data')) ?></div>
            <?php endif; ?>
          </div>
        </div>

        <div data-panel="media"<?= $tab === 'media' ? '' : ' style="display:none"' ?>>
          <?php if (!$profileMediaEnabled): ?>
            <div class="card glass reveal">Media disabled.</div>
          <?php else: ?>
            <div class="xf-toolbar reveal">
              <div class="xf-filters">
                <?php
                  $mediaFilter = (string)($_GET['media'] ?? 'all');
                  if (!in_array($mediaFilter, ['all','images','files'], true)) $mediaFilter = 'all';
                ?>
                <a class="xf-filter<?= $mediaFilter === 'all' ? ' active' : '' ?>" href="<?= e(url('user.php?id=' . $userId . '&tab=media&media=all')) ?>">All</a>
                <a class="xf-filter<?= $mediaFilter === 'images' ? ' active' : '' ?>" href="<?= e(url('user.php?id=' . $userId . '&tab=media&media=images')) ?>">Images</a>
                <a class="xf-filter<?= $mediaFilter === 'files' ? ' active' : '' ?>" href="<?= e(url('user.php?id=' . $userId . '&tab=media&media=files')) ?>">Files</a>
              </div>
            </div>
            <div class="xf-stack">
              <?php foreach ($mediaRows as $m): ?>
                <?php
                  $mime = (string)($m['mime'] ?? '');
                  $isImage = str_starts_with($mime, 'image/');
                  $fileName = (string)($m['file_name'] ?? '');
                  $size = (int)($m['size_bytes'] ?? 0);
                  $url = url('attachment.php?id=' . (int)($m['id'] ?? 0));
                ?>
                <div class="card glass reveal" style="display:flex;gap:12px;align-items:center;">
                  <?php if ($isImage && !empty($m['file_path'])): ?>
                    <img src="<?= e($url) ?>" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:12px;border:1px solid rgba(0,0,0,.08);" />
                  <?php else: ?>
                    <div style="width:64px;height:64px;border-radius:12px;border:1px solid rgba(0,0,0,.08);display:flex;align-items:center;justify-content:center;font-weight:700;">FILE</div>
                  <?php endif; ?>
                  <div style="min-width:0;">
                    <div style="font-weight:700;"><?= e($fileName) ?></div>
                    <div class="xf-meta"><?= e($mime) ?> - <?= number_format(max(1, (int)round($size / 1024))) ?> KB</div>
                  </div>
                  <div style="margin-left:auto;">
                    <a class="btn" href="<?= e($url) ?>">View</a>
                  </div>
                </div>
              <?php endforeach; ?>
              <?php if (!$mediaRows): ?>
                <div class="card glass reveal"><?= e(t('no_data')) ?></div>
              <?php endif; ?>
            </div>
            <?php
              if ($mediaTotal > $perPage) {
                $base_url = url('user.php');
                $query = ['id' => $userId, 'tab' => 'media', 'media' => (string)($_GET['media'] ?? 'all')];
                $total_pages = (int)ceil($mediaTotal / $perPage);
                $page = $page;
                include __DIR__ . '/partials/xf/pager.php';
              }
            ?>
          <?php endif; ?>
        </div>

        <div data-panel="followers"<?= $tab === 'followers' ? '' : ' style="display:none"' ?>>
          <div class="card glass reveal">
            <div class="xf-follow-list">
              <?php $profileUser = $user; ?>
              <?php foreach ($followersRows as $urow): ?>
                <?php $user = $urow; include __DIR__ . '/partials/xf/user_card.php'; ?>
              <?php endforeach; ?>
              <?php $user = $profileUser; ?>
              <?php if (!$followersRows): ?>
                <div class="xf-topic-meta"><?= e(t('no_data')) ?></div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div data-panel="following"<?= $tab === 'following' ? '' : ' style="display:none"' ?>>
          <div class="card glass reveal">
            <div class="xf-follow-list">
              <?php $profileUser = $user; ?>
              <?php foreach ($followingRows as $urow): ?>
                <?php $user = $urow; include __DIR__ . '/partials/xf/user_card.php'; ?>
              <?php endforeach; ?>
              <?php $user = $profileUser; ?>
              <?php if (!$followingRows): ?>
                <div class="xf-topic-meta"><?= e(t('no_data')) ?></div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>

  <?php if ($meId > 0 && !$isSelf && $profileVisitorsEnabled && !empty($privacy['show_visitors'])): ?>
    <script>
      (function(){
        try {
          var data = new URLSearchParams();
          data.set('user_id', <?= (int)$user['id'] ?>);
          fetch(<?= json_encode(url('ajax/visitors_ping.php'), JSON_UNESCAPED_SLASHES) ?>, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': window.__CSRF_TOKEN__ || ''},
            body: data.toString()
          });
        } catch (e) {}
      })();
    </script>
  <?php endif; ?>

  <script>
    (function(){
      var forms = document.querySelectorAll('[data-profile-ajax]');
      forms.forEach(function(form){
        if (form.dataset.ajaxReady) return;
        form.dataset.ajaxReady = '1';
        form.addEventListener('submit', function(ev){
          if (!form.getAttribute('data-profile-ajax')) return;
          ev.preventDefault();
          var url = form.getAttribute('data-profile-ajax');
          var data = new FormData(form);
          fetch(url, {
            method: 'POST',
            headers: {'X-CSRF-Token': window.__CSRF_TOKEN__ || ''},
            body: data
          }).then(function(r){ return r.json(); }).then(function(res){
            if (res && res.ok) {
              window.location.reload();
            } else {
              alert('Failed to submit.');
            }
          }).catch(function(){ alert('Failed to submit.'); });
        });
      });
    })();
  </script>
</body>
</html>
