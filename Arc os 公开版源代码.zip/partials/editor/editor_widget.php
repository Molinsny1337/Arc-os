<?php
declare(strict_types=1);

$action_url = $action_url ?? '';
$content_name = $content_name ?? 'content';
$initial_value = $initial_value ?? '';
$mode = $mode ?? 'post';
$csrf_token = $csrf_token ?? (function_exists('csrf_token') ? (string)csrf_token() : '');
$attachments_enabled = $attachments_enabled ?? true;
$draft_key = $draft_key ?? '';
$placeholder = $placeholder ?? '';
$content_id = $content_id ?? 0;
$content_type = $content_type ?? (string)$mode;
$mentions_enabled = $mentions_enabled ?? true;
$tags_enabled = $tags_enabled ?? true;
$full_screen_enabled = $full_screen_enabled ?? true;
$min_height = isset($min_height) ? (int)$min_height : 0;

$preview_url = url('ajax/preview.php');
$upload_url = url('ajax/upload_attachment.php');
$mention_url = url('ajax/mention_users.php');
$tag_url = url('ajax/suggest_tags.php');
$quote_url = url('ajax/quote.php');
$draft_save_url = url('ajax/draft_save.php');
$draft_load_url = url('ajax/draft_load.php');
$attach_remove_url = url('ajax/attachment_remove.php');
$emoji_url = url('ajax/emojis.php');
?>
<div class="arc-editor glass" data-arc-editor="1"
  data-mode="visual"
  data-editor-mode="<?= e((string)$mode) ?>"
  data-content-type="<?= e((string)$content_type) ?>"
  data-preview-url="<?= e($preview_url) ?>"
  data-upload-url="<?= e($upload_url) ?>"
  data-mention-url="<?= e($mention_url) ?>"
  data-tag-url="<?= e($tag_url) ?>"
  data-quote-url="<?= e($quote_url) ?>"
  data-emoji-url="<?= e($emoji_url) ?>"
  data-draft-save-url="<?= e($draft_save_url) ?>"
  data-draft-load-url="<?= e($draft_load_url) ?>"
  data-attach-remove-url="<?= e($attach_remove_url) ?>"
  data-draft-key="<?= e((string)$draft_key) ?>"
  data-csrf="<?= e((string)$csrf_token) ?>"
  data-attachments="<?= $attachments_enabled ? '1' : '0' ?>"
  data-content-id="<?= (int)$content_id ?>"
  data-mentions="<?= $mentions_enabled ? '1' : '0' ?>"
  data-tags="<?= $tags_enabled ? '1' : '0' ?>"
  data-fullscreen="<?= $full_screen_enabled ? '1' : '0' ?>"
  data-min-height="<?= $min_height ?>"
>
  <div class="arc-editor-top">
    <div class="arc-editor-tabs" role="tablist">
      <button type="button" class="arc-editor-tab is-active" data-arc-editor-mode="visual" aria-selected="true">Visual</button>
      <button type="button" class="arc-editor-tab" data-arc-editor-mode="bbcode" aria-selected="false">BBCode</button>
      <button type="button" class="arc-editor-tab" data-arc-editor-mode="preview" aria-selected="false">Preview</button>
    </div>
    <div class="arc-editor-toolbar" data-arc-editor-toolbar="1" role="toolbar" aria-label="Editor toolbar">
      <button type="button" class="arc-editor-btn" data-cmd="bold" title="Bold"><span class="t">B</span></button>
      <button type="button" class="arc-editor-btn" data-cmd="italic" title="Italic"><span class="t" style="font-style:italic">I</span></button>
      <button type="button" class="arc-editor-btn" data-cmd="underline" title="Underline"><span class="t" style="text-decoration:underline">U</span></button>
      <button type="button" class="arc-editor-btn" data-cmd="strike" title="Strike"><span class="t" style="text-decoration:line-through">S</span></button>
      <span class="arc-editor-sep"></span>
      <select class="arc-editor-select" data-cmd="color-select" aria-label="Text color">
        <option value=""><?= e(t('color') ?? 'Color') ?></option>
        <option value="#111111">Black</option>
        <option value="#0a84ff">Blue</option>
        <option value="#e11d48">Red</option>
        <option value="#16a34a">Green</option>
        <option value="#7c3aed">Purple</option>
      </select>
      <select class="arc-editor-select" data-cmd="size-select" aria-label="Text size">
        <option value=""><?= e(t('size') ?? 'Size') ?></option>
        <option value="12">12</option>
        <option value="14">14</option>
        <option value="16">16</option>
        <option value="18">18</option>
        <option value="20">20</option>
        <option value="24">24</option>
        <option value="28">28</option>
      </select>
      <span class="arc-editor-sep"></span>
      <button type="button" class="arc-editor-btn" data-cmd="align-left" title="Align left">L</button>
      <button type="button" class="arc-editor-btn" data-cmd="align-center" title="Align center">C</button>
      <button type="button" class="arc-editor-btn" data-cmd="align-right" title="Align right">R</button>
      <button type="button" class="arc-editor-btn" data-cmd="align-justify" title="Justify">J</button>
      <span class="arc-editor-sep"></span>
      <button type="button" class="arc-editor-btn" data-cmd="ul" title="Bullet list">UL</button>
      <button type="button" class="arc-editor-btn" data-cmd="ol" title="Numbered list">OL</button>
      <button type="button" class="arc-editor-btn" data-cmd="indent" title="Indent">In</button>
      <button type="button" class="arc-editor-btn" data-cmd="outdent" title="Outdent">Out</button>
      <span class="arc-editor-sep"></span>
      <button type="button" class="arc-editor-btn" data-cmd="quote" title="Quote">Quote</button>
      <select class="arc-editor-select" data-cmd="code-lang" aria-label="Code language">
        <option value=""><?= e(t('code') ?? 'Code') ?></option>
        <option value="plain">Plain</option>
        <option value="php">PHP</option>
        <option value="js">JS</option>
        <option value="html">HTML</option>
        <option value="css">CSS</option>
        <option value="sql">SQL</option>
      </select>
      <button type="button" class="arc-editor-btn" data-cmd="icode" title="Inline code">Inline</button>
      <span class="arc-editor-sep"></span>
      <button type="button" class="arc-editor-btn" data-cmd="link" title="Link">Link</button>
      <button type="button" class="arc-editor-btn" data-cmd="image" title="Image">Image</button>
      <select class="arc-editor-select" data-cmd="media-type" aria-label="Media type">
        <option value=""><?= e(t('media') ?? 'Media') ?></option>
        <option value="auto">Auto</option>
        <option value="youtube">YouTube</option>
        <option value="bilibili">Bilibili</option>
      </select>
      <button type="button" class="arc-editor-btn" data-cmd="spoiler" title="Spoiler">Spoiler</button>
      <button type="button" class="arc-editor-btn" data-cmd="table" title="Table">Table</button>
      <button type="button" class="arc-editor-btn" data-cmd="hr" title="HR">HR</button>
      <button type="button" class="arc-editor-btn" data-cmd="emoji" title="Emoji">:)</button>
      <span class="arc-editor-sep"></span>
      <button type="button" class="arc-editor-btn" data-cmd="undo" title="Undo">Undo</button>
      <button type="button" class="arc-editor-btn" data-cmd="redo" title="Redo">Redo</button>
      <button type="button" class="arc-editor-btn" data-cmd="fullscreen" title="Fullscreen">Full</button>
    </div>
  </div>

  <div class="arc-editor-body">
    <div class="arc-editor-visual" data-arc-editor-visual="1" contenteditable="true" role="textbox" aria-multiline="true" data-placeholder="<?= e((string)$placeholder) ?>"></div>
    <textarea class="arc-editor-source" data-arc-editor-source="1" spellcheck="false" aria-label="BBCode source"></textarea>
    <div class="arc-editor-preview" data-arc-editor-preview="1" aria-live="polite"></div>
  </div>

  <div class="arc-editor-quote-bar" data-arc-quote-bar hidden>
    <div class="arc-editor-quote-meta">Quotes: <span data-arc-quote-count>0</span></div>
    <div class="arc-editor-quote-actions">
      <button type="button" class="arc-editor-btn" data-arc-quote-insert="1">Insert Quotes</button>
      <button type="button" class="arc-editor-btn" data-arc-quote-clear="1">Clear</button>
    </div>
  </div>

  <?php if ($attachments_enabled): ?>
    <div class="arc-editor-attachments" data-arc-editor-attachments="1">
      <div class="arc-editor-attach-head">
        <span class="arc-editor-attach-title">Attachments</span>
        <div class="arc-editor-attach-actions">
          <select class="arc-editor-select" data-arc-editor-insert="1" aria-label="Insert position">
            <option value="cursor">Insert at cursor</option>
            <option value="end">Insert at end</option>
          </select>
          <button type="button" class="arc-editor-btn" data-arc-editor-upload="1">Upload</button>
          <input type="file" data-arc-editor-file="1" multiple>
        </div>
      </div>
      <div class="arc-editor-attach-list" data-arc-editor-attach-list="1"></div>
    </div>
  <?php endif; ?>

  <div class="arc-editor-suggest" data-arc-editor-suggest="1" hidden></div>
  <div class="arc-editor-emoji" data-arc-editor-emoji="1" hidden></div>

  <textarea name="<?= e((string)$content_name) ?>" data-arc-editor-hidden="1" hidden><?= e((string)$initial_value) ?></textarea>
  <input type="hidden" name="draft_key" value="<?= e((string)$draft_key) ?>">
</div>
