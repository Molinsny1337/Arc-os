<?php
declare(strict_types=1);
$__app_js_v = @filemtime(__DIR__ . '/../assets/app.js') ?: 1;
$__welcome_js_v = @filemtime(__DIR__ . '/../assets/js/welcome.js') ?: 1;
?>
<script src="<?= e(url('assets/app.js?v=' . $__app_js_v)) ?>"></script>
<script src="<?= e(url('assets/js/welcome.js?v=' . $__welcome_js_v)) ?>"></script>
