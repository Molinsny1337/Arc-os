<?php
declare(strict_types=1);

$__welcome_title = $title ?? 'Welcome';
$__app_css_v = @filemtime(__DIR__ . '/../assets/app.css') ?: 1;
$__glass_css_v = @filemtime(__DIR__ . '/../assets/apple_glass_light.css') ?: 1;
$__welcome_css_v = @filemtime(__DIR__ . '/../assets/css/welcome.css') ?: 1;
$__base_path = function_exists('base_path') ? base_path() : '';
?>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta name="color-scheme" content="light" />
<meta name="theme-color" content="#ffffff" />
<title><?= e((string)$__welcome_title) ?></title>
<link rel="stylesheet" href="<?= e(url('assets/app.css?v=' . $__app_css_v)) ?>" />
<link rel="stylesheet" href="<?= e(url('assets/apple_glass_light.css?v=' . $__glass_css_v)) ?>" />
<link rel="stylesheet" href="<?= e(url('assets/css/welcome.css?v=' . $__welcome_css_v)) ?>" />
<script>
  window.__BASE_PATH__ = <?= json_encode($__base_path, JSON_UNESCAPED_SLASHES) ?>;
  window.__CLICK_EFFECT__ = "none";
  window.__CSRF_TOKEN__ = "";
</script>
