<?php
declare(strict_types=1);
// expects: $title
$__site_name = 'Arc OS';
if ((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting')) {
  $__site_name = (string)get_setting('site_name', 'Arc OS');
}
$__title = $title ?? $__site_name;
$__layout_mode = $__layout_mode ?? false;
if (!$__layout_mode && function_exists('is_admin') && is_admin()) {
  $__layout_mode = (($_GET['layout'] ?? '') === '1');
}
$__can_favicon = true;
$__can_custom_css = true;
if ((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('is_installed') && is_installed() && class_exists('ArcOS\\Services\\FeatureGate')) {
  $__can_favicon = ArcOS\Services\FeatureGate::enabled('favicon');
  $__can_custom_css = ArcOS\Services\FeatureGate::enabled('custom_css');
}
?>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<!-- 强制浅色方案：避免深色系统主题下出现“白底白字”这类看不见的灾难 -->
<meta name="color-scheme" content="light" />
<meta name="theme-color" content="#ffffff" />
<title><?= e($__title) ?></title>
<?php $icon = ''; if ($__can_favicon && (!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting')) { $icon = (string)get_setting('site_icon', ''); } if ($icon !== ''): ?>
  <link rel="icon" href="<?= e(preg_match("~^https?://~i", $icon) ? $icon : url($icon)) ?>" />
<?php endif; ?>

<?php
// cache busting for assets (avoids stale CSS after updates)
$__app_css_v = @filemtime(__DIR__ . '/../assets/app.css') ?: 1;
$__admin_css_v = @filemtime(__DIR__ . '/../assets/admin.css') ?: 1;
$__admin_js_v = @filemtime(__DIR__ . '/../assets/admin.js') ?: 1;
$__rte_css_v = @filemtime(__DIR__ . '/../assets/rte.css') ?: 1;
$__rte_js_v = @filemtime(__DIR__ . '/../assets/rte.js') ?: 1;
$__ui_layout_css_v = @filemtime(__DIR__ . '/../assets/ui_layout.css') ?: 1;
$__ui_layout_js_v = @filemtime(__DIR__ . '/../assets/ui_layout.js') ?: 1;
$__editor_css_v = @filemtime(__DIR__ . '/../assets/editor/editor.css') ?: 1;
$__density_css_v = @filemtime(__DIR__ . '/../assets/xf_density_comfort.css') ?: 1;
$__layout_mode_css_v = @filemtime(__DIR__ . '/../assets/layout_mode.css') ?: 1;
?>
<link rel="stylesheet" href="<?= e(url('assets/app.css?v=' . $__app_css_v)) ?>" />
  <link rel="stylesheet" href="<?= e(url('assets/xf_extra.css?v=' . (@filemtime(__DIR__ . '/../assets/xf_extra.css') ?: 1))) ?>" />
  <link rel="stylesheet" href="<?= e(url('assets/xf_theme.css?v=' . (@filemtime(__DIR__ . '/../assets/xf_theme.css') ?: 1))) ?>" />
<link rel="stylesheet" href="<?= e(url('assets/profile_xf.css?v=' . $__app_css_v)) ?>" />
<?php if (!empty($__need_density) || !empty($__need_glass)): ?>
  <link rel="stylesheet" href="<?= e(url('assets/xf_density_comfort.css?v=' . $__density_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__need_rte)): ?>
  <link rel="stylesheet" href="<?= e(url('assets/rte.css?v=' . $__rte_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__need_editor)): ?>
  <link rel="stylesheet" href="<?= e(url('assets/editor/editor.css?v=' . $__editor_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__layout_mode)): ?>
  <link rel="stylesheet" href="<?= e(url('assets/layout_mode.css?v=' . $__layout_mode_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__need_ui_layout)): ?>
  <link rel="stylesheet" href="<?= e(url('assets/ui_layout.css?v=' . $__ui_layout_css_v)) ?>" />
<?php endif; ?>
<?php if (defined('ADMIN_ENTRY') || str_starts_with($_SERVER['SCRIPT_NAME'] ?? '', BASE_PATH . '/admin')): ?>
  <link rel="stylesheet" href="<?= e(url('assets/admin.css?v=' . $__admin_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__need_glass)): ?>
  <?php $__glass_css_v = @filemtime(__DIR__ . '/../assets/apple_glass_light.css') ?: 1; ?>
  <link rel="stylesheet" href="<?= e(url('assets/apple_glass_light.css?v=' . $__glass_css_v)) ?>" />
  <?php $__xf_layout_css_v = @filemtime(__DIR__ . '/../assets/xf_layout.css') ?: 1; ?>
  <link rel="stylesheet" href="<?= e(url('assets/xf_layout.css?v=' . $__xf_layout_css_v)) ?>" />
<?php endif; ?>
<?php if (!empty($__need_tooltip)): ?>
  <?php $__tooltip_css_v = @filemtime(__DIR__ . '/../assets/user_tooltip.css') ?: 1; ?>
  <link rel="stylesheet" href="<?= e(url('assets/user_tooltip.css?v=' . $__tooltip_css_v)) ?>" />
<?php endif; ?>

  <script defer src="<?= e(url('assets/xf_theme.js?v=' . (@filemtime(__DIR__ . '/../assets/xf_theme.js') ?: 1))) ?>"></script>
<?php if (!empty($__need_rte)): ?>
  <script defer src="<?= e(url('assets/rte.js?v=' . $__rte_js_v)) ?>"></script>
<?php endif; ?>
<?php if (!empty($__need_ui_layout)): ?>
  <script defer src="<?= e(url('assets/ui_layout.js?v=' . $__ui_layout_js_v)) ?>"></script>
<?php endif; ?>
<?php if ((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('turnstile_configured') && turnstile_configured()): ?>
  <?= turnstile_script_tag() ?>
<?php endif; ?>
<?php if (defined('ADMIN_ENTRY') || str_starts_with($_SERVER['SCRIPT_NAME'] ?? '', BASE_PATH . '/admin')): ?>
  <script defer src="<?= e(url('assets/admin.js?v=' . $__admin_js_v)) ?>"></script>
<?php endif; ?>

<?php
// Custom CSS (admin-configurable)
if ($__can_custom_css && (!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting')) {
  $css = (string)get_setting('custom_css', '');
  if (trim($css) !== '') {
    // Prevent breaking out of <style> (best-effort).
    $css = str_ireplace('</style', '</sty' . 'le', $css);
    echo "<style id=\"custom-css\">\\n" . $css . "\\n</style>\\n";
  }
}
?>

<?php
// Per-profile user CSS vars (safe, scoped). Set $__profile_user_css_vars before including head.
if (!empty($__profile_user_css_vars) && is_string($__profile_user_css_vars)) {
  $css = (string)$__profile_user_css_vars;
  if (trim($css) !== '') {
    $css = str_ireplace('</style', '</sty' . 'le', $css);
    echo "<style id=\"profile-user-css\">\\n" . $css . "\\n</style>\\n";
  }
}
?>

<?php
// Custom head HTML (superadmin-controlled in admin UI)
if ((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting')) {
  $headHtml = (string)get_setting('custom_head_html', '');
  if (trim($headHtml) !== '') {
    echo $headHtml . "\n";
  }
}
?>

<script>
  window.__BASE_PATH__ = <?= json_encode(base_path(), JSON_UNESCAPED_SLASHES) ?>;
  window.__CLICK_EFFECT__ = <?= json_encode((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting') ? (string)get_setting('click_effect', 'none') : 'none', JSON_UNESCAPED_SLASHES) ?>;
  window.__CSRF_TOKEN__ = <?= json_encode(function_exists('csrf_token') ? (string)csrf_token() : '', JSON_UNESCAPED_SLASHES) ?>;
</script>
