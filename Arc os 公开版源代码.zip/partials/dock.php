<?php
declare(strict_types=1);
// Simple home dock (only include where needed)
if (!function_exists('t')) {
  require_once __DIR__ . '/../includes/bootstrap.php';
}

$user = function_exists('current_user') ? current_user() : null;

$home = function_exists('url') ? url('index.php') : '/index.php';
$forum = function_exists('url') ? url('forum.php') : '/forum.php';
$whats_new = function_exists('url') ? url('whats_new.php') : '/whats_new.php';
$members = function_exists('url') ? url('members.php') : '/members.php';
$tickets = function_exists('url') ? url('tickets.php') : '/tickets.php';
$account = function_exists('url') ? url('account.php') : '/account.php';
$login = function_exists('url') ? url('login.php') : '/login.php';

$ticketsHref = $tickets . '#create';
$ticketsHref = $user ? $ticketsHref : ($login . '?next=' . urlencode($ticketsHref));
$accountHref = $user ? $account : ($login . '?next=' . urlencode($account));
?>

<nav class="arc-dock" aria-label="<?= e(t('menu')) ?>">
  <a class="arc-dock-item" href="<?= e($home) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">H</span>
    <span class="arc-dock-t"><?= e(t('home')) ?></span>
  </a>
  <a class="arc-dock-item" href="<?= e($forum) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">F</span>
    <span class="arc-dock-t"><?= e(t('forum')) ?></span>
  </a>
  <a class="arc-dock-item" href="<?= e($whats_new) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">N</span>
    <span class="arc-dock-t"><?= e(t('whats_new')) ?></span>
  </a>
  <a class="arc-dock-item" href="<?= e($members) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">M</span>
    <span class="arc-dock-t"><?= e(t('members')) ?></span>
  </a>
  <a class="arc-dock-item" href="<?= e($ticketsHref) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">T</span>
    <span class="arc-dock-t"><?= e(t('tickets')) ?></span>
  </a>
  <a class="arc-dock-item" href="<?= e($accountHref) ?>" data-transition="1">
    <span class="arc-dock-ic" aria-hidden="true">U</span>
    <span class="arc-dock-t"><?= e(t('account')) ?></span>
  </a>
</nav>
