<?php
declare(strict_types=1);
$active = $active ?? 'dashboard';
$canMail = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('mail') : false;
$canModeration = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('moderation') : false;
$canAppearance = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('custom_css') : false;
?>
<aside class="admin-sidebar">
  <nav class="admin-menu">
    <a href="<?= e(function_exists('admin_url') ? admin_url('index') : url('admin/index.php')) ?>" class="<?= $active === 'dashboard' ? 'active' : '' ?>"><?= e(t('dashboard')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('posts') : url('admin/posts.php')) ?>" class="<?= $active === 'threads' ? 'active' : '' ?>"><?= e(t('threads')) ?></a>
    <?php if ($canModeration): ?>
      <a href="<?= e(function_exists('admin_url') ? admin_url('review_center') : url('admin/review_center.php')) ?>" class="<?= ($active ?? '') === 'review' ? 'active' : '' ?>"><?= e(t('review_center')) ?></a>
    <?php endif; ?>
    <a href="<?= e(function_exists('admin_url') ? admin_url('links') : url('admin/links.php')) ?>" class="<?= $active === 'links' ? 'active' : '' ?>"><?= e(t('links')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('users') : url('admin/users.php')) ?>" class="<?= $active === 'users' ? 'active' : '' ?>"><?= e(t('users')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('bans') : url('admin/bans.php')) ?>" class="<?= ($active ?? '') === 'bans' ? 'active' : '' ?>"><?= e(t('ban_center')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('trophies') : url('admin/trophies.php')) ?>" class="<?= ($active ?? '') === 'trophies' ? 'active' : '' ?>"><?= e(t('trophies')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('groups') : url('admin/groups.php')) ?>" class="<?= ($active ?? '') === 'groups' ? 'active' : '' ?>"><?= e(t('groups')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('tickets') : url('admin/tickets.php')) ?>" class="<?= ($active ?? '') === 'tickets' ? 'active' : '' ?>"><?= e(t('tickets')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('logs') : url('admin/logs.php')) ?>" class="<?= ($active ?? '') === 'logs' ? 'active' : '' ?>"><?= e(t('logs')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('api') : url('admin/api.php')) ?>" class="<?= ($active ?? '') === 'api' ? 'active' : '' ?>"><?= e(t('api')) ?></a>
    <?php if ($canAppearance): ?>
      <a href="<?= e(function_exists('admin_url') ? admin_url('appearance') : url('admin/appearance.php')) ?>" class="<?= ($active ?? '') === 'appearance' ? 'active' : '' ?>"><?= e(t('appearance')) ?></a>
    <?php endif; ?>
    <a href="<?= e(function_exists('admin_url') ? admin_url('layouts') : url('admin/layouts.php')) ?>" class="<?= ($active ?? '') === 'layouts' ? 'active' : '' ?>"><?= e(t('layouts')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('emoji_packs') : url('admin/emoji_packs.php')) ?>" class="<?= ($active ?? '') === 'emoji_packs' ? 'active' : '' ?>"><?= e(t('emoji_packs') !== 'emoji_packs' ? t('emoji_packs') : 'Emoji packs') ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('settings') : url('admin/settings.php')) ?>" class="<?= $active === 'settings' ? 'active' : '' ?>"><?= e(t('settings')) ?></a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('settings_license') : url('admin/settings_license.php')) ?>" class="<?= ($active ?? '') === 'settings_license' ? 'active' : '' ?>">License</a>
    <?php if ($canMail): ?>
      <a href="<?= e(function_exists('admin_url') ? admin_url('settings_mail') : url('admin/settings_mail.php')) ?>" class="<?= ($active ?? '') === 'mail_settings' ? 'active' : '' ?>"><?= e(t('mail_settings') !== 'mail_settings' ? t('mail_settings') : 'Mail settings') ?></a>
      <a href="<?= e(function_exists('admin_url') ? admin_url('mail_queue') : url('admin/mail_queue.php')) ?>" class="<?= ($active ?? '') === 'mail_queue' ? 'active' : '' ?>"><?= e(t('mail_queue') !== 'mail_queue' ? t('mail_queue') : 'Mail queue') ?></a>
    <?php endif; ?>
    <a href="<?= e(function_exists('admin_url') ? admin_url('settings_discord') : url('admin/settings_discord.php')) ?>" class="<?= ($active ?? '') === 'discord' ? 'active' : '' ?>">Discord</a>
    <a href="<?= e(function_exists('admin_url') ? admin_url('profile_fields') : url('admin/profile_fields.php')) ?>" class="<?= ($active ?? '') === 'profile_fields' ? 'active' : '' ?>">Profile Fields</a>
    <a href="<?= e(url('index.php')) ?>" data-transition="off"><?= e(t('view_site')) ?></a>
  </nav>
</aside>
