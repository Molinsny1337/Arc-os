<?php
declare(strict_types=1);
// Nav should work even before install (welcome.php loads bootstrap only)
if (!function_exists('t')) {
  require_once __DIR__ . '/../includes/bootstrap.php';
}

$site = 'Arc OS';
if ((!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) && function_exists('get_setting')) {
  $site = (string)get_setting('site_name', 'Arc OS');
}

$user = function_exists('current_user') ? current_user() : null;
$isAdmin = function_exists('is_admin') ? is_admin() : false;

$langs = function_exists('supported_langs') ? supported_langs() : [
  'zh-CN' => ['name' => 'Simplified Chinese', 'flag' => 'CN'],
  'en' => ['name' => 'English', 'flag' => 'EN'],
];

$cur = function_exists('lang') ? lang() : 'zh-CN';
$curMeta = $langs[$cur] ?? reset($langs);

if (!function_exists('arc_with_lang')) {
  function arc_with_lang(string $lang): string {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $parts = parse_url($uri);
    $path = $parts['path'] ?? '/';
    $q = [];
    if (!empty($parts['query'])) parse_str($parts['query'], $q);
    $q['lang'] = $lang;
    $qs = http_build_query($q);
    return $path . ($qs ? ('?' . $qs) : '');
  }
}

$unreadAlerts = 0;
$uAvatar = '';
if ($user) {
  if (function_exists('arc_alert_unread_count')) {
    try { $unreadAlerts = arc_alert_unread_count((int)$user['id']); } catch (Throwable $e) {}
  }

  $uAvatar = function_exists('arc_avatar_url') ? arc_avatar_url((string)($user['avatar'] ?? '')) : (base_path() . '/assets/avatar.svg');
}

$home = function_exists('url') ? url('index.php') : '/index.php';
$forum = function_exists('url') ? url('forum.php') : '/forum.php';
$about = function_exists('url') ? url('about.php') : '/about.php';
$apps = function_exists('url') ? url('apps.php') : '/apps.php';
$search = function_exists('url') ? url('search.php') : '/search.php';
$whats_new = function_exists('url') ? url('whats_new.php') : '/whats_new.php';
$members = function_exists('url') ? url('members.php') : '/members.php';
$conversations = function_exists('url') ? url('conversations.php') : '/conversations.php';
$admin = function_exists('admin_url') ? admin_url('index') : (function_exists('url') ? url('admin/index.php') : '/admin/index.php');
$login = function_exists('url') ? url('login.php') : '/login.php';
$register = function_exists('url') ? url('register.php') : '/register.php';
$logout = function_exists('url') ? url('logout.php') : '/logout.php';
$account = function_exists('url') ? url('account.php') : '/account.php';
$profile = function_exists('url') ? url('user.php?id=' . ($user ? (int)$user['id'] : 0)) : '/user.php';
$layoutUrl = '';
if ($isAdmin) {
  $uri = $_SERVER['REQUEST_URI'] ?? '/';
  $parts = parse_url($uri);
  $path = $parts['path'] ?? '/';
  $q = [];
  if (!empty($parts['query'])) parse_str($parts['query'], $q);
  $q['layout'] = '1';
  $layoutUrl = $path . '?' . http_build_query($q);
}
$layoutLabel = function_exists('t') ? t('layout') : 'Layout';
if ($layoutLabel === 'layout') $layoutLabel = 'Layout';
?>

<header class="topbar" data-nav>
  <div class="container nav-inner">
    <a class="brand" href="<?= e($home) ?>"><?= e($site) ?></a>

    <button class="nav-burger" type="button" aria-label="<?= e(t('menu')) ?>" data-burger>
      <span></span><span></span>
    </button>

    <nav class="nav-links" data-links>
      <a href="<?= e($home) ?>"><?= e(t('home')) ?></a>
      <a href="<?= e($forum) ?>"><?= e(t('forum')) ?></a>
      <a href="<?= e($whats_new) ?>"><?= e(t('whats_new')) ?></a>
      <a href="<?= e($members) ?>"><?= e(t('members')) ?></a>
      <a href="<?= e($conversations) ?>"><?= e(t('conversations')) ?></a>
      <a href="<?= e($about) ?>"><?= e(t('about')) ?></a>
      <a href="<?= e($apps) ?>"><?= e(t('apps')) ?></a>
      <a href="<?= e($search) ?>"><?= e(t('search')) ?></a>
      <?php if ($user && $isAdmin): ?>
        <a href="<?= e($admin) ?>"><?= e(t('admin')) ?></a>
        <?php if ($layoutUrl !== ''): ?>
          <a data-transition="off" href="<?= e($layoutUrl) ?>"><?= e($layoutLabel) ?></a>
        <?php endif; ?>
      <?php endif; ?>
    </nav>
    <div class="nav-right">
      <div class="lang">
        <button class="lang-btn" type="button" data-langbtn aria-label="<?= e(t('language')) ?>">
          <span class="flag"><?= e($curMeta['flag']) ?></span>
          <span class="lang-name"><?= e($curMeta['name']) ?></span>
          <span class="chev">&#9662;</span>
        </button>
        <div class="lang-menu" data-langmenu>
          <?php foreach ($langs as $code => $meta): ?>
            <a data-transition="off" href="<?= e(arc_with_lang($code)) ?>" class="<?= $code === $cur ? 'active' : '' ?>">
              <span class="flag"><?= e($meta['flag']) ?></span>
              <span><?= e($meta['name']) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if ($user): ?>
        <div class="userbox">
          <button class="avatar-btn" type="button" data-userbtn aria-label="<?= e(t('account')) ?>">
            <img class="avatar" src="<?= e($uAvatar) ?>" alt="<?= e(t('avatar')) ?>" width="34" height="34" loading="lazy">
          </button>
          <div class="user-menu" data-usermenu>
            <div class="user-meta">
              <div class="user-name"><?= e(function_exists('display_name_of') ? display_name_of($user) : (string)$user['username']) ?></div>
              <div class="muted"><?= e((string)$user['email']) ?></div>
            </div>
            <a data-transition="1" href="<?= e($profile) ?>"><?= e(t('profile')) ?></a>
            <a data-transition="1" href="<?= e($account) ?>"><?= e(t('account')) ?></a>
            <a class="menu-item" href="<?= e(url('notifications.php')) ?>" data-transition="on">
              <?= e(t('notifications')) ?>
              <?php if ($unreadAlerts > 0): ?><span class="badge" style="margin-left:6px"><?= (int)$unreadAlerts ?></span><?php endif; ?>
            </a>
            <a href="<?= e($logout) ?>"><?= e(t('logout')) ?></a>
          </div>
        </div>
      <?php else: ?>
        <a class="nav-cta" href="<?= e($login) ?>"><?= e(t('login')) ?></a>
        <a class="nav-cta ghost" href="<?= e($register) ?>"><?= e(t('register')) ?></a>
      <?php endif; ?>
    </div>
  </div>
</header>

<script>
(() => {
  const burger = document.querySelector('[data-burger]');
  const links = document.querySelector('[data-links]');
  if (burger && links) {
    burger.addEventListener('click', () => {
      links.classList.toggle('open');
      burger.classList.toggle('open');
    });
  }

  const langBtn = document.querySelector('[data-langbtn]');
  const langMenu = document.querySelector('[data-langmenu]');
  if (langBtn && langMenu) {
    langBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      langMenu.classList.toggle('open');
    });
  }

  const userBtn = document.querySelector('[data-userbtn]');
  const userMenu = document.querySelector('[data-usermenu]');
  if (userBtn && userMenu) {
    userBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      userMenu.classList.toggle('open');
    });
  }

  document.addEventListener('click', () => {
    langMenu && langMenu.classList.remove('open');
    userMenu && userMenu.classList.remove('open');
  });
})();
</script>
