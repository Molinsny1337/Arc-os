<?php
declare(strict_types=1);
include __DIR__ . '/footer.php'; ?>