<?php
declare(strict_types=1);
?>
<footer class="wrap footer reveal">
  © <?= date('Y') ?> <?= function_exists('get_setting') ? e(get_setting('site_name','Arc OS')) : 'Arc OS' ?>
</footer>
<?php
// Custom footer HTML (superadmin-controlled in admin UI)
if (function_exists('get_setting')) {
  $footerHtml = (string)get_setting('custom_footer_html', '');
  if (trim($footerHtml) !== '') {
    echo $footerHtml . "\n";
  }
}
?>
<?php $__app_js_v = @filemtime(__DIR__ . '/../assets/app.js') ?: 1; ?>
<script src="<?= e(url('assets/app.js?v=' . $__app_js_v)) ?>"></script>
<?php if (!empty($__need_editor)): ?>
  <?php $__editor_js_v = @filemtime(__DIR__ . '/../assets/editor/editor.js') ?: 1; ?>
  <?php $__editor_preview_v = @filemtime(__DIR__ . '/../assets/editor/preview.js') ?: 1; ?>
  <?php $__editor_toolbar_v = @filemtime(__DIR__ . '/../assets/editor/toolbar.js') ?: 1; ?>
  <?php $__editor_emoji_data_v = @filemtime(__DIR__ . '/../assets/editor/emoji_data.js') ?: 1; ?>
  <?php $__editor_emoji_v = @filemtime(__DIR__ . '/../assets/editor/picker_emoji.js') ?: 1; ?>
  <?php $__editor_uploader_v = @filemtime(__DIR__ . '/../assets/editor/uploader.js') ?: 1; ?>
  <?php $__editor_mentions_v = @filemtime(__DIR__ . '/../assets/editor/mentions.js') ?: 1; ?>
  <?php $__editor_draft_v = @filemtime(__DIR__ . '/../assets/editor/draft.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/editor/editor.js?v=' . $__editor_js_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/preview.js?v=' . $__editor_preview_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/toolbar.js?v=' . $__editor_toolbar_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/emoji_data.js?v=' . $__editor_emoji_data_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/picker_emoji.js?v=' . $__editor_emoji_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/uploader.js?v=' . $__editor_uploader_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/mentions.js?v=' . $__editor_mentions_v)) ?>"></script>
  <script defer src="<?= e(url('assets/editor/draft.js?v=' . $__editor_draft_v)) ?>"></script>
<?php endif; ?>
<?php if (!empty($__need_glass)): ?>
  <?php $__glass_js_v = @filemtime(__DIR__ . '/../assets/apple_glass_light.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/apple_glass_light.js?v=' . $__glass_js_v)) ?>"></script>
  <?php $__xf_js_v = @filemtime(__DIR__ . '/../assets/xf_interactions.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/xf_interactions.js?v=' . $__xf_js_v)) ?>"></script>
<?php endif; ?>
<?php if (!empty($__need_tooltip)): ?>
  <?php $__tooltip_js_v = @filemtime(__DIR__ . '/../assets/user_tooltip.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/user_tooltip.js?v=' . $__tooltip_js_v)) ?>"></script>
<?php endif; ?>
<?php if (!empty($__layout_mode)): ?>
  <?php $__layout_js_v = @filemtime(__DIR__ . '/../assets/layout_mode.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/layout_mode.js?v=' . $__layout_js_v)) ?>"></script>
<?php endif; ?>
<?php
// Custom JS (superadmin-controlled in admin UI)
if (function_exists('get_setting')) {
  $js = (string)get_setting('custom_js', '');
  if (trim($js) !== '') {
    // Prevent breaking out of <script> (best-effort).
    $js = str_ireplace('</script', '</scri' . 'pt', $js);
    echo "<script id=\"custom-js\">\n" . $js . "\n</script>\n";
  }
}
?>
