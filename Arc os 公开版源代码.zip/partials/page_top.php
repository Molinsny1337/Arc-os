<?php
declare(strict_types=1);
// expects: $title (optional)
$langCode = function_exists('lang') ? lang() : 'zh-CN';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/nav.php'; ?>

