<?php
declare(strict_types=1);
$threads = isset($threads) && is_array($threads) ? $threads : [];
$readMap = isset($readMap) && is_array($readMap) ? $readMap : [];
$canModerate = isset($canModerate) ? (bool)$canModerate : false;
if (!$threads):
?>
  <div class="xf-topic-meta"><?= e(function_exists('t') ? t('no_topics') : 'No topics') ?></div>
<?php
  return;
endif;
?>
<div class="xf-thread-list">
  <?php foreach ($threads as $trow): ?>
    <?php
      $threadId = (int)($trow['id'] ?? 0);
      $slug = (string)($trow['slug'] ?? '');
      $title = (string)($trow['title'] ?? '');
      $authorId = (int)($trow['author_id'] ?? 0);
      $author = (string)($trow['author_username'] ?? '');
      $authorAvatar = (string)($trow['author_avatar'] ?? '');
      $created = (string)($trow['created_at'] ?? '');
      $replyCount = (int)($trow['reply_count'] ?? 0);
      $viewCount = (int)($trow['view_count'] ?? 0);
      $lastAt = (string)($trow['last_post_at'] ?? '');
      $lastUser = (string)($trow['last_post_username'] ?? '');
      $prefix = (string)($trow['prefix'] ?? '');
      $prefixCss = (string)($trow['prefix_css'] ?? '');
      $tags = $trow['tags'] ?? [];
      if (is_string($tags)) $tags = array_filter(array_map('trim', explode(',', $tags)));
      if (!is_array($tags)) $tags = [];
      $isSticky = (int)($trow['is_sticky'] ?? 0) === 1;
      $isLocked = (int)($trow['is_locked'] ?? 0) === 1;
      $isFeatured = (int)($trow['is_featured'] ?? 0) === 1;
      $href = url('forum_post.php?slug=' . urlencode($slug));
      $readAt = isset($readMap[$threadId]) ? (string)$readMap[$threadId] : '';
      $isUnread = $lastAt !== '' && ($readAt === '' || strtotime($lastAt) > strtotime($readAt));
    ?>
    <div class="xf-thread-row">
      <?php if ($canModerate): ?>
        <div class="xf-thread-select">
          <input type="checkbox" name="thread_ids[]" value="<?= (int)$threadId ?>" />
        </div>
      <?php endif; ?>
      <a class="xf-thread-link" href="<?= e($href) ?>">
        <span class="xf-avatar" aria-hidden="true">
          <?php if ($authorAvatar !== ''): ?>
            <img src="<?= e(function_exists('arc_avatar_url') ? arc_avatar_url($authorAvatar) : $authorAvatar) ?>" alt="" />
          <?php else: ?>
            <span><?= e(mb_strtoupper(mb_substr($author, 0, 1))) ?></span>
          <?php endif; ?>
        </span>
        <div class="xf-thread-main">
          <div class="xf-thread-title">
            <?php if ($isUnread): ?><span class="xf-unread-dot" aria-hidden="true"></span><?php endif; ?>
            <?php if ($isSticky): ?><span class="xf-status" title="<?= e(t('sticky')) ?>">P</span><?php endif; ?>
            <?php if ($isLocked): ?><span class="xf-status" title="<?= e(t('locked')) ?>">L</span><?php endif; ?>
            <?php if ($isFeatured): ?><span class="xf-status" title="<?= e(t('featured')) ?>">F</span><?php endif; ?>
            <?php if ($prefix !== ''): ?><span class="xf-prefix <?= e($prefixCss) ?>"><?= e($prefix) ?></span><?php endif; ?>
            <span><?= e($title) ?></span>
          </div>
          <div class="xf-meta">
            <?php if ($author !== '' && $authorId > 0): ?>
              <a class="xf-user-link js-user-tooltip" data-user-id="<?= (int)$authorId ?>" href="<?= e(url('user.php?id=' . $authorId)) ?>"><?= e($author) ?></a>
            <?php elseif ($author !== ''): ?>
              <span><?= e($author) ?></span>
            <?php endif; ?>
            <?php if ($created !== ''): ?><span><?= e($created) ?></span><?php endif; ?>
            <?php foreach ($tags as $tag): ?>
              <span class="xf-tag">#<?= e((string)$tag) ?></span>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="xf-thread-stats">
          <div><strong><?= $replyCount ?></strong> <?= e(t('replies')) ?></div>
          <div><strong><?= $viewCount ?></strong> <?= e(t('views')) ?></div>
        </div>
        <div class="xf-thread-last">
          <?php if ($lastUser !== ''): ?><div><?= e($lastUser) ?></div><?php endif; ?>
          <?php if ($lastAt !== ''): ?><div><?= e($lastAt) ?></div><?php endif; ?>
        </div>
      </a>
    </div>
  <?php endforeach; ?>
</div>
