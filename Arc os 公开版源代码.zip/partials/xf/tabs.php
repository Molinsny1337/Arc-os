<?php
declare(strict_types=1);
$tabs = isset($tabs) && is_array($tabs) ? $tabs : [];
$active = isset($active) ? (string)$active : '';
if (!$tabs) return;
?>
<div class="xf-tabs" data-tabs data-default="<?= e($active !== '' ? $active : (string)($tabs[0]['id'] ?? '')) ?>">
  <?php foreach ($tabs as $t): ?>
    <?php
      $id = (string)($t['id'] ?? '');
      $label = (string)($t['label'] ?? '');
      $href = (string)($t['href'] ?? '#');
      $isActive = $active !== '' ? $active === $id : (bool)($t['active'] ?? false);
    ?>
    <a class="xf-tab<?= $isActive ? ' active' : '' ?>" href="<?= e($href) ?>" data-tab="<?= e($id) ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>