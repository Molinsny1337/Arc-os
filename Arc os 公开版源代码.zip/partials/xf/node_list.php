<?php
declare(strict_types=1);
$nodes = isset($nodes) && is_array($nodes) ? $nodes : [];
$readMap = isset($readMap) && is_array($readMap) ? $readMap : [];
if (!$nodes):
?>
  <div class="xf-topic-meta"><?= e(function_exists('t') ? t('no_data') : 'No data') ?></div>
<?php
  return;
endif;

$parents = [];
$children = [];
$order = [];
foreach ($nodes as $node) {
  $id = (int)($node['id'] ?? 0);
  if ($id <= 0) continue;
  $parentId = isset($node['parent_id']) ? (int)$node['parent_id'] : 0;
  if ($parentId <= 0) {
    $parents[$id] = $node;
    $order[] = $id;
  } else {
    if (!isset($children[$parentId])) $children[$parentId] = [];
    $children[$parentId][] = $node;
  }
}

$renderNode = function(array $node, array $subNodes) use ($readMap): string {
  $nid = (int)($node['id'] ?? 0);
  $title = (string)($node['title'] ?? '');
  $desc = (string)($node['description'] ?? '');
  $threads = (int)($node['thread_count'] ?? 0);
  $replies = (int)($node['message_count'] ?? 0);
  $lastAt = (string)($node['last_post_at'] ?? '');
  $lastUser = (string)($node['last_post_username'] ?? '');
  $lastTitle = (string)($node['last_post_title'] ?? '');
  $lastSlug = (string)($node['last_post_slug'] ?? '');
  $url = url('forum_view.php?fid=' . $nid);
  $lastUrl = $lastSlug !== '' ? url('forum_post.php?slug=' . urlencode($lastSlug)) : $url;
  $readAt = isset($readMap[$nid]) ? (string)$readMap[$nid] : '';
  $isUnread = $lastAt !== '' && ($readAt === '' || strtotime($lastAt) > strtotime($readAt));

  ob_start();
  ?>
  <div class="xf-node-row">
    <div class="xf-node-main">
      <a class="xf-node-link" href="<?= e($url) ?>">
        <span class="xf-node-icon<?= $isUnread ? ' is-unread' : '' ?>" aria-hidden="true"></span>
        <div>
          <div class="xf-node-title"><?= e($title) ?></div>
          <?php if ($desc !== ''): ?><div class="xf-node-desc"><?= e($desc) ?></div><?php endif; ?>
        </div>
      </a>
      <?php if ($subNodes): ?>
        <div class="xf-node-sub">
          <?php foreach ($subNodes as $sn): ?>
            <a href="<?= e(url('forum_view.php?fid=' . (int)($sn['id'] ?? 0))) ?>" class="xf-subnode">
              <?= e((string)($sn['title'] ?? '')) ?>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
    <div class="xf-node-stats">
      <div><strong><?= $threads ?></strong> <?= e(t('threads')) ?></div>
      <div><strong><?= $replies ?></strong> <?= e(t('replies')) ?></div>
    </div>
    <div class="xf-node-last">
      <?php if ($lastUser !== ''): ?><div><?= e($lastUser) ?></div><?php endif; ?>
      <?php if ($lastAt !== ''): ?><div><?= e($lastAt) ?></div><?php endif; ?>
      <?php if ($lastTitle !== ''): ?>
        <a href="<?= e($lastUrl) ?>" class="xf-last-title"><?= e($lastTitle) ?></a>
      <?php endif; ?>
    </div>
  </div>
  <?php
  return (string)ob_get_clean();
};
?>

<div class="xf-node-list">
  <?php foreach ($order as $pid): ?>
    <?php
      $parent = $parents[$pid] ?? null;
      if (!$parent) continue;
      $kids = $children[$pid] ?? [];
    ?>
    <?php if ($kids): ?>
      <div class="xf-category">
        <div class="xf-category-head">
          <h2><?= e((string)($parent['title'] ?? '')) ?></h2>
          <?php if (!empty($parent['description'])): ?><p><?= e((string)$parent['description']) ?></p><?php endif; ?>
        </div>
        <div class="xf-category-body">
          <?php foreach ($kids as $child): ?>
            <?php
              $childId = (int)($child['id'] ?? 0);
              $subNodes = $children[$childId] ?? [];
              echo $renderNode($child, $subNodes);
            ?>
          <?php endforeach; ?>
        </div>
      </div>
    <?php else: ?>
      <?php echo $renderNode($parent, []); ?>
    <?php endif; ?>
  <?php endforeach; ?>
</div>
