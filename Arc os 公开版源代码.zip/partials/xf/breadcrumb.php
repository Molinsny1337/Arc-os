<?php
declare(strict_types=1);
$crumbs = isset($crumbs) && is_array($crumbs) ? $crumbs : [];
if (!$crumbs) return;
$label = function_exists('t') ? t('breadcrumb') : 'Breadcrumb';
?>
<nav class="xf-breadcrumb" aria-label="<?= e($label) ?>">
  <?php foreach ($crumbs as $i => $c): ?>
    <?php
      $text = (string)($c['label'] ?? '');
      $href = (string)($c['url'] ?? '');
    ?>
    <?php if ($href !== ''): ?>
      <a href="<?= e($href) ?>"><?= e($text) ?></a>
    <?php else: ?>
      <span><?= e($text) ?></span>
    <?php endif; ?>
    <?php if ($i < count($crumbs) - 1): ?><span class="xf-sep">/</span><?php endif; ?>
  <?php endforeach; ?>
</nav>