<?php
declare(strict_types=1);
$page = isset($page) ? max(1, (int)$page) : 1;
$total_pages = isset($total_pages) ? max(1, (int)$total_pages) : 1;
$base_url = isset($base_url) && is_string($base_url) && $base_url !== '' ? $base_url : (string)($_SERVER['PHP_SELF'] ?? '');
$query = isset($query) && is_array($query) ? $query : [];

if ($total_pages <= 1) return;

$buildUrl = function(int $p) use ($base_url, $query): string {
  $q = $query;
  $q['page'] = $p;
  $qs = http_build_query($q);
  $href = $base_url;
  if ($qs !== '') $href .= (str_contains($href, '?') ? '&' : '?') . $qs;
  return $href;
};
?>
<div class="xf-pager" role="navigation" aria-label="<?= e(function_exists('t') ? t('pagination') : 'Pagination') ?>">
  <?php if ($page > 1): ?>
    <a href="<?= e($buildUrl($page - 1)) ?>">&laquo;</a>
  <?php else: ?>
    <span class="active">&laquo;</span>
  <?php endif; ?>

  <?php
    $start = max(1, $page - 2);
    $end = min($total_pages, $page + 2);
    if ($start > 1) echo '<a href="' . e($buildUrl(1)) . '">1</a>';
    if ($start > 2) echo '<span>...</span>';
    for ($p = $start; $p <= $end; $p++):
  ?>
    <?php if ($p === $page): ?>
      <span class="active"><?= $p ?></span>
    <?php else: ?>
      <a href="<?= e($buildUrl($p)) ?>"><?= $p ?></a>
    <?php endif; ?>
  <?php endfor; ?>
  <?php
    if ($end < $total_pages - 1) echo '<span>...</span>';
    if ($end < $total_pages) echo '<a href="' . e($buildUrl($total_pages)) . '">' . $total_pages . '</a>';
  ?>

  <?php if ($page < $total_pages): ?>
    <a href="<?= e($buildUrl($page + 1)) ?>">&raquo;</a>
  <?php else: ?>
    <span class="active">&raquo;</span>
  <?php endif; ?>
</div>
