<?php
declare(strict_types=1);

$posts = isset($posts) && is_array($posts) ? $posts : [];
$meId = isset($meId) ? (int)$meId : 0;
$canModerate = isset($canModerate) ? (bool)$canModerate : false;
$threadId = isset($threadId) ? (int)$threadId : 0;

$bbPdo = (isset($pdo) && $pdo instanceof PDO) ? $pdo : null;
$bbPfx = isset($pfx) ? (string)$pfx : null;
require_once __DIR__ . '/../../includes/services/BbCode.php';

if (!$posts):
?>
  <div class="xf-topic-meta"><?= e(function_exists('t') ? t('no_data') : 'No data') ?></div>
<?php
  return;
endif;
?>

<div class="xf-post-stream">
  <?php foreach ($posts as $p): ?>
    <?php
      $postType = (string)($p['post_type'] ?? 'comment');
      $postId = (int)($p['id'] ?? 0);
      $authorId = (int)($p['author_id'] ?? 0);
      $author = (string)($p['author_username'] ?? '');
      $display = (string)($p['author_display_name'] ?? '');
      $avatar = (string)($p['author_avatar'] ?? '');
      $userTitle = (string)($p['author_user_title'] ?? '');
      $role = (string)($p['author_role'] ?? '');
      $created = (string)($p['created_at'] ?? '');
      $updated = (string)($p['updated_at'] ?? '');
      $content = (string)($p['content'] ?? '');
      $signature = (string)($p['author_signature'] ?? '');
      $discord = (string)($p['author_discord_username'] ?? '');
      $discordDisc = (string)($p['author_discord_discriminator'] ?? '');
      $isDeleted = (int)($p['is_deleted'] ?? 0) === 1;
      $deleteReason = (string)($p['delete_reason'] ?? '');
      $position = (int)($p['position'] ?? 0);
      $floor = $postType === 'thread' ? 1 : (1 + $position);
      $isMine = $meId > 0 && $authorId === $meId;
      $canEdit = $isMine || $canModerate;
      $canDelete = $isMine || $canModerate;
      if ($discord !== '' && $discordDisc !== '' && $discordDisc !== '0') $discord .= '#' . $discordDisc;
      $profileName = $display !== '' ? $display : $author;
      $msgCount = (int)($p['author_message_count'] ?? 0);
      $reactionScore = (int)($p['author_reaction_score'] ?? 0);
    ?>
    <article class="xf-post" id="post-<?= (int)$postId ?>">
      <aside class="xf-post-author card glass">
        <a class="xf-avatar js-user-tooltip" data-user-id="<?= (int)$authorId ?>" data-transition="1" href="<?= e(url('user.php?id=' . $authorId)) ?>" aria-label="<?= e($profileName) ?>">
          <?php if ($avatar !== ''): ?>
            <img src="<?= e(function_exists('arc_avatar_url') ? arc_avatar_url($avatar) : $avatar) ?>" alt="" loading="lazy" />
          <?php else: ?>
            <span><?= e(mb_strtoupper(mb_substr($profileName, 0, 1))) ?></span>
          <?php endif; ?>
        </a>
        <div class="xf-author-name">
          <a class="js-user-tooltip" data-user-id="<?= (int)$authorId ?>" data-transition="1" href="<?= e(url('user.php?id=' . $authorId)) ?>"><?= e($profileName !== '' ? $profileName : t('user')) ?></a>
        </div>
        <?php if ($userTitle !== ''): ?>
          <div class="xf-author-meta"><?= e($userTitle) ?></div>
        <?php endif; ?>
        <?php if ($role !== '' && $role !== 'registered'): ?>
          <span class="badge" style="margin-top:6px"><?= e($role) ?></span>
        <?php endif; ?>
        <?php if ($discord !== ''): ?>
          <div class="xf-author-meta xf-discord-label">Discord: <?= e($discord) ?></div>
        <?php endif; ?>
        <div class="xf-author-stats">
          <div><strong><?= $msgCount ?></strong> <?= e(t('messages')) ?></div>
          <div><strong><?= $reactionScore ?></strong> <?= e(t('reactions')) ?></div>
        </div>
      </aside>

      <div class="xf-post-body">
        <header class="xf-post-head">
          <div class="xf-post-meta">
            <span class="xf-floor">#<?= (int)$floor ?></span>
            <?php if ($created !== ''): ?><span><?= e($created) ?></span><?php endif; ?>
            <?php if ($updated !== '' && $updated !== $created): ?>
              <span class="xf-edit-note"><?= e(t('edited')) ?></span>
            <?php endif; ?>
          </div>
          <div class="xf-post-links">
            <a href="#post-<?= (int)$postId ?>" class="xf-permalink">?</a>
          </div>
        </header>

        <div class="xf-post-content card glass">
          <?php if ($isDeleted && !$canModerate && !$isMine): ?>
            <div class="xf-deleted"><?= e(t('content_deleted')) ?></div>
          <?php elseif ($isDeleted): ?>
            <div class="xf-deleted">
              <?= e(t('content_deleted')) ?>
              <?php if ($deleteReason !== ''): ?>
                <div class="xf-meta" style="margin-top:6px"><?= e($deleteReason) ?></div>
              <?php endif; ?>
            </div>
          <?php else: ?>
            <?= ArcOS\Services\BbCode::render($content, $bbPdo, $bbPfx) ?>
            <?php if ($signature !== '' && function_exists('get_setting') && get_setting('profile_signatures_enabled', '1') === '1'): ?>
              <div class="xf-signature"><?= ArcOS\Services\BbCode::render($signature, $bbPdo, $bbPfx) ?></div>
            <?php endif; ?>
          <?php endif; ?>
        </div>

        <footer class="xf-post-actions">
          <div class="xf-actions-left">
            <button type="button" class="btn" data-quote-id="<?= (int)$postId ?>" data-quote-type="<?= e($postType === 'thread' ? 'post' : 'comment') ?>"><?= e(t('quote')) ?></button>
            <button type="button" class="btn" data-quote-id="<?= (int)$postId ?>" data-quote-type="<?= e($postType === 'thread' ? 'post' : 'comment') ?>" data-quote-multi="1"><?= e(t('multi_quote')) ?></button>
          </div>
          <div class="xf-actions-right">
            <?php if ($canEdit): ?>
              <?php if ($postType === 'thread'): ?>
                <a class="btn" href="<?= e(url('forum_post_edit.php?id=' . (int)$postId)) ?>"><?= e(t('edit')) ?></a>
              <?php else: ?>
                <a class="btn" href="<?= e(url('forum_comment_edit.php?id=' . (int)$postId)) ?>"><?= e(t('edit')) ?></a>
              <?php endif; ?>
            <?php endif; ?>
            <?php if ($canDelete): ?>
              <?php if (!$isDeleted): ?>
                <form method="post" action="<?= e($postType === 'thread' ? url('forum_post_delete.php') : url('forum_comment_delete.php')) ?>" style="display:inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$postId ?>">
                  <button class="btn" type="submit"><?= e(t('delete')) ?></button>
                </form>
              <?php else: ?>
                <form method="post" action="<?= e($postType === 'thread' ? url('forum_post_restore.php') : url('forum_comment_restore.php')) ?>" style="display:inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$postId ?>">
                  <button class="btn" type="submit"><?= e(t('restore')) ?></button>
                </form>
              <?php endif; ?>
            <?php endif; ?>
            <?php if ($meId > 0): ?>
              <form method="post" action="<?= e(url('report.php')) ?>" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="content_type" value="<?= e($postType === 'thread' ? 'thread' : 'post_comment') ?>">
                <input type="hidden" name="content_id" value="<?= (int)$postId ?>">
                <input type="hidden" name="reason" value="Report">
                <input type="hidden" name="details" value="">
                <button class="btn" type="submit"><?= e(t('report')) ?></button>
              </form>
            <?php endif; ?>
          </div>
        </footer>
      </div>
    </article>
  <?php endforeach; ?>
</div>
