<?php
declare(strict_types=1);
$user = isset($user) && is_array($user) ? $user : [];
if (!$user) return;
$name = function_exists('display_name_of') ? display_name_of($user) : (string)($user['username'] ?? '');
$avatar = (string)($user['avatar'] ?? '');
$href = url('user.php?id=' . (int)($user['id'] ?? 0));
$discord = (string)($user['discord_username'] ?? '');
$discordDisc = (string)($user['discord_discriminator'] ?? '');
if ($discord !== '' && $discordDisc !== '' && $discordDisc !== '0') {
  $discord .= '#' . $discordDisc;
}
?>
<a class="xf-member-row js-user-tooltip" data-user-id="<?= (int)($user['id'] ?? 0) ?>" href="<?= e($href) ?>">
  <span class="xf-avatar">
    <?php if ($avatar !== ''): ?>
      <img src="<?= e(function_exists('arc_avatar_url') ? arc_avatar_url($avatar) : $avatar) ?>" alt="" />
    <?php else: ?>
      <span><?= e(mb_strtoupper(mb_substr($name, 0, 1))) ?></span>
    <?php endif; ?>
  </span>
  <span style="min-width:0">
    <div class="xf-node-title"><?= e($name) ?></div>
    <?php if ($discord !== ''): ?>
      <div class="xf-meta xf-discord-label">Discord: <?= e($discord) ?></div>
    <?php elseif (!empty($user['created_at'])): ?>
      <div class="xf-meta"><?= e((string)$user['created_at']) ?></div>
    <?php endif; ?>
  </span>
  <span class="xf-stats">#<?= (int)($user['id'] ?? 0) ?></span>
</a>
