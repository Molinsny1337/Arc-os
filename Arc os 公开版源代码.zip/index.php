<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
arc_log('visit_home');

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/includes/modules/forum/ForumRepository.php';

$repo = new ArcOS\Modules\Forum\ForumRepository($pdo, $pfx);
$popularNodes = $repo->fetchPopularNodes(6);
$latestThreads = $repo->fetchLatestThreads(8);
$latestMembers = $repo->fetchLatestMembers(16);
$stats = $repo->fetchStats();

$onlineMembers = [];
$onlineCount = 0;
try {
  $stmt = $pdo->prepare("SELECT id, username, avatar, last_active FROM {$pfx}users WHERE last_active >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) ORDER BY last_active DESC LIMIT 12");
  $stmt->execute();
  $onlineMembers = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users WHERE last_active >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
  $stmt->execute();
  $onlineCount = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {
  $onlineMembers = [];
  $onlineCount = 0;
}

$homeTitle = (string)get_setting('home_title', site_name());
$homeTagline = (string)get_setting('home_tagline', t('home_tagline_default'));
$homeSubtitle = (string)get_setting('home_subtitle', '');

$me = current_user();
$isAdmin = function_exists('is_admin') ? is_admin() : false;

$layoutItems = [];
try {
  if ($me && !$isAdmin) {
    $cookieLayout = arc_get_user_ui_layout_cookie((int)($me['id'] ?? 0));
    if ($cookieLayout) $layoutItems = $cookieLayout;
  }
} catch (Throwable $e) {}
if (!$layoutItems) {
  $layoutItems = arc_get_layout_setting_items('home_layout', arc_home_layout_default_items(), arc_home_layout_allowed_ids());
}

$layoutItems = arc_layout_normalize_items($layoutItems, arc_home_layout_default_items(), arc_home_layout_allowed_ids());

$customTitle = (string)get_setting('home_custom_title', '');
$customHtml = (string)get_setting('home_custom_html', '');

$__need_glass = true;
$__need_ui_layout = (bool)$me;
include __DIR__ . '/partials/page_top.php';
?>

<?php
  $layoutScope = $me ? ($isAdmin ? 'home_global' : 'home_user') : '';
  $layoutCanEdit = $me ? '1' : '0';
  $layoutDefault = json_encode(arc_home_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutDefault)) $layoutDefault = '[]';
  $layoutLabels = [];
  foreach (arc_home_layout_allowed_ids() as $id) $layoutLabels[$id] = t('block_' . $id);
  $layoutLabelsJson = json_encode($layoutLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutLabelsJson)) $layoutLabelsJson = '{}';
  $layoutUi = [
    'edit' => t('layout_edit'),
    'done' => t('layout_done'),
    'reset' => t('reset'),
    'blocks' => t('home_blocks'),
    'saved' => t('layout_saved'),
    'save_failed' => t('layout_save_failed'),
    'hide' => t('hide'),
    'show' => t('show'),
  ];
  $layoutUiJson = json_encode($layoutUi, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutUiJson)) $layoutUiJson = '{}';
?>

<main class="wrap home-shell"
  data-arc-layout-root="1"
  data-arc-can-edit="<?= e($layoutCanEdit) ?>"
  data-arc-layout-scope="<?= e($layoutScope) ?>"
  data-arc-save-url="<?= e(url('layout_save.php')) ?>"
  data-arc-csrf="<?= e(csrf_token()) ?>"
  data-arc-default="<?= e($layoutDefault) ?>"
  data-arc-labels="<?= e($layoutLabelsJson) ?>"
  data-arc-ui="<?= e($layoutUiJson) ?>"
>
  <?php foreach ($layoutItems as $it):
    $sid = (string)($it['id'] ?? '');
    $enabled = (bool)($it['enabled'] ?? true);
    if ($sid === '') continue;
  ?>
    <?php if ($sid === 'hero'): ?>
      <header class="home-hero reveal-group" data-arc-layout-item="1" data-id="hero" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-hero-inner">
          <div class="home-hero-copy">
            <div class="home-kicker reveal"><?= e(t('forum')) ?></div>
            <h1 class="reveal"><?= e($homeTitle) ?></h1>
            <p class="reveal home-tagline"><?= e($homeTagline) ?></p>
            <?php if ($homeSubtitle !== ''): ?><p class="reveal home-subtitle"><?= e($homeSubtitle) ?></p><?php endif; ?>
            <div class="home-hero-actions reveal">
              <a class="btn primary" href="<?= e(url('forum.php')) ?>"><?= e(t('enter_forum')) ?></a>
              <a class="btn" href="<?= e(url('whats_new.php')) ?>"><?= e(t('latest_topics')) ?></a>
            </div>
          </div>
          <div class="home-hero-card glass reveal">
            <div class="home-hero-metric">
              <span><?= e(t('online_now')) ?></span>
              <strong><?= (int)$onlineCount ?></strong>
            </div>
            <div class="home-hero-metric">
              <span><?= e(t('threads_today')) ?></span>
              <strong><?= (int)($stats['threads_today'] ?? 0) ?></strong>
            </div>
            <div class="home-hero-metric">
              <span><?= e(t('replies_today')) ?></span>
              <strong><?= (int)($stats['replies_today'] ?? 0) ?></strong>
            </div>
            <a class="btn" href="<?= e(url('members.php')) ?>" style="margin-top:8px"><?= e(t('members')) ?></a>
          </div>
        </div>
      </header>
    <?php elseif ($sid === 'forum_nodes'): ?>
      <section class="home-section reveal-group" data-arc-layout-item="1" data-id="forum_nodes" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-section-head reveal">
          <div>
            <h2><?= e(t('forum_nodes')) ?></h2>
            <p><?= e(t('home_forum_nodes_sub')) ?></p>
          </div>
          <a class="btn" href="<?= e(url('forum.php')) ?>"><?= e(t('view_all')) ?></a>
        </div>
        <div class="home-grid">
          <?php foreach ($popularNodes as $node): ?>
            <a class="home-card glass reveal" href="<?= e(url('forum_view.php?fid=' . (int)$node['id'])) ?>">
              <div class="home-card-icon"><?= e(mb_substr((string)$node['title'], 0, 1)) ?></div>
              <div class="home-card-title"><?= e((string)$node['title']) ?></div>
              <?php if (!empty($node['description'])): ?>
                <div class="home-card-desc"><?= e((string)$node['description']) ?></div>
              <?php endif; ?>
              <div class="home-card-meta">
                <span><?= (int)($node['thread_count'] ?? 0) ?> <?= e(t('threads')) ?></span>
                <span><?= (int)($node['message_count'] ?? 0) ?> <?= e(t('replies')) ?></span>
              </div>
              <?php if (!empty($node['last_post_at'])): ?>
                <div class="home-card-last">
                  <?= e(t('last_post')) ?> · <?= e((string)$node['last_post_at']) ?>
                </div>
              <?php endif; ?>
            </a>
          <?php endforeach; ?>
          <?php if (!$popularNodes): ?>
            <div class="home-card glass reveal">
              <div class="home-card-title"><?= e(t('no_data')) ?></div>
              <div class="home-card-desc"><?= e(t('be_first')) ?></div>
            </div>
          <?php endif; ?>
        </div>
      </section>
    <?php elseif ($sid === 'latest_topics'): ?>
      <section class="home-section reveal-group" data-arc-layout-item="1" data-id="latest_topics" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-section-head reveal">
          <div>
            <h2><?= e(t('latest_topics')) ?></h2>
            <p><?= e(t('home_latest_topics_sub')) ?></p>
          </div>
          <a class="btn" href="<?= e(url('whats_new.php')) ?>"><?= e(t('whats_new')) ?></a>
        </div>
        <div class="home-thread-list">
          <?php foreach ($latestThreads as $trow): ?>
            <?php
              $href = url('forum_post.php?slug=' . urlencode((string)$trow['slug']));
              $forumTitle = (string)($trow['forum_title'] ?? '');
              $excerpt = (string)($trow['excerpt'] ?? '');
              if ($excerpt === '') {
                $excerpt = trim((string)($trow['title'] ?? ''));
              }
            ?>
            <a class="home-thread-row reveal" href="<?= e($href) ?>">
              <div class="home-thread-avatar">
                <?php if (!empty($trow['author_avatar'])): ?>
                  <img src="<?= e(arc_avatar_url((string)$trow['author_avatar'])) ?>" alt="" />
                <?php else: ?>
                  <span><?= e(mb_strtoupper(mb_substr((string)($trow['author_username'] ?? '?'), 0, 1))) ?></span>
                <?php endif; ?>
              </div>
              <div class="home-thread-body">
                <div class="home-thread-title"><?= e((string)$trow['title']) ?></div>
                <div class="home-thread-meta">
                  <span><?= e($forumTitle !== '' ? $forumTitle : t('forum')) ?></span>
                  <span><?= e((string)($trow['author_username'] ?? '')) ?></span>
                  <span><?= e((string)($trow['created_at'] ?? '')) ?></span>
                </div>
              </div>
              <div class="home-thread-stats">
                <span><?= (int)($trow['reply_count'] ?? 0) ?> <?= e(t('replies')) ?></span>
                <span><?= (int)($trow['view_count'] ?? 0) ?> <?= e(t('views')) ?></span>
              </div>
            </a>
          <?php endforeach; ?>
          <?php if (!$latestThreads): ?>
            <div class="home-thread-empty reveal"><?= e(t('no_topics')) ?></div>
          <?php endif; ?>
        </div>
      </section>
    <?php elseif ($sid === 'today_stats'): ?>
      <section class="home-section reveal-group" data-arc-layout-item="1" data-id="today_stats" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-section-head reveal">
          <div>
            <h2><?= e(t('today_stats')) ?></h2>
            <p><?= e(t('home_stats_sub')) ?></p>
          </div>
        </div>
        <div class="home-stats">
          <div class="home-stat-card glass reveal">
            <div class="home-stat-title"><?= e(t('threads')) ?></div>
            <div class="home-stat-value"><?= (int)($stats['threads_total'] ?? 0) ?></div>
            <div class="home-stat-meta"><?= e(t('today')) ?>: <?= (int)($stats['threads_today'] ?? 0) ?></div>
          </div>
          <div class="home-stat-card glass reveal">
            <div class="home-stat-title"><?= e(t('replies')) ?></div>
            <div class="home-stat-value"><?= (int)($stats['replies_total'] ?? 0) ?></div>
            <div class="home-stat-meta"><?= e(t('today')) ?>: <?= (int)($stats['replies_today'] ?? 0) ?></div>
          </div>
          <div class="home-stat-card glass reveal">
            <div class="home-stat-title"><?= e(t('members')) ?></div>
            <div class="home-stat-value"><?= (int)($stats['members_total'] ?? 0) ?></div>
            <div class="home-stat-meta"><?= e(t('today')) ?>: <?= (int)($stats['members_today'] ?? 0) ?></div>
          </div>
          <div class="home-stat-card glass reveal">
            <div class="home-stat-title"><?= e(t('online_now')) ?></div>
            <div class="home-stat-value"><?= (int)$onlineCount ?></div>
            <div class="home-stat-meta"><?= e(t('active_5m')) ?></div>
          </div>
        </div>
        <div class="home-online-wall">
          <?php foreach ($onlineMembers as $m): ?>
            <a class="home-avatar-chip reveal" href="<?= e(url('user.php?id=' . (int)$m['id'])) ?>" data-transition="1">
              <?php if (!empty($m['avatar'])): ?>
                <img src="<?= e(arc_avatar_url((string)$m['avatar'])) ?>" alt="" />
              <?php else: ?>
                <span><?= e(mb_strtoupper(mb_substr((string)$m['username'], 0, 1))) ?></span>
              <?php endif; ?>
            </a>
          <?php endforeach; ?>
          <?php if (!$onlineMembers): ?>
            <div class="home-thread-empty reveal"><?= e(t('no_data')) ?></div>
          <?php endif; ?>
        </div>
      </section>
    <?php elseif ($sid === 'new_members'): ?>
      <section class="home-section reveal-group" data-arc-layout-item="1" data-id="new_members" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-section-head reveal">
          <div>
            <h2><?= e(t('new_members')) ?></h2>
            <p><?= e(t('home_new_members_sub')) ?></p>
          </div>
          <a class="btn" href="<?= e(url('members.php')) ?>"><?= e(t('members')) ?></a>
        </div>
        <div class="home-avatars">
          <?php foreach ($latestMembers as $m): ?>
            <a class="home-avatar-card reveal" href="<?= e(url('user.php?id=' . (int)$m['id'])) ?>" data-transition="1">
              <div class="home-avatar-img">
                <?php if (!empty($m['avatar'])): ?>
                  <img src="<?= e(arc_avatar_url((string)$m['avatar'])) ?>" alt="" />
                <?php else: ?>
                  <span><?= e(mb_strtoupper(mb_substr((string)$m['username'], 0, 1))) ?></span>
                <?php endif; ?>
              </div>
              <div class="home-avatar-name"><?= e((string)$m['username']) ?></div>
            </a>
          <?php endforeach; ?>
        </div>
      </section>
    <?php elseif ($sid === 'custom_html'): ?>
      <section class="home-section reveal-group" data-arc-layout-item="1" data-id="custom_html" <?= $enabled ? '' : 'hidden' ?>>
        <div class="home-section-head reveal">
          <div>
            <h2><?= e($customTitle !== '' ? $customTitle : t('custom_block')) ?></h2>
          </div>
        </div>
        <div class="home-card glass reveal">
          <?php if (trim(strip_tags($customHtml)) !== ''): ?>
            <?= arc_render_richtext($customHtml) ?>
          <?php else: ?>
            <div class="muted"><?= e(t('custom_block_tip')) ?></div>
          <?php endif; ?>
        </div>
      </section>
    <?php endif; ?>
  <?php endforeach; ?>
</main>

<?php include __DIR__ . '/partials/dock.php'; ?>
<?php include __DIR__ . '/partials/page_bottom.php'; ?>
