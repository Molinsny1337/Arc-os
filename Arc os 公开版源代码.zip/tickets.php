<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();

$me = current_user();
$title = t('tickets');
$__need_editor = true;
$__need_glass = true;
require_once __DIR__ . '/includes/services/BbCode.php';

$err = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  require_csrf();
  arc_rate_limit('tickets_create_' . (int)$me['id'], 12, 300);
  try {
    $subject = (string)($_POST['subject'] ?? '');
    $message = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
    $id = arc_ticket_create((int)$me['id'], $subject, $message);
    arc_log('ticket_create', 'ticket', $id);
    redirect(url('ticket.php?id=' . $id));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$tickets = arc_user_tickets((int)$me['id'], 80, 0);
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap" style="padding-top:28px;padding-bottom:80px;">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('tickets')) ?></h1>
      <p class="reveal"><?= e(t('tickets_sub')) ?></p>
    </header>

    <?php if ($err): ?>
      <div class="alert reveal"><?= e($err) ?></div>
    <?php endif; ?>

    <section class="reveal-group" id="create" style="margin-top:16px;">
      <div class="card reveal" style="padding:16px;">
        <div style="font-weight:800;"><?= e(t('create_ticket')) ?></div>
        <div style="color:var(--muted);font-size:13px;margin-top:6px;"><?= e(t('create_ticket_tip')) ?></div>

        <form method="post" data-overlay="1" style="margin-top:12px;display:grid;gap:10px;">
          <?= csrf_field() ?>
          <div class="field">
            <label class="label"><?= e(t('ticket_subject')) ?></label>
            <input class="input" name="subject" maxlength="191" placeholder="<?= e(t('ticket_subject_placeholder')) ?>" required />
          </div>
          <div class="field">
            <label class="label"><?= e(t('ticket_message')) ?></label>
            <?php
              $content_name = 'message';
              $initial_value = '';
              $mode = 'ticket_new';
              $attachments_enabled = true;
              $placeholder = t('ticket_message_placeholder');
              $draft_key = 'ticket_new_' . (int)$me['id'];
              $content_type = 'ticket';
              $content_id = 0;
              include __DIR__ . '/partials/editor/editor_widget.php';
            ?>
          </div>
          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="btn primary" type="submit"><?= e(t('submit_ticket')) ?></button>
          </div>
        </form>
      </div>
    </section>

    <section class="reveal-group" style="margin-top:14px;">
      <div class="card reveal" style="padding:16px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
          <div style="font-weight:800;"><?= e(t('my_tickets')) ?></div>
          <a class="btn" href="<?= e(url('account.php')) ?>"><?= e(t('account')) ?></a>
        </div>

        <?php if (!$tickets): ?>
          <div style="margin-top:12px;color:var(--muted);"><?= e(t('no_tickets')) ?></div>
        <?php else: ?>
          <div style="margin-top:12px;display:grid;gap:10px;">
            <?php foreach ($tickets as $t): ?>
              <?php
                $tid = (int)($t['id'] ?? 0);
                $sub = (string)($t['subject'] ?? '');
                $status = (string)($t['status'] ?? 'open');
                $badge = $status === 'closed' ? 'badge closed' : 'badge open';
              ?>
              <a class="card" href="<?= e(url('ticket.php?id=' . $tid)) ?>" style="padding:14px;display:block;border:1px solid rgba(0,0,0,.08);border-radius:16px;background:rgba(255,255,255,.7);">
                <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
                  <div style="font-weight:750;"><?= e($sub) ?></div>
                  <span class="<?= e($badge) ?>"><?= e($status === 'closed' ? t('status_closed') : t('status_open')) ?></span>
                </div>
                <div style="margin-top:6px;color:var(--muted);font-size:13px;display:flex;justify-content:space-between;gap:10px;">
                  <span>#<?= (int)$tid ?></span>
                  <span><?= e((string)($t['updated_at'] ?? '')) ?></span>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
