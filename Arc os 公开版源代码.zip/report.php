<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

require_once __DIR__ . '/includes/services/ReportService.php';

$me = current_user();
$type = trim((string)($_POST['content_type'] ?? ''));
$contentId = (int)($_POST['content_id'] ?? 0);
$reason = trim((string)($_POST['reason'] ?? ''));
$details = trim((string)($_POST['details'] ?? ''));
$back = $_SERVER['HTTP_REFERER'] ?? url('index.php');

if ($type === '' || $contentId <= 0 || $reason === '') {
  redirect($back);
}

$pdo = db();
$pfx = table_prefix();
ArcOS\Services\ReportService::create($pdo, $pfx, (int)$me['id'], $type, $contentId, $reason, $details);

redirect($back);
