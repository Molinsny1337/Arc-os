<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$me = current_user();
if (!$me) redirect(url('login.php'));
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'react');
require_not_banned();
require_post();
require_csrf();
arc_rate_limit('react', 120, 60);

$pdo = db();
$pfx = table_prefix();

$postId = (int)($_POST['post_id'] ?? 0);
$reaction = trim((string)($_POST['reaction'] ?? 'like'));
$types = arc_reaction_types();
if (!$postId || !isset($types[$reaction])) {
  redirect($_SERVER['HTTP_REFERER'] ?? url('index.php'));
}

try {
  // toggle reaction
  $stmt = $pdo->prepare("SELECT id FROM {$pfx}post_reactions WHERE post_id=? AND user_id=? AND reaction=? LIMIT 1");
  $stmt->execute([$postId, (int)$me['id'], $reaction]);
  $id = $stmt->fetchColumn();
  if ($id) {
    $pdo->prepare("DELETE FROM {$pfx}post_reactions WHERE id=?")->execute([(int)$id]);
  } else {
    $pdo->prepare("INSERT IGNORE INTO {$pfx}post_reactions (post_id, user_id, reaction, created_at) VALUES (?,?,?,NOW())")
        ->execute([$postId, (int)$me['id'], $reaction]);
  }
} catch (Throwable $e) {}

redirect($_SERVER['HTTP_REFERER'] ?? url('index.php'));
