<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
$me = current_user();
if (!$me) redirect(url('login.php'));
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'post_profile');
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';
require_once __DIR__ . '/includes/services/ProfileService.php';
require_not_banned();
require_post();
require_csrf();
arc_rate_limit('profile_post_comment', 120, 60);

$pdo = db();
$pfx = table_prefix();

$ppid = (int)($_POST['profile_post_id'] ?? 0);
$msg = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
if ($ppid<=0 || $msg==='') redirect($_SERVER['HTTP_REFERER'] ?? url('index.php'));

if (function_exists('get_setting') && get_setting('profile_posts_enabled', '1') !== '1') {
  http_response_code(403);
  exit('Profile posts disabled');
}

$stmt0 = $pdo->prepare("SELECT user_id FROM {$pfx}xf_profile_posts WHERE id=? LIMIT 1");
$stmt0->execute([$ppid]);
$profileUserId = (int)($stmt0->fetchColumn() ?: 0);
if ($profileUserId > 0 && !ArcOS\Services\ProfileService::canPostOnProfile($pdo, $pfx, (int)$me['id'], $profileUserId)) {
  redirect(url('user.php?id=' . $profileUserId));
}

try {
$stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_post_comments (profile_post_id, user_id, message_bbcode, is_deleted, created_at)
  VALUES (?,?,?,?,NOW())");
$stmt->execute([$ppid, (int)$me['id'], $msg, 0]);
$commentId = (int)$pdo->lastInsertId();
  $draftKey = trim((string)($_POST['draft_key'] ?? ''));
  if ($draftKey !== '') {
    ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'profile_post_comment', $commentId);
  }
  ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'profile_post_comment', $commentId, $msg);
  $tags = ArcOS\Services\MentionService::extractTags($msg);
  ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'profile_post_comment', $commentId, $tags);
  // alert owner of profile post (not necessarily profile owner)
  $stmt2 = $pdo->prepare("SELECT user_id, author_user_id FROM {$pfx}xf_profile_posts WHERE id=?");
  $stmt2->execute([$ppid]);
  $row = $stmt2->fetch(PDO::FETCH_ASSOC);
  if ($row) {
    $owner = (int)$row['user_id'];
    $author = (int)$row['author_user_id'];
    if (function_exists('arc_create_alert')) {
      if ($owner && $owner !== (int)$me['id']) arc_create_alert($owner, (int)$me['id'], 'profile_post_comment', 'profile_post', $ppid, []);
      if ($author && $author !== (int)$me['id'] && $author !== $owner) arc_create_alert($author, (int)$me['id'], 'profile_post_comment', 'profile_post', $ppid, []);
    } else {
      if ($owner && $owner !== (int)$me['id']) arc_add_alert($owner, 'profile_post_comment', $ppid, (string)$me['username'], null);
      if ($author && $author !== (int)$me['id'] && $author !== $owner) arc_add_alert($author, 'profile_post_comment', $ppid, (string)$me['username'], null);
    }
  }
} catch (Throwable $e) {}

redirect($_SERVER['HTTP_REFERER'] ?? url('index.php'));
