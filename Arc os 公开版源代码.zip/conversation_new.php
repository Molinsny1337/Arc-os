<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$me = current_user();
if (!$me) redirect(url('login.php?next=' . urlencode(url('conversation_new.php'))));
require_once __DIR__ . '/includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'start_conversation');
require_not_banned();
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/includes/conversations.php';

$err = '';
$formTitle = '';
$to = '';
$message = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
  $to = trim((string)($_GET['to'] ?? ''));
  $formTitle = trim((string)($_GET['title'] ?? ''));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_post();
  require_csrf();
  arc_rate_limit('conv_new', 20, 60);

  $formTitle = trim((string)($_POST['title'] ?? ''));
  $to = trim((string)($_POST['to'] ?? ''));
  $message = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));

  if ($to === '' || $message === '') {
    $err = t('fill_all');
  } else {
    $names = preg_split('/[\\s,，]+/u', $to, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $names = array_values(array_unique(array_slice($names, 0, 10)));

    $ids = [];
    if ($names) {
      $in = implode(',', array_fill(0, count($names), '?'));
      $stmt = $pdo->prepare("SELECT id FROM {$pfx}users WHERE username IN ({$in}) LIMIT 20");
      $stmt->execute($names);
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      foreach ($rows as $r) {
        $uid = (int)($r['id'] ?? 0);
        if ($uid > 0 && $uid !== (int)$me['id']) $ids[] = $uid;
      }
    }
    $ids = array_values(array_unique($ids));

    if (!$ids) {
      $err = t('user_not_found');
    } else {
      $cid = conv_create($pdo, $pfx, (int)$me['id'], $ids, $formTitle, $message);
      if ($cid > 0) {
        $stmt = $pdo->prepare("SELECT last_message_id FROM {$pfx}conversations WHERE id=? LIMIT 1");
        $stmt->execute([$cid]);
        $mid = (int)$stmt->fetchColumn();
        if ($mid > 0) {
          $draftKey = trim((string)($_POST['draft_key'] ?? ''));
          if ($draftKey !== '') {
            ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'conversation', $mid);
          }
          ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'conversation', $mid, $message);
          $tags = ArcOS\Services\MentionService::extractTags($message);
          ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'conversation', $mid, $tags);
        }
        foreach ($ids as $uid) {
          arc_add_alert((int)$uid, 'conversation', (int)$cid, (string)$me['username'], json_encode(['title' => $formTitle], JSON_UNESCAPED_UNICODE));
        }
        redirect(url('conversation.php?id=' . (int)$cid));
      } else {
        $err = t('install_failed');
      }
    }
  }
}

$title = site_name() . ' - ' . t('new_conversation');
$__need_glass = true;
$__need_editor = true;
?>
<?php include __DIR__ . '/partials/page_top.php'; ?>

<main class="wrap">
  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e(t('new_conversation')) ?></h1>
      <p class="reveal"><?= e(t('new_conversation_sub')) ?></p>
    </div>
    <div class="card glass xf-hero-card reveal">
      <div class="xf-meta"><?= e(t('usernames_hint')) ?></div>
    </div>
  </header>

  <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>

  <section class="section reveal-group">
    <form class="form glass reveal" method="post" data-overlay="1">
      <?= csrf_field() ?>

      <div class="field">
        <label class="label"><?= e(t('title')) ?> (<?= e(t('optional')) ?>)</label>
        <input class="input" name="title" value="<?= e($formTitle) ?>" maxlength="191" />
      </div>

      <div class="field">
        <label class="label"><?= e(t('to')) ?></label>
        <input class="input" name="to" value="<?= e($to) ?>" placeholder="alice, bob" />
        <div class="note"><?= e(t('usernames_hint')) ?></div>
      </div>

      <div class="field">
        <label class="label"><?= e(t('content')) ?></label>
        <?php
          $draftKey = 'conv_new_' . (int)($me['id'] ?? 0);
          $content_name = 'message';
          $initial_value = $message;
          $mode = 'conversation';
          $attachments_enabled = true;
          $placeholder = t('content_placeholder');
          $content_id = 0;
          $draft_key = $draftKey;
          include __DIR__ . '/partials/editor/editor_widget.php';
        ?>
      </div>

      <button class="btn" type="submit"><?= e(t('send')) ?></button>
    </form>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
