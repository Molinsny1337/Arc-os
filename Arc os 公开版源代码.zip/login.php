<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/DiscordOAuthService.php';

$title = t('login') . ' - ' . site_name();
$err = '';
$discordEnabled = ArcOS\Services\DiscordOAuthService::isConfigured();

$next = (string)($_POST['next'] ?? ($_GET['next'] ?? url('index.php')));
if (!str_starts_with($next, base_path())) {
  $next = url('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('login', 20, 300);
  $username = (string)($_POST['username'] ?? '');
  $password = (string)($_POST['password'] ?? '');

  try {
    if (turnstile_required('login')) {
      $token = (string)($_POST['cf-turnstile-response'] ?? '');
      if (!verify_turnstile($token)) {
        throw new RuntimeException(t('captcha_failed'));
      }
    }

    if (!login_attempt($username, $password, null)) {
      arc_log('login_failed', null, null, ['u'=>$username]);
      throw new RuntimeException(t('login_failed'));
    }
    $u = current_user();
    arc_log('login_success', 'user', $u ? (int)$u['id'] : null);
    $hello = $u['username'] ?? $username;
    redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode(t('welcome_title')) . '&to=' . urlencode($next));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <div class="overlay">
    <div class="overlay-card">
      <div class="title"><?= e(t('logging_in')) ?></div>
      <div class="sub"><?= e(t('please_wait')) ?></div>
    </div>
  </div>

  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('login')) ?></h1>
      <p class="reveal"><?= e(t('login_sub')) ?></p>
    </header>

    <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>

    <section class="reveal-group">
      <form class="form reveal" method="post" data-overlay="1">
        <?= csrf_field() ?>
        <div class="field">
          <label class="label"><?= e(t('username_or_email')) ?></label>
          <input class="input" name="username" placeholder="<?= e(t('username_or_email_placeholder')) ?>" />
        </div>
        <div class="field">
          <label class="label"><?= e(t('password')) ?></label>
          <input class="input" type="password" name="password" placeholder="********" />
        </div>
        <button class="btn" type="submit"><?= e(t('login')) ?></button>
        <?php if ($discordEnabled): ?>
          <a class="btn btn-discord" href="<?= e(url('discord/auth') . '?next=' . urlencode($next)) ?>" style="margin-left:8px"><?= e('Discord') ?></a>
        <?php endif; ?>
        <input type="hidden" name="next" value="<?= e($next) ?>" />
        <div class="note"><?= e(t('no_account')) ?><a href="<?= e(url('register.php')) ?>"><?= e(t('register')) ?></a></div>
      </form>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
