<?php
declare(strict_types=1);
define('ARC_PREINSTALL', true);
require_once __DIR__ . '/includes/bootstrap.php';

function arc_installed_flag(): bool {
  $lock = __DIR__ . '/data/installed.lock';
  if (is_file($lock)) return true;

  $cfgPath = __DIR__ . '/includes/config.php';
  if (!is_file($cfgPath)) return false;
  $cfg = require $cfgPath;
  if (!is_array($cfg)) return false;
  $host = trim((string)($cfg['host'] ?? ''));
  $name = trim((string)($cfg['name'] ?? ''));
  return ($host !== '' && $name !== '');
}

$installed = arc_installed_flag();
$continueUrl = $installed ? url('forum.php') : url('install.php');

$langCode = lang();
$langs = supported_langs();
$title = t('welcome_title');
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/welcome_head.php'; ?>
</head>
<body class="welcome-page">
  <main class="welcome-shell">
    <section class="welcome-card">
      <div id="helloText" class="welcome-hello"><?= e(t('welcome_hello')) ?></div>
      <div id="helloLang" class="welcome-lang"><?= e(($langs[$langCode]['name'] ?? $langCode)) ?></div>

      <a class="welcome-btn" href="<?= e($continueUrl) ?>" data-transition="off"><?= e(t('continue')) ?></a>
      <p class="welcome-sub"><?= e(t('welcome_sub')) ?></p>
    </section>
  </main>
  <?php include __DIR__ . '/partials/welcome_footer.php'; ?>
</body>
</html>
