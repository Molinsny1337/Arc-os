<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_not_banned();
require_post();
require_csrf();
arc_rate_limit('upload_image', 20, 60);

header('Content-Type: application/json; charset=utf-8');

$me = current_user();
if (!$me) {
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>t('login_required')], JSON_UNESCAPED_UNICODE);
  exit;
}
if ((int)($me['is_verified'] ?? 0) !== 1) {
  http_response_code(403);
  echo json_encode(['ok'=>false,'error'=>t('not_verified')], JSON_UNESCAPED_UNICODE);
  exit;
}

if (empty($_FILES['image']) || !is_array($_FILES['image'])) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>t('missing_image_file')], JSON_UNESCAPED_UNICODE);
  exit;
}

$f = $_FILES['image'];
if (($f['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>sprintf(t('upload_failed_code_fmt'), (int)$f['error'])], JSON_UNESCAPED_UNICODE);
  exit;
}

$max = 5 * 1024 * 1024; // 5MB
$size = (int)($f['size'] ?? 0);
if ($size <= 0 || $size > $max) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>t('image_size_invalid')], JSON_UNESCAPED_UNICODE);
  exit;
}

$tmp = (string)($f['tmp_name'] ?? '');
if ($tmp === '' || !is_uploaded_file($tmp)) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>t('invalid_upload_file')], JSON_UNESCAPED_UNICODE);
  exit;
}

// Validate mime
$mime = '';
if (function_exists('finfo_open')) {
  $fi = finfo_open(FILEINFO_MIME_TYPE);
  if ($fi) { $mime = (string)finfo_file($fi, $tmp); finfo_close($fi); }
}
$allowed = [
  'image/jpeg' => 'jpg',
  'image/png' => 'png',
  'image/webp' => 'webp',
  'image/gif' => 'gif',
];
$ext = $allowed[$mime] ?? '';
if ($ext === '') {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>t('unsupported_image_type')], JSON_UNESCAPED_UNICODE);
  exit;
}

$dirFs = __DIR__ . '/uploads/editor';
$dirUrl = 'uploads/editor';
@mkdir($dirFs, 0775, true);
@file_put_contents($dirFs . '/index.html', '');

$name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
$destFs = $dirFs . '/' . $name;

if (!move_uploaded_file($tmp, $destFs)) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>t('save_image_failed')], JSON_UNESCAPED_UNICODE);
  exit;
}

// Hardening: remove exec bit
@chmod($destFs, 0644);

$urlOut = url($dirUrl . '/' . $name);

arc_log('upload_image','image', 0, ['user_id'=>(int)$me['id'], 'path'=>$dirUrl . '/' . $name]);

echo json_encode(['ok'=>true,'url'=>$urlOut], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
