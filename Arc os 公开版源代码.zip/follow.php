<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_not_banned();

require_post();
require_csrf();
arc_rate_limit('follow', 30, 60);

$me = current_user();
$target_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
$action = (string)($_POST['action'] ?? 'toggle');
$back = $_SERVER['HTTP_REFERER'] ?? (base_path() . '/');

if ($target_id <= 0 || $target_id === (int)$me['id']) {
  header('Location: ' . $back);
  exit;
}

$pdo = db();
$pfx = table_prefix();

if ($action === 'unfollow') {
  $st = $pdo->prepare("DELETE FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=?");
  $st->execute([(int)$me['id'], $target_id]);
} elseif ($action === 'follow') {
  $st = $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_user_follow (follower_id, followed_id, created_at) VALUES (?,?,NOW())");
  $st->execute([(int)$me['id'], $target_id]);
} else { // toggle
  $st = $pdo->prepare("SELECT 1 FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=? LIMIT 1");
  $st->execute([(int)$me['id'], $target_id]);
  $exists = (bool)$st->fetchColumn();
  if ($exists) {
    $st = $pdo->prepare("DELETE FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=?");
    $st->execute([(int)$me['id'], $target_id]);
  } else {
    $st = $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_user_follow (follower_id, followed_id, created_at) VALUES (?,?,NOW())");
    $st->execute([(int)$me['id'], $target_id]);
  }
}

header('Location: ' . $back);
exit;
