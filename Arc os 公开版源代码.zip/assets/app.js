(() => {
  const base = (window.__BASE_PATH__ || "").replace(/\/$/, "");
  const TRANSITION_PAGE = base + "/transition.php";
  const NAV_DELAY_MS = 50;
  const CLICK_EFFECT = String(window.__CLICK_EFFECT__ || "none").toLowerCase();

  // Track last pointer position for click-origin ripple
  const lastPtr = { x: null, y: null, t: 0 };

  function spawnClickRipple(x, y) {
    try {
      if (CLICK_EFFECT !== "ripple") return;
      if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      if (!document.body) return;

      const el = document.createElement("div");
      el.className = "arc-click-ripple";
      el.style.left = x + "px";
      el.style.top = y + "px";
      document.body.appendChild(el);

      const cleanup = () => { try { el.remove(); } catch {} };
      el.addEventListener("animationend", cleanup, { once: true });
      setTimeout(cleanup, 1200);
    } catch {}
  }

  // ---------- Tiny click sound (WebAudio, no files) ----------
  let audioCtx = null;
  function playClick() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!audioCtx) audioCtx = new AC();
      if (audioCtx.state === "suspended") audioCtx.resume();

      const t = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(1200, t);

      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.05, t + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start(t);
      osc.stop(t + 0.065);
    } catch {}
  }

  document.addEventListener(
    "pointerdown",
    (e) => {
      // Record click position for the next navigation
      if (typeof e.clientX === "number" && typeof e.clientY === "number") {
        lastPtr.x = e.clientX;
        lastPtr.y = e.clientY;
        lastPtr.t = performance.now();
        if (e.button === 0) spawnClickRipple(e.clientX, e.clientY);
      }

      // Sound only for left-click on links (can be disabled via data-sound="off")
      if (e.button !== 0) return;
      const a = e.target.closest("a");
      if (!a) return;
      if (a.dataset.sound === "off") return;
      playClick();
    },
    { capture: true }
  );

  function isModifiedClick(e) {
    return e.metaKey || e.ctrlKey || e.shiftKey || e.altKey;
  }

  function transitionEnabled(a) {
    const raw = a.dataset.transition;
    if (raw == null || raw === "") {
      // Default: ON for internal links
      return true;
    }
    const v = String(raw).toLowerCase().trim();
    if (v === "0" || v === "off" || v === "false" || v === "no") return false;
    return true;
  }

  // ---------- Transition for internal links ----------
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a");
    if (!a) return;

    if (!transitionEnabled(a)) return;
    if (a.hasAttribute("download")) return;
    if (a.target && a.target !== "_self") return;
    if (isModifiedClick(e)) return;

    const href = a.getAttribute("href");
    if (!href) return;

    if (href.startsWith("#")) return;
    if (
      href.startsWith("mailto:") ||
      href.startsWith("tel:") ||
      href.startsWith("javascript:")
    )
      return;

    let url;
    try {
      url = new URL(href, location.href);
    } catch {
      return;
    }

    // external: don't hijack
    if (url.origin !== location.origin) return;

    // same-page hash nav: don't hijack
    if (url.pathname === location.pathname && url.search === location.search && url.hash) return;

    e.preventDefault();

    const to = url.pathname + url.search + url.hash;

    // Use last pointer coords if recent
    const now = performance.now();
    let x = null;
    let y = null;
    if (lastPtr.x != null && lastPtr.y != null && now - lastPtr.t < 900) {
      x = Math.max(0, Math.min(Math.round(lastPtr.x), innerWidth));
      y = Math.max(0, Math.min(Math.round(lastPtr.y), innerHeight));
    }

    const params = new URLSearchParams();
    params.set("to", to);
    if (x != null && y != null) {
      params.set("x", String(x));
      params.set("y", String(y));
    }

    const rippleUrl = `${TRANSITION_PAGE}?${params.toString()}`;

    setTimeout(() => {
      location.href = rippleUrl;
    }, NAV_DELAY_MS);
  });

  // ---------- Scroll reveal ----------
  function initReveal() {
    document.querySelectorAll(".reveal-group").forEach((group) => {
      group.querySelectorAll(".reveal").forEach((el, i) => {
        el.style.setProperty("--i", i);
      });
    });

    const els = document.querySelectorAll(".reveal");
    if (!els.length) return;

    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      els.forEach((el) => el.classList.add("active"));
      return;
    }

    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("active");
            obs.unobserve(en.target);
          }
        });
      },
      { threshold: 0.18 }
    );

    els.forEach((el) => obs.observe(el));
  }

  // ---------- Form submit overlay ----------
  function initSubmittingOverlay() {
    document.querySelectorAll("form[data-overlay='1']").forEach((form) => {
      form.addEventListener("submit", () => {
        document.body.classList.add("submitting");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initReveal();
    initSubmittingOverlay();
  });
})();

// Typewriter (homepage / hero)
(() => {
  function type(el) {
    const text = el.getAttribute("data-text") || el.textContent || "";
    const speed = parseInt(el.getAttribute("data-speed") || "42", 10);
    const cursor = document.createElement("span");
    cursor.className = "tw-cursor";
    cursor.textContent = "▍";
    el.textContent = "";
    el.appendChild(document.createTextNode(""));
    el.appendChild(cursor);
    let i = 0;
    function tick() {
      const node = el.firstChild;
      if (!node) return;
      node.textContent = text.slice(0, i);
      i++;
      if (i <= text.length) {
        setTimeout(tick, Math.max(12, speed));
      } else {
        cursor.classList.add("done");
      }
    }
    tick();
  }
  addEventListener("load", () => {
    document.querySelectorAll("[data-typewriter]").forEach(type);
  });
})();
