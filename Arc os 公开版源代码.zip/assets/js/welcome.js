﻿function triggerJump(el) {
  if (!el) return;
  el.classList.remove('arc-jump');
  void el.offsetWidth;
  el.classList.add('arc-jump');
}

document.addEventListener('DOMContentLoaded', () => {
  const cycles = [
    { hello: '你好', lang: '简体中文' },
    { hello: 'Hello', lang: 'English' },
    { hello: 'Привет', lang: 'Русский' },
    { hello: '你好', lang: '繁體中文' },
  ];

  const helloEl = document.getElementById('helloText');
  const langEl = document.getElementById('helloLang');
  if (!helloEl || !langEl) return;

  let idx = 0;
  const INTERVAL_MS = 1000;
  const SWAP_MS = 420;

  setInterval(() => {
    idx = (idx + 1) % cycles.length;

    helloEl.classList.add('fade-out');
    langEl.classList.add('fade-out');

    setTimeout(() => {
      helloEl.textContent = cycles[idx].hello;
      langEl.textContent = cycles[idx].lang;

      requestAnimationFrame(() => {
        helloEl.classList.remove('fade-out');
        langEl.classList.remove('fade-out');
      });
    }, SWAP_MS);
  }, INTERVAL_MS);
});
