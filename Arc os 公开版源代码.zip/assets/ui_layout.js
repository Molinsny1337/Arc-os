// UI layout editor + sortable (FLIP animation, no dependencies)
(function(){
  const prefersReducedMotion = () => {
    try { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
    catch(e){ return false; }
  };

  function q(sel, el){ return (el || document).querySelector(sel); }
  function qa(sel, el){ return Array.from((el || document).querySelectorAll(sel)); }
  function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }

  function recordRects(items){
    const m = new Map();
    for (const el of items) m.set(el, el.getBoundingClientRect());
    return m;
  }

  function flipAnimate(items, firstRects){
    if (prefersReducedMotion()) return;
    for (const el of items) {
      const first = firstRects.get(el);
      if (!first) continue;
      const last = el.getBoundingClientRect();
      const dx = first.left - last.left;
      const dy = first.top - last.top;
      if (!dx && !dy) continue;

      el.style.transition = 'transform 0s';
      el.style.transform = `translate(${dx}px, ${dy}px)`;
      // force reflow
      el.getBoundingClientRect();
      el.style.transition = 'transform 260ms cubic-bezier(.2,.8,.2,1)';
      el.style.transform = '';
      // cleanup after transition
      const onEnd = () => {
        el.style.transition = '';
        el.style.transform = '';
        el.removeEventListener('transitionend', onEnd);
      };
      el.addEventListener('transitionend', onEnd);
    }
  }

  function trySetDragImage(e, el){
    try{
      if (!e.dataTransfer) return;
      const c = document.createElement('canvas');
      c.width = 1; c.height = 1;
      e.dataTransfer.setDragImage(c, 0, 0);
    }catch(_){}
  }

  function initSortable(list, opts){
    if (!list || list.dataset.arcSortableInited) return;
    list.dataset.arcSortableInited = '1';

    const itemSelector = opts && opts.itemSelector ? opts.itemSelector : '.arc-sortable-item';
    const handleSelector = opts && opts.handleSelector ? opts.handleSelector : '.arc-sortable-handle';
    const onChange = opts && typeof opts.onChange === 'function' ? opts.onChange : function(){};

    let dragEl = null;
    let dragOverEl = null;

    function items(){ return qa(itemSelector, list); }

    // enable dragging
    for (const it of items()) {
      it.setAttribute('draggable', 'true');
      const handle = q(handleSelector, it);
      if (handle) {
        handle.addEventListener('mousedown', () => {});
      }
    }

    list.addEventListener('dragstart', (e) => {
      const target = e.target && e.target.closest ? e.target.closest(itemSelector) : null;
      if (!target || !list.contains(target)) return;
      // if handle exists, require it
      const handle = q(handleSelector, target);
      if (handle && !(e.target && e.target.closest && e.target.closest(handleSelector))) {
        e.preventDefault();
        return;
      }

      dragEl = target;
      dragEl.classList.add('is-dragging');
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', target.getAttribute('data-id') || '');
      }
      trySetDragImage(e, target);
    });

    list.addEventListener('dragend', () => {
      if (dragEl) dragEl.classList.remove('is-dragging');
      if (dragOverEl) dragOverEl.classList.remove('is-drop-target');
      dragEl = null;
      dragOverEl = null;
      onChange();
    });

    list.addEventListener('dragover', (e) => {
      if (!dragEl) return;
      e.preventDefault();
      const over = e.target && e.target.closest ? e.target.closest(itemSelector) : null;
      if (!over || over === dragEl || !list.contains(over)) return;

      if (dragOverEl && dragOverEl !== over) dragOverEl.classList.remove('is-drop-target');
      dragOverEl = over;
      dragOverEl.classList.add('is-drop-target');

      const before = recordRects(items());

      const rect = over.getBoundingClientRect();
      const after = (e.clientY - rect.top) > (rect.height / 2);
      if (after) over.after(dragEl);
      else over.before(dragEl);

      flipAnimate(items(), before);
    });
  }

  function parseJsonAttr(el, name, fallback){
    const raw = el && el.getAttribute ? (el.getAttribute(name) || '') : '';
    if (!raw) return fallback;
    try { return JSON.parse(raw); } catch(e){ return fallback; }
  }

  function debounce(fn, wait){
    let t = null;
    return function(){
      const args = arguments;
      if (t) clearTimeout(t);
      t = setTimeout(() => { t = null; fn.apply(null, args); }, wait);
    };
  }

  function toast(msg){
    if (!msg) return;
    let el = document.getElementById('arc-layout-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'arc-layout-toast';
      el.className = 'arc-layout-toast';
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.remove('show');
    el.getBoundingClientRect();
    el.classList.add('show');
    clearTimeout(el.__t);
    el.__t = setTimeout(() => el.classList.remove('show'), 1800);
  }

  // Pointer-based sortable (works on touch); only used by on-page layout editor.
  function initPointerSortable(container, opts){
    if (!container || container.dataset.arcPointerSortableInited) return;
    container.dataset.arcPointerSortableInited = '1';

    const itemSelector = opts && opts.itemSelector ? opts.itemSelector : '[data-arc-layout-item]';
    const handleSelector = opts && opts.handleSelector ? opts.handleSelector : '[data-arc-layout-handle]';
    const onChange = opts && typeof opts.onChange === 'function' ? opts.onChange : function(){};
    const isEnabled = opts && typeof opts.isEnabled === 'function' ? opts.isEnabled : function(){ return true; };

    let dragEl = null;
    let pointerId = null;

    function visibleItems(){
      return qa(itemSelector, container).filter((el) => !el.hasAttribute('hidden'));
    }

    function endDrag(){
      if (!dragEl) return;
      dragEl.classList.remove('is-dragging');
      dragEl = null;
      pointerId = null;
      onChange();
    }

    container.addEventListener('pointerdown', (e) => {
      if (!isEnabled()) return;
      const handle = e.target && e.target.closest ? e.target.closest(handleSelector) : null;
      if (!handle || !container.contains(handle)) return;
      const item = handle.closest(itemSelector);
      if (!item || !container.contains(item) || item.hasAttribute('hidden')) return;

      pointerId = e.pointerId;
      dragEl = item;
      dragEl.classList.add('is-dragging');
      try { handle.setPointerCapture(pointerId); } catch(_){}
      e.preventDefault();
    }, { passive: false });

    container.addEventListener('pointermove', (e) => {
      if (!dragEl || pointerId === null || e.pointerId !== pointerId) return;
      e.preventDefault();

      const items = visibleItems();
      const others = items.filter((x) => x !== dragEl);
      const before = recordRects(items);

      const y = e.clientY;
      let insertBefore = null;
      for (const it of others) {
        const r = it.getBoundingClientRect();
        if (y < (r.top + r.height / 2)) { insertBefore = it; break; }
      }
      if (insertBefore) {
        if (insertBefore !== dragEl.nextSibling) container.insertBefore(dragEl, insertBefore);
      } else {
        if (dragEl !== container.lastElementChild) container.appendChild(dragEl);
      }

      flipAnimate(items, before);
    }, { passive: false });

    container.addEventListener('pointerup', (e) => {
      if (pointerId !== null && e.pointerId === pointerId) endDrag();
    });
    container.addEventListener('pointercancel', (e) => {
      if (pointerId !== null && e.pointerId === pointerId) endDrag();
    });
  }

  function serializeList(list, enabledSelector){
    const out = [];
    qa('.arc-sortable-item[data-id]', list).forEach((li) => {
      const id = li.getAttribute('data-id') || '';
      const cb = enabledSelector ? q(enabledSelector, li) : q('input[type="checkbox"]', li);
      out.push({ id, enabled: cb ? !!cb.checked : true });
    });
    return out;
  }

  function initPersonalLayout(){
    const enable = document.getElementById('uiLayoutEnable');
    const list = document.getElementById('uiLayoutList');
    const json = document.getElementById('uiLayoutJson');
    const reset = document.getElementById('uiLayoutReset');
    if (!enable || !list || !json || !reset) return;

    const defRaw = json.getAttribute('data-default') || '[]';
    let DEFAULT = [];
    try { DEFAULT = JSON.parse(defRaw) || []; } catch(e){ DEFAULT = []; }

    function applyDisabled(){
      if (enable.checked) list.classList.remove('arc-sortable-disabled');
      else list.classList.add('arc-sortable-disabled');
    }

    function sync(){
      const items = serializeList(list, 'input.ui-enabled');
      json.value = JSON.stringify(items);
      applyDisabled();
    }

    function resetToDefault(){
      for (const it of DEFAULT) {
        const el = q(`.arc-sortable-item[data-id="${(window.CSS&&CSS.escape)?CSS.escape(it.id):it.id}"]`, list);
        if (el) list.appendChild(el);
        const cb = el ? q('input.ui-enabled', el) : null;
        if (cb) cb.checked = !!it.enabled;
      }
      enable.checked = true;
      sync();
    }

    initSortable(list, { itemSelector: '.arc-sortable-item', handleSelector: '.arc-sortable-handle', onChange: sync });
    list.addEventListener('change', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('ui-enabled')) sync();
    });
    enable.addEventListener('change', sync);
    reset.addEventListener('click', resetToDefault);
    sync();
  }

  function initAdminHomeLayout(){
    const list = document.getElementById('layout_list');
    const hidden = document.getElementById('home_layout_json');
    if (!list || !hidden) return;

    function sync(){
      const items = serializeList(list, '.layout-enabled');
      hidden.value = JSON.stringify(items);
    }

    initSortable(list, { itemSelector: '.arc-sortable-item', handleSelector: '.arc-sortable-handle', onChange: sync });
    list.addEventListener('change', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('layout-enabled')) sync();
    });
    sync();
  }

  function initProfileDesignLayout(){
    const list = document.getElementById('profileLayoutList');
    const json = document.getElementById('profileLayoutJson');
    const reset = document.getElementById('profileLayoutReset');
    if (!list || !json || !reset) return;

    const defRaw = json.getAttribute('data-default') || '[]';
    let DEFAULT = [];
    try { DEFAULT = JSON.parse(defRaw) || []; } catch(e){ DEFAULT = []; }

    function sync(){
      const items = serializeList(list, 'input.profile-enabled');
      json.value = JSON.stringify(items);
    }

    function resetToDefault(){
      for (const it of DEFAULT) {
        const el = q(`.arc-sortable-item[data-id="${(window.CSS&&CSS.escape)?CSS.escape(it.id):it.id}"]`, list);
        if (el) list.appendChild(el);
        const cb = el ? q('input.profile-enabled', el) : null;
        if (cb) cb.checked = !!it.enabled;
      }
      sync();
    }

    initSortable(list, { itemSelector: '.arc-sortable-item', handleSelector: '.arc-sortable-handle', onChange: sync });
    list.addEventListener('change', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('profile-enabled')) sync();
    });
    reset.addEventListener('click', resetToDefault);
    sync();
  }

  function initAdminLayoutsPage(){
    const lists = qa('[data-arc-admin-layout-list="1"]');
    if (!lists.length) return;

    for (const list of lists) {
      if (list.dataset.arcAdminLayoutInited) continue;
      list.dataset.arcAdminLayoutInited = '1';

      const hiddenId = (list.getAttribute('data-arc-hidden') || '').trim();
      if (!hiddenId) continue;
      const hidden = document.getElementById(hiddenId);
      if (!hidden) continue;

      function sync(){
        const items = serializeList(list, '.layout-enabled');
        hidden.value = JSON.stringify(items);
      }

      initSortable(list, { itemSelector: '.arc-sortable-item', handleSelector: '.arc-sortable-handle', onChange: sync });
      list.addEventListener('change', (e) => {
        if (e.target && e.target.classList && e.target.classList.contains('layout-enabled')) sync();
      });
      sync();
    }
  }

  function initOnPageLayoutEditors(){
    const roots = qa('[data-arc-layout-root]');
    if (!roots.length) return;

    for (const root of roots) {
      if (root.dataset.arcLayoutRootInited) continue;
      root.dataset.arcLayoutRootInited = '1';

      const canEdit = (root.getAttribute('data-arc-can-edit') || '') === '1';
      if (!canEdit) continue;

      const scope = (root.getAttribute('data-arc-layout-scope') || '').trim();
      const saveUrl = (root.getAttribute('data-arc-save-url') || '').trim();
      const csrf = (root.getAttribute('data-arc-csrf') || '').trim();

      const UI = parseJsonAttr(root, 'data-arc-ui', {
        edit: 'Edit layout',
        done: 'Done',
        reset: 'Reset',
        blocks: 'Blocks',
        saved: 'Saved',
        save_failed: 'Save failed',
        hide: 'Hide',
        show: 'Show',
      });
      const DEFAULT = parseJsonAttr(root, 'data-arc-default', []);
      const LABELS = parseJsonAttr(root, 'data-arc-labels', {});

      const itemSelector = '[data-arc-layout-item][data-id]';

      function itemsAll(){
        return qa(itemSelector, root);
      }

      function itemsVisible(){
        return itemsAll().filter((el) => !el.hasAttribute('hidden'));
      }

      function serialize(){
        return itemsAll().map((el) => ({
          id: el.getAttribute('data-id') || '',
          enabled: !el.hasAttribute('hidden'),
        })).filter((it) => !!it.id);
      }

      function applyFrom(items){
        const byId = new Map();
        itemsAll().forEach((el) => byId.set(el.getAttribute('data-id') || '', el));

        // reorder
        for (const it of items) {
          const el = byId.get(it.id);
          if (!el) continue;
          root.appendChild(el);
        }
        // apply enabled
        for (const it of items) {
          const el = byId.get(it.id);
          if (!el) continue;
          if (it.enabled) el.removeAttribute('hidden');
          else el.setAttribute('hidden', 'hidden');
        }
      }

      async function saveNow(){
        if (!saveUrl || !scope) return;
        const payload = { scope, items: serialize() };
        try {
          const res = await fetch(saveUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify(payload),
            credentials: 'same-origin',
          });
          if (!res.ok) throw new Error('http_' + res.status);
          const j = await res.json().catch(() => null);
          if (!j || j.ok !== true) throw new Error('bad_response');
          toast(UI.saved || 'Saved');
        } catch (e) {
          toast(UI.save_failed || 'Save failed');
        }
      }

      const saveDebounced = debounce(saveNow, 450);

      function ensureBlockControls(el){
        if (!el || el.querySelector('.arc-layout-controls')) return;
        el.classList.add('arc-layout-item');

        const controls = document.createElement('div');
        controls.className = 'arc-layout-controls';

        const handle = document.createElement('button');
        handle.type = 'button';
        handle.className = 'arc-layout-btn arc-layout-handle arc-sortable-handle';
        handle.setAttribute('data-arc-layout-handle', '1');
        handle.setAttribute('title', UI.edit || 'Edit');
        handle.textContent = '::';

        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'arc-layout-btn arc-layout-delete';
        del.setAttribute('title', UI.hide || 'Hide');
        del.textContent = '×';
        del.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          el.setAttribute('hidden', 'hidden');
          refreshPanel();
          saveDebounced();
        });

        controls.appendChild(handle);
        controls.appendChild(del);
        el.appendChild(controls);
      }

      itemsAll().forEach(ensureBlockControls);

      // floating button
      const fab = document.createElement('button');
      fab.type = 'button';
      fab.className = 'arc-layout-fab';
      fab.textContent = UI.edit || 'Edit';
      document.body.appendChild(fab);

      // bottom panel
      const panel = document.createElement('div');
      panel.className = 'arc-layout-panel';
      panel.innerHTML = `
        <div class="arc-layout-panel-head">
          <div class="arc-layout-panel-title">${(UI.blocks || 'Blocks')}</div>
          <div style="display:flex;gap:8px;align-items:center">
            <button type="button" class="arc-layout-panel-btn" data-arc-reset>${UI.reset || 'Reset'}</button>
            <button type="button" class="arc-layout-panel-btn primary" data-arc-done>${UI.done || 'Done'}</button>
          </div>
        </div>
        <div class="arc-layout-panel-list" data-arc-list></div>
      `;
      document.body.appendChild(panel);

      function setEditing(on){
        root.classList.toggle('arc-layout-editing', !!on);
        document.body.classList.toggle('arc-layout-editing', !!on);
        panel.classList.toggle('open', !!on);
        fab.classList.toggle('open', !!on);
        if (on) refreshPanel();
      }

      function refreshPanel(){
        const list = q('[data-arc-list]', panel);
        if (!list) return;
        const current = new Map();
        for (const it of serialize()) current.set(it.id, !!it.enabled);

        // Ensure stable order: DEFAULT first, then any remaining.
        const order = [];
        for (const it of (Array.isArray(DEFAULT) ? DEFAULT : [])) if (it && it.id) order.push(it.id);
        for (const it of serialize()) if (!order.includes(it.id)) order.push(it.id);

        list.innerHTML = '';
        for (const id of order) {
          const label = (LABELS && LABELS[id]) ? LABELS[id] : id;
          const enabled = !!current.get(id);
          const row = document.createElement('label');
          row.className = 'arc-layout-toggle';
          row.innerHTML = `
            <input type="checkbox" ${enabled ? 'checked' : ''} data-arc-toggle="${id}">
            <span class="arc-layout-toggle-label">${label}</span>
          `;
          list.appendChild(row);
        }
      }

      panel.addEventListener('change', (e) => {
        const t = e.target;
        if (!t || t.tagName !== 'INPUT' || t.type !== 'checkbox') return;
        const id = t.getAttribute('data-arc-toggle') || '';
        if (!id) return;
        const el = q(`${itemSelector}[data-id="${(window.CSS&&CSS.escape)?CSS.escape(id):id}"]`, root);
        if (!el) return;
        if (t.checked) el.removeAttribute('hidden');
        else el.setAttribute('hidden', 'hidden');
        saveDebounced();
      });

      const doneBtn = q('[data-arc-done]', panel);
      if (doneBtn) doneBtn.addEventListener('click', () => setEditing(false));
      const resetBtn = q('[data-arc-reset]', panel);
      if (resetBtn) resetBtn.addEventListener('click', () => {
        applyFrom(Array.isArray(DEFAULT) ? DEFAULT : []);
        refreshPanel();
        saveDebounced();
      });

      fab.addEventListener('click', () => setEditing(!root.classList.contains('arc-layout-editing')));

      // Long-press to enter edit mode (touch only; iOS-like)
      let lpTimer = null;
      let lpStart = null;
      function clearLp(){ if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } lpStart = null; }

      root.addEventListener('pointerdown', (e) => {
        if (root.classList.contains('arc-layout-editing')) return;
        if (e.pointerType !== 'touch') return;
        const it = e.target && e.target.closest ? e.target.closest(itemSelector) : null;
        if (!it || !root.contains(it) || it.hasAttribute('hidden')) return;
        lpStart = { x: e.clientX, y: e.clientY };
        lpTimer = setTimeout(() => {
          lpTimer = null;
          setEditing(true);
        }, 420);
      }, { passive: true });

      root.addEventListener('pointermove', (e) => {
        if (!lpTimer || !lpStart) return;
        const dx = Math.abs(e.clientX - lpStart.x);
        const dy = Math.abs(e.clientY - lpStart.y);
        if (dx + dy > 10) clearLp();
      }, { passive: true });
      root.addEventListener('pointerup', clearLp, { passive: true });
      root.addEventListener('pointercancel', clearLp, { passive: true });

      // Prevent accidental navigation while editing
      root.addEventListener('click', (e) => {
        if (!root.classList.contains('arc-layout-editing')) return;
        const target = e.target;
        if (!target) return;
        if (target.closest && (target.closest('.arc-layout-controls') || target.closest('.arc-layout-panel'))) return;
        const a = target.closest ? target.closest('a') : null;
        if (a) { e.preventDefault(); e.stopPropagation(); }
      }, true);

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && root.classList.contains('arc-layout-editing')) setEditing(false);
      });

      initPointerSortable(root, {
        itemSelector,
        handleSelector: '[data-arc-layout-handle]',
        isEnabled: () => root.classList.contains('arc-layout-editing'),
        onChange: () => saveDebounced(),
      });
    }
  }

  function init(){
    initPersonalLayout();
    initAdminHomeLayout();
    initProfileDesignLayout();
    initAdminLayoutsPage();
    initOnPageLayoutEditors();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
