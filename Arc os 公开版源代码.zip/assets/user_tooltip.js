(() => {
  const cache = new Map();
  let tooltip = null;
  let activeEl = null;
  let hideTimer = null;

  function createTooltip() {
    if (tooltip) return tooltip;
    tooltip = document.createElement('div');
    tooltip.className = 'xf-tooltip';
    tooltip.setAttribute('role', 'dialog');
    tooltip.addEventListener('mouseenter', () => {
      if (hideTimer) clearTimeout(hideTimer);
    });
    tooltip.addEventListener('mouseleave', () => {
      scheduleHide();
    });
    document.body.appendChild(tooltip);
    return tooltip;
  }

  function escapeText(value) {
    if (value === null || value === undefined) return '';
    return String(value);
  }

  function scheduleHide() {
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      hideTooltip();
    }, 220);
  }

  function hideTooltip() {
    if (tooltip) tooltip.classList.remove('show');
    activeEl = null;
  }

  function positionTooltip(target) {
    if (!tooltip || !target) return;
    const rect = target.getBoundingClientRect();
    const ttRect = tooltip.getBoundingClientRect();
    const padding = 12;
    let top = rect.bottom + 10;
    let left = rect.left;
    if (left + ttRect.width > window.innerWidth - padding) {
      left = window.innerWidth - ttRect.width - padding;
    }
    if (left < padding) left = padding;
    if (top + ttRect.height > window.innerHeight - padding) {
      top = rect.top - ttRect.height - 10;
    }
    if (top < padding) top = padding;
    tooltip.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
  }

  function renderTooltip(data) {
    const user = data.user || {};
    const urls = data.urls || {};
    const avatar = user.avatar || '';
    const title = user.title || '';
    const role = user.role || '';
    const name = user.name || user.username || 'User';
    const joined = user.joined || '';
    const last = user.last_active || '';
    const stats = `Threads ${user.threads || 0} · Replies ${user.replies || 0} · Reactions ${user.reactions || 0}`;

    tooltip.innerHTML = '';
    const card = document.createElement('div');
    card.className = 'xf-tooltip-card';

    const head = document.createElement('div');
    head.className = 'xf-tooltip-head';

    const avatarWrap = document.createElement('div');
    avatarWrap.className = 'xf-tooltip-avatar';
    if (avatar) {
      const img = document.createElement('img');
      img.src = avatar;
      img.alt = '';
      avatarWrap.appendChild(img);
    } else {
      const span = document.createElement('span');
      span.textContent = name.slice(0, 1).toUpperCase();
      avatarWrap.appendChild(span);
    }

    const meta = document.createElement('div');
    meta.className = 'xf-tooltip-meta';

    const nameEl = document.createElement('div');
    nameEl.className = 'xf-tooltip-name';
    nameEl.textContent = escapeText(name);

    const titleEl = document.createElement('div');
    titleEl.className = 'xf-tooltip-title';
    titleEl.textContent = escapeText(title !== '' ? title : role);

    meta.appendChild(nameEl);
    if (title !== '' || role !== '') meta.appendChild(titleEl);

    head.appendChild(avatarWrap);
    head.appendChild(meta);

    const body = document.createElement('div');
    body.className = 'xf-tooltip-body';
    body.textContent = stats;

    const foot = document.createElement('div');
    foot.className = 'xf-tooltip-actions';
    const profileBtn = document.createElement('a');
    profileBtn.className = 'btn';
    profileBtn.href = urls.profile || '#';
    profileBtn.textContent = 'Profile';
    const msgBtn = document.createElement('a');
    msgBtn.className = 'btn';
    msgBtn.href = urls.message || '#';
    msgBtn.textContent = 'Message';

    foot.appendChild(profileBtn);
    foot.appendChild(msgBtn);

    const metaRow = document.createElement('div');
    metaRow.className = 'xf-tooltip-sub';
    const joinedEl = document.createElement('div');
    joinedEl.textContent = joined ? `Joined ${joined}` : '';
    const lastEl = document.createElement('div');
    lastEl.textContent = last ? `Active ${last}` : '';
    if (joined) metaRow.appendChild(joinedEl);
    if (last) metaRow.appendChild(lastEl);

    card.appendChild(head);
    card.appendChild(body);
    if (joined || last) card.appendChild(metaRow);
    card.appendChild(foot);

    tooltip.appendChild(card);
  }

  function fetchUser(id) {
    if (cache.has(id)) return Promise.resolve(cache.get(id));
    const url = (window.__BASE_PATH__ || '') + '/ajax/user_tooltip.php?id=' + encodeURIComponent(id);
    return fetch(url, {
      headers: {'X-CSRF-Token': window.__CSRF_TOKEN__ || ''},
      credentials: 'same-origin',
    }).then((r) => r.json()).then((res) => {
      if (res && res.ok) {
        cache.set(id, res);
        return res;
      }
      throw new Error('tooltip_failed');
    });
  }

  function onEnter(ev) {
    const el = ev.currentTarget;
    const id = el.getAttribute('data-user-id');
    if (!id) return;
    activeEl = el;
    createTooltip();
    tooltip.classList.add('show');
    tooltip.innerHTML = '<div class=\"xf-tooltip-card\">Loading…</div>';
    positionTooltip(el);
    fetchUser(id).then((data) => {
      if (activeEl !== el) return;
      renderTooltip(data);
      positionTooltip(el);
    }).catch(() => {
      if (activeEl !== el) return;
      tooltip.innerHTML = '<div class=\"xf-tooltip-card\">Unavailable</div>';
      positionTooltip(el);
    });
  }

  function onLeave() {
    scheduleHide();
  }

  function bind() {
    document.querySelectorAll('.js-user-tooltip[data-user-id]').forEach((el) => {
      if (el.dataset.tooltipReady) return;
      el.dataset.tooltipReady = '1';
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
      el.addEventListener('focus', onEnter);
      el.addEventListener('blur', onLeave);
    });
  }

  function init() {
    bind();
    document.addEventListener('scroll', () => hideTooltip(), {passive: true});
    window.addEventListener('resize', () => hideTooltip());
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
