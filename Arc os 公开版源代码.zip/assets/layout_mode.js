(function(){
  const isLayout = new URLSearchParams(location.search).get('layout') === '1';
  if (!isLayout) return;
  document.documentElement.dataset.layoutMode = 'on';
  document.body.dataset.layoutMode = 'on';

  function ajax(url, data){
    const fd = new FormData();
    Object.entries(data||{}).forEach(([k,v])=>fd.append(k,v));
    return fetch(url, {method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json());
  }

  function getCsrf(){
    const el = document.querySelector('input[name="_csrf"]');
    if (el && el.value) return el.value;
    if (window.__CSRF_TOKEN__) return window.__CSRF_TOKEN__;
    return '';
  }

  const blocks = Array.from(document.querySelectorAll('[data-block-id]'));
  if (!blocks.length) return;

  const floating = document.createElement('div');
  floating.className = 'layout-floating';
  floating.innerHTML = '<button class="layout-btn" data-act="blocks">Blocks</button><button class="layout-btn" data-act="save">Save</button><button class="layout-btn" data-act="reset">Reset</button><button class="layout-btn" data-act="exit">Exit</button>';
  document.body.appendChild(floating);

  const panel = document.createElement('div');
  panel.className = 'layout-panel';
  panel.innerHTML = '<div class="layout-panel-head"><div class="layout-panel-title">Blocks</div><button class="layout-btn" data-act="close">Close</button></div><div class="layout-panel-list"></div>';
  document.body.appendChild(panel);

  const pageKey = document.body.getAttribute('data-page-key') || (location.pathname.replace(/\W+/g,'_') || 'page');

  function collect(){
    const out = {page: pageKey, columns: {}, blocks: {sidebar:[], main:[]}, hidden: []};
    const sidebar = document.querySelector('[data-layout-zone="sidebar"]');
    const main = document.querySelector('[data-layout-zone="main"]');
    if (sidebar) {
      sidebar.querySelectorAll('[data-block-id]').forEach(el=>{
        out.blocks.sidebar.push(el.dataset.blockId);
        if (el.hasAttribute('hidden')) out.hidden.push(el.dataset.blockId);
      });
    }
    if (main) {
      main.querySelectorAll('[data-block-id]').forEach(el=>{
        out.blocks.main.push(el.dataset.blockId);
        if (el.hasAttribute('hidden')) out.hidden.push(el.dataset.blockId);
      });
    }
    const width = getComputedStyle(document.documentElement).getPropertyValue('--sidebar-w').replace('px','').trim();
    if (width) out.columns.sidebarWidth = parseInt(width,10);
    return out;
  }

  function save(){
    const layout = JSON.stringify(collect());
    ajax((window.__BASE_PATH__||'') + '/ajax/layout_save.php', {page: pageKey, layout: layout, _csrf: getCsrf()}).then(()=>{
      floating.dataset.status = 'saved';
    });
  }

  function reset(){
    ajax((window.__BASE_PATH__||'') + '/ajax/layout_reset.php', {page: pageKey, _csrf: getCsrf()}).then(()=>location.reload());
  }

  function togglePanel(show){
    if (typeof show === 'boolean') panel.classList.toggle('open', show);
    else panel.classList.toggle('open');
    if (panel.classList.contains('open')) refreshPanel();
  }

  floating.addEventListener('click', function(e){
    const act = e.target.getAttribute('data-act');
    if (!act) return;
    if (act==='save') save();
    if (act==='reset') reset();
    if (act==='blocks') togglePanel();
    if (act==='exit') { const url = new URL(location.href); url.searchParams.delete('layout'); location.href = url.toString(); }
  });

  panel.addEventListener('click', function(e){
    const act = e.target.getAttribute('data-act');
    if (act === 'close') togglePanel(false);
  });

  function refreshPanel(){
    const list = panel.querySelector('.layout-panel-list');
    list.innerHTML = '';
    blocks.forEach((el)=>{
      const id = el.dataset.blockId || '';
      if (!id) return;
      const label = el.dataset.blockLabel || id;
      const row = document.createElement('label');
      row.className = 'layout-toggle';
      row.innerHTML = '<input type="checkbox" data-block="' + id + '" ' + (el.hasAttribute('hidden') ? '' : 'checked') + '> <span>' + label + '</span>';
      list.appendChild(row);
    });
  }

  panel.addEventListener('change', function(e){
    const input = e.target;
    if (!input || input.tagName !== 'INPUT') return;
    const id = input.getAttribute('data-block') || '';
    if (!id) return;
    const target = document.querySelector('[data-block-id="' + id.replace(/"/g,'') + '"]');
    if (!target) return;
    if (input.checked) target.removeAttribute('hidden');
    else target.setAttribute('hidden', 'hidden');
  });

  // Drag-sort blocks
  let dragEl = null;
  let placeholder = null;
  function startDrag(el){
    dragEl = el;
    placeholder = document.createElement('div');
    placeholder.className = 'layout-block placeholder';
    placeholder.style.height = dragEl.offsetHeight + 'px';
    dragEl.parentNode.insertBefore(placeholder, dragEl.nextSibling);
    dragEl.style.opacity = '0.6';
    dragEl.style.transform = 'scale(1.01)';
  }
  function endDrag(){
    if (!dragEl || !placeholder) return;
    dragEl.style.opacity = '';
    dragEl.style.transform = '';
    placeholder.replaceWith(dragEl);
    dragEl = null; placeholder = null;
  }
  function onMove(e){
    if (!dragEl || !placeholder) return;
    const y = e.clientY;
    const zone = dragEl.parentNode;
    const items = Array.from(zone.children).filter(c=>c!==dragEl && c!==placeholder && c.hasAttribute && c.hasAttribute('data-block-id'));
    for (const item of items){
      const rect = item.getBoundingClientRect();
      if (y < rect.top + rect.height/2){
        zone.insertBefore(placeholder, item);
        return;
      }
    }
    zone.appendChild(placeholder);
  }

  document.addEventListener('pointermove', onMove);
  document.addEventListener('pointerup', function(){ endDrag(); });

  blocks.forEach(el=>{
    el.classList.add('layout-block');
    if (!el.querySelector('[data-layout-handle]')) {
      const handle = document.createElement('button');
      handle.type = 'button';
      handle.className = 'layout-handle';
      handle.setAttribute('data-layout-handle', '1');
      handle.textContent = '::';
      el.insertBefore(handle, el.firstChild);
    }
    const handle = el.querySelector('[data-layout-handle]');
    if (handle) {
      handle.addEventListener('pointerdown', function(e){
        e.preventDefault();
        startDrag(el);
      });
    }
  });

  // Resizer
  const resizer = document.querySelector('.layout-resizer');
  if (resizer){
    resizer.addEventListener('pointerdown', function(e){
      e.preventDefault();
      const startX = e.clientX;
      const startW = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--sidebar-w').replace('px',''),10) || 280;
      function move(ev){
        const dx = ev.clientX - startX;
        let w = startW + dx;
        w = Math.max(240, Math.min(360, w));
        document.documentElement.style.setProperty('--sidebar-w', w + 'px');
      }
      function up(){
        document.removeEventListener('pointermove', move);
        document.removeEventListener('pointerup', up);
      }
      document.addEventListener('pointermove', move);
      document.addEventListener('pointerup', up);
    });
  }
})();
