(function () {
  const base = (window.__BASE_PATH__ || '').replace(/\/$/, '');
  const url = base + '/admin/ajax/analytics.php';
  const rangeWrap = document.querySelector('[data-chart-range]');
  const trafficCanvas = document.querySelector('[data-chart="traffic"]');
  const postsCanvas = document.querySelector('[data-chart="posts"]');
  const routesEl = document.querySelector('[data-chart="routes"]');

  if (!trafficCanvas || !postsCanvas || !routesEl) return;

  let range = 'today';

  function setActive(btn) {
    if (!rangeWrap) return;
    rangeWrap.querySelectorAll('button').forEach(function (b) { b.classList.remove('is-active'); });
    btn.classList.add('is-active');
  }

  function drawLine(canvas, labels, series) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.clientWidth;
    const h = canvas.height = canvas.getAttribute('height') || 200;
    const pad = 28;

    ctx.clearRect(0, 0, w, h);
    const max = Math.max(1, series.reduce(function (m, v) { return Math.max(m, v); }, 0));

    ctx.strokeStyle = 'rgba(0,0,0,0.08)';
    ctx.beginPath();
    ctx.moveTo(pad, h - pad);
    ctx.lineTo(w - pad, h - pad);
    ctx.stroke();

    function plot(values, color) {
      ctx.beginPath();
      values.forEach(function (v, i) {
        const x = pad + (i * (w - pad * 2) / Math.max(1, values.length - 1));
        const y = h - pad - (v / max) * (h - pad * 2);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    plot(series[0], 'rgba(10,132,255,0.85)');
    plot(series[1], 'rgba(34,197,94,0.85)');
  }

  function drawBars(canvas, labels, bars) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width = canvas.clientWidth;
    const h = canvas.height = canvas.getAttribute('height') || 200;
    const pad = 24;
    ctx.clearRect(0, 0, w, h);

    const max = Math.max(1, bars.reduce(function (m, v) { return Math.max(m, v[0], v[1]); }, 0));
    const barW = (w - pad * 2) / bars.length;
    bars.forEach(function (b, i) {
      const x = pad + i * barW;
      const v1 = b[0];
      const v2 = b[1];
      const h1 = (v1 / max) * (h - pad * 2);
      const h2 = (v2 / max) * (h - pad * 2);
      ctx.fillStyle = 'rgba(10,132,255,0.55)';
      ctx.fillRect(x + 2, h - pad - h1, (barW / 2) - 4, h1);
      ctx.fillStyle = 'rgba(34,197,94,0.55)';
      ctx.fillRect(x + barW / 2, h - pad - h2, (barW / 2) - 4, h2);
    });
  }

  function renderRoutes(routes) {
    routesEl.innerHTML = '';
    if (!routes || !routes.length) {
      routesEl.textContent = 'No data';
      return;
    }
    const max = Math.max.apply(null, routes.map(function (r) { return r.value; }));
    routes.forEach(function (r) {
      const row = document.createElement('div');
      row.className = 'admin-route-item';
      const label = document.createElement('div');
      label.textContent = r.label || 'other';
      const bar = document.createElement('div');
      bar.className = 'admin-route-bar';
      const fill = document.createElement('span');
      fill.style.width = Math.round((r.value / max) * 100) + '%';
      bar.appendChild(fill);
      const meta = document.createElement('div');
      meta.className = 'admin-route-meta';
      meta.textContent = String(r.value);
      row.appendChild(label);
      row.appendChild(bar);
      row.appendChild(meta);
      routesEl.appendChild(row);
    });
  }

  function fetchData() {
    const req = url + '?range=' + encodeURIComponent(range);
    fetch(req, { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (payload) {
        if (!payload || !payload.ok) return;
        const data = payload.data || {};
        const labels = Array.isArray(data.labels) ? data.labels : [];
        const line = Array.isArray(data.line) ? data.line : [];
        const bar = Array.isArray(data.bar) ? data.bar : [];
        const pv = line.map(function (p) { return p.pv || 0; });
        const uv = line.map(function (p) { return p.uv || 0; });
        const bars = bar.map(function (b) { return [b.threads || 0, b.replies || 0]; });
        drawLine(trafficCanvas, labels, [pv, uv]);
        drawBars(postsCanvas, labels, bars);
        renderRoutes(data.routes || []);
      })
      .catch(function () {});
  }

  if (rangeWrap) {
    rangeWrap.querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        range = btn.getAttribute('data-range') || 'today';
        setActive(btn);
        fetchData();
      });
    });
    const first = rangeWrap.querySelector('button[data-range="today"]') || rangeWrap.querySelector('button');
    if (first) setActive(first);
  }

  fetchData();
})();
