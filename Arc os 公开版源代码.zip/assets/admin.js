// Arc OS admin: make elements visible (admin pages don't load footer/app.js)
(function(){
  function show(){
    document.querySelectorAll('.admin-fade').forEach(el => el.classList.add('in'));
    document.querySelectorAll('.reveal').forEach((el,i)=>{
      el.style.setProperty('--i', i);
      el.classList.add('active');
    });
  }
  addEventListener('DOMContentLoaded', show);
  addEventListener('load', show);
})();
