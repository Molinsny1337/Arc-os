(() => {
  const prefersReducedMotion = () => {
    try {
      return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) {
      return false;
    }
  };

  function bindPressState(selector) {
    document.querySelectorAll(selector).forEach((el) => {
      if (el.dataset.xfPress) return;
      el.dataset.xfPress = '1';
      el.addEventListener('pointerdown', () => {
        if (prefersReducedMotion()) return;
        el.classList.add('is-pressed');
      });
      const clear = () => el.classList.remove('is-pressed');
      el.addEventListener('pointerup', clear);
      el.addEventListener('pointerleave', clear);
      el.addEventListener('blur', clear);
    });
  }

  function bindDropdowns(scope) {
    scope.querySelectorAll('[data-xf-dropdown]').forEach((wrap) => {
      if (wrap.dataset.xfDropdownReady) return;
      wrap.dataset.xfDropdownReady = '1';
      const toggle = wrap.querySelector('[data-xf-toggle]');
      const menu = wrap.querySelector('[data-xf-menu]');
      if (!toggle || !menu) return;

      const close = () => {
        wrap.classList.remove('is-open');
        menu.setAttribute('aria-hidden', 'true');
      };

      toggle.addEventListener('click', (ev) => {
        ev.preventDefault();
        const open = wrap.classList.toggle('is-open');
        menu.setAttribute('aria-hidden', open ? 'false' : 'true');
      });

      document.addEventListener('click', (ev) => {
        if (!wrap.contains(ev.target)) close();
      });

      close();
    });
  }

  function bindFilters(scope) {
    scope.querySelectorAll('.xf-filters').forEach((group) => {
      if (group.dataset.xfFiltersReady) return;
      group.dataset.xfFiltersReady = '1';
      group.querySelectorAll('.xf-filter').forEach((filter) => {
        filter.addEventListener('click', () => {
          group.querySelectorAll('.xf-filter').forEach((f) => f.classList.remove('active'));
          filter.classList.add('active');
        });
      });
    });
  }

  function init() {
    bindPressState('.btn, .xf-filter, .xf-pill');
    bindDropdowns(document);
    bindFilters(document);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();