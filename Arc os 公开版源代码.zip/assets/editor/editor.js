(function () {
  function $(sel, el) { return (el || document).querySelector(sel); }
  function $$(sel, el) { return Array.from((el || document).querySelectorAll(sel)); }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function bbcodeToHtml(bbcode) {
    let out = escapeHtml(bbcode || '');

    // code blocks
    const tokens = [];
    out = out.replace(/\[code(?:=([^\]]+))?\]([\s\S]*?)\[\/code\]/gi, function (_, lang, body) {
      const cls = lang ? (' class="language-' + escapeHtml(lang) + '"') : '';
      const key = '[[CODE_' + tokens.length + ']]';
      tokens.push('<pre class="bb-code"><code' + cls + '>' + body + '</code></pre>');
      return key;
    });

    out = out.replace(/\[icode\]([\s\S]*?)\[\/icode\]/gi, function (_, body) {
      const key = '[[ICODE_' + tokens.length + ']]';
      tokens.push('<code class="bb-icode">' + body + '</code>');
      return key;
    });

    out = out.replace(/\[b\]([\s\S]*?)\[\/b\]/gi, '<strong>$1</strong>');
    out = out.replace(/\[i\]([\s\S]*?)\[\/i\]/gi, '<em>$1</em>');
    out = out.replace(/\[u\]([\s\S]*?)\[\/u\]/gi, '<u>$1</u>');
    out = out.replace(/\[s\]([\s\S]*?)\[\/s\]/gi, '<s>$1</s>');
    out = out.replace(/\[color=([^\]]+)\]([\s\S]*?)\[\/color\]/gi, '<span style="color:$1">$2</span>');
    out = out.replace(/\[size=([0-9]+)\]([\s\S]*?)\[\/size\]/gi, '<span style="font-size:$1px">$2</span>');
    out = out.replace(/\[(left|center|right|justify)\]([\s\S]*?)\[\/\1\]/gi, '<div style="text-align:$1">$2</div>');

    out = out.replace(/\[quote(?:=[^\]]+)?\]/gi, '<blockquote class="bb-quote">');
    out = out.replace(/\[\/quote\]/gi, '</blockquote>');

    out = out.replace(/\[spoiler(?:=[^\]]+)?\]/gi, '<details class="bb-spoiler" open><summary>Spoiler</summary><div class="bb-spoiler-body">');
    out = out.replace(/\[\/spoiler\]/gi, '</div></details>');

    out = out.replace(/\[list(?:=(1))?\]([\s\S]*?)\[\/list\]/gi, function (_, ordered, body) {
      const items = body.split(/\[\*\]/).map(function (s) { return s.trim(); }).filter(Boolean);
      const lis = items.map(function (it) { return '<li>' + it + '</li>'; }).join('');
      const tag = ordered ? 'ol' : 'ul';
      return '<' + tag + ' class="bb-list">' + lis + '</' + tag + '>';
    });

    out = out.replace(/\[table\]/gi, '<table class="bb-table">');
    out = out.replace(/\[\/table\]/gi, '</table>');
    out = out.replace(/\[tr\]/gi, '<tr>');
    out = out.replace(/\[\/tr\]/gi, '</tr>');
    out = out.replace(/\[th\]/gi, '<th>');
    out = out.replace(/\[\/th\]/gi, '</th>');
    out = out.replace(/\[td\]/gi, '<td>');
    out = out.replace(/\[\/td\]/gi, '</td>');

    out = out.replace(/\[url=([^\]]+)\]([\s\S]*?)\[\/url\]/gi, function (_, href, label) {
      return '<a href="' + href + '" target="_blank" rel="nofollow ugc noopener">' + label + '</a>';
    });

    out = out.replace(/\[url\]([\s\S]*?)\[\/url\]/gi, function (_, href) {
      return '<a href="' + href + '" target="_blank" rel="nofollow ugc noopener">' + href + '</a>';
    });

    out = out.replace(/\[img\]([\s\S]*?)\[\/img\]/gi, function (_, src) {
      return '<img src="' + src + '" alt="" loading="lazy">';
    });

    out = out.replace(/\[user=([0-9]+)\]([\s\S]*?)\[\/user\]/gi, function (_, id, name) {
      return '<span class="bb-user" data-user-id="' + id + '">@' + name + '</span>';
    });

    out = out.replace(/\[tag\]([\s\S]*?)\[\/tag\]/gi, function (_, tag) {
      return '<span class="bb-tag" data-tag="' + tag + '">#' + tag + '</span>';
    });

    function emojiByCode(code) {
      const key = String(code || '').trim().toLowerCase();
      if (!key) return '';
      const idx = window.ArcEmojiIndex || {};
      const item = idx[key];
      if (!item) return ':' + escapeHtml(key) + ':';
      if (item.unicode) return escapeHtml(item.unicode);
      if (item.image) {
        return '<img class="bb-emoji" data-emoji="' + escapeHtml(key) + '" src="' + escapeHtml(item.image) + '" alt=":' + escapeHtml(key) + ':">';
      }
      return ':' + escapeHtml(key) + ':';
    }

    function stickerById(id) {
      const key = String(id || '').trim();
      if (!key) return '';
      const idx = window.ArcEmojiById || {};
      const item = idx[key];
      if (!item || !item.image) return '';
      return '<img class="bb-sticker" data-sticker="' + escapeHtml(key) + '" src="' + escapeHtml(item.image) + '" alt="[sticker]">';
    }

    out = out.replace(/\[emoji=([^\]]+)\]/gi, function (_, code) {
      return emojiByCode(code);
    });

    out = out.replace(/\[sticker=([0-9]+)\]/gi, function (_, id) {
      return stickerById(id);
    });

    out = out.replace(/\[attach\]([0-9]+)\[\/attach\]/gi, function (_, id) {
      return '<span class="bb-attach" data-attach-id="' + id + '">Attachment #' + id + '</span>';
    });

    out = out.replace(/\[hr\]/gi, '<hr>');

    out = out.replace(/\n/g, '<br>');

    tokens.forEach(function (html, i) {
      out = out.replace('[[CODE_' + i + ']]', html).replace('[[ICODE_' + i + ']]', html);
    });

    return out;
  }

  function htmlToBbcode(html) {
    const root = document.createElement('div');
    root.innerHTML = html || '';

    function walk(node) {
      let out = '';
      node.childNodes.forEach(function (child) {
        out += nodeToBb(child);
      });
      return out;
    }

    function nodeToBb(node) {
      if (node.nodeType === 3) return node.nodeValue || '';
      if (node.nodeType !== 1) return '';
      const tag = node.tagName.toLowerCase();

      if (tag === 'br') return '\n';
      if (tag === 'p' || tag === 'div') {
        const inner = walk(node);
        const align = node.style && node.style.textAlign ? node.style.textAlign : '';
        if (align === 'center' || align === 'right' || align === 'left' || align === 'justify') {
          return '[' + align + ']' + inner + '[/' + align + ']' + '\n\n';
        }
        return inner + '\n\n';
      }
      if (tag === 'strong' || tag === 'b') return wrap('b', walk(node));
      if (tag === 'em' || tag === 'i') return wrap('i', walk(node));
      if (tag === 'u') return wrap('u', walk(node));
      if (tag === 's' || tag === 'del') return wrap('s', walk(node));
      if (tag === 'blockquote') return wrap('quote', walk(node));
      if (tag === 'pre') return wrap('code', node.textContent || '');
      if (tag === 'code') return wrap('icode', node.textContent || '');
      if (tag === 'font') {
        let inner = walk(node);
        const color = node.getAttribute('color') || '';
        const sizeAttr = node.getAttribute('size') || '';
        if (color) inner = '[color=' + color + ']' + inner + '[/color]';
        if (sizeAttr) {
          const sizeNum = parseInt(sizeAttr, 10);
          const px = sizeNum ? (sizeNum * 2 + 10) : 14;
          inner = '[size=' + px + ']' + inner + '[/size]';
        }
        return inner;
      }
      if (tag === 'a') {
        const href = node.getAttribute('href') || '';
        const label = walk(node).trim() || href;
        return '[url=' + href + ']' + label + '[/url]';
      }
      if (tag === 'img') {
        const src = node.getAttribute('src') || '';
        const emojiCode = node.getAttribute('data-emoji');
        if (emojiCode) return '[emoji=' + emojiCode + ']';
        const stickerId = node.getAttribute('data-sticker');
        if (stickerId) return '[sticker=' + stickerId + ']';
        return src ? '[img]' + src + '[/img]' : '';
      }
      if (tag === 'ul') {
        let out = '[list]';
        node.querySelectorAll('li').forEach(function (li) {
          out += '[*]' + walk(li);
        });
        return out + '[/list]';
      }
      if (tag === 'ol') {
        let out = '[list=1]';
        node.querySelectorAll('li').forEach(function (li) {
          out += '[*]' + walk(li);
        });
        return out + '[/list]';
      }
      if (tag === 'table') return wrap('table', walk(node));
      if (tag === 'tr') return wrap('tr', walk(node));
      if (tag === 'th') return wrap('th', walk(node));
      if (tag === 'td') return wrap('td', walk(node));
      if (tag === 'details') return wrap('spoiler', walk(node));
      if (tag === 'hr') return '[hr]';

      if (node.getAttribute) {
        const attId = node.getAttribute('data-attach-id');
        if (attId) return '[attach]' + attId + '[/attach]';

        const emojiCode = node.getAttribute('data-emoji');
        if (emojiCode) return '[emoji=' + emojiCode + ']';

        const stickerId = node.getAttribute('data-sticker');
        if (stickerId) return '[sticker=' + stickerId + ']';

        const userId = node.getAttribute('data-user-id');
        if (userId) {
          const name = node.textContent || '';
          const clean = name.replace(/^@/, '');
          return '[user=' + userId + ']' + clean + '[/user]';
        }

        const tagName = node.getAttribute('data-tag');
        if (tagName) {
          const cleanTag = tagName.replace(/^#/, '');
          return '[tag]' + cleanTag + '[/tag]';
        }
      }

      const color = node.style && node.style.color ? node.style.color : '';
      const size = node.style && node.style.fontSize ? node.style.fontSize : '';
      if (color || size) {
        let inner = walk(node);
        if (color) inner = '[color=' + color + ']' + inner + '[/color]';
        if (size) inner = '[size=' + parseInt(size, 10) + ']' + inner + '[/size]';
        return inner;
      }

      return walk(node);
    }

    function wrap(tag, inner) {
      return '[' + tag + ']' + (inner || '') + '[/' + tag + ']';
    }

    const raw = walk(root);
    return raw.replace(/\n{3,}/g, '\n\n').trim();
  }

  function debounce(fn, wait) {
    let t = null;
    return function () {
      const args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(null, args); }, wait);
    };
  }

  const ArcEditor = {
    plugins: [],
    activeEditor: null,
    use: function (fn) {
      if (typeof fn === 'function') this.plugins.push(fn);
    },
    init: function (root) {
      if (!root || root.__arcEditor) return;
      const visual = $('[data-arc-editor-visual]', root);
      const source = $('[data-arc-editor-source]', root);
      const hidden = $('[data-arc-editor-hidden]', root);
      const preview = $('[data-arc-editor-preview]', root);
      const tabs = $$('[data-arc-editor-mode]', root);
      const form = root.closest('form');

      const minH = parseInt(root.dataset.minHeight || '0', 10);
      if (minH > 0) {
        visual.style.minHeight = minH + 'px';
        source.style.minHeight = minH + 'px';
      }

      const quoteBar = $('[data-arc-quote-bar]', root);
      const quoteCount = $('[data-arc-quote-count]', root);
      const quoteInsert = $('[data-arc-quote-insert]', root);
      const quoteClear = $('[data-arc-quote-clear]', root);
      const quoteStorageKey = 'arc_quote_' + (root.dataset.quoteKey || location.pathname);

      const editor = {
        root: root,
        visual: visual,
        source: source,
        hidden: hidden,
        preview: preview,
        form: form,
        mode: 'visual',
        lastHtml: '',
        quoteBuffer: [],
        quoteIds: new Set(),
        persistQuotes: function () {
          try {
            const payload = { ids: Array.from(editor.quoteIds), quotes: editor.quoteBuffer };
            localStorage.setItem(quoteStorageKey, JSON.stringify(payload));
          } catch (e) {}
        },
        loadQuotes: function () {
          try {
            const raw = localStorage.getItem(quoteStorageKey);
            if (!raw) return;
            const data = JSON.parse(raw);
            const ids = Array.isArray(data.ids) ? data.ids : [];
            const quotes = Array.isArray(data.quotes) ? data.quotes : [];
            editor.quoteIds = new Set(ids.map(String));
            editor.quoteBuffer = quotes.map(String);
            if (quoteCount) quoteCount.textContent = String(editor.quoteBuffer.length);
            if (quoteBar) quoteBar.hidden = editor.quoteBuffer.length === 0;
          } catch (e) {}
        },
        setMode: function (mode) {
          editor.mode = mode;
          root.dataset.mode = mode;
          tabs.forEach(function (btn) {
            const active = btn.getAttribute('data-arc-editor-mode') === mode;
            btn.classList.toggle('is-active', active);
            btn.setAttribute('aria-selected', active ? 'true' : 'false');
          });
          if (mode === 'visual') {
            visual.innerHTML = bbcodeToHtml(hidden.value || '');
            visual.focus();
          } else if (mode === 'bbcode') {
            source.value = hidden.value || '';
            source.focus();
          } else if (mode === 'preview') {
            editor.requestPreview();
          }
        },
        syncHidden: function () {
          if (editor.mode === 'bbcode') {
            hidden.value = source.value || '';
          } else {
            hidden.value = htmlToBbcode(visual.innerHTML || '');
          }
        },
        requestPreview: debounce(function () {
          const url = root.dataset.previewUrl || '';
          if (!url) return;
          editor.syncHidden();
          const csrf = root.dataset.csrf || '';
          const fd = new FormData();
          fd.append('bbcode', hidden.value || '');
          fd.append('_csrf', csrf);
          fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            body: fd
          }).then(function (r) { return r.json(); }).then(function (data) {
            if (data && data.ok && typeof data.html === 'string') {
              preview.innerHTML = data.html;
            }
          }).catch(function () {});
        }, 400),
        insertHtml: function (html) {
          visual.focus();
          document.execCommand('insertHTML', false, html);
          editor.syncHidden();
        },
        insertHtmlAtEnd: function (html) {
          visual.insertAdjacentHTML('beforeend', html);
          editor.syncHidden();
        },
        insertText: function (text) {
          visual.focus();
          document.execCommand('insertText', false, text);
          editor.syncHidden();
        },
        insertTextAtEnd: function (text) {
          visual.appendChild(document.createTextNode(text));
          editor.syncHidden();
        },
        insertBbcode: function (code) {
          const el = editor.mode === 'bbcode' ? source : hidden;
          if (editor.mode === 'bbcode') {
            const start = source.selectionStart || 0;
            const end = source.selectionEnd || 0;
            const val = source.value || '';
            source.value = val.slice(0, start) + code + val.slice(end);
            source.selectionStart = source.selectionEnd = start + code.length;
            hidden.value = source.value;
          } else {
            editor.insertText(code);
          }
        },
        insertBbcodeAtEnd: function (code) {
          const val = hidden.value || '';
          hidden.value = val + code;
          if (editor.mode === 'bbcode') {
            source.value = hidden.value;
            source.selectionStart = source.selectionEnd = source.value.length;
          } else {
            visual.innerHTML = bbcodeToHtml(hidden.value);
          }
        },
        addQuote: function (id, bbcode) {
          if (!bbcode) return;
          const key = String(id || '');
          if (key && editor.quoteIds.has(key)) return;
          if (key) editor.quoteIds.add(key);
          editor.quoteBuffer.push(bbcode);
          if (quoteCount) quoteCount.textContent = String(editor.quoteBuffer.length);
          if (quoteBar) quoteBar.hidden = editor.quoteBuffer.length === 0;
          editor.persistQuotes();
        },
        insertQuotes: function () {
          if (!editor.quoteBuffer.length) return;
          const merged = editor.quoteBuffer.join('\n');
          if (editor.mode === 'bbcode') {
            editor.insertBbcode(merged + '\n');
          } else {
            editor.insertHtml(ArcEditor.bbcodeToHtml(merged) + '<br>');
          }
          editor.clearQuotes();
        },
        clearQuotes: function () {
          editor.quoteBuffer = [];
          editor.quoteIds = new Set();
          if (quoteCount) quoteCount.textContent = '0';
          if (quoteBar) quoteBar.hidden = true;
          try { localStorage.removeItem(quoteStorageKey); } catch (e) {}
        }
      };

      root.__arcEditor = editor;

      editor.loadQuotes();

      // init content
      hidden.value = hidden.value || '';
      visual.innerHTML = bbcodeToHtml(hidden.value);
      source.value = hidden.value;

      tabs.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          editor.setMode(btn.getAttribute('data-arc-editor-mode'));
        });
      });

      visual.addEventListener('input', debounce(function () { editor.syncHidden(); }, 300));
      source.addEventListener('input', debounce(function () { editor.syncHidden(); }, 200));

      if (form) {
        form.addEventListener('submit', function () {
          editor.syncHidden();
        });
      }

      visual.addEventListener('focus', function () { ArcEditor.activeEditor = editor; });
      source.addEventListener('focus', function () { ArcEditor.activeEditor = editor; });

      if (quoteInsert) {
        quoteInsert.addEventListener('click', function (e) {
          e.preventDefault();
          editor.insertQuotes();
        });
      }
      if (quoteClear) {
        quoteClear.addEventListener('click', function (e) {
          e.preventDefault();
          editor.clearQuotes();
        });
      }

      // keyboard shortcuts
      visual.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') { e.preventDefault(); document.execCommand('bold'); }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'i') { e.preventDefault(); document.execCommand('italic'); }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'u') { e.preventDefault(); document.execCommand('underline'); }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); ArcEditor.insertLink(editor); }
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && form) { form.requestSubmit(); }
      });

      // plugins
      ArcEditor.plugins.forEach(function (fn) {
        try { fn(editor); } catch (e) {}
      });
    },
    insertLink: function (editor) {
      const url = prompt('Link URL');
      if (!url) return;
      document.execCommand('createLink', false, url);
      editor.syncHidden();
    },
    bbcodeToHtml: bbcodeToHtml,
    htmlToBbcode: htmlToBbcode,
    escapeHtml: escapeHtml
  };

  window.ArcEditor = ArcEditor;

  function initAll() {
    $$('[data-arc-editor]').forEach(function (root) { ArcEditor.init(root); });
  }

  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-quote-id]');
    if (!btn) return;
    e.preventDefault();
    const id = btn.getAttribute('data-quote-id');
    const type = btn.getAttribute('data-quote-type') || 'comment';
    const isMulti = btn.hasAttribute('data-quote-multi');
    const editor = ArcEditor.activeEditor || (document.querySelector('[data-arc-editor]') && document.querySelector('[data-arc-editor]').__arcEditor);
    if (!editor) return;
    const url = editor.root.dataset.quoteUrl || '';
    if (!url) return;
    fetch(url + '?id=' + encodeURIComponent(id) + '&type=' + encodeURIComponent(type), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data || !data.ok || !data.bbcode) return;
        if (isMulti) {
          editor.addQuote(id, data.bbcode);
          return;
        }
        if (editor.mode === 'bbcode') {
          editor.insertBbcode(data.bbcode + '\n');
        } else {
          editor.insertHtml(ArcEditor.bbcodeToHtml(data.bbcode) + '<br>');
        }
      })
      .catch(function () {});
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
})();
