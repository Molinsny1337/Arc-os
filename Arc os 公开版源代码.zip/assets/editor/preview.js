(function () {
  if (!window.ArcEditor) return;

  function debounce(fn, wait) {
    let t = null;
    return function () {
      const args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(null, args); }, wait);
    };
  }

  window.ArcEditor.use(function (editor) {
    if (!editor.preview) return;
    const refresh = debounce(function () {
      if (editor.mode === 'preview') editor.requestPreview();
    }, 400);
    editor.visual.addEventListener('input', refresh);
    editor.source.addEventListener('input', refresh);
  });
})();
