﻿(function () {
  if (!window.ArcEditor) return;

  function getTextBeforeCaretInContentEditable(el) {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return '';
    const range = sel.getRangeAt(0).cloneRange();
    range.collapse(true);
    range.setStart(el, 0);
    return range.toString();
  }

  window.ArcEditor.use(function (editor) {
    const root = editor.root;
    const suggest = root.querySelector('[data-arc-editor-suggest]');
    if (!suggest) return;
    const allowMentions = root.dataset.mentions !== '0';
    const allowTags = root.dataset.tags !== '0';

    let activeIndex = -1;
    let items = [];
    let currentMode = '';

    function hide() {
      suggest.hidden = true;
      suggest.innerHTML = '';
      items = [];
      activeIndex = -1;
      currentMode = '';
    }

    function render(list, type) {
      suggest.innerHTML = '';
      list.forEach(function (item, idx) {
        const row = document.createElement('div');
        row.className = 'arc-editor-suggest-item' + (idx === activeIndex ? ' is-active' : '');
        if (type === 'user') {
          const av = document.createElement('div');
          av.className = 'arc-editor-suggest-avatar';
          if (item.avatar) {
            const img = document.createElement('img');
            img.src = item.avatar;
            av.appendChild(img);
          }
          const name = document.createElement('span');
          name.textContent = item.name;
          row.appendChild(av);
          row.appendChild(name);
        } else {
          row.textContent = item.tag;
        }
        row.addEventListener('click', function () { apply(item, type); });
        suggest.appendChild(row);
      });
      suggest.hidden = list.length === 0;
      items = list;
      currentMode = type;
    }

    function apply(item, type) {
      if (type === 'user') {
        if (editor.mode === 'bbcode') {
          editor.insertBbcode('[user=' + item.id + ']' + item.name + '[/user]');
        } else {
          editor.insertHtml('<span class="bb-user" data-user-id="' + item.id + '">@' + item.name + '</span>');
        }
      } else {
        if (editor.mode === 'bbcode') {
          editor.insertBbcode('[tag]' + item.tag + '[/tag]');
        } else {
          editor.insertHtml('<span class="bb-tag" data-tag="' + item.tag + '">#' + item.tag + '</span>');
        }
      }
      hide();
    }

    function fetchUsers(q) {
      const url = root.dataset.mentionUrl || '';
      if (!url) return;
      fetch(url + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.ok && Array.isArray(data.items)) {
            const list = data.items.map(function (u) {
              return { id: u.id, name: u.name, avatar: u.avatar || '' };
            });
            render(list, 'user');
          }
        })
        .catch(function () {});
    }

    function fetchTags(q) {
      const url = root.dataset.tagUrl || '';
      if (!url) return;
      fetch(url + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.ok && Array.isArray(data.items)) {
            const list = data.items.map(function (t) { return { tag: t }; });
            render(list, 'tag');
          }
        })
        .catch(function () {});
    }

    function checkTrigger(text) {
      const tail = text.slice(-30);
      const m = /([@#])([A-Za-z0-9_\-]{1,32})$/.exec(tail);
      if (!m) return hide();
      const sig = m[1];
      const q = m[2];
      if (sig === '@' && allowMentions) fetchUsers(q);
      if (sig === '#' && allowTags) fetchTags(q);
    }

    function onInput() {
      if (editor.mode === 'bbcode') {
        const pos = editor.source.selectionStart || 0;
        const text = (editor.source.value || '').slice(0, pos);
        checkTrigger(text);
      } else {
        checkTrigger(getTextBeforeCaretInContentEditable(editor.visual));
      }
    }

    editor.visual.addEventListener('keyup', onInput);
    editor.source.addEventListener('keyup', onInput);

    function handleKey(e) {
      if (suggest.hidden || items.length === 0) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        activeIndex = Math.min(items.length - 1, activeIndex + 1);
        render(items, currentMode);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        activeIndex = Math.max(0, activeIndex - 1);
        render(items, currentMode);
      } else if (e.key === 'Enter') {
        if (activeIndex >= 0 && items[activeIndex]) {
          e.preventDefault();
          apply(items[activeIndex], currentMode);
        }
      } else if (e.key === 'Escape') {
        hide();
      }
    }

    editor.visual.addEventListener('keydown', handleKey);
    editor.source.addEventListener('keydown', handleKey);

    document.addEventListener('click', function (e) {
      if (suggest.hidden) return;
      if (root.contains(e.target)) return;
      hide();
    });
  });
})();
