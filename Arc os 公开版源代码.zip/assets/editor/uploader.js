(function () {
  if (!window.ArcEditor) return;

  function formatSize(bytes) {
    if (!bytes) return '0B';
    const kb = bytes / 1024;
    if (kb < 1024) return Math.round(kb) + 'KB';
    return (kb / 1024).toFixed(1) + 'MB';
  }

  window.ArcEditor.use(function (editor) {
    const root = editor.root;
    if (root.dataset.attachments !== '1') return;

    const fileInput = root.querySelector('[data-arc-editor-file]');
    const uploadBtn = root.querySelector('[data-arc-editor-upload]');
    const list = root.querySelector('[data-arc-editor-attach-list]');
    const insertSelect = root.querySelector('[data-arc-editor-insert]');
    const visual = editor.visual;

    editor.attachments = [];

    function insertPosition() {
      return insertSelect && insertSelect.value ? insertSelect.value : 'cursor';
    }

    function insertAttachment(item) {
      const id = item.attachment_id;
      const pos = insertPosition();
      if (editor.mode === 'bbcode') {
        if (pos === 'end' && typeof editor.insertBbcodeAtEnd === 'function') {
          editor.insertBbcodeAtEnd('[attach]' + id + '[/attach]');
        } else {
          editor.insertBbcode('[attach]' + id + '[/attach]');
        }
      } else {
        const html = '<span class="bb-attach" data-attach-id="' + id + '">Attachment #' + id + '</span>';
        if (pos === 'end' && typeof editor.insertHtmlAtEnd === 'function') {
          editor.insertHtmlAtEnd(html);
        } else {
          editor.insertHtml(html);
        }
      }
    }

    function renderItem(item) {
      const row = document.createElement('div');
      row.className = 'arc-editor-attach-item';
      row.dataset.id = item.attachment_id;

      const left = document.createElement('div');
      left.style.display = 'flex';
      left.style.alignItems = 'center';
      left.style.gap = '10px';

      const thumb = document.createElement('div');
      thumb.className = 'arc-editor-attach-thumb';
      if (item.is_image && (item.thumb_url || item.url)) {
        const img = document.createElement('img');
        img.src = item.thumb_url || item.url;
        thumb.appendChild(img);
      } else {
        thumb.textContent = 'FILE';
      }

      const meta = document.createElement('div');
      meta.className = 'arc-editor-attach-meta';
      meta.innerHTML = '<strong>' + (item.file_name || 'file') + '</strong><span>' + formatSize(item.size) + '</span>';

      left.appendChild(thumb);
      left.appendChild(meta);

      const actions = document.createElement('div');
      actions.className = 'arc-editor-attach-actions';

      const btnInsert = document.createElement('button');
      btnInsert.type = 'button';
      btnInsert.className = 'arc-editor-btn';
      btnInsert.textContent = 'Insert';
      btnInsert.addEventListener('click', function () { insertAttachment(item); });

      const btnRemove = document.createElement('button');
      btnRemove.type = 'button';
      btnRemove.className = 'arc-editor-btn';
      btnRemove.textContent = 'Remove';
      btnRemove.addEventListener('click', function () {
        removeAttachment(item.attachment_id, row);
      });

      actions.appendChild(btnInsert);
      actions.appendChild(btnRemove);

      row.appendChild(left);
      row.appendChild(actions);
      return row;
    }

    function addAttachment(item) {
      editor.attachments.push(item);
      if (list) list.appendChild(renderItem(item));
    }

    function removeAttachment(id, row) {
      const url = root.dataset.attachRemoveUrl || '';
      if (!url) return;
      const fd = new FormData();
      fd.append('attachment_id', String(id));
      fd.append('_csrf', root.dataset.csrf || '');
      fetch(url, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data && data.ok) {
            editor.attachments = editor.attachments.filter(function (it) { return it.attachment_id !== id; });
            if (row && row.parentNode) row.parentNode.removeChild(row);
          }
        })
        .catch(function () {});
    }

    function uploadFiles(files) {
      if (!files || !files.length) return;
      const url = root.dataset.uploadUrl || '';
      if (!url) return;
      const draftKey = root.dataset.draftKey || '';
      const contentType = root.dataset.contentType || root.dataset.editorMode || 'post';
      Array.from(files).forEach(function (file) {
        const fd = new FormData();
        fd.append('file[]', file);
        fd.append('draft_key', draftKey);
        fd.append('content_type', contentType);
        fd.append('_csrf', root.dataset.csrf || '');
        fetch(url, { method: 'POST', credentials: 'same-origin', body: fd })
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (data && data.ok && Array.isArray(data.items)) {
              data.items.forEach(addAttachment);
            }
          })
          .catch(function () {});
      });
    }

    if (uploadBtn && fileInput) {
      uploadBtn.addEventListener('click', function (e) {
        e.preventDefault();
        fileInput.click();
      });
      fileInput.addEventListener('change', function () {
        uploadFiles(fileInput.files || []);
        fileInput.value = '';
      });
    }

    if (visual) {
      visual.addEventListener('dragover', function (e) { e.preventDefault(); });
      visual.addEventListener('drop', function (e) {
        e.preventDefault();
        if (e.dataTransfer && e.dataTransfer.files) {
          uploadFiles(e.dataTransfer.files);
        }
      });

      visual.addEventListener('paste', function (e) {
        const items = (e.clipboardData && e.clipboardData.items) ? e.clipboardData.items : [];
        const files = [];
        for (let i = 0; i < items.length; i++) {
          const it = items[i];
          if (it.kind === 'file') {
            const f = it.getAsFile();
            if (f) files.push(f);
          }
        }
        if (files.length) {
          e.preventDefault();
          uploadFiles(files);
        }
      });
    }
  });
})();
