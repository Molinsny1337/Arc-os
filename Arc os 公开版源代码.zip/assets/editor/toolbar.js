(function () {
  if (!window.ArcEditor) return;

  function wrapSelection(textarea, open, close) {
    const start = textarea.selectionStart || 0;
    const end = textarea.selectionEnd || 0;
    const val = textarea.value || '';
    const selected = val.slice(start, end);
    const next = val.slice(0, start) + open + selected + close + val.slice(end);
    textarea.value = next;
    textarea.selectionStart = textarea.selectionEnd = start + open.length + selected.length + close.length;
    return next;
  }

  function mapFontSize(px) {
    const num = parseInt(px, 10) || 14;
    const mapped = Math.round((num - 10) / 2);
    return Math.max(1, Math.min(7, mapped));
  }

  function selectionText() {
    const sel = window.getSelection();
    return sel ? (sel.toString() || '') : '';
  }

  window.ArcEditor.use(function (editor) {
    const root = editor.root;
    const toolbar = root.querySelector('[data-arc-editor-toolbar]');
    const source = editor.source;

    function isSource() { return editor.mode === 'bbcode'; }

    function insertHtml(html) { editor.insertHtml(html); }
    function insertText(text) { editor.insertText(text); }

    function wrapBb(open, close) {
      if (!source) return;
      wrapSelection(source, open, close);
      editor.syncHidden();
    }

    function cmd(name, value) {
      if (name === 'bold') {
        return isSource() ? wrapBb('[b]', '[/b]') : document.execCommand('bold');
      }
      if (name === 'italic') {
        return isSource() ? wrapBb('[i]', '[/i]') : document.execCommand('italic');
      }
      if (name === 'underline') {
        return isSource() ? wrapBb('[u]', '[/u]') : document.execCommand('underline');
      }
      if (name === 'strike') {
        return isSource() ? wrapBb('[s]', '[/s]') : document.execCommand('strikeThrough');
      }
      if (name === 'color') {
        const c = String(value || '').trim();
        if (!c) return;
        if (isSource()) return wrapBb('[color=' + c + ']', '[/color]');
        document.execCommand('styleWithCSS', false, true);
        return document.execCommand('foreColor', false, c);
      }
      if (name === 'size') {
        const s = String(value || '').trim();
        if (!s) return;
        if (isSource()) return wrapBb('[size=' + s + ']', '[/size]');
        document.execCommand('styleWithCSS', false, true);
        return document.execCommand('fontSize', false, String(mapFontSize(s)));
      }
      if (name === 'align-left') {
        return isSource() ? wrapBb('[left]', '[/left]') : document.execCommand('justifyLeft');
      }
      if (name === 'align-center') {
        return isSource() ? wrapBb('[center]', '[/center]') : document.execCommand('justifyCenter');
      }
      if (name === 'align-right') {
        return isSource() ? wrapBb('[right]', '[/right]') : document.execCommand('justifyRight');
      }
      if (name === 'align-justify') {
        return isSource() ? wrapBb('[justify]', '[/justify]') : document.execCommand('justifyFull');
      }
      if (name === 'ul') {
        return isSource() ? wrapBb('[list]\n[*]', '[/list]') : document.execCommand('insertUnorderedList');
      }
      if (name === 'ol') {
        return isSource() ? wrapBb('[list=1]\n[*]', '[/list]') : document.execCommand('insertOrderedList');
      }
      if (name === 'indent') return document.execCommand('indent');
      if (name === 'outdent') return document.execCommand('outdent');
      if (name === 'quote') {
        if (isSource()) return wrapBb('[quote]', '[/quote]');
        const txt = editor.escapeHtml(selectionText());
        return insertHtml('<blockquote class="bb-quote">' + txt + '</blockquote>');
      }
      if (name === 'code') {
        const lang = String(value || '').trim();
        if (isSource()) return wrapBb(lang && lang !== 'plain' ? ('[code=' + lang + ']') : '[code]', '[/code]');
        const cls = lang && lang !== 'plain' ? (' class="language-' + editor.escapeHtml(lang) + '"') : '';
        const txt = editor.escapeHtml(selectionText());
        return insertHtml('<pre class="bb-code"><code' + cls + '>' + txt + '</code></pre>');
      }
      if (name === 'icode') {
        if (isSource()) return wrapBb('[icode]', '[/icode]');
        const txt = editor.escapeHtml(selectionText());
        return insertHtml('<code class="bb-icode">' + txt + '</code>');
      }
      if (name === 'link') {
        const url = prompt('Link URL');
        if (!url) return;
        if (isSource()) return wrapBb('[url=' + url + ']', '[/url]');
        return document.execCommand('createLink', false, url);
      }
      if (name === 'image') {
        const src = prompt('Image URL');
        if (!src) return;
        return isSource() ? wrapBb('[img]' + src, '[/img]') : insertHtml('<img src="' + editor.escapeHtml(src) + '" alt="">');
      }
      if (name === 'media') {
        const m = prompt('Media URL');
        if (!m) return;
        const t = String(value || '').trim();
        if (isSource()) {
          return wrapBb(t && t !== 'auto' ? ('[media=' + t + ']') : '[media]', '[/media]');
        }
        const code = (t && t !== 'auto') ? ('[media=' + t + ']' + m + '[/media]') : ('[media]' + m + '[/media]');
        return insertText(code);
      }
      if (name === 'spoiler') {
        return isSource() ? wrapBb('[spoiler]', '[/spoiler]') : insertHtml('<details class="bb-spoiler"><summary>Spoiler</summary><div class="bb-spoiler-body"></div></details>');
      }
      if (name === 'table') {
        if (isSource()) {
          return editor.insertBbcode('[table]\n[tr][th]A[/th][th]B[/th][/tr]\n[tr][td]1[/td][td]2[/td][/tr]\n[/table]');
        }
        return insertHtml('<table class="bb-table"><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>');
      }
      if (name === 'hr') {
        return isSource() ? editor.insertBbcode('[hr]') : insertHtml('<hr>');
      }
      if (name === 'emoji') {
        if (typeof editor.toggleEmoji === 'function') return editor.toggleEmoji();
        return editor.insertText(':)');
      }
      if (name === 'undo') return document.execCommand('undo');
      if (name === 'redo') return document.execCommand('redo');
      if (name === 'fullscreen') {
        if (root.dataset.fullscreen === '0') return;
        root.classList.toggle('arc-editor-fullscreen');
        return;
      }
    }

    if (!toolbar) return;
    toolbar.addEventListener('click', function (e) {
      const btn = e.target.closest('[data-cmd]');
      if (!btn) return;
      if (btn.tagName === 'SELECT') return;
      e.preventDefault();
      const name = btn.getAttribute('data-cmd');
      if (name === 'code-lang') {
        cmd('code', btn.value || '');
      } else if (name === 'media-type') {
        cmd('media', btn.value || '');
      } else {
        cmd(name);
      }
      editor.syncHidden();
    });

    toolbar.addEventListener('change', function (e) {
      const sel = e.target.closest('select[data-cmd]');
      if (!sel) return;
      const name = sel.getAttribute('data-cmd') || '';
      const value = sel.value || '';
      if (!value) return;
      if (name === 'color-select') cmd('color', value);
      if (name === 'size-select') cmd('size', value);
      if (name === 'code-lang') cmd('code', value);
      if (name === 'media-type') cmd('media', value);
      sel.selectedIndex = 0;
      editor.syncHidden();
    });
  });
})();
