﻿(function () {
  if (!window.ArcEditor) return;

  function debounce(fn, wait) {
    let t = null;
    return function () {
      const args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(null, args); }, wait);
    };
  }

  window.ArcEditor.use(function (editor) {
    const root = editor.root;
    const draftKey = root.dataset.draftKey || '';
    const saveUrl = root.dataset.draftSaveUrl || '';
    const loadUrl = root.dataset.draftLoadUrl || '';
    const contentType = root.dataset.contentType || root.dataset.editorMode || 'post';
    const contentId = parseInt(root.dataset.contentId || '0', 10) || 0;
    if (!draftKey || !saveUrl || !loadUrl) return;

    let dirty = false;

    function collectAttachments() {
      if (Array.isArray(editor.attachments)) {
        return editor.attachments.map(function (it) { return it.attachment_id; });
      }
      return [];
    }

    function saveDraft() {
      editor.syncHidden();
      const fd = new FormData();
      fd.append('draft_key', draftKey);
      fd.append('content_type', contentType);
      fd.append('content_id', String(contentId));
      fd.append('bbcode', editor.hidden.value || '');
      fd.append('attachments', JSON.stringify(collectAttachments()));
      fd.append('_csrf', root.dataset.csrf || '');
      fetch(saveUrl, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function () { dirty = false; })
        .catch(function () {});
    }

    const debouncedSave = debounce(saveDraft, 1200);

    function markDirty() {
      dirty = true;
      debouncedSave();
    }

    editor.visual.addEventListener('input', markDirty);
    editor.source.addEventListener('input', markDirty);

    // load draft if exists
    fetch(loadUrl + '?draft_key=' + encodeURIComponent(draftKey), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data || !data.ok || !data.draft) return;
        const bb = data.draft.bbcode || '';
        if (!bb) return;
        if (editor.hidden.value && editor.hidden.value.trim() !== '') return;
        if (confirm('Draft found. Restore?')) {
          editor.hidden.value = bb;
          editor.source.value = bb;
          editor.visual.innerHTML = window.ArcEditor.bbcodeToHtml(bb);
        }
      })
      .catch(function () {});

    window.addEventListener('beforeunload', function (e) {
      if (!dirty) return;
      e.preventDefault();
      e.returnValue = '';
    });
  });
})();
