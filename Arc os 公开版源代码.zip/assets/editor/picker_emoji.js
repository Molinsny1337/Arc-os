(function () {
  if (!window.ArcEditor) return;

  const RECENT_KEY = 'arc_emoji_recent';

  function loadRecent() {
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      const arr = JSON.parse(raw || '[]');
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function saveRecent(list) {
    try { localStorage.setItem(RECENT_KEY, JSON.stringify(list.slice(0, 24))); } catch (e) {}
  }

  function addRecent(key) {
    const list = loadRecent().filter(function (k) { return k !== key; });
    list.unshift(key);
    saveRecent(list);
  }

  function buildFallback() {
    const base = Array.isArray(window.ArcEmojiData) ? window.ArcEmojiData : [];
    return base.map(function (u, i) {
      return { id: 'u' + i, shortcode: '', unicode: u, image_url: '', is_sticker: 0, category: 'unicode' };
    });
  }

  window.ArcEditor.use(function (editor) {
    const root = editor.root;
    const panel = root.querySelector('[data-arc-editor-emoji]');
    if (!panel) return;

    const emojiUrl = root.dataset.emojiUrl || 'ajax/emojis.php';
    let loaded = false;
    let emojis = [];
    let byCategory = {};
    let activeCategory = 'recent';
    let listEl = null;
    let tabsEl = null;
    let searchEl = null;

    function setGlobals(data) {
      if (data && data.index) window.ArcEmojiIndex = data.index;
      if (data && data.by_id) window.ArcEmojiById = data.by_id;
    }

    function groupByCategory(items) {
      const map = {};
      items.forEach(function (it) {
        const cat = String(it.category || 'other');
        if (!map[cat]) map[cat] = [];
        map[cat].push(it);
      });
      return map;
    }

    function renderTabs() {
      const cats = Object.keys(byCategory);
      tabsEl.innerHTML = '';
      const allTabs = ['recent'].concat(cats);
      allTabs.forEach(function (cat) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'arc-emoji-tab' + (cat === activeCategory ? ' active' : '');
        btn.textContent = cat;
        btn.addEventListener('click', function () {
          activeCategory = cat;
          renderList();
          renderTabs();
        });
        tabsEl.appendChild(btn);
      });
    }

    function renderList() {
      const term = (searchEl.value || '').trim().toLowerCase();
      listEl.innerHTML = '';
      let list = [];
      if (term) {
        list = emojis.filter(function (it) {
          const code = String(it.shortcode || '').toLowerCase();
          return code.indexOf(term) !== -1;
        });
      } else if (activeCategory === 'recent') {
        const recent = loadRecent();
        list = recent.map(function (code) {
          return emojis.find(function (it) { return it.shortcode === code || String(it.id) === code; });
        }).filter(Boolean);
      } else {
        list = byCategory[activeCategory] || [];
      }

      if (!list.length) {
        const empty = document.createElement('div');
        empty.className = 'arc-emoji-empty';
        empty.textContent = 'No emojis';
        listEl.appendChild(empty);
        return;
      }

      list.forEach(function (it) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'arc-emoji-item';
        btn.setAttribute('aria-label', it.shortcode || 'emoji');
        if (it.unicode) {
          btn.textContent = it.unicode;
        } else if (it.image_url) {
          const img = document.createElement('img');
          img.src = it.image_url;
          img.alt = it.shortcode || 'emoji';
          btn.appendChild(img);
        } else {
          btn.textContent = ':' + (it.shortcode || '') + ':';
        }
        btn.addEventListener('click', function () {
          if (it.unicode) {
            editor.insertText(it.unicode);
          } else if (it.is_sticker) {
            editor.insertBbcode('[sticker=' + it.id + ']');
          } else {
            editor.insertBbcode('[emoji=' + it.shortcode + ']');
          }
          if (it.shortcode) addRecent(it.shortcode);
          else if (it.id) addRecent(String(it.id));
          panel.hidden = true;
        });
        listEl.appendChild(btn);
      });
    }

    function buildUI() {
      panel.innerHTML = '';
      panel.classList.add('arc-emoji-panel');

      const head = document.createElement('div');
      head.className = 'arc-emoji-head';

      searchEl = document.createElement('input');
      searchEl.type = 'text';
      searchEl.className = 'arc-emoji-search';
      searchEl.placeholder = 'Search emoji';
      searchEl.addEventListener('input', function () { renderList(); });

      head.appendChild(searchEl);
      panel.appendChild(head);

      tabsEl = document.createElement('div');
      tabsEl.className = 'arc-emoji-tabs';
      panel.appendChild(tabsEl);

      listEl = document.createElement('div');
      listEl.className = 'arc-emoji-list';
      panel.appendChild(listEl);
    }

    function ensureData() {
      if (loaded) return Promise.resolve();
      return fetch(emojiUrl, { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (!data || !data.ok) throw new Error('bad');
          const packs = Array.isArray(data.packs) ? data.packs : [];
          const items = [];
          packs.forEach(function (p) {
            const arr = Array.isArray(p.emojis) ? p.emojis : [];
            arr.forEach(function (it) { items.push(it); });
          });
          emojis = items.length ? items : buildFallback();
          byCategory = groupByCategory(emojis);
          setGlobals(data);
          loaded = true;
        })
        .catch(function () {
          emojis = buildFallback();
          byCategory = groupByCategory(emojis);
          loaded = true;
        });
    }

    editor.toggleEmoji = function () {
      panel.hidden = !panel.hidden;
      if (!panel.hidden) {
        ensureData().then(function () {
          if (!listEl) buildUI();
          renderTabs();
          renderList();
        });
      }
    };

    document.addEventListener('click', function (e) {
      if (panel.hidden) return;
      if (panel.contains(e.target) || root.contains(e.target)) return;
      panel.hidden = true;
    });
  });
})();
