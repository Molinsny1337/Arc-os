(() => {
  const prefersReducedMotion = () => {
    try {
      return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) {
      return false;
    }
  };

  function initTabs(scope) {
    const tabContainers = scope.querySelectorAll('[data-arc-tabs]');
    tabContainers.forEach((tabsEl) => {
      if (tabsEl.dataset.arcTabsInited) return;
      tabsEl.dataset.arcTabsInited = '1';

      const tabScope = tabsEl.closest('[data-arc-tabs-scope]') || scope;
      const triggers = Array.from(tabsEl.querySelectorAll('[data-arc-tab]'));
      const panels = Array.from(tabScope.querySelectorAll('[data-arc-tab-panel]'));

      if (!triggers.length || !panels.length) return;

      const getDefaultTab = () => {
        const explicit = tabsEl.getAttribute('data-arc-default');
        if (explicit) return explicit;
        const hash = (window.location.hash || '').replace('#tab-', '');
        if (hash) return hash;
        return triggers[0].getAttribute('data-arc-tab') || '';
      };

      const activate = (name, updateHash) => {
        if (!name) return;
        triggers.forEach((el) => {
          const isActive = el.getAttribute('data-arc-tab') === name;
          el.classList.toggle('active', isActive);
          el.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });
        panels.forEach((panel) => {
          const isActive = panel.getAttribute('data-arc-tab-panel') === name;
          panel.style.display = isActive ? 'block' : 'none';
          panel.setAttribute('aria-hidden', isActive ? 'false' : 'true');
        });
        if (updateHash && !prefersReducedMotion()) {
          const nextHash = '#tab-' + name;
          if (window.location.hash !== nextHash) {
            history.replaceState(null, '', nextHash);
          }
        }
      };

      tabsEl.addEventListener('click', (ev) => {
        const target = ev.target.closest('[data-arc-tab]');
        if (!target || !tabsEl.contains(target)) return;
        ev.preventDefault();
        activate(target.getAttribute('data-arc-tab') || '', true);
      });

      activate(getDefaultTab(), false);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initTabs(document));
  } else {
    initTabs(document);
  }
})();



