// Arc OS Rich Text Editor (lightweight; WP-classic-ish UX)
// Enhances: <textarea data-rte="1"> -> toolbar + Visual/Text tabs
// Submits sanitized HTML back into the textarea on form submit.

(function () {
  function $(sel, el) { return (el || document).querySelector(sel); }
  function $$(sel, el) { return Array.from((el || document).querySelectorAll(sel)); }

  const lang = ((document.documentElement && document.documentElement.getAttribute('lang')) || 'en').toLowerCase();
  const isZh = lang.startsWith('zh');
  const I18N = {
    en: {
      placeholder: 'Write something…',
      visual: 'Visual',
      text: 'Text',
      bold: 'Bold',
      italic: 'Italic',
      underline: 'Underline',
      strike: 'Strikethrough',
      heading: 'Heading',
      paragraph: 'Paragraph',
      h2: 'Heading 2',
      h3: 'Heading 3',
      ul: 'Bullet list',
      ol: 'Numbered list',
      quote: 'Quote',
      code: 'Code block',
      inlineCode: 'Inline code',
      link: 'Insert link',
      unlink: 'Remove link',
      image: 'Add media',
      undo: 'Undo',
      redo: 'Redo',
      clear: 'Clear formatting',
      uploading: 'Uploading image…',
      uploaded: 'Image inserted.',
      uploadFailed: 'Upload failed: ',
      linkUrl: 'Link URL (https://...)',
      linkText: 'Link text',
      codePrompt: 'Code',
    },
    zh: {
      placeholder: '写点什么…',
      visual: '可视化',
      text: '文本',
      bold: '加粗',
      italic: '斜体',
      underline: '下划线',
      strike: '删除线',
      heading: '标题',
      paragraph: '正文',
      h2: '标题 2',
      h3: '标题 3',
      ul: '无序列表',
      ol: '有序列表',
      quote: '引用',
      code: '代码块',
      inlineCode: '行内代码',
      link: '插入链接',
      unlink: '取消链接',
      image: '添加媒体',
      undo: '撤销',
      redo: '重做',
      clear: '清除格式',
      uploading: '正在上传图片…',
      uploaded: '已插入图片。',
      uploadFailed: '上传失败：',
      linkUrl: '链接地址（https://...）',
      linkText: '链接文字',
      codePrompt: '代码',
    },
  };

  function t(key) {
    const pack = isZh ? I18N.zh : I18N.en;
    return (pack && pack[key]) || I18N.en[key] || key;
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function createBtn(label, title, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'rte-btn';
    b.innerHTML = label;
    b.title = title;
    b.addEventListener('click', function (e) {
      e.preventDefault();
      onClick();
    });
    return b;
  }

  function createTab(label, isActive) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'rte-tab' + (isActive ? ' active' : '');
    b.textContent = label;
    return b;
  }

  function createSep() {
    const s = document.createElement('span');
    s.className = 'rte-sep';
    s.setAttribute('aria-hidden', 'true');
    return s;
  }

  function getCsrf(form) {
    const i = form ? form.querySelector('input[name="_csrf"]') : null;
    return i ? i.value : '';
  }

  function insertHTML(html) {
    document.execCommand('insertHTML', false, html);
  }

  async function uploadImage(file, form) {
    const csrf = getCsrf(form);
    const fd = new FormData();
    fd.append('_csrf', csrf);
    fd.append('image', file);
    const res = await fetch((window.__BASE_PATH__ || '') + '/upload_image.php', {
      method: 'POST',
      credentials: 'same-origin',
      body: fd,
    });
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok || !data || !data.ok) {
      const msg = (data && data.error) ? data.error : ('HTTP ' + res.status);
      throw new Error(msg);
    }
    return data.url;
  }

  function enhance(textarea) {
    if (!textarea || textarea.dataset.rteInited) return;
    textarea.dataset.rteInited = '1';

    const form = textarea.closest('form') || document.body;

    const wrap = document.createElement('div');
    wrap.className = 'rte';

    const top = document.createElement('div');
    top.className = 'rte-top';

    const tabs = document.createElement('div');
    tabs.className = 'rte-tabs';

    const tabVisual = createTab(t('visual'), true);
    const tabText = createTab(t('text'), false);
    tabs.appendChild(tabVisual);
    tabs.appendChild(tabText);

    const toolbar = document.createElement('div');
    toolbar.className = 'rte-toolbar';

    const editor = document.createElement('div');
    editor.className = 'rte-editor';
    editor.contentEditable = 'true';
    editor.setAttribute('role', 'textbox');
    editor.setAttribute('aria-multiline', 'true');
    editor.dataset.placeholder = textarea.getAttribute('placeholder') || t('placeholder');

    const status = document.createElement('div');
    status.className = 'rte-status';
    status.textContent = '';

    const source = document.createElement('textarea');
    source.className = 'rte-source';
    source.spellcheck = false;
    source.wrap = 'off';

    // initial content
    editor.innerHTML = textarea.value || '';
    source.value = textarea.value || '';

    // compact mode for places like profile comments
    const minH = parseInt(textarea.getAttribute('data-rte-min') || '', 10);
    if (!Number.isNaN(minH) && minH > 60 && minH < 1200) {
      editor.style.minHeight = String(minH) + 'px';
      source.style.minHeight = String(minH) + 'px';
    }

    // heading selector (XF-like)
    const heading = document.createElement('select');
    heading.className = 'rte-select';
    heading.title = t('heading');
    heading.innerHTML =
      '<option value="p">' + t('paragraph') + '</option>' +
      '<option value="h2">' + t('h2') + '</option>' +
      '<option value="h3">' + t('h3') + '</option>';
    heading.addEventListener('change', function () {
      const v = heading.value || 'p';
      document.execCommand('formatBlock', false, v);
      heading.value = 'p';
      editor.focus();
    });

    toolbar.appendChild(heading);
    toolbar.appendChild(createSep());

    toolbar.appendChild(createBtn('<b>B</b>', t('bold'), () => document.execCommand('bold', false)));
    toolbar.appendChild(createBtn('<i>I</i>', t('italic'), () => document.execCommand('italic', false)));
    toolbar.appendChild(createBtn('<span style="text-decoration:underline;">U</span>', t('underline'), () => document.execCommand('underline', false)));
    toolbar.appendChild(createBtn('<span style="text-decoration:line-through;">S</span>', t('strike'), () => document.execCommand('strikeThrough', false)));
    toolbar.appendChild(createSep());

    toolbar.appendChild(createBtn('•', t('ul'), () => document.execCommand('insertUnorderedList', false)));
    toolbar.appendChild(createBtn('1.', t('ol'), () => document.execCommand('insertOrderedList', false)));
    toolbar.appendChild(createSep());

    toolbar.appendChild(createBtn('❝', t('quote'), () => {
      const sel = window.getSelection();
      const text = sel ? sel.toString() : '';
      if (text.trim() === '') {
        insertHTML('<blockquote><p><br></p></blockquote>');
        return;
      }
      insertHTML('<blockquote><p>' + escapeHtml(text) + '</p></blockquote>');
    }));

    toolbar.appendChild(createBtn('&lt;/&gt;', t('code'), () => {
      const sel = window.getSelection();
      const text = sel ? sel.toString() : '';
      const code = (text && text.trim() !== '') ? text : (prompt(t('codePrompt')) || '');
      if (!code) return;
      insertHTML('<pre><code>' + escapeHtml(code) + '</code></pre>');
    }));

    toolbar.appendChild(createBtn('&lt;c&gt;', t('inlineCode'), () => {
      const sel = window.getSelection();
      const text = sel ? sel.toString() : '';
      if (text.trim() === '') return;
      insertHTML('<code>' + escapeHtml(text) + '</code>');
    }));

    toolbar.appendChild(createSep());

    toolbar.appendChild(createBtn('🔗', t('link'), () => {
      const url = prompt(t('linkUrl')) || '';
      if (!url.trim()) return;
      const sel = window.getSelection();
      const text = sel ? sel.toString() : '';
      if (text.trim() !== '') {
        document.execCommand('createLink', false, url);
      } else {
        const label = prompt(t('linkText')) || url;
        insertHTML('<a href="' + escapeHtml(url) + '">' + escapeHtml(label) + '</a>');
      }
      // best-effort: ensure rel/target
      try {
        const a = sel && sel.anchorNode ? sel.anchorNode.parentElement.closest('a') : null;
        if (a) {
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'nofollow ugc noopener');
        }
      } catch (e) {}
    }));

    toolbar.appendChild(createBtn('⛔', t('unlink'), () => document.execCommand('unlink', false)));
    toolbar.appendChild(createSep());

    toolbar.appendChild(createBtn('🖼️', t('image'), async () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        status.textContent = t('uploading');
        try {
          const url = await uploadImage(file, form);
          insertHTML('<img src="' + escapeHtml(url) + '" alt="">');
          status.textContent = t('uploaded');
        } catch (err) {
          status.textContent = t('uploadFailed') + (err && err.message ? err.message : '');
        }
      };
      input.click();
    }));

    toolbar.appendChild(createSep());
    toolbar.appendChild(createBtn('↶', t('undo'), () => document.execCommand('undo', false)));
    toolbar.appendChild(createBtn('↷', t('redo'), () => document.execCommand('redo', false)));
    toolbar.appendChild(createBtn('Tx', t('clear'), () => document.execCommand('removeFormat', false)));

    // build
    top.appendChild(tabs);
    top.appendChild(toolbar);
    wrap.appendChild(top);

    const body = document.createElement('div');
    body.className = 'rte-body';
    body.appendChild(editor);
    body.appendChild(source);
    wrap.appendChild(body);
    wrap.appendChild(status);

    textarea.style.display = 'none';
    textarea.insertAdjacentElement('afterend', wrap);

    function setMode(mode) {
      const isVisual = mode === 'visual';
      wrap.dataset.mode = isVisual ? 'visual' : 'text';
      tabVisual.classList.toggle('active', isVisual);
      tabText.classList.toggle('active', !isVisual);
      toolbar.style.display = isVisual ? '' : 'none';
      editor.style.display = isVisual ? '' : 'none';
      source.style.display = isVisual ? 'none' : '';
      if (isVisual) {
        // sync text -> visual
        editor.innerHTML = source.value || '';
        editor.focus();
      } else {
        // sync visual -> text
        source.value = editor.innerHTML || '';
        source.focus();
      }
    }

    tabVisual.addEventListener('click', (e) => { e.preventDefault(); setMode('visual'); });
    tabText.addEventListener('click', (e) => { e.preventDefault(); setMode('text'); });

    function normalizeEmpty() {
      const html = editor.innerHTML || '';
      const stripped = html.replace(/&nbsp;/g, ' ').replace(/<br\s*\/?\s*>/gi, '').trim();
      if (stripped === '' || stripped === '<p></p>' || stripped === '<p> </p>') editor.innerHTML = '';
    }

    // submit sync
    form.addEventListener('submit', function () {
      const mode = wrap.dataset.mode || 'visual';
      if (mode === 'text') {
        textarea.value = source.value || '';
      } else {
        normalizeEmpty();
        textarea.value = editor.innerHTML;
      }
    });

    // paste: plain text (safer)
    editor.addEventListener('paste', function (e) {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, text);
    });

    // paste in source: keep default behavior

    // default mode
    setMode('visual');
  }

  function init() {
    $$('textarea[data-rte="1"]').forEach(enhance);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
