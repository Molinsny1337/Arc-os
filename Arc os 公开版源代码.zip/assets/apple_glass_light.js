(() => {
  const prefersReducedMotion = () => {
    try {
      return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) {
      return false;
    }
  };

  function addHoverClass(selector) {
    document.querySelectorAll(selector).forEach((el) => {
      if (el.dataset.glassHover) return;
      el.dataset.glassHover = '1';
      el.addEventListener('pointerenter', () => {
        if (prefersReducedMotion()) return;
        el.classList.add('is-hover');
      });
      el.addEventListener('pointerleave', () => {
        el.classList.remove('is-hover');
      });
      el.addEventListener('focusin', () => {
        el.classList.add('is-hover');
      });
      el.addEventListener('focusout', () => {
        el.classList.remove('is-hover');
      });
    });
  }

  function enhanceTabs(scope) {
    scope.querySelectorAll('[data-tabs]').forEach((tabs) => {
      if (tabs.dataset.tabsReady) return;
      tabs.dataset.tabsReady = '1';

      const triggers = Array.from(tabs.querySelectorAll('[data-tab]'));
      if (!triggers.length) return;

      const container = tabs.closest('[data-tabs-scope]') || scope;
      const panels = Array.from(container.querySelectorAll('[data-panel]'));

      const activate = (name) => {
        triggers.forEach((t) => {
          const active = t.getAttribute('data-tab') === name;
          t.classList.toggle('active', active);
          t.setAttribute('aria-selected', active ? 'true' : 'false');
          t.setAttribute('role', 'tab');
        });
        panels.forEach((p) => {
          const active = p.getAttribute('data-panel') === name;
          p.style.display = active ? 'block' : 'none';
          p.setAttribute('aria-hidden', active ? 'false' : 'true');
          p.setAttribute('role', 'tabpanel');
        });
      };

      triggers.forEach((t) => {
        t.setAttribute('role', 'tab');
        t.setAttribute('aria-selected', 'false');
      });
      tabs.setAttribute('role', 'tablist');

      tabs.addEventListener('click', (ev) => {
        const trigger = ev.target.closest('[data-tab]');
        if (!trigger || !tabs.contains(trigger)) return;
        ev.preventDefault();
        activate(trigger.getAttribute('data-tab') || '');
      });

      const defaultTab = tabs.getAttribute('data-default') || triggers[0].getAttribute('data-tab') || '';
      activate(defaultTab);
    });
  }

  function enhanceReveal(scope) {
    scope.querySelectorAll('.reveal-group').forEach((group) => {
      const children = Array.from(group.children);
      children.forEach((el, index) => {
        if (!el.classList.contains('reveal')) el.classList.add('reveal');
        el.style.setProperty('--i', String(index));
      });
    });
  }

  function init() {
    addHoverClass('.card');
    addHoverClass('.list-item');
    enhanceTabs(document);
    enhanceReveal(document);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();