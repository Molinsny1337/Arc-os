<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$title = t('verify_title') . ' · ' . site_name();
$token = trim($_GET['token'] ?? '');
$err = '';
$ok = '';

try {
  if ($token === '') throw new RuntimeException(t('missing_token'));
  $pdo = db();
  $pfx = table_prefix();

  $stmt = $pdo->prepare("SELECT id, username, is_verified FROM {$pfx}users WHERE verify_token=? LIMIT 1");
  $stmt->execute([$token]);
  $u = $stmt->fetch();
  if (!$u) throw new RuntimeException(t('invalid_token'));

  $pdo->prepare("UPDATE {$pfx}users SET is_verified=1, verify_token=NULL, updated_at=NOW() WHERE id=?")->execute([(int)$u['id']]);

  $ok = t('verify_done');

  // If the user is logged in, refresh session
  if (!empty($_SESSION['user_id']) && (int)$_SESSION['user_id'] === (int)$u['id']) {
    refresh_session_user((int)$u['id']);
  }

} catch (Throwable $e) {
  $err = $e->getMessage();
}
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('verify_title')) ?></h1>
      <p class="reveal"><?= e(t('verify_sub')) ?></p>
    </header>

    <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>
    <?php if ($ok): ?>
      <div class="admin-card pad reveal" style="max-width:560px;margin:0 auto;">
        <?= e($ok) ?>
        <div class="note"><?= e(t('verify_done_note')) ?></div>
        <div style="margin-top:10px;display:flex;gap:10px;flex-wrap:wrap;">
          <a class="btn" href="<?= e(url('login.php')) ?>"><?= e(t('login')) ?></a>
          <a class="btn" href="<?= e(url('forum.php')) ?>"><?= e(t('open_forum')) ?></a>
        </div>
      </div>
    <?php endif; ?>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
