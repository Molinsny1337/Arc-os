<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

$me = current_user();
$commentId = (int)($_POST['id'] ?? 0);
$back = $_SERVER['HTTP_REFERER'] ?? url('index.php');

if ($commentId <= 0) {
  redirect($back);
}

$pdo = db();
$pfx = table_prefix();

$stmt = $pdo->prepare("SELECT c.id, c.user_id, c.profile_post_id, p.user_id AS profile_user_id
  FROM {$pfx}xf_profile_post_comments c
  JOIN {$pfx}xf_profile_posts p ON p.id=c.profile_post_id
  WHERE c.id=? LIMIT 1");
$stmt->execute([$commentId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) {
  redirect($back);
}

$commentUserId = (int)($row['user_id'] ?? 0);
$profileUserId = (int)($row['profile_user_id'] ?? 0);
$meId = (int)($me['id'] ?? 0);

if ($meId !== $commentUserId && $meId !== $profileUserId && !is_admin()) {
  http_response_code(403);
  exit('Forbidden');
}

try {
  $pdo->prepare("UPDATE {$pfx}xf_profile_post_comments SET is_deleted=1 WHERE id=?")
    ->execute([$commentId]);
} catch (Throwable $e) {}

redirect(url('user.php?id=' . $profileUserId));
