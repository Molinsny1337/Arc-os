<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/ReadStateService.php';

$pdo = db();
$pfx = table_prefix();
$me = current_user();
(new ArcOS\Services\Permission())->requirePerm($me, 'view_forum');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$total = 0;
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE type='forum' AND status='published' AND is_deleted=0");
  $stmt->execute();
  $total = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {
  $total = 0;
}

$items = [];
try {
  $stmt = $pdo->prepare("SELECT p.id, p.title, p.slug, p.created_at, p.reply_count, p.view_count, p.last_post_at,
      u.username AS author_username, u.avatar AS author_avatar,
      lu.username AS last_post_username,
      f.title AS forum_title
    FROM {$pfx}posts p
    LEFT JOIN {$pfx}users u ON u.id=p.author_id
    LEFT JOIN {$pfx}users lu ON lu.id=p.last_post_user_id
    LEFT JOIN {$pfx}forums f ON f.id=p.forum_id
    WHERE p.type='forum' AND p.status='published' AND p.is_deleted=0
    ORDER BY COALESCE(p.last_post_at, p.created_at) DESC
    LIMIT ? OFFSET ?");
  $stmt->bindValue(1, $perPage, PDO::PARAM_INT);
  $stmt->bindValue(2, $offset, PDO::PARAM_INT);
  $stmt->execute();
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $items = [];
}

$ids = array_map(fn($r) => (int)($r['id'] ?? 0), $items);
$ids = array_values(array_filter($ids, fn($v) => $v > 0));
$readMap = [];
if ($ids) {
  $readMap = ArcOS\Services\ReadStateService::threadMap($pdo, $pfx, (int)($me['id'] ?? 0), $ids);
}

$title = site_name() . ' - ' . t('whats_new');
$layoutItems = arc_get_layout_setting_items('whats_new_layout', arc_whats_new_layout_default_items(), arc_whats_new_layout_allowed_ids());
$__need_ui_layout = is_admin();
$__need_glass = true;
$__need_density = true;
$__need_tooltip = true;
?>
<?php include __DIR__ . '/partials/page_top.php'; ?>

<?php
  $layoutCanEdit = is_admin() ? '1' : '0';
  $layoutDefault = json_encode(arc_whats_new_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutDefault)) $layoutDefault = '[]';
  $layoutLabels = [];
  foreach (arc_whats_new_layout_allowed_ids() as $id) $layoutLabels[$id] = t('block_' . $id);
  $layoutLabelsJson = json_encode($layoutLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutLabelsJson)) $layoutLabelsJson = '{}';
  $layoutUi = [
    'edit' => t('layout_edit'),
    'done' => t('layout_done'),
    'reset' => t('reset'),
    'blocks' => t('layout_blocks'),
    'saved' => t('layout_saved'),
    'save_failed' => t('layout_save_failed'),
    'hide' => t('hide'),
    'show' => t('show'),
  ];
  $layoutUiJson = json_encode($layoutUi, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutUiJson)) $layoutUiJson = '{}';
?>

<main class="wrap"
  data-arc-layout-root="1"
  data-arc-can-edit="<?= e($layoutCanEdit) ?>"
  data-arc-layout-scope="whats_new_global"
  data-arc-save-url="<?= e(url('layout_save.php')) ?>"
  data-arc-csrf="<?= e(csrf_token()) ?>"
  data-arc-default="<?= e($layoutDefault) ?>"
  data-arc-labels="<?= e($layoutLabelsJson) ?>"
  data-arc-ui="<?= e($layoutUiJson) ?>"
>
  <?php foreach ($layoutItems as $it):
    $sid = (string)($it['id'] ?? '');
    $enabled = (bool)($it['enabled'] ?? true);
    if ($sid === '') continue;
  ?>
    <?php if ($sid === 'hero'): ?>
      <header class="hero xf-hero reveal-group" data-arc-layout-item="1" data-id="hero" <?= $enabled ? '' : 'hidden' ?>>
        <div>
          <h1 class="reveal"><?= e(t('whats_new')) ?></h1>
          <p class="reveal"><?= e(t('whats_new_sub')) ?></p>
        </div>
        <div class="card glass xf-hero-card reveal">
          <div class="xf-meta"><?= e(t('results')) ?>: <?= (int)$total ?></div>
        </div>
      </header>
    <?php elseif ($sid === 'whats_new_list'): ?>
      <section class="section reveal-group" data-arc-layout-item="1" data-id="whats_new_list" <?= $enabled ? '' : 'hidden' ?>>
        <div class="card glass reveal">
          <?php if (!$items): ?>
            <div class="muted"><?= e(t('no_data')) ?></div>
          <?php else: ?>
            <?php $threads = $items; include __DIR__ . '/partials/xf/thread_list.php'; ?>
          <?php endif; ?>
        </div>
        <?php
          if ($total > $perPage) {
            $base_url = url('whats_new.php');
            $query = [];
            $total_pages = (int)ceil($total / $perPage);
            $page = $page;
            include __DIR__ . '/partials/xf/pager.php';
          }
        ?>
      </section>
    <?php endif; ?>
  <?php endforeach; ?>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
