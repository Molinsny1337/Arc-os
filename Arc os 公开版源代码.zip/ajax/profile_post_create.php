<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
require_post();
require_csrf();

$me = current_user();
if (!$me) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'login_required'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

require_once __DIR__ . '/../includes/services/Permission.php';
require_once __DIR__ . '/../includes/services/BbCode.php';
require_once __DIR__ . '/../includes/services/MentionService.php';
require_once __DIR__ . '/../includes/services/UploadService.php';
require_once __DIR__ . '/../includes/services/ProfileService.php';

header('Content-Type: application/json; charset=utf-8');

try {
  (new ArcOS\Services\Permission())->requirePerm($me, 'post_profile', ['json' => true]);
  require_not_banned();

  $profileUserId = (int)($_POST['profile_user_id'] ?? 0);
  $message = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
  if ($profileUserId <= 0 || $message === '') {
    echo json_encode(['ok' => false, 'error' => 'invalid'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $pdo = db();
  $pfx = table_prefix();

  if (!ArcOS\Services\ProfileService::canPostOnProfile($pdo, $pfx, (int)$me['id'], $profileUserId)) {
    echo json_encode(['ok' => false, 'error' => 'forbidden'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_posts (user_id, author_user_id, message_bbcode, is_deleted, created_at, updated_at)
    VALUES (?,?,?,?,NOW(),NOW())");
  $stmt->execute([$profileUserId, (int)$me['id'], $message, 0]);
  $postId = (int)$pdo->lastInsertId();

  $draftKey = trim((string)($_POST['draft_key'] ?? ''));
  if ($draftKey !== '') {
    ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'profile_post', $postId);
  }

  ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'profile_post', $postId, $message);
  $tags = ArcOS\Services\MentionService::extractTags($message);
  ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'profile_post', $postId, $tags);

  if (function_exists('arc_create_alert')) {
    if ($profileUserId !== (int)$me['id']) {
      arc_create_alert($profileUserId, (int)$me['id'], 'profile_post', 'profile_post', $postId, []);
    }
  }

  echo json_encode(['ok' => true, 'id' => $postId], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'server_error'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
