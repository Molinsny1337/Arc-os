<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/../includes/services/EmojiService.php';

$packs = ArcOS\Services\EmojiService::listPacks($pdo, $pfx, false);
$index = ArcOS\Services\EmojiService::emojiIndex($pdo, $pfx);
$byId = [];
foreach ($index as $code => $item) {
  $id = (string)($item['id'] ?? '');
  if ($id !== '') $byId[$id] = $item;
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
  'ok' => true,
  'packs' => $packs,
  'index' => $index,
  'by_id' => $byId,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
