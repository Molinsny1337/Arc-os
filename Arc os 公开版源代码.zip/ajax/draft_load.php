<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}

$draftKey = trim((string)($_GET['draft_key'] ?? ''));
if ($draftKey === '') {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => true, 'draft' => null], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

require_once __DIR__ . '/../includes/services/EditorDraftService.php';
$draft = ArcOS\Services\EditorDraftService::load(db(), table_prefix(), (int)$me['id'], $draftKey);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'draft' => $draft], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);