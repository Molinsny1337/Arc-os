<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
$me = current_user();
if (!$me) { http_response_code(401); exit(json_encode(['ok'=>false,'error'=>'LOGIN_REQUIRED'])); }
require_once __DIR__ . '/../includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'manage_layout', ['json'=>true]);
require_post();
require_csrf();

$page = trim((string)($_POST['page'] ?? ''));
$json = (string)($_POST['layout'] ?? '');
if ($page === '' || $json === '') { http_response_code(400); exit(json_encode(['ok'=>false,'error'=>'BAD_REQUEST'])); }

$layoutJson = json_encode(json_decode($json, true), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if (!is_string($layoutJson)) { http_response_code(400); exit(json_encode(['ok'=>false,'error'=>'INVALID_JSON'])); }

$pdo = db();
$pfx = table_prefix();
try {
  $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_layout_settings (user_id, scope, page_key, layout_json, updated_at)
    VALUES (NULL, 'global', ?, ?, NOW())
    ON DUPLICATE KEY UPDATE layout_json=VALUES(layout_json), updated_at=NOW()");
  $stmt->execute([$page, $layoutJson]);
} catch (Throwable $e) {
  http_response_code(500);
  exit(json_encode(['ok'=>false,'error'=>'DB']));
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true]);