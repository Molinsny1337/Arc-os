<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
require_post();
require_csrf();

$me = current_user();
if (!$me) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'login_required'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

require_once __DIR__ . '/../includes/services/Permission.php';
require_once __DIR__ . '/../includes/services/BbCode.php';
require_once __DIR__ . '/../includes/services/MentionService.php';
require_once __DIR__ . '/../includes/services/UploadService.php';
require_once __DIR__ . '/../includes/services/ProfileService.php';

header('Content-Type: application/json; charset=utf-8');

try {
  (new ArcOS\Services\Permission())->requirePerm($me, 'post_profile', ['json' => true]);
  require_not_banned();

  $postId = (int)($_POST['profile_post_id'] ?? 0);
  $message = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
  if ($postId <= 0 || $message === '') {
    echo json_encode(['ok' => false, 'error' => 'invalid'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  if (function_exists('get_setting') && get_setting('profile_posts_enabled', '1') !== '1') {
    echo json_encode(['ok' => false, 'error' => 'disabled'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $pdo = db();
  $pfx = table_prefix();

  $stmt = $pdo->prepare("SELECT user_id FROM {$pfx}xf_profile_posts WHERE id=? LIMIT 1");
  $stmt->execute([$postId]);
  $profileUserId = (int)($stmt->fetchColumn() ?: 0);
  if ($profileUserId <= 0) {
    echo json_encode(['ok' => false, 'error' => 'invalid'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  if (!ArcOS\Services\ProfileService::canPostOnProfile($pdo, $pfx, (int)$me['id'], $profileUserId)) {
    echo json_encode(['ok' => false, 'error' => 'forbidden'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_post_comments (profile_post_id, user_id, message_bbcode, is_deleted, created_at)
    VALUES (?,?,?,?,NOW())");
  $stmt->execute([$postId, (int)$me['id'], $message, 0]);
  $commentId = (int)$pdo->lastInsertId();

  $draftKey = trim((string)($_POST['draft_key'] ?? ''));
  if ($draftKey !== '') {
    ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'profile_post_comment', $commentId);
  }

  ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'profile_post_comment', $commentId, $message);
  $tags = ArcOS\Services\MentionService::extractTags($message);
  ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'profile_post_comment', $commentId, $tags);

  $stmt = $pdo->prepare("SELECT user_id, author_user_id FROM {$pfx}xf_profile_posts WHERE id=? LIMIT 1");
  $stmt->execute([$postId]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($row && function_exists('arc_create_alert')) {
    $profileUserId = (int)($row['user_id'] ?? 0);
    $authorUserId = (int)($row['author_user_id'] ?? 0);
    if ($profileUserId > 0 && $profileUserId !== (int)$me['id']) {
      arc_create_alert($profileUserId, (int)$me['id'], 'profile_post_comment', 'profile_post', $postId, []);
    }
    if ($authorUserId > 0 && $authorUserId !== (int)$me['id'] && $authorUserId !== $profileUserId) {
      arc_create_alert($authorUserId, (int)$me['id'], 'profile_post_comment', 'profile_post', $postId, []);
    }
  }

  echo json_encode(['ok' => true, 'id' => $commentId], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'server_error'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
