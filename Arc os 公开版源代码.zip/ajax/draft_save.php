<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}

require_post();
require_csrf();

$draftKey = trim((string)($_POST['draft_key'] ?? ''));
$contentType = trim((string)($_POST['content_type'] ?? 'post'));
$contentId = (int)($_POST['content_id'] ?? 0);
$bbcode = (string)($_POST['bbcode'] ?? '');
$attachmentsRaw = (string)($_POST['attachments'] ?? '[]');
$attachments = [];
if ($attachmentsRaw !== '') {
  $tmp = json_decode($attachmentsRaw, true);
  if (is_array($tmp)) $attachments = $tmp;
}

require_once __DIR__ . '/../includes/services/EditorDraftService.php';
ArcOS\Services\EditorDraftService::save(db(), table_prefix(), (int)$me['id'], $draftKey, $contentType, $contentId, $bbcode, $attachments);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);