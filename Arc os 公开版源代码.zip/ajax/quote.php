<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}

$type = trim((string)($_GET['type'] ?? 'comment'));
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  http_response_code(400);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'BAD_ID']);
  exit;
}

$pdo = db();
$pfx = table_prefix();

$author = '';
$content = '';
try {
  if ($type === 'post') {
    $stmt = $pdo->prepare("SELECT p.content, u.username FROM {$pfx}posts p LEFT JOIN {$pfx}users u ON u.id=p.author_id WHERE p.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['content']; $author = (string)$row['username']; }
  } elseif ($type === 'profile_post') {
    $stmt = $pdo->prepare("SELECT p.message_bbcode, u.username FROM {$pfx}xf_profile_posts p LEFT JOIN {$pfx}users u ON u.id=p.author_user_id WHERE p.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['message_bbcode']; $author = (string)$row['username']; }
  } elseif ($type === 'profile_post_comment') {
    $stmt = $pdo->prepare("SELECT p.message_bbcode, u.username FROM {$pfx}xf_profile_post_comments p LEFT JOIN {$pfx}users u ON u.id=p.user_id WHERE p.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['message_bbcode']; $author = (string)$row['username']; }
  } elseif ($type === 'profile_comment') {
    $stmt = $pdo->prepare("SELECT p.content, u.username FROM {$pfx}profile_comments p LEFT JOIN {$pfx}users u ON u.id=p.author_id WHERE p.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['content']; $author = (string)$row['username']; }
  } elseif ($type === 'conversation') {
    $stmt = $pdo->prepare("SELECT m.message, u.username FROM {$pfx}conversation_messages m LEFT JOIN {$pfx}users u ON u.id=m.user_id WHERE m.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['message']; $author = (string)$row['username']; }
  } else {
    $stmt = $pdo->prepare("SELECT c.content, u.username FROM {$pfx}post_comments c LEFT JOIN {$pfx}users u ON u.id=c.author_id WHERE c.id=? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) { $content = (string)$row['content']; $author = (string)$row['username']; }
  }
} catch (Throwable $e) {}

if ($content === '') {
  http_response_code(404);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'NOT_FOUND']);
  exit;
}

// If stored as HTML, strip tags for safety.
if (preg_match('/<[^>]+>/', $content)) {
  $content = strip_tags($content);
}
$content = trim($content);

$meta = $author !== '' ? ($author . ', id=' . $id) : ('id=' . $id);
$bbcode = '[quote=' . $meta . ']' . $content . "[/quote]\n";

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'bbcode' => $bbcode], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
