<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}
require_once __DIR__ . '/../includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'upload_attachment', ['json' => true, 'status' => 403]);
require_post();
require_csrf();

$attId = (int)($_POST['attachment_id'] ?? 0);
if ($attId <= 0) {
  http_response_code(400);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'BAD_ID']);
  exit;
}

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/../includes/services/UploadService.php';
$ok = ArcOS\Services\UploadService::deleteAttachment($pdo, $pfx, $attId, (int)$me['id']);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => $ok], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);