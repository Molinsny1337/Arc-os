<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_once __DIR__ . '/../includes/services/Permission.php';

$pdo = db();
$pfx = table_prefix();
$me = current_user();
(new ArcOS\Services\Permission())->requirePerm($me, 'view_profiles');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'invalid_id']);
  exit;
}

$user = null;
try {
  $stmt = $pdo->prepare("SELECT id, username, display_name, avatar, user_title, role, created_at, last_active
    FROM {$pfx}users WHERE id=? LIMIT 1");
  $stmt->execute([$id]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
  $user = null;
}

if (!$user) {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'not_found']);
  exit;
}

$threadCount = 0;
$replyCount = 0;
$reactionScore = 0;
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE author_id=? AND type='forum' AND status='published'");
  $stmt->execute([$id]);
  $threadCount = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE author_id=? AND is_deleted=0");
  $stmt->execute([$id]);
  $replyCount = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_reactions r JOIN {$pfx}posts p ON p.id=r.post_id WHERE p.author_id=?");
  $stmt->execute([$id]);
  $reactionScore = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}

$isFollowing = false;
$meId = (int)($me['id'] ?? 0);
if ($meId > 0 && $meId !== $id) {
  try {
    $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=? LIMIT 1");
    $stmt->execute([$meId, $id]);
    $isFollowing = (bool)$stmt->fetchColumn();
  } catch (Throwable $e) {}
}

$name = function_exists('display_name_of') ? display_name_of($user) : (string)($user['username'] ?? '');
$avatar = (string)($user['avatar'] ?? '');
if ($avatar !== '' && function_exists('arc_avatar_url')) $avatar = arc_avatar_url($avatar);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
  'ok' => true,
  'user' => [
    'id' => (int)$user['id'],
    'name' => $name,
    'username' => (string)($user['username'] ?? ''),
    'title' => (string)($user['user_title'] ?? ''),
    'role' => (string)($user['role'] ?? ''),
    'avatar' => $avatar,
    'joined' => (string)($user['created_at'] ?? ''),
    'last_active' => (string)($user['last_active'] ?? ''),
    'threads' => $threadCount,
    'replies' => $replyCount,
    'reactions' => $reactionScore,
    'is_following' => $isFollowing,
  ],
  'urls' => [
    'profile' => url('user.php?id=' . (int)$user['id']),
    'message' => url('conversation_new.php?to=' . urlencode((string)($user['username'] ?? ''))),
    'follow' => url('follow.php'),
  ],
]);
