<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}

$q = trim((string)($_GET['q'] ?? ''));
if ($q === '' || strlen($q) < 2) {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => true, 'items' => []], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/../includes/services/MentionService.php';
$rows = ArcOS\Services\MentionService::suggestUsers($pdo, $pfx, $q, 8);
$items = [];
foreach ($rows as $r) {
  $avatar = (string)($r['avatar'] ?? '');
  if ($avatar !== '' && function_exists('arc_avatar_url')) {
    $avatar = arc_avatar_url($avatar);
  }
  $items[] = [
    'id' => (int)($r['id'] ?? 0),
    'name' => (string)(($r['display_name'] ?? '') !== '' ? $r['display_name'] : ($r['username'] ?? '')),
    'avatar' => $avatar,
  ];
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'items' => $items], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
