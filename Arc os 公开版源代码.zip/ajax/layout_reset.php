<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
$me = current_user();
if (!$me) { http_response_code(401); exit(json_encode(['ok'=>false,'error'=>'LOGIN_REQUIRED'])); }
require_once __DIR__ . '/../includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'manage_layout', ['json'=>true]);
require_post();
require_csrf();

$page = trim((string)($_POST['page'] ?? ''));
if ($page === '') { http_response_code(400); exit(json_encode(['ok'=>false,'error'=>'BAD_PAGE'])); }

$pdo = db();
$pfx = table_prefix();
try {
  $stmt = $pdo->prepare("DELETE FROM {$pfx}xf_layout_settings WHERE scope='global' AND page_key=?");
  $stmt->execute([$page]);
} catch (Throwable $e) {
  http_response_code(500);
  exit(json_encode(['ok'=>false,'error'=>'DB']));
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true]);