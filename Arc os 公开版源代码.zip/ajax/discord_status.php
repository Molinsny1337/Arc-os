<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

header('Content-Type: application/json; charset=utf-8');

$me = current_user();
if (!$me) {
  echo json_encode(['ok' => false, 'error' => 'login_required'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

try {
  $pdo = db();
  $pfx = table_prefix();
  $stmt = $pdo->prepare("SELECT discord_user_id, discord_username, discord_discriminator, discord_avatar FROM {$pfx}xf_user_discord WHERE user_id=? LIMIT 1");
  $stmt->execute([(int)$me['id']]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) {
    echo json_encode(['ok' => true, 'bound' => false], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $uid = (string)($row['discord_user_id'] ?? '');
  $name = (string)($row['discord_username'] ?? '');
  $disc = (string)($row['discord_discriminator'] ?? '');
  $avatar = (string)($row['discord_avatar'] ?? '');
  $label = $name;
  if ($disc !== '' && $disc !== '0') $label .= '#' . $disc;

  $avatarUrl = '';
  if ($uid !== '' && $avatar !== '') {
    $avatarUrl = 'https://cdn.discordapp.com/avatars/' . rawurlencode($uid) . '/' . rawurlencode($avatar) . '.png?size=96';
  }

  echo json_encode([
    'ok' => true,
    'bound' => true,
    'discord_username' => $label,
    'avatar_url' => $avatarUrl,
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  echo json_encode(['ok' => false, 'error' => 'server_error'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
