<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$me = current_user();
if (!$me) {
  http_response_code(401);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => false, 'error' => 'LOGIN_REQUIRED']);
  exit;
}

$q = trim((string)($_GET['q'] ?? ''));
if ($q === '') {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['ok' => true, 'items' => []], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/../includes/services/MentionService.php';
$items = ArcOS\Services\MentionService::suggestTags($pdo, $pfx, $q, 8);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'items' => $items], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);