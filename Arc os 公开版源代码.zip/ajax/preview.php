<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
require_post();
require_csrf();

$bbcode = '';
if (stripos((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json') !== false) {
  $raw = file_get_contents('php://input');
  $data = $raw ? json_decode($raw, true) : null;
  if (is_array($data)) $bbcode = (string)($data['bbcode'] ?? '');
} else {
  $bbcode = (string)($_POST['bbcode'] ?? '');
}

require_once __DIR__ . '/../includes/services/BbCode.php';
$pdo = db();
$pfx = table_prefix();
$html = ArcOS\Services\BbCode::render($bbcode, $pdo, $pfx);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'html' => $html], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);