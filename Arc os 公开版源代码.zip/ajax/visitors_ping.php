<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
require_post();
require_csrf();

$me = current_user();
if (!$me) {
  http_response_code(403);
  echo json_encode(['ok' => false, 'error' => 'login_required'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

require_once __DIR__ . '/../includes/services/ProfileService.php';

header('Content-Type: application/json; charset=utf-8');

try {
  $profileUserId = (int)($_POST['user_id'] ?? 0);
  if ($profileUserId <= 0 || $profileUserId === (int)$me['id']) {
    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  if (function_exists('get_setting') && get_setting('profile_visitors_enabled', '1') !== '1') {
    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  $pdo = db();
  $pfx = table_prefix();
  ArcOS\Services\ProfileService::recordVisit($pdo, $pfx, $profileUserId, (int)$me['id']);

  echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok' => false, 'error' => 'server_error'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
