<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();
$me = current_user();
if (!$me) { http_response_code(401); exit(json_encode(['ok'=>false,'error'=>'LOGIN_REQUIRED'])); }
require_once __DIR__ . '/../includes/services/Permission.php';
(new ArcOS\Services\Permission())->requirePerm($me, 'manage_layout', ['json'=>true]);

$page = trim((string)($_GET['page'] ?? ''));
if ($page === '') { http_response_code(400); exit(json_encode(['ok'=>false,'error'=>'BAD_PAGE'])); }

$pdo = db();
$pfx = table_prefix();
try {
  $stmt = $pdo->prepare("SELECT layout_json FROM {$pfx}xf_layout_settings WHERE scope='global' AND page_key=? LIMIT 1");
  $stmt->execute([$page]);
  $json = (string)($stmt->fetchColumn() ?: '');
  $layout = $json ? json_decode($json, true) : null;
} catch (Throwable $e) { $layout = null; }
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true,'layout'=>$layout], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);