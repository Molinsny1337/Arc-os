<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();
$__need_glass = true;
$__need_tooltip = true;

require_once __DIR__ . '/includes/modules/forum/ForumRepository.php';
require_once __DIR__ . '/includes/modules/forum/ThreadRepository.php';
require_once __DIR__ . '/includes/services/ReadStateService.php';
require_once __DIR__ . '/includes/services/WatchService.php';
require_once __DIR__ . '/includes/services/Permission.php';

$forumRepo = new ArcOS\Modules\Forum\ForumRepository($pdo, $pfx);
$threadRepo = new ArcOS\Modules\Forum\ThreadRepository($pdo, $pfx);
$perm = new ArcOS\Services\Permission();

$fid = isset($_GET['fid']) ? (int)$_GET['fid'] : 0;
if ($fid <= 0) {
  http_response_code(404);
  $title = t('not_found');
  $langCode = function_exists('lang') ? lang() : 'en';
  ?>
  <!doctype html>
  <html lang="<?= e($langCode) ?>">
  <head>
    <?php include __DIR__ . '/partials/head.php'; ?>
  </head>
  <body>
    <?php include __DIR__ . '/partials/nav.php'; ?>
    <main class="wrap xf-apple xf-forum-view">
      <header class="hero xf-hero reveal-group">
        <h1 class="reveal"><?= e(t('not_found')) ?></h1>
      </header>
    </main>
    <?php include __DIR__ . '/partials/footer.php'; ?>
  </body>
  </html>
  <?php
  exit;
}

$forumRow = $forumRepo->fetchForum($fid);
if (!$forumRow) {
  http_response_code(404);
  $title = t('not_found');
  $langCode = function_exists('lang') ? lang() : 'en';
  ?>
  <!doctype html>
  <html lang="<?= e($langCode) ?>">
  <head>
    <?php include __DIR__ . '/partials/head.php'; ?>
  </head>
  <body>
    <?php include __DIR__ . '/partials/nav.php'; ?>
    <main class="wrap xf-apple xf-forum-view">
      <header class="hero xf-hero reveal-group">
        <h1 class="reveal"><?= e(t('not_found')) ?></h1>
      </header>
    </main>
    <?php include __DIR__ . '/partials/footer.php'; ?>
  </body>
  </html>
  <?php
  exit;
}

$me = current_user();
$meId = (int)($me['id'] ?? 0);
$canModerate = $perm->can($me, 'soft_delete') || (function_exists('is_admin') && is_admin());

$sort = (string)($_GET['sort'] ?? 'last_reply');
$read = (string)($_GET['read'] ?? 'all');
$prefixId = (int)($_GET['prefix'] ?? 0);
$tag = trim((string)($_GET['tag'] ?? ''));
$watching = isset($_GET['watching']) && (int)$_GET['watching'] === 1;

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

$filters = [
  'read' => $read,
  'prefix' => $prefixId,
  'tag' => $tag,
  'watching' => $watching,
];

$threads = $threadRepo->fetchByForum($fid, $sort, $page, $perPage, $filters, $meId);
$totalThreads = $threadRepo->countByForum($fid, $filters, $meId);
$totalPages = max(1, (int)ceil($totalThreads / $perPage));
if ($page > $totalPages) $page = $totalPages;

$threadIds = array_map(function(array $r): int { return (int)($r['id'] ?? 0); }, $threads);
$readMap = $meId > 0 ? ArcOS\Services\ReadStateService::threadMap($pdo, $pfx, $meId, $threadIds) : [];

$prefixes = [];
try {
  $stmt = $pdo->prepare("SELECT id, title, css_class FROM {$pfx}xf_thread_prefixes WHERE is_enabled=1 ORDER BY display_order ASC, id ASC");
  $stmt->execute();
  $prefixes = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$isWatching = false;
if ($meId > 0) {
  $isWatching = ArcOS\Services\WatchService::isWatchingForum($pdo, $pfx, $meId, $fid);
}

$title = site_name() . ' - ' . (string)$forumRow['title'];
$langCode = function_exists('lang') ? lang() : 'en';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

<main class="wrap xf-apple xf-forum-view">
  <?php $crumbs = [
    ['label' => t('forum'), 'url' => url('forum.php')],
    ['label' => (string)$forumRow['title']],
  ]; ?>
  <?php include __DIR__ . '/partials/xf/breadcrumb.php'; ?>

  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e((string)$forumRow['title']) ?></h1>
      <?php if (!empty($forumRow['description'])): ?><p class="reveal"><?= e((string)$forumRow['description']) ?></p><?php endif; ?>
      <div class="xf-hero-actions reveal">
        <a class="btn primary" href="<?= e(url('forum_new.php?fid=' . (int)$forumRow['id'])) ?>"><?= e(t('new_topic')) ?></a>
        <a class="btn" href="<?= e(url('whats_new.php')) ?>"><?= e(t('whats_new')) ?></a>
      </div>
    </div>
    <div class="card glass xf-hero-card reveal">
      <h3><?= e(t('threads')) ?></h3>
      <p><?= (int)($forumRow['thread_count'] ?? 0) ?> <?= e(t('threads')) ?> ? <?= (int)($forumRow['message_count'] ?? 0) ?> <?= e(t('replies')) ?></p>
      <?php if ($meId > 0): ?>
        <form method="post" action="<?= e(url('watch_forum.php')) ?>" style="margin-top:8px">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$forumRow['id'] ?>">
          <button class="btn" type="submit"><?= $isWatching ? e(t('unwatch')) : e(t('watch')) ?></button>
        </form>
      <?php endif; ?>
    </div>
  </header>

  <div class="xf-toolbar reveal">
    <div class="xf-filters">
      <?php
        $sortOptions = [
          'last_reply' => t('sort_last_reply'),
          'created' => t('sort_newest'),
          'replies' => t('sort_replies'),
          'views' => t('sort_views'),
        ];
      ?>
      <?php foreach ($sortOptions as $key => $label): ?>
        <a class="xf-filter<?= $sort === $key ? ' active' : '' ?>" href="<?= e(url('forum_view.php?fid=' . (int)$forumRow['id'] . '&sort=' . urlencode($key))) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>
    <div class="xf-actions">
      <form method="get" action="<?= e(url('forum_view.php')) ?>" class="xf-toolbar-form">
        <input type="hidden" name="fid" value="<?= (int)$forumRow['id'] ?>">
        <select class="input" name="read">
          <option value="all" <?= $read === 'all' ? 'selected' : '' ?>><?= e(t('all')) ?></option>
          <option value="unread" <?= $read === 'unread' ? 'selected' : '' ?>><?= e(t('unread')) ?></option>
          <option value="read" <?= $read === 'read' ? 'selected' : '' ?>><?= e(t('read')) ?></option>
        </select>
        <select class="input" name="prefix">
          <option value="0"><?= e(t('prefix')) ?></option>
          <?php foreach ($prefixes as $px): ?>
            <option value="<?= (int)$px['id'] ?>" <?= $prefixId === (int)$px['id'] ? 'selected' : '' ?>><?= e((string)$px['title']) ?></option>
          <?php endforeach; ?>
        </select>
        <input class="input" name="tag" value="<?= e($tag) ?>" placeholder="#tag" />
        <?php if ($meId > 0): ?>
          <label class="xf-check">
            <input type="checkbox" name="watching" value="1" <?= $watching ? 'checked' : '' ?> />
            <span><?= e(t('watching')) ?></span>
          </label>
        <?php endif; ?>
        <button class="btn" type="submit"><?= e(t('filter')) ?></button>
      </form>
    </div>
  </div>

  <?php if ($totalPages > 1): ?>
    <?php
      $base_url = url('forum_view.php');
      $query = ['fid' => (int)$forumRow['id'], 'sort' => $sort, 'read' => $read, 'prefix' => $prefixId, 'tag' => $tag];
      if ($watching) $query['watching'] = '1';
      $total_pages = $totalPages;
      include __DIR__ . '/partials/xf/pager.php';
    ?>
  <?php endif; ?>

  <section class="section reveal-group">
    <div class="card glass reveal">
      <?php
        $threads = $threads;
        $readMap = $readMap;
        $canModerate = $canModerate;
        include __DIR__ . '/partials/xf/thread_list.php';
      ?>
    </div>
  </section>

  <?php if ($totalPages > 1): ?>
    <?php
      $base_url = url('forum_view.php');
      $query = ['fid' => (int)$forumRow['id'], 'sort' => $sort, 'read' => $read, 'prefix' => $prefixId, 'tag' => $tag];
      if ($watching) $query['watching'] = '1';
      $total_pages = $totalPages;
      include __DIR__ . '/partials/xf/pager.php';
    ?>
  <?php endif; ?>
</main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
