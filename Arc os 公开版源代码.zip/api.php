<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

function api_json($data, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store');
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function api_get_key(): string {
  $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (is_string($h) && preg_match('/^\\s*Bearer\\s+(.+)\\s*$/i', $h, $m)) return trim((string)$m[1]);
  $k = $_SERVER['HTTP_X_API_KEY'] ?? '';
  if (is_string($k) && $k !== '') return trim($k);
  $k = $_GET['key'] ?? '';
  return is_string($k) ? trim($k) : '';
}

function api_require_enabled(): void {
  if (get_setting('api_enabled', '0') !== '1') api_json(['ok' => false, 'error' => 'api_disabled'], 404);
}

function api_require_master(): void {
  $master = (string)get_setting('api_master_key', '');
  if ($master === '') api_json(['ok' => false, 'error' => 'api_key_not_set'], 403);
  $k = api_get_key();
  if ($k === '' || !hash_equals($master, $k)) api_json(['ok' => false, 'error' => 'unauthorized'], 401);
}

function api_require_entitlement_or_master(): void {
  $master = (string)get_setting('api_master_key', '');
  $ent = (string)get_setting('api_entitlement_key', '');
  if ($master === '' && $ent === '') api_json(['ok' => false, 'error' => 'api_key_not_set'], 403);
  $k = api_get_key();
  if ($k === '') api_json(['ok' => false, 'error' => 'unauthorized'], 401);
  if ($master !== '' && hash_equals($master, $k)) return;
  if ($ent !== '' && hash_equals($ent, $k)) return;
  api_json(['ok' => false, 'error' => 'unauthorized'], 401);
}

function api_require_read_or_master(): void {
  if (get_setting('api_public_read', '1') === '1') return;
  api_require_master();
}

// CORS / preflight (optional)
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
  api_require_enabled();
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Headers: Authorization, X-API-Key, Content-Type');
  header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
  exit;
}

api_require_enabled();
header('Access-Control-Allow-Origin: *');

$pdo = db();
$pfx = table_prefix();

$resource = (string)($_GET['resource'] ?? ($_GET['r'] ?? 'info'));
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($method === 'GET' && ($resource === '' || $resource === 'info')) {
  api_require_read_or_master();
  api_json([
    'ok' => true,
    'resources' => [
      'info' => ['method' => 'GET', 'desc' => 'API info'],
      'posts' => ['method' => 'GET', 'desc' => 'List posts: type=forum|page, status=published|draft|all'],
      'post' => ['method' => 'GET', 'desc' => 'Get post by id or slug'],
      'forums' => ['method' => 'GET', 'desc' => 'List forums'],
      'forum_threads' => ['method' => 'GET', 'desc' => 'List forum threads: forum_id or forum_slug'],
      'groups' => ['method' => 'GET', 'auth' => 'master', 'desc' => 'List identity groups'],
      'entitlement' => ['method' => 'GET', 'auth' => 'entitlement_or_master', 'desc' => 'Check user groups / paid status'],
      'custom_css' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Update custom CSS'],
      'custom_head_html' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Update custom <head> HTML injection'],
      'custom_footer_html' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Update custom footer HTML injection'],
      'custom_js' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Update custom JS injection'],
      'appearance' => ['method' => 'GET', 'auth' => 'master', 'desc' => 'Get appearance injections (CSS/JS/head/footer)'],
      'page' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Create/update a page (type=page)'],
      'layout' => ['method' => 'POST', 'auth' => 'master', 'desc' => 'Save home layout JSON'],
    ],
  ]);
}

if ($method === 'GET' && $resource === 'posts') {
  api_require_read_or_master();
  $type = (string)($_GET['type'] ?? 'all');
  if (!in_array($type, ['all', 'forum', 'page'], true)) $type = 'all';

  $status = (string)($_GET['status'] ?? 'published');
  if (!in_array($status, ['all', 'published', 'draft'], true)) $status = 'published';

  $limit = max(1, min(100, (int)($_GET['limit'] ?? 20)));
  $offset = max(0, (int)($_GET['offset'] ?? 0));

  $where = [];
  $params = [];
  if ($type !== 'all') { $where[] = "type=?"; $params[] = $type; }
  if ($status !== 'all') { $where[] = "status=?"; $params[] = $status; }
  $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

  $stmt = $pdo->prepare("SELECT id, type, forum_id, title, slug, excerpt, status, created_at, updated_at, author_id
    FROM {$pfx}posts {$whereSql}
    ORDER BY created_at DESC
    LIMIT {$limit} OFFSET {$offset}");
  $stmt->execute($params);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  api_json(['ok' => true, 'items' => $rows]);
}

if ($method === 'GET' && $resource === 'post') {
  api_require_read_or_master();
  $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
  $slug = trim((string)($_GET['slug'] ?? ''));
  if ($id <= 0 && $slug === '') api_json(['ok' => false, 'error' => 'missing_id_or_slug'], 400);

  if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}posts WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
  } else {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}posts WHERE slug=? LIMIT 1");
    $stmt->execute([$slug]);
  }
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$row) api_json(['ok' => false, 'error' => 'not_found'], 404);
  api_json(['ok' => true, 'item' => $row]);
}

if ($method === 'GET' && $resource === 'forums') {
  api_require_read_or_master();
  $rows = $pdo->query("SELECT id, parent_id, title, slug, description, display_order, thread_count, message_count, last_post_at, created_at
    FROM {$pfx}forums
    ORDER BY parent_id IS NULL DESC, display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  api_json(['ok' => true, 'items' => $rows]);
}

if ($method === 'GET' && $resource === 'forum_threads') {
  api_require_read_or_master();
  $forumId = isset($_GET['forum_id']) ? (int)$_GET['forum_id'] : 0;
  $forumSlug = trim((string)($_GET['forum_slug'] ?? ''));
  if ($forumId <= 0 && $forumSlug === '') api_json(['ok' => false, 'error' => 'missing_forum'], 400);
  if ($forumId <= 0) {
    $st = $pdo->prepare("SELECT id FROM {$pfx}forums WHERE slug=? LIMIT 1");
    $st->execute([$forumSlug]);
    $forumId = (int)($st->fetchColumn() ?: 0);
    if ($forumId <= 0) api_json(['ok' => false, 'error' => 'forum_not_found'], 404);
  }
  $limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
  $offset = max(0, (int)($_GET['offset'] ?? 0));
  $stmt = $pdo->prepare("SELECT id, forum_id, title, slug, reply_count, view_count, is_sticky, is_locked, created_at, updated_at
    FROM {$pfx}posts
    WHERE type='forum' AND status='published' AND forum_id=?
    ORDER BY is_sticky DESC, last_post_at DESC, created_at DESC
    LIMIT {$limit} OFFSET {$offset}");
  $stmt->execute([$forumId]);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  api_json(['ok' => true, 'items' => $rows]);
}

if ($method === 'GET' && $resource === 'groups') {
  api_require_master();
  $tG = $pfx . 'groups';
  $tUG = $pfx . 'user_groups';
  try {
    $rows = $pdo->query("SELECT g.id, g.slug, g.name, g.is_paid,
        (SELECT COUNT(*) FROM {$tUG} ug WHERE ug.group_id = g.id) AS members
      FROM {$tG} g
      ORDER BY g.is_paid DESC, g.name ASC, g.id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    api_json(['ok' => true, 'items' => $rows]);
  } catch (Throwable $e) {
    api_json(['ok' => true, 'items' => []]);
  }
}

if ($method === 'GET' && $resource === 'entitlement') {
  api_require_entitlement_or_master();

  $userIn = trim((string)($_GET['user'] ?? ''));
  $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
  if ($id <= 0 && $userIn === '') api_json(['ok' => false, 'error' => 'missing_user'], 400);

  // Resolve user
  if ($id > 0) {
    $st = $pdo->prepare("SELECT id, username FROM {$pfx}users WHERE id=? LIMIT 1");
    $st->execute([$id]);
  } else {
    $st = $pdo->prepare("SELECT id, username FROM {$pfx}users WHERE username=? OR email=? LIMIT 1");
    $st->execute([$userIn, $userIn]);
  }
  $u = $st->fetch(PDO::FETCH_ASSOC);
  if (!$u) api_json(['ok' => false, 'error' => 'user_not_found'], 404);
  $uid = (int)($u['id'] ?? 0);

  $groups = [];
  $paid = false;
  try {
    $tUG = $pfx . 'user_groups';
    $tG = $pfx . 'groups';
    $st2 = $pdo->prepare("SELECT g.slug, g.is_paid
      FROM {$tUG} ug
      JOIN {$tG} g ON g.id = ug.group_id
      WHERE ug.user_id = ?
      ORDER BY g.is_paid DESC, g.slug ASC");
    $st2->execute([$uid]);
    while ($r = $st2->fetch(PDO::FETCH_ASSOC)) {
      $slug = (string)($r['slug'] ?? '');
      if ($slug === '') continue;
      $groups[] = $slug;
      if ((int)($r['is_paid'] ?? 0) === 1) $paid = true;
    }
  } catch (Throwable $e) {}

  api_json([
    'ok' => true,
    'user' => [
      'id' => $uid,
      'username' => (string)($u['username'] ?? ''),
    ],
    'groups' => $groups,
    'paid' => $paid,
  ]);
}

if ($method === 'GET' && $resource === 'appearance') {
  api_require_master();
  api_json([
    'ok' => true,
    'custom_css' => (string)get_setting('custom_css', ''),
    'custom_head_html' => (string)get_setting('custom_head_html', ''),
    'custom_footer_html' => (string)get_setting('custom_footer_html', ''),
    'custom_js' => (string)get_setting('custom_js', ''),
  ]);
}

// write resources
if ($method === 'POST' && $resource === 'custom_css') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);
  $css = (string)($j['css'] ?? '');
  set_setting('custom_css', $css);
  api_json(['ok' => true]);
}

if ($method === 'POST' && $resource === 'custom_head_html') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);
  $html = (string)($j['html'] ?? ($j['head_html'] ?? ''));
  set_setting('custom_head_html', $html);
  api_json(['ok' => true]);
}

if ($method === 'POST' && $resource === 'custom_footer_html') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);
  $html = (string)($j['html'] ?? ($j['footer_html'] ?? ''));
  set_setting('custom_footer_html', $html);
  api_json(['ok' => true]);
}

if ($method === 'POST' && $resource === 'custom_js') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);
  $js = (string)($j['js'] ?? '');
  set_setting('custom_js', $js);
  api_json(['ok' => true]);
}

if ($method === 'POST' && $resource === 'layout') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);
  set_setting('home_layout', json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  api_json(['ok' => true]);
}

if ($method === 'POST' && $resource === 'page') {
  api_require_master();
  $raw = file_get_contents('php://input') ?: '';
  $j = json_decode($raw, true);
  if (!is_array($j)) api_json(['ok' => false, 'error' => 'invalid_json'], 400);

  $pageId = isset($j['id']) ? (int)$j['id'] : 0;
  $titleIn = trim((string)($j['title'] ?? ''));
  $slugIn = trim((string)($j['slug'] ?? ''));
  $contentIn = (string)($j['content'] ?? '');
  $statusIn = ((string)($j['status'] ?? 'draft') === 'published') ? 'published' : 'draft';

  if ($titleIn === '') api_json(['ok' => false, 'error' => 'missing_title'], 400);
  if ($slugIn === '') $slugIn = slugify($titleIn);
  $slugIn = unique_post_slug($slugIn, 'page', $pageId > 0 ? $pageId : null);

  $contentIn = arc_sanitize_richtext($contentIn);
  $excerpt = trim((string)($j['excerpt'] ?? ''));
  if ($excerpt === '') {
    $plain = trim(preg_replace('/\\s+/', ' ', strip_tags($contentIn)) ?? '');
    $excerpt = mb_substr($plain, 0, 80, 'UTF-8');
  }

  $review_state = ($statusIn === 'published') ? 'approved' : 'pending';
  $authorId = isset($j['author_id']) ? (int)$j['author_id'] : 0;
  if ($authorId <= 0) $authorId = 1;

  if ($pageId > 0) {
    $stmt = $pdo->prepare("UPDATE {$pfx}posts
      SET type='page', title=?, slug=?, excerpt=?, content=?, status=?, review_state=?, updated_at=NOW()
      WHERE id=?");
    $stmt->execute([$titleIn, $slugIn, $excerpt, $contentIn, $statusIn, $review_state, $pageId]);
    api_json(['ok' => true, 'id' => $pageId, 'slug' => $slugIn]);
  }

  $stmt = $pdo->prepare("INSERT INTO {$pfx}posts (author_id, type, title, slug, excerpt, content, status, review_state, created_at, updated_at)
    VALUES (?, 'page', ?, ?, ?, ?, ?, ?, NOW(), NOW())");
  $stmt->execute([$authorId, $titleIn, $slugIn, $excerpt, $contentIn, $statusIn, $review_state]);
  $newId = (int)$pdo->lastInsertId();
  api_json(['ok' => true, 'id' => $newId, 'slug' => $slugIn]);
}

api_json(['ok' => false, 'error' => 'not_found'], 404);
