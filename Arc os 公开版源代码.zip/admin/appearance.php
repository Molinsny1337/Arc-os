<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$canAppearance = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('custom_css') : false;
if (!$canAppearance) {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && class_exists('ArcOS\\Services\\FeatureGate')) {
    ArcOS\Services\FeatureGate::deny('custom_css');
  }
  http_response_code(403);
  $title = t('appearance');
  $active = 'appearance';
  ?>
  <!doctype html>
  <html lang="<?= e(lang()) ?>">
  <head><?php include __DIR__ . '/../partials/head.php'; ?></head>
  <body class="admin">
    <?php include __DIR__ . '/../partials/nav.php'; ?>
    <div class="admin-shell">
      <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
      <main class="admin-main">
        <div class="admin-card pad" style="margin-top:14px;">
          <div style="font-weight:700;">Appearance customization is a Pro/Business feature.</div>
          <div class="sub" style="margin-top:6px;">Activate a license to enable custom CSS and theme options.</div>
        </div>
      </main>
    </div>
  </body>
  </html>
  <?php
  exit;
}

$title = t('appearance');
$active = 'appearance';

$css = (string)get_setting('custom_css', '');
$js = (string)get_setting('custom_js', '');
$headHtml = (string)get_setting('custom_head_html', '');
$footerHtml = (string)get_setting('custom_footer_html', '');
$clickEffect = (string)get_setting('click_effect', 'none');
$layoutRaw = (string)get_setting('home_layout', '');
$layout = json_decode($layoutRaw, true);
if (!is_array($layout)) $layout = [];

$layoutItems = [];
foreach ($layout as $it) {
  if (is_string($it) && $it !== '') $layoutItems[] = ['id' => $it, 'enabled' => true];
  elseif (is_array($it) && isset($it['id'])) $layoutItems[] = ['id' => (string)$it['id'], 'enabled' => (bool)($it['enabled'] ?? true)];
}
if (!$layoutItems) {
  $layoutItems = arc_home_layout_default_items();
}

$customTitle = (string)get_setting('home_custom_title', '');
$customHtml = (string)get_setting('home_custom_html', '');
$ok = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_appearance', 60, 60);
  try {
    $css = (string)($_POST['custom_css'] ?? '');
    set_setting('custom_css', $css);

    $clickEffect = (string)($_POST['click_effect'] ?? 'none');
    if (!in_array($clickEffect, ['none', 'ripple'], true)) $clickEffect = 'none';
    set_setting('click_effect', $clickEffect);

    $customTitle = trim((string)($_POST['home_custom_title'] ?? ''));
    $customHtml = (string)($_POST['home_custom_html'] ?? '');
    $customHtml = arc_sanitize_richtext($customHtml);
    set_setting('home_custom_title', $customTitle);
    set_setting('home_custom_html', $customHtml);

    // Superadmin-only: raw HTML/JS injections
    if (is_superadmin()) {
      $js = (string)($_POST['custom_js'] ?? '');
      $headHtml = (string)($_POST['custom_head_html'] ?? '');
      $footerHtml = (string)($_POST['custom_footer_html'] ?? '');
      set_setting('custom_js', $js);
      set_setting('custom_head_html', $headHtml);
      set_setting('custom_footer_html', $footerHtml);
    }

    $postedLayout = (string)($_POST['home_layout_json'] ?? '');
    $parsed = $postedLayout !== '' ? json_decode($postedLayout, true) : null;
    if (is_array($parsed)) {
      $norm = [];
      foreach ($parsed as $it) {
        if (is_string($it) && $it !== '') $norm[] = ['id' => $it, 'enabled' => true];
        elseif (is_array($it) && isset($it['id'])) $norm[] = ['id' => (string)$it['id'], 'enabled' => (bool)($it['enabled'] ?? true)];
      }
      if ($norm) {
        $layoutItems = $norm;
        set_setting('home_layout', json_encode($layoutItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
      }
    }

    $ok = t('saved');
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$langCode = lang();
$__need_rte = true;
$__need_ui_layout = true;
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('appearance')) ?></h1>
          <div class="sub"><?= e(t('appearance_sub')) ?></div>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <form method="post" style="display:grid;gap:12px;" data-overlay="1">
          <?= csrf_field() ?>

          <label class="label"><?= e(t('custom_css')) ?></label>
          <textarea class="input" name="custom_css" rows="14" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"><?= e($css) ?></textarea>
          <div class="note"><?= e(t('custom_css_tip')) ?></div>

          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-6">
              <label class="label"><?= e(t('click_effect')) ?></label>
              <select class="input" name="click_effect">
                <option value="none" <?= $clickEffect === 'none' ? 'selected' : '' ?>><?= e(t('click_effect_none')) ?></option>
                <option value="ripple" <?= $clickEffect === 'ripple' ? 'selected' : '' ?>><?= e(t('click_effect_ripple')) ?></option>
              </select>
              <div class="note"><?= e(t('click_effect_tip')) ?></div>
            </div>
          </div>

          <div style="height:6px"></div>
          <div style="font-weight:800;"><?= e(t('danger_zone')) ?></div>
          <div class="note"><?= e(t('custom_inject_tip')) ?></div>
          <?php if (!is_superadmin()): ?>
            <div class="note"><?= e(t('superadmin_only')) ?></div>
          <?php endif; ?>

          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-12">
              <label class="label"><?= e(t('custom_head_html')) ?></label>
              <textarea class="input" name="custom_head_html" rows="6" <?= is_superadmin() ? '' : 'disabled' ?> style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"><?= e($headHtml) ?></textarea>
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('custom_footer_html')) ?></label>
              <textarea class="input" name="custom_footer_html" rows="6" <?= is_superadmin() ? '' : 'disabled' ?> style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"><?= e($footerHtml) ?></textarea>
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('custom_js')) ?></label>
              <textarea class="input" name="custom_js" rows="10" <?= is_superadmin() ? '' : 'disabled' ?> style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;"><?= e($js) ?></textarea>
            </div>
          </div>

          <div style="height:6px"></div>
          <div style="font-weight:800;"><?= e(t('home_layout')) ?></div>
          <div class="note"><?= e(t('home_layout_sub')) ?></div>

          <input type="hidden" name="home_layout_json" id="home_layout_json" value="<?= e(json_encode($layoutItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>" />
          <div class="admin-card" style="padding:10px;border-radius:14px;background:rgba(0,0,0,.02);border:1px solid rgba(0,0,0,.08);">
            <div id="layout_list" class="arc-sortable">
              <?php foreach ($layoutItems as $it): $id = (string)($it['id'] ?? ''); $en = !empty($it['enabled']); ?>
                <div class="arc-sortable-item" data-id="<?= e($id) ?>">
                  <div class="arc-sortable-row" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                    <div style="display:flex;align-items:center;gap:10px;min-width:0">
                      <span class="arc-sortable-handle" title="Drag" aria-hidden="true">::</span>
                      <span style="font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e(t('block_' . $id)) ?></span>
                    </div>
                    <label style="display:flex;align-items:center;gap:8px;margin:0;">
                      <input type="checkbox" class="layout-enabled" <?= $en ? 'checked' : '' ?> />
                      <span class="muted"><?= e(t('enabled')) ?></span>
                    </label>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>

          <div style="height:6px"></div>
          <div style="font-weight:800;"><?= e(t('custom_block')) ?></div>
          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-6">
              <label class="label"><?= e(t('title')) ?></label>
              <input class="input" name="home_custom_title" value="<?= e($customTitle) ?>" />
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('content')) ?></label>
              <textarea class="input" name="home_custom_html" data-rte="1" rows="8"><?= e($customHtml) ?></textarea>
              <div class="note"><?= e(t('custom_block_tip')) ?></div>
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          </div>
        </form>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
