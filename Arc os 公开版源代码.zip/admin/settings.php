<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · ' . t('settings');
$err = '';
$active = 'settings';
$canMail = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('mail') : false;
$canFavicon = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('favicon') : false;

function bool_post(string $key): string {
  return isset($_POST[$key]) ? '1' : '0';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_settings', 60, 300);
  try {
    // --- Moderation & verification ---
    set_setting('require_email_verification', bool_post('require_email_verification'));
    set_setting('require_admin_approval', bool_post('require_admin_approval'));

    // --- Admin notifications ---
    set_setting('notify_admin_new_user', bool_post('notify_admin_new_user'));
    set_setting('notify_admin_new_post', bool_post('notify_admin_new_post'));

    // --- Site & home ---
    set_setting('site_name', trim((string)($_POST['site_name'] ?? 'Arc OS')));
    $siteLang = normalize_lang((string)($_POST['site_lang'] ?? 'zh-CN'));
    set_setting('site_lang', $siteLang);
    set_setting('home_title', trim((string)($_POST['home_title'] ?? 'Arc OS')));
    set_setting('home_tagline', trim((string)($_POST['home_tagline'] ?? '大道至简 · 类苹果风格动效 · PHP + MySQL')));
    set_setting('home_badge', trim((string)($_POST['home_badge'] ?? '大道至简 · 类苹果风格动效 · PHP + MySQL')));
    set_setting('home_subtitle', trim((string)($_POST['home_subtitle'] ?? '')));

    // 首页打字机效果
    set_setting('home_typewriter_enabled', bool_post('home_typewriter_enabled'));
    $speed = (int)($_POST['home_type_speed_ms'] ?? 42);
    if ($speed < 10) $speed = 10;
    if ($speed > 500) $speed = 500;
    set_setting('home_type_speed_ms', (string)$speed);

    // icon: url or file upload
    $iconUrl = trim((string)($_POST['site_icon'] ?? ''));
    $hasIconUpload = !empty($_FILES['site_icon_file']['tmp_name']) && is_uploaded_file($_FILES['site_icon_file']['tmp_name']);
    if (!$canFavicon && ($iconUrl !== '' || $hasIconUpload)) {
      if (class_exists('ArcOS\\Services\\FeatureGate')) {
        ArcOS\Services\FeatureGate::deny('favicon');
      }
      http_response_code(403);
      exit('Forbidden');
    }
    if ($canFavicon) {
      if ($hasIconUpload) {
        $uploadsDirFs = __DIR__ . '/../uploads';
        if (!is_dir($uploadsDirFs)) @mkdir($uploadsDirFs, 0755, true);
        $dst = $uploadsDirFs . '/site-icon.png';
        @move_uploaded_file($_FILES['site_icon_file']['tmp_name'], $dst);
        $iconUrl = 'uploads/site-icon.png';
      }
      set_setting('site_icon', $iconUrl);
    }

    // --- Transition ---
    set_setting('transition_hello_tpl', trim((string)($_POST['transition_hello_tpl'] ?? '你好 {name}')));
    set_setting('transition_hint_text', trim((string)($_POST['transition_hint_text'] ?? '正在进入…')));
    $ms = (int)($_POST['transition_min_show_ms'] ?? 2200);
    if ($ms < 300) $ms = 300;
    if ($ms > 12000) $ms = 12000;
    set_setting('transition_min_show_ms', (string)$ms);

    $wms = (int)($_POST['welcome_hold_ms'] ?? 2600);
    if ($wms < 600) $wms = 600;
    if ($wms > 20000) $wms = 20000;
    set_setting('welcome_hold_ms', (string)$wms);


    // --- Cloudflare Turnstile（人机验证）---
    set_setting('turnstile_enabled', bool_post('turnstile_enabled'));
    set_setting('turnstile_site_key', trim((string)($_POST['turnstile_site_key'] ?? '')));
    set_setting('turnstile_secret_key', trim((string)($_POST['turnstile_secret_key'] ?? '')));
    set_setting('turnstile_on_login', bool_post('turnstile_on_login'));
    set_setting('turnstile_on_register', bool_post('turnstile_on_register'));
    set_setting('turnstile_on_admin', bool_post('turnstile_on_admin'));
    set_setting('turnstile_on_post', bool_post('turnstile_on_post'));
    set_setting('turnstile_on_comment', bool_post('turnstile_on_comment'));

    $u = current_user();
    $hello = $u['username'] ?? 'Admin';
    $back = function_exists('admin_url') ? admin_url('settings') : url('admin/settings.php');
    redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode(t('saved')) . '&to=' . urlencode($back));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$reqV = get_setting('require_email_verification', '1') === '1';
$reqA = get_setting('require_admin_approval', '1') === '1';
$notifyU = get_setting('notify_admin_new_user', '1') === '1';
$notifyP = get_setting('notify_admin_new_post', '1') === '1';

$site_name = (string)get_setting('site_name', 'Arc OS');
$site_lang = normalize_lang((string)get_setting('site_lang', 'zh-CN'));
$home_title = (string)get_setting('home_title', 'Arc OS');
$home_tagline = (string)get_setting('home_tagline', '大道至简 · 类苹果风格动效 · PHP + MySQL');
$home_badge = (string)get_setting('home_badge', '大道至简 · 类苹果风格动效 · PHP + MySQL');
$home_subtitle = (string)get_setting('home_subtitle', '');
$home_typewriter_enabled = get_setting('home_typewriter_enabled', '1') === '1';
$home_type_speed_ms = (string)get_setting('home_type_speed_ms', '42');
$site_icon = (string)get_setting('site_icon', '');

$trans_tpl = (string)get_setting('transition_hello_tpl', '你好 {name}');
$trans_hint = (string)get_setting('transition_hint_text', '正在进入…');
$trans_ms = (string)get_setting('transition_min_show_ms', '2200');
$welcome_ms = (string)get_setting('welcome_hold_ms', '2600');

?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('settings')) ?></h1>
          <div class="sub"><?= e(t('settings_desc')) ?></div>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <form method="post" enctype="multipart/form-data" data-overlay="1" class="admin-fade" style="display:grid;gap:14px;max-width:920px;">
        <?= csrf_field() ?>

        <section class="admin-card pad">
          <div style="font-weight:700;"><?= e(t('moderation')) ?></div>
          <div class="sub"><?= e(t('moderation_desc')) ?></div>
          <div style="display:grid;gap:10px;margin-top:12px;">
            <label style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="require_email_verification" <?= $reqV ? 'checked' : '' ?> />
              <span><?= e(t('require_email_verification')) ?></span>
            </label>
            <label style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="require_admin_approval" <?= $reqA ? 'checked' : '' ?> />
              <span><?= e(t('require_admin_approval')) ?></span>
            </label>

            <div style="height:6px;"></div>

            <label style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="notify_admin_new_user" <?= $notifyU ? 'checked' : '' ?> />
              <span><?= e(t('notify_admin_new_user')) ?></span>
            </label>
            <label style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="notify_admin_new_post" <?= $notifyP ? 'checked' : '' ?> />
              <span><?= e(t('notify_admin_new_post')) ?></span>
            </label>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;"><?= e(t('mail_settings') !== 'mail_settings' ? t('mail_settings') : 'Mail settings') ?></div>
          <div class="sub"><?= e(t('smtp_desc')) ?></div>
          <?php if ($canMail): ?>
            <div style="margin-top:10px;">
              <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('settings_mail') : url('admin/settings_mail.php')) ?>"><?= e(t('open_mail_settings') !== 'open_mail_settings' ? t('open_mail_settings') : 'Open mail settings') ?></a>
            </div>
          <?php else: ?>
            <div class="note" style="margin-top:8px;">Mail is available in Pro/Business.</div>
          <?php endif; ?>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;"><?= e(t('site_settings')) ?></div>
          <div class="sub"><?= e(t('site_settings_desc')) ?></div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('site_name')) ?></label>
              <input class="input" name="site_name" value="<?= e($site_name) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('home_title')) ?></label>
              <input class="input" name="home_title" value="<?= e($home_title) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('site_lang')) ?></label>
              <select class="input" name="site_lang">
                <?php foreach (supported_langs() as $code => $meta): ?>
                  <option value="<?= e($code) ?>" <?= $code === $site_lang ? 'selected' : '' ?>>
                    <?= e($meta['name']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label"><?= e(t('home_tagline')) ?></label>
              <input class="input" name="home_tagline" value="<?= e($home_tagline) ?>" />
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label"><?= e(t('home_badge')) ?></label>
              <input class="input" name="home_badge" value="<?= e($home_badge) ?>" />
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label"><?= e(t('home_subtitle')) ?></label>
              <input class="input" name="home_subtitle" value="<?= e($home_subtitle) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="check" style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="home_typewriter_enabled" <?= $home_typewriter_enabled ? 'checked' : '' ?> />
                <span><?= e(t('home_typewriter_enabled')) ?></span>
              </label>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('home_type_speed_ms')) ?></label>
              <input class="input" name="home_type_speed_ms" value="<?= e($home_type_speed_ms) ?>" />
            </div>
            <?php if ($canFavicon): ?>
              <div class="field" style="grid-column: span 6;">
                <label class="label"><?= e(t('site_icon')) ?></label>
                <input class="input" name="site_icon" value="<?= e($site_icon) ?>" placeholder="/uploads/site-icon.png" />
              </div>
              <div class="field" style="grid-column: span 6;">
                <label class="label"><?= e(t('site_icon_upload')) ?></label>
                <input class="input" type="file" name="site_icon_file" accept="image/png,image/jpeg,image/webp" />
              </div>
            <?php else: ?>
              <div class="field" style="grid-column: span 12;">
                <div class="note">Custom favicon is available in Pro/Business.</div>
              </div>
            <?php endif; ?>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;"><?= e(t('transition')) ?></div>
          <div class="sub"><?= e(t('transition_desc')) ?></div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 12;">
              <label class="label"><?= e(t('transition_hello_tpl')) ?></label>
              <input class="input" name="transition_hello_tpl" value="<?= e($trans_tpl) ?>" />
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label"><?= e(t('transition_hint_text')) ?></label>
              <input class="input" name="transition_hint_text" value="<?= e($trans_hint) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('transition_min_show_ms')) ?></label>
              <input class="input" name="transition_min_show_ms" value="<?= e($trans_ms) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('welcome_hold_ms')) ?></label>
              <input class="input" name="welcome_hold_ms" value="<?= e($welcome_ms) ?>" />
            </div>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;"><?= e(t('captcha')) ?></div>
          <div class="sub"><?= e(t('captcha_desc')) ?></div>

          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 12;">
              <label class="check">
                <input type="checkbox" name="turnstile_enabled" <?= get_setting('turnstile_enabled','0')==='1'?'checked':'' ?> />
                <span><?= e(t('turnstile_enable')) ?></span>
              </label>
            </div>

            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('turnstile_site_key')) ?></label>
              <input class="input" name="turnstile_site_key" value="<?= e((string)get_setting('turnstile_site_key','')) ?>" placeholder="0x..." />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label"><?= e(t('turnstile_secret_key')) ?></label>
              <input class="input" name="turnstile_secret_key" value="<?= e((string)get_setting('turnstile_secret_key','')) ?>" placeholder="0x..." />
            </div>

            <div class="field" style="grid-column: span 12;">
              <div class="sub" style="margin-bottom:8px;"><?= e(t('turnstile_where')) ?></div>
              <label class="check"><input type="checkbox" name="turnstile_on_login" <?= get_setting('turnstile_on_login','0')==='1'?'checked':'' ?> /> <span><?= e(t('login')) ?></span></label>
              <label class="check" style="margin-left:14px;"><input type="checkbox" name="turnstile_on_register" <?= get_setting('turnstile_on_register','0')==='1'?'checked':'' ?> /> <span><?= e(t('register')) ?></span></label>
              <label class="check" style="margin-left:14px;"><input type="checkbox" name="turnstile_on_admin" <?= get_setting('turnstile_on_admin','0')==='1'?'checked':'' ?> /> <span><?= e(t('admin_login')) ?></span></label>
              <label class="check" style="margin-left:14px;"><input type="checkbox" name="turnstile_on_post" <?= get_setting('turnstile_on_post','0')==='1'?'checked':'' ?> /> <span><?= e(t('turnstile_post')) ?></span></label>
              <label class="check" style="margin-left:14px;"><input type="checkbox" name="turnstile_on_comment" <?= get_setting('turnstile_on_comment','0')==='1'?'checked':'' ?> /> <span><?= e(t('turnstile_comment')) ?></span></label>
            </div>
          </div>
        </section>

        <div style="display:flex;gap:10px;align-items:center;">
          <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('upgrade') : url('admin/upgrade.php')) ?>"><?= e(t('run_upgrade')) ?></a>
          <span class="note"><?= e(t('settings_save_tip')) ?></span>
        </div>

      </form>

    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e(url('assets/admin.js')) ?>"></script>
</body>
</html>
