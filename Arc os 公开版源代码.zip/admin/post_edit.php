<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$u = current_user();

$title = t('admin') . ' · ' . t('edit_post');
$pdo = db();
$pfx = table_prefix();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$err = '';
$saved = false;

$post = [
  'title' => '',
  'slug' => '',
  'excerpt' => '',
  'content' => '',
  'type' => 'forum',
  'status' => 'draft',
];

if ($id > 0) {
  $stmt = $pdo->prepare("SELECT * FROM {$pfx}posts WHERE id = ? LIMIT 1");
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  if ($row) $post = array_merge($post, $row);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_post_edit', 120, 300);
  $t = trim($_POST['title'] ?? '');
  $s = trim($_POST['slug'] ?? '');
  $ex = trim($_POST['excerpt'] ?? '');
  $c = (string)($_POST['content'] ?? '');
  $c = arc_sanitize_richtext($c);
  $st = ($_POST['status'] ?? 'draft') === 'published' ? 'published' : 'draft';
  $review_state = ($st === 'published') ? 'approved' : 'pending';
  $type = (string)($_POST['type'] ?? 'forum');
  if (!in_array($type, ['forum', 'page'], true)) $type = 'forum';

  try {
    if ($t === '') throw new RuntimeException('标题不能为空。');
    if ($s === '') $s = slugify($t);
    // 确保 (slug,type) 唯一，避免重复标题导致保存失败
    $s = unique_post_slug($s, $type, $id > 0 ? $id : null);

    // excerpt auto
    if ($ex === '') {
      $plain = trim(preg_replace('/\s+/', ' ', strip_tags($c)) ?? '');
      $ex = mb_substr($plain, 0, 80, 'UTF-8');
    }

    if ($id > 0) {
      $stmt = $pdo->prepare("UPDATE {$pfx}posts
        SET type=?, title=?, slug=?, excerpt=?, content=?, status=?, review_state=?, updated_at=NOW()
        WHERE id=?");
      $stmt->execute([$type, $t, $s, $ex, $c, $st, $review_state, $id]);
    } else {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}posts (author_id, type, title, slug, excerpt, content, status, review_state, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
      $stmt->execute([(int)$u['id'], $type, $t, $s, $ex, $c, $st, $review_state]);
      $id = (int)$pdo->lastInsertId();
    }

    // after save, go through ripple with hello message
    $u = current_user();
    $hello = $u['username'] ?? t('admin');
    $back = function_exists('admin_url') ? admin_url('post_edit', ['id' => (int)$id]) : url('admin/post_edit.php?id=' . $id);
    redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode(t('saved')) . '&to=' . urlencode($back));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$__need_editor = true;
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="overlay">
    <div class="overlay-card">
      <div class="title"><?= e(t('saving')) ?></div>
      <div class="sub"><?= e(t('please_wait')) ?></div>
    </div>
  </div>

  <div class="admin-shell">
    <?php $active = 'posts'; include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e($id>0 ? t('edit_post') : t('new_post')) ?></h1>
          <div class="sub"><?= e(t('admin_post_edit_sub')) ?></div>
        </div>
        <div class="admin-actions">
          <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('posts') : url('admin/posts.php')) ?>"><?= e(t('back')) ?></a>
          <?php if ($id>0): ?>
            <?php
              $preview = ($post['type'] ?? '') === 'page'
                ? 'page.php?slug=' . urlencode((string)$post['slug'])
                : 'forum_post.php?slug=' . urlencode((string)$post['slug']);
            ?>
            <a class="admin-btn" href="<?= e(url($preview)) ?>" data-transition="off"><?= e(t('preview')) ?></a>
          <?php endif; ?>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <div class="admin-card pad admin-fade">
        <form method="post" data-overlay="1" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-12">
              <label class="label"><?= e(t('title')) ?></label>
              <input class="input" name="title" value="<?= e((string)$post['title']) ?>" />
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('slug')) ?> (max 191)</label>
              <input class="input" name="slug" value="<?= e((string)$post['slug']) ?>" placeholder="<?= e(t('auto_from_title')) ?>" />
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('excerpt')) ?></label>
              <input class="input" name="excerpt" value="<?= e((string)$post['excerpt']) ?>" placeholder="<?= e(t('auto_from_content')) ?>" />
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('type')) ?></label>
              <select class="input" name="type">
                <option value="forum" <?= ($post['type'] ?? '') === 'forum' ? 'selected' : '' ?>>forum</option>
                <option value="page" <?= ($post['type'] ?? '') === 'page' ? 'selected' : '' ?>>page</option>
              </select>
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('status')) ?></label>
              <select class="input" name="status">
                <option value="draft" <?= ($post['status'] ?? '') === 'draft' ? 'selected' : '' ?>><?= e(t('draft')) ?></option>
                <option value="published" <?= ($post['status'] ?? '') === 'published' ? 'selected' : '' ?>><?= e(t('published')) ?></option>
              </select>
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('content')) ?></label>
              <?php
                $content_name = 'content';
                $initial_value = (string)$post['content'];
                $mode = 'post_edit';
                $attachments_enabled = true;
                $placeholder = t('content_placeholder');
                $draft_key = 'admin_post_' . (int)($post['id'] ?? 0);
                $content_type = 'post';
                $content_id = (int)($post['id'] ?? 0);
                include __DIR__ . '/../partials/editor/editor_widget.php';
              ?>
            </div>
          </div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
            <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('posts') : url('admin/posts.php')) ?>"><?= e(t('cancel')) ?></a>
          </div>
        </form>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e('assets/admin.js') ?>"></script>
</body>
</html>
