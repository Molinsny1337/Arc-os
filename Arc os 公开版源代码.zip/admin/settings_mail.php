<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();
$canMail = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('mail') : false;
if (!$canMail) {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && class_exists('ArcOS\\Services\\FeatureGate')) {
    ArcOS\Services\FeatureGate::deny('mail');
  }
  http_response_code(403);
  $title = t('admin') . ' · ' . (t('mail_settings') !== 'mail_settings' ? t('mail_settings') : 'Mail settings');
  $active = 'mail_settings';
  ?>
  <!doctype html>
  <html lang="<?= e(lang()) ?>">
  <head><?php include __DIR__ . '/../partials/head.php'; ?></head>
  <body class="admin">
    <?php include __DIR__ . '/../partials/nav.php'; ?>
    <div class="admin-shell">
      <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
      <main class="admin-main">
        <div class="admin-card pad" style="margin-top:14px;">
          <div style="font-weight:700;">Mail is a Pro/Business feature.</div>
          <div class="sub" style="margin-top:6px;">Activate a license to configure SMTP and send emails.</div>
        </div>
      </main>
    </div>
  </body>
  </html>
  <?php
  exit;
}
require_once __DIR__ . '/../includes/services/CryptoService.php';
require_once __DIR__ . '/../includes/services/MailService.php';

$title = t('admin') . ' · ' . (t('mail_settings') !== 'mail_settings' ? t('mail_settings') : 'Mail settings');
$active = 'mail_settings';
$err = '';
$ok = '';
$testMsg = '';

function bool_post(string $key): string {
  return isset($_POST[$key]) ? '1' : '0';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_mail_settings', 60, 300);
  try {
    $action = (string)($_POST['action'] ?? 'save');
    $mailMode = (($_POST['mail_mode'] ?? 'mail') === 'smtp') ? 'smtp' : 'mail';
    set_setting('mail_mode', $mailMode);

    $host = trim((string)($_POST['smtp_host'] ?? ''));
    $port = trim((string)($_POST['smtp_port'] ?? '587'));
    $user = trim((string)($_POST['smtp_user'] ?? ''));
    $enc = (($_POST['smtp_enc'] ?? 'tls') === 'none') ? 'none' : 'tls';
    $from = trim((string)($_POST['smtp_from'] ?? ''));
    $fromName = trim((string)($_POST['smtp_from_name'] ?? 'Arc OS'));
    $replyTo = trim((string)($_POST['smtp_reply_to'] ?? ''));

    set_setting('smtp_host', $host);
    set_setting('smtp_port', $port);
    set_setting('smtp_user', $user);
    set_setting('smtp_enc', $enc);
    set_setting('smtp_from', $from);
    set_setting('smtp_from_name', $fromName);
    set_setting('smtp_reply_to', $replyTo);

    $smtpPass = (string)($_POST['smtp_pass'] ?? '');
    if (isset($_POST['smtp_pass_clear'])) {
      delete_setting('smtp_pass_enc');
    } elseif ($smtpPass !== '') {
      $encPass = ArcOS\Services\CryptoService::encrypt($smtpPass);
      if ($encPass === '') throw new RuntimeException('Encrypt SMTP password failed.');
      set_setting('smtp_pass_enc', $encPass);
    }
    set_setting('smtp_pass', '');

    if ($action === 'test') {
      $testEmail = trim((string)($_POST['test_email'] ?? ''));
      if ($testEmail === '') throw new RuntimeException('Test email is required.');
      $subject = 'Arc OS SMTP test';
      $html = '<p>This is a test email from Arc OS.</p><p>If you received this, SMTP is configured.</p>';
      $text = 'This is a test email from Arc OS. If you received this, SMTP is configured.';
      $error = '';
      $okSend = ArcOS\Services\MailService::deliver($testEmail, $subject, $html, $text, $error);
      $testMsg = $okSend ? 'Test email sent.' : ('Test failed: ' . $error);
    } else {
      $ok = t('saved');
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$mailMode = (string)get_setting('mail_mode', 'mail');
$smtp_host = (string)get_setting('smtp_host', '');
$smtp_port = (string)get_setting('smtp_port', '587');
$smtp_user = (string)get_setting('smtp_user', '');
$smtp_enc  = (string)get_setting('smtp_enc', 'tls');
$smtp_from = (string)get_setting('smtp_from', $smtp_user);
$smtp_from_name = (string)get_setting('smtp_from_name', 'Arc OS');
$smtp_reply_to = (string)get_setting('smtp_reply_to', '');
$smtp_pass_set = (string)get_setting('smtp_pass_enc', '') !== '';

$appKeyMissing = !defined('APP_KEY') || APP_KEY === '';
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('mail_settings') !== 'mail_settings' ? t('mail_settings') : 'Mail settings') ?></h1>
          <div class="sub"><?= e(t('smtp_desc')) ?></div>
        </div>
      </div>

      <?php if ($appKeyMissing): ?>
        <div class="alert admin-fade">APP_KEY is empty. SMTP passwords cannot be encrypted.</div>
      <?php endif; ?>
      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>
      <?php if ($ok): ?><div class="admin-card pad admin-fade"><?= e($ok) ?></div><?php endif; ?>
      <?php if ($testMsg): ?><div class="admin-card pad admin-fade"><?= e($testMsg) ?></div><?php endif; ?>

      <form method="post" class="admin-fade" style="display:grid;gap:14px;max-width:980px;">
        <?= csrf_field() ?>
        <section class="admin-card pad">
          <div style="font-weight:700;">SMTP</div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Mode</label>
              <select class="input" name="mail_mode">
                <option value="mail" <?= ($mailMode==='mail')?'selected':'' ?>>PHP mail()</option>
                <option value="smtp" <?= ($mailMode==='smtp')?'selected':'' ?>>SMTP</option>
              </select>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Encryption</label>
              <select class="input" name="smtp_enc">
                <option value="tls" <?= ($smtp_enc==='tls')?'selected':'' ?>>TLS (STARTTLS)</option>
                <option value="none" <?= ($smtp_enc==='none')?'selected':'' ?>>None</option>
              </select>
            </div>

            <div class="field" style="grid-column: span 6;">
              <label class="label">SMTP Host</label>
              <input class="input" name="smtp_host" value="<?= e($smtp_host) ?>" placeholder="smtp.example.com" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">SMTP Port</label>
              <input class="input" name="smtp_port" value="<?= e($smtp_port) ?>" placeholder="587" />
            </div>

            <div class="field" style="grid-column: span 6;">
              <label class="label">SMTP User</label>
              <input class="input" name="smtp_user" value="<?= e($smtp_user) ?>" placeholder="user@example.com" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">SMTP Password <?= $smtp_pass_set ? '(configured)' : '' ?></label>
              <input class="input" type="password" name="smtp_pass" value="" placeholder="********" />
              <label class="check" style="display:flex;gap:8px;align-items:center;margin-top:8px;">
                <input type="checkbox" name="smtp_pass_clear" />
                <span>Clear stored password</span>
              </label>
            </div>

            <div class="field" style="grid-column: span 6;">
              <label class="label">From Email</label>
              <input class="input" name="smtp_from" value="<?= e($smtp_from) ?>" placeholder="no-reply@example.com" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">From Name</label>
              <input class="input" name="smtp_from_name" value="<?= e($smtp_from_name) ?>" placeholder="Arc OS" />
            </div>

            <div class="field" style="grid-column: span 12;">
              <label class="label">Reply-To</label>
              <input class="input" name="smtp_reply_to" value="<?= e($smtp_reply_to) ?>" placeholder="support@example.com" />
            </div>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;">Test email</div>
          <div class="sub">Send a test email using the current configuration.</div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;">
            <input class="input" name="test_email" placeholder="you@example.com" style="min-width:260px;flex:1;" />
            <button class="admin-btn" type="submit" name="action" value="test">Send test</button>
          </div>
        </section>

        <div style="display:flex;gap:10px;align-items:center;">
          <button class="admin-btn primary" type="submit" name="action" value="save"><?= e(t('save')) ?></button>
          <a class="admin-btn ghost" href="<?= e(function_exists('admin_url') ? admin_url('mail_queue') : url('admin/mail_queue.php')) ?>"><?= e(t('mail_queue') !== 'mail_queue' ? t('mail_queue') : 'Mail queue') ?></a>
        </div>
      </form>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e(url('assets/admin.js')) ?>"></script>
</body>
</html>
