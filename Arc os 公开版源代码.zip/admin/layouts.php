<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · ' . t('layouts');
$active = 'layouts';

$ok = '';
$err = '';

// Layout definitions (settings-driven; admin-editable)
$defs = [
  'home_layout' => [
    'title' => t('home') . ' · ' . t('home_layout'),
    'allowed' => arc_home_layout_allowed_ids(),
    'default' => arc_home_layout_default_items(),
  ],
  'forum_layout' => [
    'title' => t('forum') . ' · ' . t('layouts'),
    'allowed' => arc_forum_layout_allowed_ids(),
    'default' => arc_forum_layout_default_items(),
  ],
  'whats_new_layout' => [
    'title' => t('whats_new') . ' · ' . t('layouts'),
    'allowed' => arc_whats_new_layout_allowed_ids(),
    'default' => arc_whats_new_layout_default_items(),
  ],
  'members_layout' => [
    'title' => t('members') . ' · ' . t('layouts'),
    'allowed' => arc_members_layout_allowed_ids(),
    'default' => arc_members_layout_default_items(),
  ],
  'admin_dashboard_layout' => [
    'title' => t('dashboard') . ' · ' . t('layouts'),
    'allowed' => arc_admin_dashboard_layout_allowed_ids(),
    'default' => arc_admin_dashboard_layout_default_items(),
  ],
];

// load current
$layouts = [];
foreach ($defs as $key => $cfg) {
  $layouts[$key] = arc_get_layout_setting_items($key, $cfg['default'], $cfg['allowed']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_layouts', 240, 300);
  try {
    foreach ($defs as $key => $cfg) {
      $raw = (string)($_POST['layout_json'][$key] ?? '');
      $parsed = $raw !== '' ? json_decode($raw, true) : null;
      if (!is_array($parsed)) continue;
      $items = arc_layout_normalize_items($parsed, $cfg['default'], $cfg['allowed']);
      set_setting($key, json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
      $layouts[$key] = $items;
    }
    $ok = t('saved');
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$__need_ui_layout = true;
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('layouts')) ?></h1>
          <div class="sub"><?= e(t('layouts_sub')) ?></div>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
        <div style="height:12px;"></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
        <div style="height:12px;"></div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade">
        <form method="post" data-overlay="1" style="display:grid;gap:14px;">
          <?= csrf_field() ?>

          <?php foreach ($defs as $key => $cfg): ?>
            <?php
              $items = $layouts[$key] ?? [];
              $hiddenId = 'layout_json_' . $key;
              $labels = [];
              foreach ($cfg['allowed'] as $id) $labels[$id] = t('block_' . $id);
            ?>
            <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:12px;flex-wrap:wrap">
              <div style="font-weight:800;"><?= e($cfg['title']) ?></div>
              <?php
                $viewUrl = ($key === 'home_layout')
                  ? url('index.php')
                  : (($key === 'forum_layout')
                    ? url('forum.php')
                    : (($key === 'whats_new_layout')
                      ? url('whats_new.php')
                      : (($key === 'members_layout')
                        ? url('members.php')
                        : (function_exists('admin_url') ? admin_url('index') : url('admin/index.php')))));
              ?>
              <a class="admin-btn" href="<?= e($viewUrl) ?>" data-transition="off"><?= e(t('view')) ?></a>
            </div>
            <div class="note"><?= e(t('home_layout_sub')) ?></div>

            <input type="hidden" name="layout_json[<?= e($key) ?>]" id="<?= e($hiddenId) ?>" value="<?= e(json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>" />
            <div class="admin-card" style="padding:10px;border-radius:14px;background:rgba(0,0,0,.02);border:1px solid rgba(0,0,0,.08);">
              <div class="arc-sortable" data-arc-admin-layout-list="1" data-arc-hidden="<?= e($hiddenId) ?>">
                <?php foreach ($items as $it): $id = (string)($it['id'] ?? ''); $en = !empty($it['enabled']); ?>
                  <div class="arc-sortable-item" data-id="<?= e($id) ?>">
                    <div class="arc-sortable-row" style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                      <div style="display:flex;align-items:center;gap:10px;min-width:0">
                        <span class="arc-sortable-handle" title="<?= e(t('drag')) ?>" aria-hidden="true">::</span>
                        <span style="font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($labels[$id] ?? $id) ?></span>
                      </div>
                      <label style="display:flex;align-items:center;gap:8px;margin:0;">
                        <input type="checkbox" class="layout-enabled" <?= $en ? 'checked' : '' ?> />
                        <span class="muted"><?= e(t('enabled')) ?></span>
                      </label>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>

            <div style="height:10px;"></div>
          <?php endforeach; ?>

          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          </div>
        </form>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
