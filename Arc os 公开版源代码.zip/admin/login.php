<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();

$title = t('admin_login');
$err = '';
$next = (string)($_GET['next'] ?? (function_exists('admin_url') ? admin_url('index') : url('admin/index.php')));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_login', 15, 300);
  $username = (string)($_POST['username'] ?? '');
  $password = (string)($_POST['password'] ?? '');

  try {
    if (turnstile_required('admin')) {
      $token = (string)($_POST['cf-turnstile-response'] ?? '');
      if (!verify_turnstile($token)) {
        throw new RuntimeException(t('captcha_failed'));
      }
    }

    if (!login_attempt($username, $password, 'admin')) {
      throw new RuntimeException(t('admin_login_failed'));
    }
    $u = current_user();
    $hello = $u['username'] ?? $username;
    redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode(t('admin')) . '&to=' . urlencode($next));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <div class="overlay">
    <div class="overlay-card">
      <div class="title"><?= e(t('signing_in')) ?></div>
      <div class="sub"><?= e(t('admin')) ?></div>
    </div>
  </div>

  <main class="wrap" style="padding-top:84px;padding-bottom:80px;">
    <div class="admin-card pad admin-fade" style="max-width:460px;margin:0 auto;">
      <div style="font-weight:750;letter-spacing:-.01em;font-size:18px;"><?= e(t('admin')) ?></div>
      <div style="margin-top:6px;color:var(--admin-muted);font-size:13px;"><?= e(t('admin_login_sub')) ?></div>

      <?php if ($err): ?><div class="alert" style="margin-top:12px;"><?= e($err) ?></div><?php endif; ?>

      <form method="post" data-overlay="1" style="margin-top:12px;display:grid;gap:12px;">
        <?= csrf_field() ?>
        <div class="field">
          <label class="label"><?= e(t('username')) ?></label>
          <input class="input" name="username" autocomplete="username" />
        </div>
        <div class="field">
          <label class="label"><?= e(t('password')) ?></label>
          <input class="input" type="password" name="password" autocomplete="current-password" />
        </div>
        <button class="admin-btn primary" type="submit" style="justify-content:center;"><?= e(t('login_btn')) ?></button>
        <div class="note"><?= e(t('back_home')) ?>: <a href="<?= e(url('index.php')) ?>"><?= e(t('home')) ?></a></div>
      </form>
    </div>
  </main>

  <script src="<?= e('assets/app.js') ?>"></script>
  <script src="<?= e('assets/admin.js') ?>"></script>
</body>
</html>
