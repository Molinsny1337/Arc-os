<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · ' . t('users');
$pdo = db();
$pfx = table_prefix();
$err = '';
$active = 'users';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_users', 240, 300);
  try {
    $action = (string)($_POST['action'] ?? '');

    // Only superadmin can manage admins
    if (in_array($action, ['create_admin','promote_admin','demote_admin','delete_admin'], true)) {
      require_superadmin();
    }

    if ($action === 'create_user' || $action === 'create_admin') {
      $uname = trim((string)($_POST['new_user_user'] ?? ''));
      $email = strtolower(trim((string)($_POST['new_user_email'] ?? '')));
      $pass  = (string)($_POST['new_user_pass'] ?? '');

      if ($uname === '' || $email === '' || $pass === '') {
        throw new RuntimeException(t('fill_all'));
      }
      if (strlen($pass) < 8) {
        throw new RuntimeException(t('password_min8'));

      }

      $role = ($action === 'create_admin') ? 'admin' : (((string)($_POST['new_user_role'] ?? 'user')) === 'admin' ? 'admin' : 'user');
      $isVerified = (int)($_POST['new_user_verified'] ?? 0) === 1 ? 1 : 0;
      $canPost = (int)($_POST['new_user_can_post'] ?? 0) === 1 ? 1 : 0;

      // admins default can_post=1 and verified=1 unless explicitly set
      if ($role === 'admin') {
        $canPost = 1;
        if ($isVerified !== 0) $isVerified = 1;
      }

      $verifyToken = $isVerified ? null : random_token(32); // 64 chars fits verify_token

      // Uniqueness checks (avoid raw SQL duplicate key errors)
      $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE username=? LIMIT 1");
      $st->execute([$uname]);
      if ($st->fetchColumn()) throw new RuntimeException(t('username_taken'));

      $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE email=? LIMIT 1");
      $st->execute([$email]);
      if ($st->fetchColumn()) throw new RuntimeException(t('email_taken'));

      // 管理员操作日志
      arc_log('admin_create_user', 'user', null, ['as'=>$action]);
      $stmt = $pdo->prepare("INSERT INTO {$pfx}users
        (username, email, password_hash, role, is_verified, verify_token, can_post, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
      $stmt->execute([
        $uname,
        $email,
        password_hash($pass, PASSWORD_DEFAULT),
        $role,
        $isVerified,
        $verifyToken,
        $canPost,
      ]);

      redirect(function_exists('admin_url') ? admin_url('users') : url('admin/users.php'));
    }

    // actions that require a user id
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) throw new RuntimeException('Bad user id.');

    if ($action === 'approve') {
      $pdo->prepare("UPDATE {$pfx}users SET can_post=1, updated_at=NOW() WHERE id=?")->execute([$id]);
    } elseif ($action === 'revoke') {
      $pdo->prepare("UPDATE {$pfx}users SET can_post=0, updated_at=NOW() WHERE id=?")->execute([$id]);
    } elseif ($action === 'make_admin') {
      $pdo->prepare("UPDATE {$pfx}users SET role='admin', can_post=1, is_verified=1, updated_at=NOW() WHERE id=?")->execute([$id]);
    } elseif ($action === 'delete') {
      // don't allow deleting yourself
      $me = current_user();
      if ($me && (int)$me['id'] === $id) throw new RuntimeException('Cannot delete yourself.');
      $pdo->prepare("DELETE FROM {$pfx}users WHERE id=?")->execute([$id]);
    } else {
      throw new RuntimeException('Bad action.');
    }

    redirect(function_exists('admin_url') ? admin_url('users') : url('admin/users.php'));
  } catch (Throwable $e) {
    if ($e instanceof PDOException) {
      $info = $e->errorInfo ?? null;
      $errno = is_array($info) && isset($info[1]) ? (int)$info[1] : 0;
      $msg = (string)($info[2] ?? $e->getMessage());
      if ($errno === 1062) {
        if (stripos($msg, 'uniq_email') !== false) $err = t('email_taken');
        elseif (stripos($msg, 'uniq_username') !== false) $err = t('username_taken');
        else $err = t('error');
      } else {
        $err = $e->getMessage();
      }
    } else {
      $err = $e->getMessage();
    }
  }
}

$users = $pdo->query("SELECT id, username, email, role, is_verified, can_post, created_at FROM {$pfx}users ORDER BY created_at DESC")->fetchAll();
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('users')) ?></h1>
          <div class="sub"><?= e(t('manage_users_tip')) ?></div>
        </div>
      </div>

      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650; color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px; color:#7f1d1d;"><?= e($err) ?></div>
        </div>
        <div style="height:12px;"></div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade">
        <div style="font-weight:650;"><?= e(t('create_user')) ?></div>
        <div class="sub"><?= e(t('create_user_tip')) ?></div>
        <form method="post" data-overlay="1" class="grid" style="margin-top:10px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="create_user" />

          <div class="field" style="grid-column: span 3;">
            <label class="label"><?= e(t('username')) ?></label>
            <input class="input" name="new_user_user" placeholder="user" />
          </div>
          <div class="field" style="grid-column: span 3;">
            <label class="label"><?= e(t('email')) ?></label>
            <input class="input" name="new_user_email" placeholder="user@example.com" />
          </div>
          <div class="field" style="grid-column: span 3;">
            <label class="label"><?= e(t('password')) ?></label>
            <input class="input" type="password" name="new_user_pass" placeholder="••••••••" />
          </div>

          <div class="field" style="grid-column: span 3;">
            <label class="label"><?= e(t('role')) ?></label>
            <select class="input" name="new_user_role">
              <option value="user"><?= e(t('role_user')) ?></option>
              <option value="admin"><?= e(t('role_admin')) ?></option>
            </select>
          </div>

          <div class="field" style="grid-column: span 4;">
            <label class="label"><?= e(t('verified')) ?></label>
            <select class="input" name="new_user_verified">
              <option value="0">0</option>
              <option value="1">1</option>
            </select>
          </div>

          <div class="field" style="grid-column: span 4;">
            <label class="label"><?= e(t('can_post')) ?></label>
            <select class="input" name="new_user_can_post">
              <option value="0">0</option>
              <option value="1">1</option>
            </select>
          </div>
<div style="grid-column: span 12; display:flex; justify-content:flex-end; gap:10px; margin-top:4px;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          </div>
        </form>
      </div>

      <div style="height:12px;"></div>

      <div class="admin-card pad admin-fade">
        <div style="font-weight:650;"><?= e(t('users')) ?></div>
        <div class="sub" style="margin-bottom:10px;"><?= e(t('users_table_tip')) ?></div>

        <table class="admin-table">
          <thead>
            <tr>
              <th style="min-width:160px;"><?= e(t('username')) ?></th>
              <th style="min-width:220px;"><?= e(t('email')) ?></th>
              <th><?= e(t('role')) ?></th>
              <th><?= e(t('verified')) ?></th>
              <th><?= e(t('can_post')) ?></th>
              <th style="min-width:180px;"><?= e(t('created')) ?></th>
              <th style="width:1%;"><?= e(t('actions')) ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $u): ?>
              <tr>
                <td><?= e($u['username']) ?></td>
                <td style="color:var(--admin-muted);"><?= e($u['email']) ?></td>
                <td><span class="admin-badge"><?= e(t('role_' . (string)($u['role'] ?? 'user'))) ?></span></td>
                <td>
                  <?php if ((int)$u['is_verified'] === 1): ?>
                    <span class="admin-badge pub"><?= e(t('yes')) ?></span>
                  <?php else: ?>
                    <span class="admin-badge"><?= e(t('no')) ?></span>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ((int)$u['can_post'] === 1): ?>
                    <span class="admin-badge pub"><?= e(t('yes')) ?></span>
                  <?php else: ?>
                    <span class="admin-badge"><?= e(t('no')) ?></span>
                  <?php endif; ?>
                </td>
                <td><?= e($u['created_at']) ?></td>
                <td style="white-space:nowrap;">
                  <div style="display:flex; gap:8px; justify-content:flex-end;">
                    <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('user_edit', ['id' => (int)$u['id']]) : url('admin/user_edit.php?id='.(int)$u['id'])) ?>"><?= e(t('edit')) ?></a>
                    <?php if ((int)$u['can_post'] === 1): ?>
                      <form method="post" data-overlay="1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>" />
                        <button class="admin-btn" name="action" value="revoke" type="submit"><?= e(t('revoke')) ?></button>
                      </form>
                    <?php else: ?>
                      <form method="post" data-overlay="1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>" />
                        <button class="admin-btn primary" name="action" value="approve" type="submit"><?= e(t('approve')) ?></button>
                      </form>
                    <?php endif; ?>

                    <?php if (($u['role'] ?? '') !== 'admin'): ?>
                      <form method="post" data-overlay="1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int)$u['id'] ?>" />
                        <button class="admin-btn" name="action" value="make_admin" type="submit"><?= e(t('make_admin')) ?></button>
                      </form>
                    <?php endif; ?>

                    <form method="post" data-overlay="1" onsubmit="return confirm(<?= json_encode(t('delete_user_confirm')) ?>);">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)$u['id'] ?>" />
                      <button class="admin-btn" name="action" value="delete" type="submit"><?= e(t('delete')) ?></button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </main>
  </div>
</body>
</html>
