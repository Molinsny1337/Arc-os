(() => {
  // Admin: add a tiny entrance motion, WP-like but minimal
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.admin-fade').forEach((el, i) => {
      el.style.transitionDelay = `${Math.min(i * 40, 200)}ms`;
      requestAnimationFrame(() => el.classList.add('in'));
    });
  });
})();
