/* Arc OS: language menu interactions */
(function(){
  function ready(fn){ if(document.readyState!=="loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }
  ready(function(){
    var menu = document.getElementById('langMenu');
    var btn  = document.getElementById('langBtn');
    var pop  = document.getElementById('langPop');
    if(!menu || !btn || !pop) return;

    function close(){ menu.classList.remove('open'); btn.setAttribute('aria-expanded','false'); }
    function open(){ menu.classList.add('open'); btn.setAttribute('aria-expanded','true'); }

    btn.addEventListener('click', function(e){
      e.preventDefault();
      e.stopPropagation();
      if(menu.classList.contains('open')) close(); else open();
    });

    document.addEventListener('click', function(){ close(); });
    document.addEventListener('keydown', function(e){ if(e.key === 'Escape') close(); });

    // Optional click SFX hook
    document.addEventListener('click', function(e){
      var a = e.target && e.target.closest ? e.target.closest('a') : null;
      if(!a) return;
      if(a.getAttribute('data-sfx') === 'off') return;
      var audio = document.getElementById('uiClick');
      if(audio && audio.play){ try { audio.currentTime = 0; audio.play(); } catch(err) {} }
    }, true);
  });
})();
