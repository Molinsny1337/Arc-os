(() => {
  const base = (window.__BASE_PATH__ || "").replace(/\/$/, "");
  const TRANSITION_PAGE = base + "/transition.php";
  const NAV_DELAY_MS = 70;

  // ---------- Tiny click sound (WebAudio, no files) ----------
  let audioCtx = null;
  function playClick() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!audioCtx) audioCtx = new AC();
      if (audioCtx.state === "suspended") audioCtx.resume();

      const t = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(1200, t);

      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.05, t + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start(t);
      osc.stop(t + 0.065);
    } catch {}
  }

  document.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    const a = e.target.closest("a");
    if (!a) return;
    if (a.dataset.sound === "off") return;
    playClick();
  }, { capture: true });

  function isModifiedClick(e){
    return e.metaKey || e.ctrlKey || e.shiftKey || e.altKey;
  }

  // ---------- Transition for internal links ----------
  document.addEventListener("click", (e) => {
    const a = e.target.closest("a");
    if (!a) return;
    if (a.hasAttribute("download")) return;
    if (a.dataset.transition === "off") return;
    if (a.target && a.target !== "_self") return;
    if (isModifiedClick(e)) return;

    const href = a.getAttribute("href");
    if (!href) return;

    if (href.startsWith("#")) return;
    if (href.startsWith("mailto:") || href.startsWith("tel:") || href.startsWith("javascript:")) return;

    let url;
    try { url = new URL(href, location.href); } catch { return; }

    // external: don't hijack (sound already played)
    if (url.origin !== location.origin) return;

    e.preventDefault();

    const to = url.pathname + url.search + url.hash;
    const rippleUrl = `${TRANSITION_PAGE}?to=${encodeURIComponent(to)}`;

    setTimeout(() => { location.href = rippleUrl; }, NAV_DELAY_MS);
  });

  // ---------- Scroll reveal ----------
  function initReveal(){
    document.querySelectorAll(".reveal-group").forEach(group => {
      group.querySelectorAll(".reveal").forEach((el, i) => {
        el.style.setProperty("--i", i);
      });
    });

    const els = document.querySelectorAll(".reveal");
    if (!els.length) return;

    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      els.forEach(el => el.classList.add("active"));
      return;
    }

    const obs = new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add("active");
          obs.unobserve(en.target);
        }
      });
    }, { threshold: 0.18 });

    els.forEach(el => obs.observe(el));
  }

  // ---------- Form submit overlay ----------
  function initSubmittingOverlay(){
    document.querySelectorAll("form[data-overlay='1']").forEach(form => {
      form.addEventListener("submit", () => {
        document.body.classList.add("submitting");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initReveal();
    initSubmittingOverlay();
  });
})();
