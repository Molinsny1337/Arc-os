<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · Discord Roles';
$active = 'discord';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_discord_role_map', 60, 300);
  try {
    $action = (string)($_POST['action'] ?? '');
    $roleId = trim((string)($_POST['role_id'] ?? ''));
    $groupId = (int)($_POST['group_id'] ?? 0);

    if ($roleId !== '' && !preg_match('/^[0-9]{6,32}$/', $roleId)) {
      throw new RuntimeException('Role ID invalid.');
    }

    $pdo = db();
    $pfx = table_prefix();

    if ($action === 'add') {
      if ($roleId === '' || $groupId <= 0) throw new RuntimeException('Fill all fields.');
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_discord_role_map (role_id, group_id)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE group_id=VALUES(group_id)");
      $stmt->execute([$roleId, $groupId]);
    } elseif ($action === 'delete') {
      if ($roleId === '' || $groupId <= 0) throw new RuntimeException('Missing map.');
      $stmt = $pdo->prepare("DELETE FROM {$pfx}xf_discord_role_map WHERE role_id=? AND group_id=?");
      $stmt->execute([$roleId, $groupId]);
    }

    $back = function_exists('admin_url') ? admin_url('discord_role_map') : url('admin/discord_role_map.php');
    redirect($back);
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$pdo = db();
$pfx = table_prefix();
$groups = [];
$maps = [];

try {
  $groups = $pdo->query("SELECT id, name FROM {$pfx}groups ORDER BY name ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $groups = [];
}

try {
  $stmt = $pdo->prepare("SELECT m.role_id, m.group_id, g.name AS group_name
    FROM {$pfx}xf_discord_role_map m
    LEFT JOIN {$pfx}groups g ON g.id=m.group_id
    ORDER BY m.role_id ASC, m.group_id ASC");
  $stmt->execute();
  $maps = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $maps = [];
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1>Discord Role Mapping</h1>
          <div class="sub">Map Discord role IDs to Arc OS user groups.</div>
        </div>
        <div class="admin-actions">
          <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('settings_discord') : url('admin/settings_discord.php')) ?>">Back</a>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <section class="admin-card pad admin-fade" style="max-width:720px;">
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="add">
          <div class="grid">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Discord Role ID</label>
              <input class="input" name="role_id" placeholder="123456789012345678" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">User Group</label>
              <select class="input" name="group_id">
                <option value="0">Select group</option>
                <?php foreach ($groups as $g): ?>
                  <option value="<?= (int)$g['id'] ?>"><?= e((string)$g['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <button class="admin-btn primary" type="submit">Add Mapping</button>
        </form>
      </section>

      <section class="admin-card pad admin-fade" style="margin-top:16px;">
        <div style="font-weight:700;">Current Mappings</div>
        <div style="overflow:auto;margin-top:10px;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Role ID</th>
                <th>Group</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($maps as $row): ?>
                <tr>
                  <td><?= e((string)($row['role_id'] ?? '')) ?></td>
                  <td><?= e((string)($row['group_name'] ?? '')) ?><?php if (!empty($row['group_id'])): ?> #<?= (int)$row['group_id'] ?><?php endif; ?></td>
                  <td style="text-align:right">
                    <form method="post" style="margin:0">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete">
                      <input type="hidden" name="role_id" value="<?= e((string)($row['role_id'] ?? '')) ?>">
                      <input type="hidden" name="group_id" value="<?= (int)($row['group_id'] ?? 0) ?>">
                      <button class="admin-btn" type="submit">Remove</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$maps): ?>
                <tr><td colspan="3" class="muted"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
