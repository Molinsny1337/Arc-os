<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin').' · '.t('logs');
$title = t('admin') . ' · ' . t('logs');
$active = 'logs';

$p = (int)($_GET['p'] ?? 1);
if ($p < 1) $p = 1;
$per = 50;
$offset = ($p-1)*$per;

$q_user = trim((string)($_GET['user'] ?? ''));
$q_action = trim((string)($_GET['action'] ?? ''));
$q_from = trim((string)($_GET['from'] ?? ''));
$q_to = trim((string)($_GET['to'] ?? ''));

$pdo = db();
$pfx = table_prefix();
$tbl = $pfx.'logs';

$where = [];
$args = [];

if ($q_user !== '') {
  if (ctype_digit($q_user)) {
    $where[] = "user_id = ?";
    $args[] = (int)$q_user;
  } else {
    $where[] = "username LIKE ?";
    $args[] = '%'.$q_user.'%';
  }
}
if ($q_action !== '') {
  $where[] = "action = ?";
  $args[] = $q_action;
}
if ($q_from !== '') {
  $where[] = "created_at >= ?";
  $args[] = $q_from.' 00:00:00';
}
if ($q_to !== '') {
  $where[] = "created_at <= ?";
  $args[] = $q_to.' 23:59:59';
}

$sqlWhere = $where ? ('WHERE '.implode(' AND ', $where)) : '';
$total = 0;
try {
  $st = $pdo->prepare("SELECT COUNT(*) c FROM {$tbl} {$sqlWhere}");
  $st->execute($args);
  $total = (int)($st->fetch()['c'] ?? 0);
} catch (Throwable $e) { $total = 0; }

$logs = [];
try {
  $st = $pdo->prepare("SELECT * FROM {$tbl} {$sqlWhere} ORDER BY id DESC LIMIT {$per} OFFSET {$offset}");
  $st->execute($args);
  $logs = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) { $logs = []; }

$pages = max(1, (int)ceil($total / $per));

$actions = [];
try {
  $actions = $pdo->query("SELECT DISTINCT action FROM {$tbl} ORDER BY action ASC LIMIT 200")->fetchAll(PDO::FETCH_COLUMN) ?: [];
} catch (Throwable $e) {}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
<?php include __DIR__ . '/../partials/nav.php'; ?>
<div class="admin-shell">
  <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
  <main class="admin-main">
    <h1><?= e(t('logs')) ?></h1>

    <form class="admin-card" method="get" action="">
      <div class="grid2">
        <div>
          <label class="label"><?= e(t('user')) ?></label>
          <input class="input" name="user" value="<?= e($q_user) ?>" placeholder="<?= e(t('user_search_placeholder')) ?>">
        </div>
        <div>
          <label class="label"><?= e(t('action')) ?></label>
          <select class="input" name="action">
            <option value=""><?= e(t('all')) ?></option>
            <?php foreach ($actions as $a): ?>
              <option value="<?= e($a) ?>" <?= $a===$q_action?'selected':'' ?>><?= e(arc_log_action_label((string)$a)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="label"><?= e(t('from')) ?></label>
          <input class="input" type="date" name="from" value="<?= e($q_from) ?>">
        </div>
        <div>
          <label class="label"><?= e(t('to')) ?></label>
          <input class="input" type="date" name="to" value="<?= e($q_to) ?>">
        </div>
      </div>
      <div style="margin-top:12px; display:flex; gap:10px;">
        <button class="admin-btn" type="submit"><?= e(t('filter')) ?></button>
        <a class="admin-btn ghost" href="<?= e(function_exists('admin_url') ? admin_url('logs') : url('admin/logs.php')) ?>"><?= e(t('reset')) ?></a>
      </div>
    </form>

    <div class="admin-card" style="margin-top:16px;">
      <div class="muted"><?= e(t('total')) ?>: <?= e((string)$total) ?></div>
      <div style="overflow:auto; margin-top:10px;">
        <table class="admin-table">
          <thead>
            <tr>
              <th><?= e(t('id')) ?></th>
              <th><?= e(t('time')) ?></th>
              <th><?= e(t('user')) ?></th>
              <th><?= e(t('action')) ?></th>
              <th><?= e(t('object')) ?></th>
              <th><?= e(t('ip')) ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($logs as $row): ?>
              <tr>
                <td><?= (int)$row['id'] ?></td>
                <td><?= e((string)$row['created_at']) ?></td>
                <td><?= e((string)($row['username'] ?? '')) ?><?php if (!empty($row['user_id'])): ?> #<?= (int)$row['user_id'] ?><?php endif; ?></td>
                <td><?= e(arc_log_action_label((string)($row['action'] ?? ''))) ?></td>
                <td><?= e((string)($row['object_type'] ?? '')) ?><?php if (!empty($row['object_id'])): ?> #<?= (int)$row['object_id'] ?><?php endif; ?></td>
                <td><?= e((string)($row['ip'] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?>
              <tr><td colspan="6" class="muted"><?= e(t('no_data')) ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="pager" style="margin-top:12px;">
        <?php for ($i=1; $i<=$pages; $i++): ?>
          <a class="page <?= $i===$p?'active':'' ?>" href="<?= e((function_exists('admin_url') ? admin_url('logs') : url('admin/logs.php')) . '?' . http_build_query(array_merge($_GET, ['p' => $i]))) ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
    </div>
  </main>
</div>
</body>
</html>
