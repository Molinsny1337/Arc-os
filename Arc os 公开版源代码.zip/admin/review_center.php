<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$canModeration = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('moderation') : false;
if (!$canModeration) {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && class_exists('ArcOS\\Services\\FeatureGate')) {
    ArcOS\Services\FeatureGate::deny('moderation');
  }
  http_response_code(403);
  $title = t('admin') . ' · ' . t('review_center');
  $active = 'review';
  ?>
  <!doctype html>
  <html lang="<?= e(lang()) ?>">
  <head><?php include __DIR__ . '/../partials/head.php'; ?></head>
  <body class="admin">
    <?php include __DIR__ . '/../partials/nav.php'; ?>
    <div class="admin-shell">
      <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
      <main class="admin-main">
        <div class="admin-card pad" style="margin-top:14px;">
          <div style="font-weight:700;">Moderation queue is a Pro/Business feature.</div>
          <div class="sub" style="margin-top:6px;">Activate a license to enable review workflows.</div>
        </div>
      </main>
    </div>
  </body>
  </html>
  <?php
  exit;
}

$title = t('admin') . ' · ' . t('review_center');
$active = 'review';
$__need_editor = true;

$pdo = db();
$pfx = table_prefix();
$me = current_user();
$adminId = (int)($me['id'] ?? 0);

$err = '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_review_action', 240, 300);

  $kind = (string)($_POST['kind'] ?? '');
  $action = (string)($_POST['action'] ?? '');
  $id = (int)($_POST['id'] ?? 0);
  $note = trim((string)($_POST['note'] ?? ''));

  try {
    if ($kind === 'user' && $id > 0) {
      $stmt = $pdo->prepare("SELECT * FROM {$pfx}review_requests WHERE id=? AND status='pending' LIMIT 1");
      $stmt->execute([$id]);
      $req = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$req) throw new RuntimeException(t('request_not_found'));

      $type = (string)($req['req_type'] ?? '');
      $payload = (string)($req['payload'] ?? '');
      $data = $payload ? json_decode($payload, true) : null;
      if (!is_array($data)) $data = [];

      if ($action === 'approve') {
        if ($type === 'username') {
          $new = trim((string)($data['username'] ?? ''));
          if ($new === '') throw new RuntimeException(t('invalid_username'));
          // uniqueness
          $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users WHERE username=?");
          $stmt->execute([$new]);
          if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException(t('username_taken'));
          $stmt = $pdo->prepare("UPDATE {$pfx}users SET username=? WHERE id=?");
          $stmt->execute([$new, (int)$req['user_id']]);
        } elseif ($type === 'avatar') {
          $new = trim((string)($data['avatar'] ?? ''));
          if ($new === '') throw new RuntimeException(t('upload_failed'));
          $stmt = $pdo->prepare("UPDATE {$pfx}users SET avatar=? WHERE id=?");
          $stmt->execute([$new, (int)$req['user_id']]);
        }
        $stmt = $pdo->prepare("UPDATE {$pfx}review_requests SET status='approved', review_note=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?");
        $stmt->execute([$note, $adminId, $id]);
        $msg = t('approved');
      } elseif ($action === 'reject') {
        // cleanup pending avatar file
        if ($type === 'avatar') {
          $new = trim((string)($data['avatar'] ?? ''));
          $old = (string)($data['avatar_old'] ?? '');
          // revert immediately-applied avatar (if present)
          $stmt = $pdo->prepare("UPDATE {$pfx}users SET avatar=? WHERE id=?");
          $stmt->execute([trim($old) !== '' ? trim($old) : null, (int)$req['user_id']]);

          if ($new && strpos($new, '/uploads/avatars/') !== false) {
            $fs = base_path() ? (base_path() . '/') : '';
            $rel = ltrim(str_replace(base_path(), '', $new), '/');
            $full = realpath(__DIR__ . '/../' . $rel);
            if ($full && is_file($full)) @unlink($full);
          }
        }
        $stmt = $pdo->prepare("UPDATE {$pfx}review_requests SET status='rejected', review_note=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?");
        $stmt->execute([$note, $adminId, $id]);
        $msg = t('rejected');
      }
    }

    if ($kind === 'post' && $id > 0) {
      $stmt = $pdo->prepare("SELECT id, status, review_state FROM {$pfx}posts WHERE id=? LIMIT 1");
      $stmt->execute([$id]);
      $post = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$post) throw new RuntimeException(t('post_not_found'));

      if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE {$pfx}posts SET status='published', review_state='approved', review_note=?, reviewed_by=?, reviewed_at=NOW(), updated_at=NOW() WHERE id=?");
        $stmt->execute([$note, $adminId, $id]);
        $msg = t('approved');
      } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE {$pfx}posts SET status='draft', review_state='rejected', review_note=?, reviewed_by=?, reviewed_at=NOW(), updated_at=NOW() WHERE id=?");
        $stmt->execute([$note, $adminId, $id]);
        $msg = t('rejected');
      }
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

// Pending user requests
$userReqs = [];
try {
  $userReqs = $pdo->query("SELECT r.*, u.username AS u_username, u.email AS u_email FROM {$pfx}review_requests r
    LEFT JOIN {$pfx}users u ON u.id=r.user_id
    WHERE r.status='pending'
    ORDER BY r.created_at DESC
    LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $userReqs = []; }

// Pending posts
$postReqs = [];
try {
  // pending = draft + review_state=pending (fallback: reviewed_at IS NULL)
  $postReqs = $pdo->query("SELECT p.id, p.type, p.title, p.slug, p.created_at, u.username AS author
    FROM {$pfx}posts p
    LEFT JOIN {$pfx}users u ON u.id=p.author_id
    WHERE p.status='draft' AND (p.review_state='pending' OR p.review_state IS NULL)
    ORDER BY p.created_at DESC
    LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $postReqs = []; }
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('review_center')) ?></h1>
          <div class="sub"><?= e(t('review_center_tip')) ?></div>
        </div>
      </div>

      <?php if ($msg): ?><div class="notice success admin-fade"><?= e($msg) ?></div><?php endif; ?>
      <?php if ($err): ?><div class="notice danger admin-fade"><?= e($err) ?></div><?php endif; ?>

      <section class="admin-card admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 10px 0;"><?= e(t('user_review_requests')) ?> <span style="color:#888;font-size:13px;">(<?= count($userReqs) ?>)</span></h2>
        <?php if (!$userReqs): ?>
          <div class="sub"><?= e(t('no_pending_requests')) ?></div>
        <?php else: ?>
          <div style="display:grid;gap:10px;">
            <?php foreach ($userReqs as $r):
              $type = (string)($r['req_type'] ?? '');
              $payload = (string)($r['payload'] ?? '');
              $data = $payload ? json_decode($payload, true) : null;
              if (!is_array($data)) $data = [];
              $what = $type === 'username' ? t('change_username') : t('change_avatar');
              $detail = '';
              if ($type === 'username') $detail = (string)($data['username'] ?? '');
              if ($type === 'avatar') $detail = (string)($data['avatar'] ?? '');
            ?>
            <div style="border:1px solid rgba(0,0,0,.08);border-radius:14px;padding:12px;display:flex;gap:12px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;">
              <div style="min-width:260px;flex:1;">
                <div style="font-weight:700;"><?= e($what) ?></div>
                <div class="sub" style="margin-top:4px;">
                  <?= e((string)($r['u_username'] ?? '')) ?> · <?= e((string)($r['created_at'] ?? '')) ?>
                </div>
                <?php if ($detail): ?>
                  <div style="margin-top:8px;font-size:13px;color:#444;word-break:break-all;">
                    <?= e($detail) ?>
                  </div>
                <?php endif; ?>
              </div>

              <form method="post" style="display:grid;gap:8px;align-items:start;min-width:260px;flex:1;">
                <?= csrf_field() ?>
                <input type="hidden" name="kind" value="user">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <?php
                  $content_name = 'note';
                  $initial_value = '';
                  $mode = 'admin_note';
                  $placeholder = t('review_note');
                  $attachments_enabled = false;
                  $mentions_enabled = false;
                  $tags_enabled = false;
                  $full_screen_enabled = false;
                  $min_height = 90;
                  include __DIR__ . '/../partials/editor/editor_widget.php';
                ?>
                <button class="admin-btn primary" type="submit" name="action" value="approve"><?= e(t('approve')) ?></button>
                <button class="admin-btn" type="submit" name="action" value="reject"><?= e(t('reject')) ?></button>
              </form>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>

      <section class="admin-card admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 10px 0;"><?= e(t('post_review_requests')) ?> <span style="color:#888;font-size:13px;">(<?= count($postReqs) ?>)</span></h2>
        <?php if (!$postReqs): ?>
          <div class="sub"><?= e(t('no_pending_requests')) ?></div>
        <?php else: ?>
          <div style="display:grid;gap:10px;">
            <?php foreach ($postReqs as $p): ?>
            <div style="border:1px solid rgba(0,0,0,.08);border-radius:14px;padding:12px;display:flex;gap:12px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;">
              <div style="min-width:260px;flex:1;">
                <div style="font-weight:700;"><?= e((string)$p['title']) ?></div>
                <div class="sub" style="margin-top:4px;">
                  <?= e((string)($p['type'] ?? '')) ?> · <?= e((string)($p['author'] ?? '')) ?> · <?= e((string)($p['created_at'] ?? '')) ?>
                </div>
                <div style="margin-top:8px;">
                  <?php if ((string)($p['type'] ?? '') === 'page'): ?>
                    <a href="<?= e(url('page.php?slug=' . urlencode((string)$p['slug']))) ?>" target="_blank"><?= e(t('preview')) ?></a>
                  <?php else: ?>
                    <a href="<?= e(url('forum_post.php?id=' . (int)$p['id'])) ?>" target="_blank"><?= e(t('preview')) ?></a>
                  <?php endif; ?>
                </div>
              </div>

              <form method="post" style="display:grid;gap:8px;align-items:start;min-width:260px;flex:1;">
                <?= csrf_field() ?>
                <input type="hidden" name="kind" value="post">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <?php
                  $content_name = 'note';
                  $initial_value = '';
                  $mode = 'admin_note';
                  $placeholder = t('review_note');
                  $attachments_enabled = false;
                  $mentions_enabled = false;
                  $tags_enabled = false;
                  $full_screen_enabled = false;
                  $min_height = 90;
                  include __DIR__ . '/../partials/editor/editor_widget.php';
                ?>
                <button class="admin-btn primary" type="submit" name="action" value="approve"><?= e(t('approve_publish')) ?></button>
                <button class="admin-btn" type="submit" name="action" value="reject"><?= e(t('reject')) ?></button>
              </form>
            </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>

    </main>
  </div>

<?php include __DIR__ . '/../partials/foot.php'; ?>
</body>
</html>
