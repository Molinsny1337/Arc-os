<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · Profile Fields';
$active = 'profile_fields';
$err = '';

function bool_post(string $key): string {
  return isset($_POST[$key]) ? '1' : '0';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_profile_fields', 60, 300);
  try {
    $pdo = db();
    $pfx = table_prefix();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'save_settings') {
      set_setting('profile_posts_enabled', bool_post('profile_posts_enabled'));
      set_setting('profile_visitors_enabled', bool_post('profile_visitors_enabled'));
      set_setting('profile_media_enabled', bool_post('profile_media_enabled'));
      set_setting('profile_signatures_enabled', bool_post('profile_signatures_enabled'));
      set_setting('profile_fields_enabled', bool_post('profile_fields_enabled'));
    } elseif ($action === 'add_field' || $action === 'update_field') {
      $fieldId = (int)($_POST['field_id'] ?? 0);
      $title = trim((string)($_POST['field_title'] ?? ''));
      $type = (string)($_POST['field_type'] ?? 'text');
      $choicesRaw = trim((string)($_POST['field_choices'] ?? ''));
      $displayOrder = (int)($_POST['display_order'] ?? 0);
      $editable = bool_post('editable');
      $showOnProfile = bool_post('show_on_profile');

      if ($title === '') throw new RuntimeException('Title required.');
      if (!in_array($type, ['text','textarea','select'], true)) throw new RuntimeException('Type invalid.');
      if ($displayOrder < 0) $displayOrder = 0;

      $choices = [];
      if ($type === 'select' && $choicesRaw !== '') {
        foreach (preg_split('/\\r?\\n/', $choicesRaw) as $line) {
          $line = trim((string)$line);
          if ($line !== '') $choices[] = $line;
        }
      }
      $choicesJson = $choices ? json_encode($choices, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
      if ($choicesJson !== null && !is_string($choicesJson)) $choicesJson = null;

      if ($action === 'add_field') {
        $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_fields
          (title, field_type, field_choices_json, display_order, editable, show_on_profile)
          VALUES (?,?,?,?,?,?)");
        $stmt->execute([$title, $type, $choicesJson, $displayOrder, $editable, $showOnProfile]);
      } else {
        if ($fieldId <= 0) throw new RuntimeException('Field ID invalid.');
        $stmt = $pdo->prepare("UPDATE {$pfx}xf_profile_fields
          SET title=?, field_type=?, field_choices_json=?, display_order=?, editable=?, show_on_profile=?
          WHERE field_id=?");
        $stmt->execute([$title, $type, $choicesJson, $displayOrder, $editable, $showOnProfile, $fieldId]);
      }
    } elseif ($action === 'delete_field') {
      $fieldId = (int)($_POST['field_id'] ?? 0);
      if ($fieldId <= 0) throw new RuntimeException('Field ID invalid.');
      $pdo->prepare("DELETE FROM {$pfx}xf_profile_fields WHERE field_id=?")->execute([$fieldId]);
      $pdo->prepare("DELETE FROM {$pfx}xf_user_field_values WHERE field_id=?")->execute([$fieldId]);
    }

    $back = function_exists('admin_url') ? admin_url('profile_fields') : url('admin/profile_fields.php');
    redirect($back);
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$pdo = db();
$pfx = table_prefix();
$fields = [];
try {
  $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_profile_fields ORDER BY display_order ASC, field_id ASC");
  $stmt->execute();
  $fields = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $fields = [];
}

$profilePostsEnabled = get_setting('profile_posts_enabled', '1') === '1';
$profileVisitorsEnabled = get_setting('profile_visitors_enabled', '1') === '1';
$profileMediaEnabled = get_setting('profile_media_enabled', '1') === '1';
$profileSignaturesEnabled = get_setting('profile_signatures_enabled', '1') === '1';
$profileFieldsEnabled = get_setting('profile_fields_enabled', '1') === '1';
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1>Profile Fields</h1>
          <div class="sub">Manage custom profile fields and profile features.</div>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <section class="admin-card pad admin-fade" style="max-width:920px;">
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_settings">
          <div style="font-weight:700;">Profile Feature Toggles</div>
          <div style="display:grid;gap:10px;margin-top:12px;">
            <label class="check" style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="profile_posts_enabled" <?= $profilePostsEnabled ? 'checked' : '' ?> />
              <span>Enable profile posts</span>
            </label>
            <label class="check" style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="profile_visitors_enabled" <?= $profileVisitorsEnabled ? 'checked' : '' ?> />
              <span>Enable profile visitors</span>
            </label>
            <label class="check" style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="profile_media_enabled" <?= $profileMediaEnabled ? 'checked' : '' ?> />
              <span>Enable media tab</span>
            </label>
            <label class="check" style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="profile_signatures_enabled" <?= $profileSignaturesEnabled ? 'checked' : '' ?> />
              <span>Show signatures under posts</span>
            </label>
            <label class="check" style="display:flex;gap:10px;align-items:center;">
              <input type="checkbox" name="profile_fields_enabled" <?= $profileFieldsEnabled ? 'checked' : '' ?> />
              <span>Enable custom profile fields</span>
            </label>
          </div>
          <button class="admin-btn primary" type="submit" style="margin-top:12px;">Save Settings</button>
        </form>
      </section>

      <section class="admin-card pad admin-fade" style="margin-top:16px;max-width:920px;">
        <div style="font-weight:700;">Add Field</div>
        <form method="post" style="margin-top:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="add_field">
          <div class="grid">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Title</label>
              <input class="input" name="field_title" />
            </div>
            <div class="field" style="grid-column: span 3;">
              <label class="label">Type</label>
              <select class="input" name="field_type">
                <option value="text">Text</option>
                <option value="textarea">Textarea</option>
                <option value="select">Select</option>
              </select>
            </div>
            <div class="field" style="grid-column: span 3;">
              <label class="label">Order</label>
              <input class="input" name="display_order" type="number" value="0" min="0" />
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label">Choices (one per line, for select)</label>
              <textarea class="input" name="field_choices" rows="3"></textarea>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="check" style="display:flex;gap:8px;align-items:center;">
                <input type="checkbox" name="editable" checked />
                <span>Editable by user</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="check" style="display:flex;gap:8px;align-items:center;">
                <input type="checkbox" name="show_on_profile" checked />
                <span>Show on profile</span>
              </label>
            </div>
          </div>
          <button class="admin-btn primary" type="submit">Add Field</button>
        </form>
      </section>

      <section class="admin-card pad admin-fade" style="margin-top:16px;">
        <div style="font-weight:700;">Existing Fields</div>
        <div style="overflow:auto;margin-top:10px;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Type</th>
                <th>Choices</th>
                <th>Order</th>
                <th>Editable</th>
                <th>Show</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($fields as $field): ?>
                <?php
                  $choices = '';
                  $rawChoices = (string)($field['field_choices_json'] ?? '');
                  if ($rawChoices !== '') {
                    $decoded = json_decode($rawChoices, true);
                    if (is_array($decoded)) $choices = implode("\n", array_map('strval', $decoded));
                  }
                ?>
                <tr>
                  <td>
                    <form method="post" style="margin:0;display:flex;gap:8px;align-items:center;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="update_field">
                      <input type="hidden" name="field_id" value="<?= (int)$field['field_id'] ?>">
                      <input class="input" name="field_title" value="<?= e((string)($field['title'] ?? '')) ?>" />
                  </td>
                  <td>
                      <select class="input" name="field_type">
                        <?php $type = (string)($field['field_type'] ?? 'text'); ?>
                        <option value="text" <?= $type === 'text' ? 'selected' : '' ?>>Text</option>
                        <option value="textarea" <?= $type === 'textarea' ? 'selected' : '' ?>>Textarea</option>
                        <option value="select" <?= $type === 'select' ? 'selected' : '' ?>>Select</option>
                      </select>
                  </td>
                  <td>
                      <textarea class="input" name="field_choices" rows="2"><?= e($choices) ?></textarea>
                  </td>
                  <td>
                      <input class="input" name="display_order" type="number" value="<?= (int)($field['display_order'] ?? 0) ?>" min="0" />
                  </td>
                  <td style="text-align:center;">
                      <input type="checkbox" name="editable" <?= !empty($field['editable']) ? 'checked' : '' ?> />
                  </td>
                  <td style="text-align:center;">
                      <input type="checkbox" name="show_on_profile" <?= !empty($field['show_on_profile']) ? 'checked' : '' ?> />
                  </td>
                  <td style="white-space:nowrap;text-align:right;">
                      <button class="admin-btn" type="submit">Save</button>
                    </form>
                    <form method="post" style="margin:6px 0 0;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete_field">
                      <input type="hidden" name="field_id" value="<?= (int)$field['field_id'] ?>">
                      <button class="admin-btn" type="submit">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$fields): ?>
                <tr><td colspan="7" class="muted"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
