<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$pdo = db();
$pfx = table_prefix();
$me = current_user();

$title = t('ban_center');
$active = 'bans';
$ok = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_bans', 120, 300);
  try {
    $action = (string)($_POST['action'] ?? '');
    $uid = (int)($_POST['user_id'] ?? 0);
    if ($uid <= 0) throw new RuntimeException(t('bad_user_id'));

    // prevent self-ban
    if ($me && (int)$me['id'] === $uid) {
      throw new RuntimeException(t('cannot_ban_self'));
    }

    if ($action === 'unban') {
      $stmt = $pdo->prepare("UPDATE {$pfx}users SET is_banned=0, banned_reason=NULL, banned_until=NULL, banned_by=NULL, banned_at=NULL WHERE id=?");
      $stmt->execute([$uid]);
      $ok = t('unban') . ': ID ' . $uid;
    } elseif ($action === 'ban') {
      $reason = trim((string)($_POST['banned_reason'] ?? ''));
      $until = trim((string)($_POST['banned_until'] ?? ''));
      $untilVal = $until !== '' ? $until : null;

      $stmt = $pdo->prepare("UPDATE {$pfx}users SET is_banned=1, banned_reason=?, banned_until=?, banned_by=?, banned_at=NOW() WHERE id=?");
      $stmt->execute([$reason !== '' ? $reason : null, $untilVal, $me ? (int)$me['id'] : null, $uid]);
      $ok = t('ban') . ': ID ' . $uid;
    } else {
      throw new RuntimeException(t('unknown_action'));
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$q = trim((string)($_GET['q'] ?? ''));
$params = [];
$where = "WHERE is_banned=1";
if ($q !== '') {
  $where .= " AND (username LIKE ? OR email LIKE ? OR display_name LIKE ?)";
  $like = '%' . $q . '%';
  $params = [$like, $like, $like];
}

$stmt = $pdo->prepare("SELECT id, username, display_name, email, banned_reason, banned_until, banned_by, banned_at
  FROM {$pfx}users {$where} ORDER BY banned_at DESC, id DESC LIMIT 200");
$stmt->execute($params);
$banned = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('ban_center')) ?></h1>
          <div class="sub"><?= e(t('ban_center_sub')) ?></div>
        </div>
        <div class="admin-actions">
          <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('users') : url('admin/users.php')) ?>"><?= e(t('users')) ?></a>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div class="admin-grid" style="gap:12px;">
          <div class="admin-col-12">
            <h2 style="margin:0 0 10px;font-size:16px;"><?= e(t('ban_user')) ?></h2>
          </div>
          <div class="admin-col-12">
            <form method="post" class="admin-grid" style="gap:12px;" data-overlay="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="ban" />
              <div class="admin-col-3">
                <label class="label"><?= e(t('user_id')) ?></label>
                <input class="input" name="user_id" inputmode="numeric" placeholder="1" />
              </div>
              <div class="admin-col-6">
                <label class="label"><?= e(t('banned_reason')) ?></label>
                <input class="input" name="banned_reason" placeholder="<?= e(t('banned_reason_placeholder')) ?>" />
              </div>
              <div class="admin-col-3">
                <label class="label"><?= e(t('banned_until')) ?></label>
                <input class="input" name="banned_until" placeholder="YYYY-MM-DD HH:MM:SS" />
              </div>
              <div class="admin-col-12" style="display:flex;justify-content:flex-end;gap:10px;">
                <button class="admin-btn" type="submit"><?= e(t('ban')) ?></button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
          <h2 style="margin:0;font-size:16px;"><?= e(t('banned_users')) ?></h2>
          <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <input class="input" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search')) ?>" style="width:260px" />
            <button class="admin-btn" type="submit"><?= e(t('filter')) ?></button>
            <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('bans') : url('admin/bans.php')) ?>"><?= e(t('reset')) ?></a>
          </form>
        </div>

        <div style="height:10px"></div>

        <?php if (!$banned): ?>
          <div class="muted"><?= e(t('no_data')) ?></div>
        <?php else: ?>
          <div style="overflow:auto;">
            <table class="admin-table">
              <thead>
                <tr>
                  <th><?= e(t('user')) ?></th>
                  <th><?= e(t('email')) ?></th>
                  <th><?= e(t('banned_reason')) ?></th>
                  <th><?= e(t('banned_until')) ?></th>
                  <th style="width:1%;"><?= e(t('actions')) ?></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($banned as $u): ?>
                  <tr>
                    <td>
                      <div style="font-weight:700"><?= e((string)$u['username']) ?></div>
                      <div class="muted" style="font-size:12px">#<?= (int)$u['id'] ?></div>
                    </td>
                    <td><?= e((string)$u['email']) ?></td>
                    <td><?= e((string)($u['banned_reason'] ?? '')) ?></td>
                    <td><?= e((string)($u['banned_until'] ?? '')) ?></td>
                    <td style="display:flex;gap:8px;flex-wrap:wrap">
                      <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('user_edit', ['id' => (int)$u['id']]) : url('admin/user_edit.php?id='.(int)$u['id'])) ?>"><?= e(t('edit')) ?></a>
                      <form method="post" style="display:inline" data-overlay="1">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="unban" />
                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>" />
                        <button class="admin-btn" type="submit"><?= e(t('unban')) ?></button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
