<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · ' . t('links');
$pdo = db();
$pfx = table_prefix();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_links', 240, 300);
  try {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
      $label = trim($_POST['label'] ?? '');
      $urlv = trim($_POST['url'] ?? '');
      $target = trim($_POST['target'] ?? '_self');
      $sort = (int)($_POST['sort_order'] ?? 0);
      if ($label === '' || $urlv === '') throw new RuntimeException('Label 与 URL 不能为空。');
      $stmt = $pdo->prepare("INSERT INTO {$pfx}links (label, url, target, sort_order, created_at, updated_at)
        VALUES (?, ?, ?, ?, NOW(), NOW())");
      $stmt->execute([$label, $urlv, $target, $sort]);
    } elseif ($action === 'update') {
      $id = (int)($_POST['id'] ?? 0);
      $label = trim($_POST['label'] ?? '');
      $urlv = trim($_POST['url'] ?? '');
      $target = trim($_POST['target'] ?? '_self');
      $sort = (int)($_POST['sort_order'] ?? 0);
      $stmt = $pdo->prepare("UPDATE {$pfx}links SET label=?, url=?, target=?, sort_order=?, updated_at=NOW() WHERE id=?");
      $stmt->execute([$label, $urlv, $target, $sort, $id]);
    } elseif ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      $stmt = $pdo->prepare("DELETE FROM {$pfx}links WHERE id=?");
      $stmt->execute([$id]);
    }
    $u = current_user();
    $hello = $u['username'] ?? 'Admin';
    $back = function_exists('admin_url') ? admin_url('links') : url('admin/links.php');
    redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode('Updated') . '&to=' . urlencode($back));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$links = $pdo->query("SELECT * FROM {$pfx}links ORDER BY sort_order ASC, id ASC")->fetchAll();
$active = 'links';
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('links')) ?></h1>
          <div class="sub">顶部导航（右上角）链接管理。</div>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <div class="admin-card pad admin-fade">
        <div style="font-weight:650;">Existing links</div>
        <div style="margin-top:10px;overflow:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Label</th>
                <th style="min-width:260px;">URL</th>
                <th>Target</th>
                <th>Sort</th>
                <th style="width:1%;"><?= e(t('save')) ?></th>
                <th style="width:1%;">Delete</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($links as $l): ?>
                <tr>
                  <form method="post" data-overlay="1">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update" />
                    <input type="hidden" name="id" value="<?= (int)$l['id'] ?>" />
                    <td><input class="input" name="label" value="<?= e((string)$l['label']) ?>" /></td>
                    <td><input class="input" name="url" value="<?= e((string)$l['url']) ?>" /></td>
                    <td>
                      <select class="input" name="target">
                        <option value="_self" <?= ($l['target'] ?? '') === '_self' ? 'selected' : '' ?>>_self</option>
                        <option value="_blank" <?= ($l['target'] ?? '') === '_blank' ? 'selected' : '' ?>>_blank</option>
                      </select>
                    </td>
                    <td style="width:110px;"><input class="input" name="sort_order" value="<?= (int)$l['sort_order'] ?>" /></td>
                    <td><button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button></td>
                    <td>
                      <button class="admin-btn" type="submit" name="action" value="delete" style="border-color:rgba(220,38,38,.25);color:#991b1b;background:rgba(220,38,38,.06);">
                        Delete
                      </button>
                    </td>
                  </form>
                </tr>
              <?php endforeach; ?>
              <?php if (!$links): ?>
                <tr><td colspan="6" style="color:var(--admin-muted);">No links yet.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div style="height:12px;"></div>

      <div class="admin-card pad admin-fade">
        <div style="font-weight:650;">Add new link</div>
        <form method="post" data-overlay="1" style="margin-top:10px;display:grid;gap:10px;grid-template-columns:repeat(12,1fr);">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="add" />
          <div style="grid-column: span 3;">
            <label class="label">Label</label>
            <input class="input" name="label" placeholder="Projects" />
          </div>
          <div style="grid-column: span 5;">
            <label class="label">URL</label>
            <input class="input" name="url" placeholder="<?= e(url('projects.php')) ?>" />
          </div>
          <div style="grid-column: span 2;">
            <label class="label">Target</label>
            <select class="input" name="target">
              <option value="_self">_self</option>
              <option value="_blank">_blank</option>
            </select>
          </div>
          <div style="grid-column: span 1;">
            <label class="label">Sort</label>
            <input class="input" name="sort_order" value="40" />
          </div>
          <div style="grid-column: span 1;display:flex;align-items:flex-end;">
            <button class="admin-btn primary" type="submit">Add</button>
          </div>
        </form>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e('assets/admin.js') ?>"></script>
</body>
</html>
