<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = 'License';
$active = 'settings_license';

function arc_admin_path_conflicts(string $path): bool {
  $path = trim($path);
  if ($path === '') return true;
  $reserved = [
    'admin', 'admincp', 'administrator', 'install', 'welcome', 'index', 'forum', 'forum_view',
    'forum_post', 'forum_new', 'login', 'register', 'logout', 'search', 'members', 'member',
    'notifications', 'conversations', 'conversation', 'api', 'attachment', 'upload', 'transition',
    'post', 'page', 'apps', 'about', 'profile', 'user', 'account', 'settings',
  ];
  if (in_array($path, $reserved, true)) return true;

  $rootFile = __DIR__ . '/../' . $path . '.php';
  $rootDir = __DIR__ . '/../' . $path;
  if (is_file($rootFile) || is_dir($rootDir)) return true;

  $existing = glob(__DIR__ . '/../*.php') ?: [];
  foreach ($existing as $file) {
    $name = strtolower(pathinfo($file, PATHINFO_FILENAME));
    if ($name === $path) return true;
  }
  return false;
}


$err = '';
$ok = '';

$baseUrl = (string)get_setting('license_center_base_url', '');
$publicKey = (string)get_setting('license_center_public_key', '');
$pendingAdminPath = (string)get_setting('pending_admin_path', '');
$lastError = (string)get_setting('license_last_error', '');
$downloadedAt = (string)get_setting('license_blob_downloaded_at', '');

$state = ArcOS\Services\LicenseService::getState();
$tier = strtolower((string)($state['tier'] ?? 'free'));
$status = strtolower((string)($state['status'] ?? 'invalid'));
$features = $state['features'] ?? [];
if (!is_array($features)) $features = [];
$siteId = (string)($state['site_id'] ?? '');
$domainBound = (string)($state['domain_bound'] ?? '');
$expiresAt = (string)($state['expires_at'] ?? '');
$graceUntil = (string)($state['grace_until'] ?? '');
$nextCheckAt = (string)($state['next_check_at'] ?? '');
$lastCheckAt = (string)($state['last_check_at'] ?? '');

$accountTokenEnc = (string)($state['account_token_enc'] ?? '');
$accountTokenSet = $accountTokenEnc !== '';
$accountTokenLast4 = '';
if ($accountTokenSet) {
  $token = ArcOS\Services\Crypto::decrypt($accountTokenEnc);
  if ($token !== '') $accountTokenLast4 = substr($token, -4);
}

$canAdminPath = ArcOS\Services\FeatureGate::enabled('admin_path');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_license', 60, 120);
  try {
    $action = (string)($_POST['action'] ?? '');
    if ($action === 'save_base') {
      $baseUrlIn = trim((string)($_POST['base_url'] ?? ''));
      $keyIn = trim((string)($_POST['public_key'] ?? ''));
      $validated = ArcOS\Services\LicenseApiClient::validateBaseUrl($baseUrlIn);
      if ($baseUrlIn !== '' && $validated === '') {
        throw new RuntimeException('Base URL must be https and not a private address.');
      }
      set_setting('license_center_base_url', $validated);
      set_setting('license_center_public_key', $keyIn);
      $baseUrl = $validated;
      $publicKey = $keyIn;
      $ok = 'License settings saved.';
    } elseif ($action === 'save_account_token') {
      $token = trim((string)($_POST['account_token'] ?? ''));
      ArcOS\Services\LicenseService::saveAccountToken($token);
      $ok = $token !== '' ? 'Account token saved.' : 'Account token cleared.';
    } elseif ($action === 'activate') {
      $licenseKey = trim((string)($_POST['license_key'] ?? ''));
      $accountToken = trim((string)($_POST['account_token'] ?? ''));
      if ($accountToken === '') {
        $enc = (string)($state['account_token_enc'] ?? '');
        if ($enc !== '') {
          $accountToken = ArcOS\Services\Crypto::decrypt($enc);
        }
      }
      if ($licenseKey === '' || $accountToken === '') {
        throw new RuntimeException('License key and account token are required.');
      }
      $res = ArcOS\Services\LicenseService::activate($licenseKey, $accountToken);
      if (!$res['ok']) {
        throw new RuntimeException(($res['error_code'] ?: 'error') . ': ' . ($res['message'] ?: 'Activation failed'));
      }
      $ok = 'License activated.';
    } elseif ($action === 'refresh_now') {
      $res = ArcOS\Services\LicenseService::refreshNow();
      if (!$res['ok']) {
        throw new RuntimeException(($res['error_code'] ?: 'error') . ': ' . ($res['message'] ?: 'Refresh failed'));
      }
      $ok = 'Refresh completed.';
    } elseif ($action === 'status_now') {
      $res = ArcOS\Services\LicenseService::statusNow();
      if (!$res['ok']) {
        throw new RuntimeException(($res['error_code'] ?: 'error') . ': ' . ($res['message'] ?: 'Status failed'));
      }
      $ok = 'Status check completed.';
    } elseif ($action === 'download_now') {
      $res = ArcOS\Services\LicenseService::downloadNow();
      if (!$res['ok']) {
        throw new RuntimeException(($res['error_code'] ?: 'error') . ': ' . ($res['message'] ?: 'Download failed'));
      }
      $ok = 'License blob downloaded.';
    } elseif ($action === 'import_blob') {
      if (empty($_FILES['license_blob']['tmp_name']) || !is_uploaded_file($_FILES['license_blob']['tmp_name'])) {
        throw new RuntimeException('License blob file required.');
      }
      $blob = (string)@file_get_contents($_FILES['license_blob']['tmp_name']);
      $res = ArcOS\Services\LicenseService::importLicenseBlob($blob);
      if (!$res['ok']) {
        throw new RuntimeException(($res['error_code'] ?: 'error') . ': ' . ($res['message'] ?: 'Import failed'));
      }
      $ok = 'License blob imported.';
    } elseif ($action === 'clear_license') {
      ArcOS\Services\LicenseService::clearLicense();
      $ok = 'License cleared.';
    } elseif ($action === 'save_pending_path') {
      $pending = strtolower(trim((string)($_POST['pending_admin_path'] ?? '')));
      if ($pending !== '' && !preg_match('/^[a-z0-9_-]{3,32}$/', $pending)) {
        throw new RuntimeException('Invalid admin path format.');
      }
      set_setting('pending_admin_path', $pending);
      $pendingAdminPath = $pending;
      $ok = 'Pending admin path saved.';
    } elseif ($action === 'apply_admin_path') {
      if (!$canAdminPath) {
        ArcOS\Services\FeatureGate::deny('admin_path');
      }
      $pending = strtolower(trim((string)($_POST['pending_admin_path'] ?? $pendingAdminPath)));
      if ($pending === '' || !preg_match('/^[a-z0-9_-]{3,32}$/', $pending)) {
        throw new RuntimeException('Invalid admin path format.');
      }
      if (arc_admin_path_conflicts($pending)) {
        throw new RuntimeException('Admin path is already in use.');
      }
      $cfgPath = __DIR__ . '/../includes/config.php';
      if (!is_file($cfgPath)) throw new RuntimeException('Config missing.');
      $cfg = require $cfgPath;
      if (!is_array($cfg)) throw new RuntimeException('Config invalid.');
      $oldPath = strtolower(trim((string)($cfg['admin_path'] ?? 'admin')));

      $entryPath = __DIR__ . '/../' . $pending . '.php';
      $entryPhp = arc_build_admin_entry_php();
      if (@file_put_contents($entryPath, $entryPhp, LOCK_EX) === false) {
        throw new RuntimeException('Failed to write admin entry file.');
      }

      $cfg['admin_path'] = $pending;
      $cfgPhp = "<?php\n// Updated by settings_license.php\nreturn " . var_export($cfg, true) . ";\n";
      if (@file_put_contents($cfgPath, $cfgPhp, LOCK_EX) === false) {
        throw new RuntimeException('Failed to update config.php.');
      }

      $disableOld = isset($_POST['disable_old_entry']);
      if ($disableOld && $oldPath !== '' && $oldPath !== 'admin' && $oldPath !== $pending) {
        $oldFile = __DIR__ . '/../' . $oldPath . '.php';
        if (is_file($oldFile)) {
          $renamed = @rename($oldFile, $oldFile . '.disabled');
          if (!$renamed) @unlink($oldFile);
        }
      }

      set_setting('pending_admin_path', '');
      $pendingAdminPath = '';
      $ok = 'Admin path applied.';
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }

  $state = ArcOS\Services\LicenseService::getState();
  $tier = strtolower((string)($state['tier'] ?? 'free'));
  $status = strtolower((string)($state['status'] ?? 'invalid'));
  $features = $state['features'] ?? [];
  if (!is_array($features)) $features = [];
  $siteId = (string)($state['site_id'] ?? '');
  $domainBound = (string)($state['domain_bound'] ?? '');
  $expiresAt = (string)($state['expires_at'] ?? '');
  $graceUntil = (string)($state['grace_until'] ?? '');
  $nextCheckAt = (string)($state['next_check_at'] ?? '');
  $lastCheckAt = (string)($state['last_check_at'] ?? '');
  $accountTokenEnc = (string)($state['account_token_enc'] ?? '');
  $accountTokenSet = $accountTokenEnc !== '';
  $accountTokenLast4 = '';
  if ($accountTokenSet) {
    $token = ArcOS\Services\Crypto::decrypt($accountTokenEnc);
    if ($token !== '') $accountTokenLast4 = substr($token, -4);
  }
}

$featureList = $features ? implode(', ', array_map('strval', $features)) : 'none';
$adminPathActive = function_exists('admin_path_value') ? admin_path_value() : 'admin';
$accountTokenPlaceholder = $accountTokenSet ? ('Saved ****' . $accountTokenLast4) : 'Paste account token';
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1>License Center</h1>
          <div class="sub">Connect this site to your License Center and manage entitlements.</div>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;">Error</div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <?php if ($status === 'grace'): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(234,179,8,.25); background:rgba(234,179,8,.06);">
          <div style="font-weight:650;">Grace period active</div>
          <div class="sub" style="margin-top:6px;">License is in grace. Please renew or refresh before downgrade.</div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">License Center Settings</h2>
        <form method="post" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_base" />
          <label class="label">Base URL (https)</label>
          <input class="input" name="base_url" value="<?= e($baseUrl) ?>" placeholder="https://license.example.com" />
          <label class="label">Public Key</label>
          <textarea class="input" name="public_key" rows="6" placeholder="Paste License Center public key"><?= e($publicKey) ?></textarea>
          <div style="display:flex;justify-content:flex-end;">
            <button class="admin-btn primary" type="submit">Save</button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">Account Token</h2>
        <form method="post" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_account_token" />
          <label class="label">Account Token (stored encrypted)</label>
          <input class="input" name="account_token" placeholder="<?= e($accountTokenPlaceholder) ?>" />
          <div style="display:flex;justify-content:flex-end;">
            <button class="admin-btn" type="submit">Save Token</button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">Activate License</h2>
        <form method="post" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="activate" />
          <label class="label">License Key</label>
          <input class="input" name="license_key" placeholder="XXXX-XXXX-XXXX" />
          <label class="label">Account Token</label>
          <input class="input" name="account_token" placeholder="Paste account token" />
          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn primary" type="submit">Activate</button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">License State</h2>
        <div class="grid" style="gap:12px;">
          <div class="field" style="grid-column: span 6;">
            <div class="label">Site ID</div>
            <div class="input" style="background:#f7f7f7;"><?= e($siteId) ?></div>
          </div>
          <div class="field" style="grid-column: span 6;">
            <div class="label">Domain</div>
            <div class="input" style="background:#f7f7f7;"><?= e($domainBound) ?></div>
          </div>
          <div class="field" style="grid-column: span 4;">
            <div class="label">Tier</div>
            <div class="input" style="background:#f7f7f7;"><?= e($tier) ?></div>
          </div>
          <div class="field" style="grid-column: span 4;">
            <div class="label">Status</div>
            <div class="input" style="background:#f7f7f7;"><?= e($status) ?></div>
          </div>
          <div class="field" style="grid-column: span 4;">
            <div class="label">Features</div>
            <div class="input" style="background:#f7f7f7;"><?= e($featureList) ?></div>
          </div>
          <div class="field" style="grid-column: span 6;">
            <div class="label">Expires At</div>
            <div class="input" style="background:#f7f7f7;"><?= e($expiresAt) ?></div>
          </div>
          <div class="field" style="grid-column: span 6;">
            <div class="label">Grace Until</div>
            <div class="input" style="background:#f7f7f7;"><?= e($graceUntil) ?></div>
          </div>
          <div class="field" style="grid-column: span 6;">
            <div class="label">Next Check At</div>
            <div class="input" style="background:#f7f7f7;"><?= e($nextCheckAt) ?></div>
          </div>
          <div class="field" style="grid-column: span 6;">
            <div class="label">Last Check At</div>
            <div class="input" style="background:#f7f7f7;"><?= e($lastCheckAt) ?></div>
          </div>
          <div class="field" style="grid-column: span 12;">
            <div class="label">Last Error</div>
            <div class="input" style="background:#f7f7f7;"><?= e($lastError) ?></div>
          </div>
          <div class="field" style="grid-column: span 12;">
            <div class="label">Blob Downloaded At</div>
            <div class="input" style="background:#f7f7f7;"><?= e($downloadedAt) ?></div>
          </div>
        </div>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">Manual Actions</h2>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="refresh_now" />
            <button class="admin-btn" type="submit">Refresh</button>
          </form>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="status_now" />
            <button class="admin-btn" type="submit">Status</button>
          </form>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="download_now" />
            <button class="admin-btn" type="submit">Download Blob</button>
          </form>
          <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="import_blob" />
            <input class="input" type="file" name="license_blob" />
            <button class="admin-btn" type="submit">Import Blob</button>
          </form>
          <form method="post" onsubmit="return confirm('Clear license and downgrade to Free?');">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="clear_license" />
            <button class="admin-btn" type="submit">Clear License</button>
          </form>
        </div>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 12px 0;">Admin Path</h2>
        <div class="sub">Active: <strong><?= e($adminPathActive) ?></strong></div>
        <form method="post" style="display:grid;gap:10px;margin-top:10px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_pending_path" />
          <label class="label">Pending Admin Path</label>
          <input class="input" name="pending_admin_path" value="<?= e($pendingAdminPath) ?>" placeholder="e.g. admincp" />
          <div style="display:flex;justify-content:flex-end;">
            <button class="admin-btn" type="submit">Save Pending</button>
          </div>
        </form>

        <form method="post" style="display:grid;gap:10px;margin-top:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="apply_admin_path" />
          <input type="hidden" name="pending_admin_path" value="<?= e($pendingAdminPath) ?>" />
          <label class="check"><input type="checkbox" name="disable_old_entry" checked /> <span>Disable old entry file after applying</span></label>
          <?php if ($canAdminPath): ?>
            <div style="display:flex;justify-content:flex-end;">
              <button class="admin-btn primary" type="submit">Apply Admin Path</button>
            </div>
          <?php else: ?>
            <div class="note">Custom admin path is available in Pro/Business.</div>
          <?php endif; ?>
        </form>
      </div>
    </main>
  </div>
</body>
</html>
