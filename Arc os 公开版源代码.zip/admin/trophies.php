<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$pdo = db();
$pfx = table_prefix();

$title = t('trophies');
$active = 'trophies';
$__need_editor = true;

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_post();
  require_csrf();
  arc_rate_limit('admin_trophies', 120, 300);

  $tTitle = trim((string)($_POST['title'] ?? ''));
  $desc = trim((string)($_POST['description'] ?? ''));
  $pts = (int)($_POST['points'] ?? 0);
  if ($tTitle === '') {
    $err = t('fill_all');
  } else {
    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}trophies (title, description, points, created_at) VALUES (?,?,?,NOW())");
      $stmt->execute([$tTitle, $desc !== '' ? $desc : null, $pts]);
      redirect(function_exists('admin_url') ? admin_url('trophies') : url('admin/trophies.php'));
    } catch (Throwable $e) {
      $err = t('save_failed');
    }
  }
}

$rows = [];
try {
  $rows = $pdo->query("SELECT * FROM {$pfx}trophies ORDER BY points DESC, id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $rows = [];
}

$langCode = lang();
require_once __DIR__ . '/../includes/services/BbCode.php';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('trophies')) ?></h1>
          <div class="sub"><?= e(t('trophies_sub')) ?></div>
        </div>
      </div>

      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade">
        <form method="post" style="display:grid;gap:12px;" data-overlay="1">
          <?= csrf_field() ?>
          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-6">
              <label class="label"><?= e(t('title')) ?></label>
              <input class="input" name="title" />
            </div>
            <div class="admin-col-3">
              <label class="label"><?= e(t('points')) ?></label>
              <input class="input" name="points" type="number" value="0" />
            </div>
            <div class="admin-col-12">
              <label class="label"><?= e(t('description')) ?></label>
              <?php
                $content_name = 'description';
                $initial_value = '';
                $mode = 'admin_note';
                $placeholder = t('description');
                $attachments_enabled = false;
                $mentions_enabled = false;
                $tags_enabled = false;
                $full_screen_enabled = false;
                $min_height = 120;
                include __DIR__ . '/../partials/editor/editor_widget.php';
              ?>
            </div>
          </div>
          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn" type="submit"><?= e(t('create')) ?></button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div style="overflow:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th><?= e(t('title')) ?></th>
                <th><?= e(t('points')) ?></th>
                <th><?= e(t('description')) ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rows as $t): ?>
                <tr>
                  <td style="font-weight:700;min-width:220px;"><?= e((string)$t['title']) ?></td>
                  <td><?= (int)$t['points'] ?></td>
                  <td style="color:var(--admin-muted);">
                    <?= ArcOS\Services\BbCode::render((string)($t['description'] ?? ''), $pdo, $pfx) ?>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$rows): ?>
                <tr><td colspan="3" style="color:var(--admin-muted);"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
