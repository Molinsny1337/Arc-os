<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/init.php';
require_installed();
require_admin();

require_once __DIR__ . '/../../includes/services/AnalyticsService.php';

$range = (string)($_GET['range'] ?? 'today');
$pdo = db();
$pfx = table_prefix();

$data = ArcOS\Services\AnalyticsService::timeseries($pdo, $pfx, $range);

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'range' => $range, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
