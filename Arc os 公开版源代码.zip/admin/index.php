<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

require_once __DIR__ . '/../includes/services/AnalyticsService.php';

$title = t('admin') . ' ? ' . t('dashboard');
$pdo = db();
$pfx = table_prefix();
$canModeration = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('moderation') : false;

$stats = ArcOS\Services\AnalyticsService::summarizeToday($pdo, $pfx);

$pendingThreads = 0;
$openReports = 0;
$latestThreads = [];
$latestUsers = [];
$latestReports = [];

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE type='forum' AND status='draft' AND (review_state='pending' OR review_state IS NULL)");
  $stmt->execute();
  $pendingThreads = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}

try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_reports WHERE status='open'");
  $stmt->execute();
  $openReports = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}

try {
  $latestThreads = $pdo->query("SELECT p.id, p.title, p.slug, p.created_at, p.reply_count, f.title AS forum_title, u.username AS author
    FROM {$pfx}posts p
    LEFT JOIN {$pfx}forums f ON f.id=p.forum_id
    LEFT JOIN {$pfx}users u ON u.id=p.author_id
    WHERE p.type='forum' AND p.status='published' AND p.is_deleted=0
    ORDER BY p.created_at DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $latestUsers = $pdo->query("SELECT id, username, email, created_at FROM {$pfx}users ORDER BY id DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

try {
  $latestReports = $pdo->query("SELECT id, content_type, content_id, reason, created_at
    FROM {$pfx}xf_reports WHERE status='open' ORDER BY created_at DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$layoutItems = arc_get_layout_setting_items('admin_dashboard_layout', arc_admin_dashboard_layout_default_items(), arc_admin_dashboard_layout_allowed_ids());
$__need_ui_layout = true;
$active = 'dashboard';
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
  <?php include __DIR__ . '/../partials/head.php'; ?>
  <?php $__charts_css_v = @filemtime(__DIR__ . '/../assets/admin_charts.css') ?: 1; ?>
  <link rel="stylesheet" href="<?= e(url('assets/admin_charts.css?v=' . $__charts_css_v)) ?>" />
</head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <?php
      $layoutDefault = json_encode(arc_admin_dashboard_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($layoutDefault)) $layoutDefault = '[]';
      $layoutLabels = [];
      foreach (arc_admin_dashboard_layout_allowed_ids() as $id) $layoutLabels[$id] = t('block_' . $id);
      $layoutLabelsJson = json_encode($layoutLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($layoutLabelsJson)) $layoutLabelsJson = '{}';
      $layoutUi = [
        'edit' => t('layout_edit'),
        'done' => t('layout_done'),
        'reset' => t('reset'),
        'blocks' => t('layout_blocks'),
        'saved' => t('layout_saved'),
        'save_failed' => t('layout_save_failed'),
        'hide' => t('hide'),
        'show' => t('show'),
      ];
      $layoutUiJson = json_encode($layoutUi, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($layoutUiJson)) $layoutUiJson = '{}';
    ?>

    <main class="admin-main"
      data-arc-layout-root="1"
      data-arc-can-edit="1"
      data-arc-layout-scope="admin_dashboard_global"
      data-arc-save-url="<?= e(url('layout_save.php')) ?>"
      data-arc-csrf="<?= e(csrf_token()) ?>"
      data-arc-default="<?= e($layoutDefault) ?>"
      data-arc-labels="<?= e($layoutLabelsJson) ?>"
      data-arc-ui="<?= e($layoutUiJson) ?>"
    >
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('dashboard')) ?></h1>
          <div class="sub">Forum health and activity overview.</div>
        </div>
        <div class="admin-actions">
          <?php if ($canModeration): ?>
            <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('review_center') : url('admin/review_center.php')) ?>">Review Center</a>
          <?php endif; ?>
          <a class="admin-btn primary" href="<?= e(url('forum_new.php')) ?>">New Thread</a>
        </div>
      </div>

      <?php foreach ($layoutItems as $it):
        $sid = (string)($it['id'] ?? '');
        $enabled = (bool)($it['enabled'] ?? true);
        if ($sid === '') continue;
      ?>
        <?php if ($sid === 'kpis'): ?>
          <div data-arc-layout-item="1" data-id="kpis" <?= $enabled ? '' : 'hidden' ?> style="margin-top:12px">
            <section class="admin-grid">
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">PV Today</div>
                <div class="v"><?= (int)($stats['pv'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">UV Today</div>
                <div class="v"><?= (int)($stats['uv'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Registrations</div>
                <div class="v"><?= (int)($stats['registrations'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Active Users</div>
                <div class="v"><?= (int)($stats['active_users'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Threads Today</div>
                <div class="v"><?= (int)($stats['threads'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Replies Today</div>
                <div class="v"><?= (int)($stats['replies'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Online (5m)</div>
                <div class="v"><?= (int)($stats['online'] ?? 0) ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Open Reports</div>
                <div class="v"><?= (int)$openReports ?></div>
              </div>
              <div class="admin-card admin-kpi admin-col-3 admin-fade">
                <div class="k">Pending Threads</div>
                <div class="v"><?= (int)$pendingThreads ?></div>
              </div>
            </section>

            <section class="admin-grid" style="margin-top:12px">
              <div class="admin-card pad admin-col-8 admin-fade">
                <div class="admin-chart-head">
                  <div>
                    <div class="title">Traffic</div>
                    <div class="sub">PV / UV</div>
                  </div>
                  <div class="admin-chart-range" data-chart-range>
                    <button class="admin-btn" data-range="today">24h</button>
                    <button class="admin-btn" data-range="7d">7d</button>
                    <button class="admin-btn" data-range="30d">30d</button>
                  </div>
                </div>
                <canvas class="admin-chart" data-chart="traffic" height="200"></canvas>
              </div>
              <div class="admin-card pad admin-col-4 admin-fade">
                <div class="admin-chart-head">
                  <div>
                    <div class="title">Threads / Replies</div>
                    <div class="sub">Posts activity</div>
                  </div>
                </div>
                <canvas class="admin-chart" data-chart="posts" height="200"></canvas>
              </div>
              <div class="admin-card pad admin-col-6 admin-fade">
                <div class="admin-chart-head">
                  <div>
                    <div class="title">Route Breakdown</div>
                    <div class="sub">Top pages</div>
                  </div>
                </div>
                <div class="admin-route-list" data-chart="routes"></div>
              </div>
            </section>
          </div>
        <?php elseif ($sid === 'latest_posts'): ?>
          <div data-arc-layout-item="1" data-id="latest_posts" <?= $enabled ? '' : 'hidden' ?> style="margin-top:12px">
            <section class="admin-grid">
              <div class="admin-card pad admin-col-12 admin-fade">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
                  <div style="font-weight:650;">Latest Threads</div>
                  <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('posts') : url('admin/posts.php')) ?>">Manage</a>
                </div>
                <div style="margin-top:10px;overflow:auto;">
                  <table class="admin-table">
                    <thead>
                      <tr>
                        <th style="min-width:260px;">Title</th>
                        <th>Forum</th>
                        <th>Replies</th>
                        <th style="min-width:180px;">Created</th>
                        <th style="width:1%;">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($latestThreads as $t): ?>
                        <tr>
                          <td><?= e((string)($t['title'] ?? '')) ?></td>
                          <td><?= e((string)($t['forum_title'] ?? '')) ?></td>
                          <td><?= (int)($t['reply_count'] ?? 0) ?></td>
                          <td><?= e((string)($t['created_at'] ?? '')) ?></td>
                          <td><a class="admin-btn" href="<?= e(url('forum_post.php?slug=' . urlencode((string)($t['slug'] ?? '')))) ?>">View</a></td>
                        </tr>
                      <?php endforeach; ?>
                      <?php if (!$latestThreads): ?>
                        <tr><td colspan="5" style="color:var(--admin-muted);">No data</td></tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            <section class="admin-grid" style="margin-top:12px">
              <div class="admin-card pad admin-col-6 admin-fade">
                <div style="font-weight:650;">Latest Users</div>
                <div style="margin-top:10px;overflow:auto;">
                  <table class="admin-table">
                    <thead>
                      <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Joined</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($latestUsers as $u): ?>
                        <tr>
                          <td><?= e((string)($u['username'] ?? '')) ?></td>
                          <td><?= e((string)($u['email'] ?? '')) ?></td>
                          <td><?= e((string)($u['created_at'] ?? '')) ?></td>
                        </tr>
                      <?php endforeach; ?>
                      <?php if (!$latestUsers): ?>
                        <tr><td colspan="3" style="color:var(--admin-muted);">No data</td></tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="admin-card pad admin-col-6 admin-fade">
                <div style="font-weight:650;">Open Reports</div>
                <div style="margin-top:10px;overflow:auto;">
                  <table class="admin-table">
                    <thead>
                      <tr>
                        <th>Type</th>
                        <th>Reason</th>
                        <th>Created</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($latestReports as $r): ?>
                        <tr>
                          <td><?= e((string)($r['content_type'] ?? '')) ?></td>
                          <td><?= e((string)($r['reason'] ?? '')) ?></td>
                          <td><?= e((string)($r['created_at'] ?? '')) ?></td>
                        </tr>
                      <?php endforeach; ?>
                      <?php if (!$latestReports): ?>
                        <tr><td colspan="3" style="color:var(--admin-muted);">No data</td></tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          </div>
        <?php elseif ($sid === 'quick_links'): ?>
          <div data-arc-layout-item="1" data-id="quick_links" <?= $enabled ? '' : 'hidden' ?> style="margin-top:12px">
            <div class="admin-card pad admin-fade">
              <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('links') : url('admin/links.php')) ?>">Edit navigation</a>
                <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('users') : url('admin/users.php')) ?>">User approvals</a>
                <?php if ($canModeration): ?>
                  <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('review_center') : url('admin/review_center.php')) ?>">Review center</a>
                <?php endif; ?>
                <a class="admin-btn" href="<?= e(url('index.php')) ?>" data-transition="off">Open site</a>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <?php $__charts_js_v = @filemtime(__DIR__ . '/../assets/admin_charts.js') ?: 1; ?>
  <script defer src="<?= e(url('assets/admin_charts.js?v=' . $__charts_js_v)) ?>"></script>
</body>
</html>
