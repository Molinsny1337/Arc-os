<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' - ' . t('upgrade');
$pdo = db();
$pfx = table_prefix();
$log = [];

function col_exists(PDO $pdo, string $table, string $col): bool {
  $stmt = $pdo->prepare("SHOW COLUMNS FROM {$table} LIKE ?");
  $stmt->execute([$col]);
  return (bool)$stmt->fetch();
}

try {
  // users table
  $usersTable = $pfx . 'users';
  if (!col_exists($pdo, $usersTable, 'email')) {
    $pdo->exec("ALTER TABLE {$usersTable} ADD COLUMN email VARCHAR(191) NOT NULL DEFAULT '' AFTER username");
    $log[] = "Added users.email";
  }
  if (!col_exists($pdo, $usersTable, 'is_verified')) {
    $pdo->exec("ALTER TABLE {$usersTable} ADD COLUMN is_verified TINYINT(1) NOT NULL DEFAULT 0 AFTER role");
    $log[] = "Added users.is_verified";
  }
  if (!col_exists($pdo, $usersTable, 'verify_token')) {
    $pdo->exec("ALTER TABLE {$usersTable} ADD COLUMN verify_token VARCHAR(64) NULL AFTER is_verified");
    $log[] = "Added users.verify_token";
  }
  if (!col_exists($pdo, $usersTable, 'can_post')) {
    $pdo->exec("ALTER TABLE {$usersTable} ADD COLUMN can_post TINYINT(1) NOT NULL DEFAULT 0 AFTER verify_token");
    $log[] = "Added users.can_post";
  }

  // posts table
  $postsTable = $pfx . 'posts';
  if (!col_exists($pdo, $postsTable, 'author_id')) {
    $pdo->exec("ALTER TABLE {$postsTable} ADD COLUMN author_id INT UNSIGNED NULL FIRST");
    $log[] = "Added posts.author_id";
  }
  if (!col_exists($pdo, $postsTable, 'type')) {
    $pdo->exec("ALTER TABLE {$postsTable} ADD COLUMN type VARCHAR(16) NOT NULL DEFAULT 'forum' AFTER author_id");
    $log[] = "Added posts.type";
  }
  // slug length reduce (if still 255)
  $stmt = $pdo->query("SHOW COLUMNS FROM {$postsTable} LIKE 'slug'")->fetch();
  if ($stmt && preg_match('/varchar\((\d+)\)/i', (string)$stmt['Type'], $m)) {
    $len = (int)$m[1];
    if ($len > 191) {
      $pdo->exec("ALTER TABLE {$postsTable} MODIFY slug VARCHAR(191) NOT NULL");
      $log[] = "Modified posts.slug to VARCHAR(191)";
    }
  }

  // settings table
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$pfx}settings (
    k VARCHAR(64) NOT NULL,
    v TEXT NULL,
    PRIMARY KEY (k)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  $log[] = "Ensured settings table";

  // defaults
  $pdo->prepare("INSERT INTO {$pfx}settings (k,v) VALUES ('require_email_verification','1') ON DUPLICATE KEY UPDATE v=v")->execute();
  $pdo->prepare("INSERT INTO {$pfx}settings (k,v) VALUES ('require_admin_approval','1') ON DUPLICATE KEY UPDATE v=v")->execute();
  $log[] = "Ensured default settings";

} catch (Throwable $e) {
  $log[] = "ERROR: " . $e->getMessage();
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <main class="wrap" style="padding-top:40px;padding-bottom:80px;">
    <div class="admin-card pad admin-fade" style="max-width:820px;margin:0 auto;">
      <div style="font-weight:750;font-size:18px;letter-spacing:-.01em;">Upgrade</div>
      <div class="note">用于已安装旧版本的数据库升级（新装不需要）。</div>

      <ul>
        <?php foreach ($log as $l): ?>
          <li><?= e($l) ?></li>
        <?php endforeach; ?>
      </ul>

      <div style="margin-top:10px;">
        <a class="admin-btn primary" href="<?= e(function_exists('admin_url') ? admin_url('index') : url('admin/index.php')) ?>"><?= e(t('back')) ?></a>
      </div>
    </div>
  </main>

  <script src="<?= e('assets/admin.js') ?>"></script>
</body>
</html>
