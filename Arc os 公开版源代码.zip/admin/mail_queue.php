<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();
$canMail = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('mail') : false;
if (!$canMail) {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && class_exists('ArcOS\\Services\\FeatureGate')) {
    ArcOS\Services\FeatureGate::deny('mail');
  }
  http_response_code(403);
  $title = t('admin') . ' · ' . (t('mail_queue') !== 'mail_queue' ? t('mail_queue') : 'Mail queue');
  $active = 'mail_queue';
  ?>
  <!doctype html>
  <html lang="<?= e(lang()) ?>">
  <head><?php include __DIR__ . '/../partials/head.php'; ?></head>
  <body class="admin">
    <?php include __DIR__ . '/../partials/nav.php'; ?>
    <div class="admin-shell">
      <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>
      <main class="admin-main">
        <div class="admin-card pad" style="margin-top:14px;">
          <div style="font-weight:700;">Mail is a Pro/Business feature.</div>
          <div class="sub" style="margin-top:6px;">Activate a license to enable mail queue tools.</div>
        </div>
      </main>
    </div>
  </body>
  </html>
  <?php
  exit;
}
require_once __DIR__ . '/../includes/services/MailService.php';

$title = t('admin') . ' · ' . (t('mail_queue') !== 'mail_queue' ? t('mail_queue') : 'Mail queue');
$active = 'mail_queue';
$pdo = db();
$pfx = table_prefix();

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_mail_queue', 120, 300);
  try {
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'send_now') {
      $res = ArcOS\Services\MailService::sendQueued($pdo, $pfx, 20);
      $msg = 'Sent: ' . (int)$res['sent'] . ' / Failed: ' . (int)$res['failed'];
    } elseif ($action === 'retry' && $id > 0) {
      $stmt = $pdo->prepare("UPDATE {$pfx}xf_mail_queue SET status='pending', attempts=0, last_error=NULL, next_attempt_at=NULL WHERE id=?");
      $stmt->execute([$id]);
      $msg = 'Queued for retry.';
    } elseif ($action === 'delete' && $id > 0) {
      $stmt = $pdo->prepare("DELETE FROM {$pfx}xf_mail_queue WHERE id=?");
      $stmt->execute([$id]);
      $msg = 'Deleted.';
    } elseif ($action === 'clear_failed') {
      $pdo->exec("DELETE FROM {$pfx}xf_mail_queue WHERE status='failed'");
      $msg = 'Failed entries cleared.';
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$status = (string)($_GET['status'] ?? 'pending');
if (!in_array($status, ['pending','failed','sent','all'], true)) $status = 'pending';

$where = '';
$params = [];
if ($status !== 'all') {
  $where = "WHERE status=?";
  $params[] = $status;
}

$counts = ['pending' => 0, 'failed' => 0, 'sent' => 0];
try {
  $rows = $pdo->query("SELECT status, COUNT(*) c FROM {$pfx}xf_mail_queue GROUP BY status")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rows as $r) {
    $counts[(string)($r['status'] ?? '')] = (int)($r['c'] ?? 0);
  }
} catch (Throwable $e) {}

$queue = [];
try {
  $stmt = $pdo->prepare("SELECT id, to_email, subject, status, attempts, last_error, created_at, sent_at
    FROM {$pfx}xf_mail_queue {$where}
    ORDER BY created_at DESC
    LIMIT 200");
  $stmt->execute($params);
  $queue = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $queue = [];
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('mail_queue') !== 'mail_queue' ? t('mail_queue') : 'Mail queue') ?></h1>
          <div class="sub">Pending: <?= (int)$counts['pending'] ?> · Failed: <?= (int)$counts['failed'] ?> · Sent: <?= (int)$counts['sent'] ?></div>
        </div>
        <div class="admin-actions">
          <form method="post" style="margin:0;display:inline-flex;gap:8px;">
            <?= csrf_field() ?>
            <button class="admin-btn" type="submit" name="action" value="send_now">Run worker</button>
            <button class="admin-btn ghost" type="submit" name="action" value="clear_failed">Clear failed</button>
          </form>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>
      <?php if ($msg): ?><div class="admin-card pad admin-fade"><?= e($msg) ?></div><?php endif; ?>

      <div class="admin-fade" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
        <a class="admin-btn <?= $status==='pending'?'primary':'' ?>" href="<?= e(url('admin/mail_queue.php?status=pending')) ?>">Pending</a>
        <a class="admin-btn <?= $status==='failed'?'primary':'' ?>" href="<?= e(url('admin/mail_queue.php?status=failed')) ?>">Failed</a>
        <a class="admin-btn <?= $status==='sent'?'primary':'' ?>" href="<?= e(url('admin/mail_queue.php?status=sent')) ?>">Sent</a>
        <a class="admin-btn <?= $status==='all'?'primary':'' ?>" href="<?= e(url('admin/mail_queue.php?status=all')) ?>">All</a>
      </div>

      <div class="admin-card pad admin-fade">
        <div style="overflow:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th><?= e(t('email')) ?></th>
                <th><?= e(t('subject')) ?></th>
                <th><?= e(t('status')) ?></th>
                <th><?= e(t('attempts')) ?></th>
                <th><?= e(t('created')) ?></th>
                <th><?= e(t('actions')) ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($queue as $row): ?>
                <tr>
                  <td><?= (int)($row['id'] ?? 0) ?></td>
                  <td><?= e((string)($row['to_email'] ?? '')) ?></td>
                  <td><?= e((string)($row['subject'] ?? '')) ?></td>
                  <td><?= e((string)($row['status'] ?? '')) ?></td>
                  <td><?= (int)($row['attempts'] ?? 0) ?></td>
                  <td><?= e((string)($row['created_at'] ?? '')) ?></td>
                  <td>
                    <form method="post" style="display:inline-flex;gap:6px;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
                      <button class="admin-btn ghost" type="submit" name="action" value="retry">Retry</button>
                      <button class="admin-btn ghost" type="submit" name="action" value="delete">Delete</button>
                    </form>
                  </td>
                </tr>
                <?php if (!empty($row['last_error'])): ?>
                  <tr>
                    <td></td>
                    <td colspan="6" style="color:var(--admin-muted);"><?= e((string)$row['last_error']) ?></td>
                  </tr>
                <?php endif; ?>
              <?php endforeach; ?>
              <?php if (!$queue): ?>
                <tr><td colspan="7" style="color:var(--admin-muted);"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e(url('assets/admin.js')) ?>"></script>
</body>
</html>
