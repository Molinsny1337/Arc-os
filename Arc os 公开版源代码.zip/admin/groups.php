<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('groups');
$active = 'groups';

$pdo = db();
$pfx = table_prefix();
$tG = $pfx . 'groups';
$tUG = $pfx . 'user_groups';

$ok = '';
$err = '';

function arc_group_slug_valid(string $slug): bool {
  return (bool)preg_match('/^[a-z0-9_-]{2,64}$/i', $slug);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_groups', 120, 60);
  try {
    require_superadmin();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'create') {
      $slug = trim((string)($_POST['slug'] ?? ''));
      $name = trim((string)($_POST['name'] ?? ''));
      $isPaid = isset($_POST['is_paid']) ? 1 : 0;
      if ($slug === '' || $name === '') throw new RuntimeException(t('fill_all'));
      if (!arc_group_slug_valid($slug)) throw new RuntimeException(t('group_slug_invalid'));
      if (mb_strlen($name, 'UTF-8') > 191) $name = mb_substr($name, 0, 191, 'UTF-8');

      $stmt = $pdo->prepare("INSERT INTO {$tG} (slug, name, is_paid, created_at, updated_at) VALUES (?,?,?,?,?)");
      $now = now_utc();
      $stmt->execute([$slug, $name, $isPaid, $now, $now]);
      $ok = t('saved');
    } elseif ($action === 'update') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) throw new RuntimeException(t('bad_group_id'));
      $slug = trim((string)($_POST['slug'] ?? ''));
      $name = trim((string)($_POST['name'] ?? ''));
      $isPaid = isset($_POST['is_paid']) ? 1 : 0;
      if ($slug === '' || $name === '') throw new RuntimeException(t('fill_all'));
      if (!arc_group_slug_valid($slug)) throw new RuntimeException(t('group_slug_invalid'));
      if (mb_strlen($name, 'UTF-8') > 191) $name = mb_substr($name, 0, 191, 'UTF-8');

      $stmt = $pdo->prepare("UPDATE {$tG} SET slug=?, name=?, is_paid=?, updated_at=? WHERE id=?");
      $stmt->execute([$slug, $name, $isPaid, now_utc(), $id]);
      $ok = t('saved');
    } elseif ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) throw new RuntimeException(t('bad_group_id'));

      $pdo->beginTransaction();
      try {
        $pdo->prepare("DELETE FROM {$tUG} WHERE group_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM {$tG} WHERE id=?")->execute([$id]);
        $pdo->commit();
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
      }
      $ok = t('saved');
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

// list groups
$groups = [];
try {
  $groups = $pdo->query("SELECT g.id, g.slug, g.name, g.is_paid,
      (SELECT COUNT(*) FROM {$tUG} ug WHERE ug.group_id = g.id) AS members
    FROM {$tG} g
    ORDER BY g.is_paid DESC, g.name ASC, g.id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $groups = [];
}

$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('groups')) ?></h1>
          <div class="sub"><?= e(t('groups_sub')) ?></div>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div style="font-weight:700;margin-bottom:10px;"><?= e(t('create_group')) ?></div>
        <form method="post" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="create" />

          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-4">
              <label class="label"><?= e(t('slug')) ?></label>
              <input class="input" name="slug" placeholder="paid" />
              <div class="note"><?= e(t('group_slug_hint')) ?></div>
            </div>
            <div class="admin-col-6">
              <label class="label"><?= e(t('name')) ?></label>
              <input class="input" name="name" placeholder="<?= e(t('paid')) ?>" />
            </div>
            <div class="admin-col-2" style="display:flex;align-items:flex-end;">
              <label style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="is_paid" />
                <span><?= e(t('paid')) ?></span>
              </label>
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div style="font-weight:700;margin-bottom:10px;"><?= e(t('existing_groups')) ?></div>
        <div style="overflow:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th style="width:1%;"><?= e(t('id')) ?></th>
                <th><?= e(t('slug')) ?></th>
                <th><?= e(t('name')) ?></th>
                <th style="width:1%;"><?= e(t('paid')) ?></th>
                <th style="width:1%;"><?= e(t('members')) ?></th>
                <th style="width:1%;"><?= e(t('actions')) ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($groups as $g): ?>
                <tr>
                  <td><?= (int)($g['id'] ?? 0) ?></td>
                  <td colspan="5">
                    <form method="post" style="display:grid;gap:10px;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)($g['id'] ?? 0) ?>" />

                      <div class="admin-grid" style="gap:10px;">
                        <div class="admin-col-4">
                          <input class="input" name="slug" value="<?= e((string)($g['slug'] ?? '')) ?>" />
                        </div>
                        <div class="admin-col-6">
                          <input class="input" name="name" value="<?= e((string)($g['name'] ?? '')) ?>" />
                        </div>
                        <div class="admin-col-2" style="display:flex;align-items:center;gap:10px;">
                          <label style="display:flex;gap:10px;align-items:center;margin:0;">
                            <input type="checkbox" name="is_paid" <?= ((int)($g['is_paid'] ?? 0) === 1) ? 'checked' : '' ?> />
                            <span><?= e(t('paid')) ?></span>
                          </label>
                        </div>
                      </div>

                      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
                        <div class="note" style="margin:0;">
                          <?= e(t('members')) ?>: <?= (int)($g['members'] ?? 0) ?>
                        </div>
                        <div style="display:flex;gap:10px;">
                          <button class="admin-btn" type="submit" name="action" value="update"><?= e(t('save')) ?></button>
                          <button class="admin-btn" type="submit" name="action" value="delete" onclick="return confirm(<?= json_encode(t('delete_group_confirm')) ?>);"><?= e(t('delete')) ?></button>
                        </div>
                      </div>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$groups): ?>
                <tr><td colspan="6" class="muted"><?= e(t('no_groups_yet')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="note" style="margin-top:10px;"><?= e(t('groups_superadmin_only')) ?></div>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
