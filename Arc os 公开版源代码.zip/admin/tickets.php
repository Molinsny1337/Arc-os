<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' · ' . t('tickets');
$active = 'tickets';
$__need_editor = true;
$__need_glass = true;
require_once __DIR__ . '/../includes/services/BbCode.php';

$pdo = db();
$pfx = table_prefix();
$err = '';

$ticketId = (int)($_GET['id'] ?? 0);

if ($ticketId > 0) {
  $st = $pdo->prepare("SELECT t.*, u.username AS ticket_username
    FROM {$pfx}tickets t
    LEFT JOIN {$pfx}users u ON u.id = t.user_id
    WHERE t.id=? LIMIT 1");
  $st->execute([$ticketId]);
  $ticket = $st->fetch(PDO::FETCH_ASSOC) ?: null;
  if (!$ticket) {
    http_response_code(404);
    exit(e(t('ticket_not_found')));
  }

  if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    require_csrf();
    arc_rate_limit('admin_ticket_' . $ticketId, 200, 300);
    try {
      $action = (string)($_POST['action'] ?? '');
      $me = current_user();
      $staffId = $me ? (int)$me['id'] : null;

      if ($action === 'reply') {
        $msg = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
        if (($ticket['status'] ?? 'open') === 'closed') {
          arc_ticket_set_status($ticketId, 'open', $staffId);
          arc_log('ticket_reopen', 'ticket', $ticketId, ['by' => 'admin']);
        }
        arc_ticket_add_message($ticketId, $staffId, true, $msg);
        arc_log('ticket_reply', 'ticket', $ticketId, ['by' => 'admin']);
        redirect(function_exists('admin_url') ? admin_url('tickets', ['id' => $ticketId]) : url('admin/tickets.php?id=' . $ticketId));
      }

      if ($action === 'close') {
        arc_ticket_set_status($ticketId, 'closed', $staffId);
        arc_log('ticket_close', 'ticket', $ticketId, ['by' => 'admin']);
        redirect(function_exists('admin_url') ? admin_url('tickets', ['id' => $ticketId]) : url('admin/tickets.php?id=' . $ticketId));
      }

      if ($action === 'reopen') {
        arc_ticket_set_status($ticketId, 'open', $staffId);
        arc_log('ticket_reopen', 'ticket', $ticketId, ['by' => 'admin']);
        redirect(function_exists('admin_url') ? admin_url('tickets', ['id' => $ticketId]) : url('admin/tickets.php?id=' . $ticketId));
      }

      throw new RuntimeException('Bad action.');
    } catch (Throwable $e) {
      $err = $e->getMessage();
    }
  }

  // reload after mutations
  $st->execute([$ticketId]);
  $ticket = $st->fetch(PDO::FETCH_ASSOC) ?: $ticket;
  $messages = arc_ticket_messages($ticketId);
  $status = (string)($ticket['status'] ?? 'open');
} else {
  $status = (string)($_GET['status'] ?? 'open');
  if (!in_array($status, ['open', 'closed', 'all'], true)) $status = 'open';
  $qStatus = $status === 'all' ? null : $status;
  $data = arc_admin_ticket_list($qStatus, 120, 0);
  $tickets = $data['items'] ?? [];
  $total = (int)($data['total'] ?? 0);
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('tickets')) ?></h1>
          <div class="sub"><?= e(t('tickets_admin_sub')) ?></div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
          <a class="admin-btn <?= $ticketId <= 0 && $status === 'open' ? 'primary' : '' ?>" href="<?= e(function_exists('admin_url') ? admin_url('tickets', ['status' => 'open']) : url('admin/tickets.php?status=open')) ?>"><?= e(t('status_open')) ?></a>
          <a class="admin-btn <?= $ticketId <= 0 && $status === 'closed' ? 'primary' : '' ?>" href="<?= e(function_exists('admin_url') ? admin_url('tickets', ['status' => 'closed']) : url('admin/tickets.php?status=closed')) ?>"><?= e(t('status_closed')) ?></a>
          <a class="admin-btn <?= $ticketId <= 0 && $status === 'all' ? 'primary' : '' ?>" href="<?= e(function_exists('admin_url') ? admin_url('tickets', ['status' => 'all']) : url('admin/tickets.php?status=all')) ?>"><?= e(t('all')) ?></a>
        </div>
      </div>

      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650; color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px; color:#7f1d1d;"><?= e($err) ?></div>
        </div>
        <div style="height:12px;"></div>
      <?php endif; ?>

      <?php if ($ticketId > 0): ?>
        <div class="admin-card pad admin-fade">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
            <div>
              <div style="font-weight:800;"><?= e(t('ticket')) ?> #<?= (int)$ticketId ?></div>
              <div class="sub" style="margin-top:6px;">
                <?= e((string)($ticket['subject'] ?? '')) ?>
                · <?= e(t('user')) ?>: <?= e((string)($ticket['ticket_username'] ?? '')) ?> (#<?= (int)($ticket['user_id'] ?? 0) ?>)
              </div>
            </div>
            <div style="display:flex;gap:10px;align-items:center;">
              <span class="admin-badge <?= $status === 'open' ? 'pub' : '' ?>"><?= e($status === 'open' ? t('status_open') : t('status_closed')) ?></span>
              <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('tickets', ['status' => $status]) : url('admin/tickets.php?status=' . urlencode($status))) ?>"><?= e(t('back')) ?></a>
            </div>
          </div>
        </div>

        <div style="height:12px;"></div>

        <div class="admin-card pad admin-fade">
          <div style="display:grid;gap:10px;">
            <?php foreach ($messages as $m): ?>
              <?php
                $isStaff = (int)($m['is_staff'] ?? 0) === 1;
                $author = (string)($m['author_username'] ?? '');
                if ($isStaff && $author === '') $author = t('staff');
                if (!$isStaff && $author === '') $author = t('user');
              ?>
              <div style="border:1px solid rgba(148,163,184,.25);border-radius:16px;padding:12px;background:rgba(248,250,252,.6);">
                <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
                  <div style="font-weight:750;"><?= e($author) ?><?= $isStaff ? ' · ' . e(t('admin')) : '' ?></div>
                  <div class="sub"><?= e((string)($m['created_at'] ?? '')) ?></div>
                </div>
                <div class="rte-content" style="margin-top:10px;"><?= ArcOS\Services\BbCode::render((string)($m['message'] ?? ''), $pdo, $pfx) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div style="height:12px;"></div>

        <div class="admin-card pad admin-fade">
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;">
            <div style="font-weight:800;"><?= e(t('reply')) ?></div>
            <div style="display:flex;gap:10px;align-items:center;">
              <?php if ($status === 'open'): ?>
                <form method="post" data-overlay="1" style="margin:0;">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="close" />
                  <button class="admin-btn" type="submit"><?= e(t('close_ticket')) ?></button>
                </form>
              <?php else: ?>
                <form method="post" data-overlay="1" style="margin:0;">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="reopen" />
                  <button class="admin-btn" type="submit"><?= e(t('reopen_ticket')) ?></button>
                </form>
              <?php endif; ?>
            </div>
          </div>

          <form method="post" data-overlay="1" style="margin-top:12px;display:grid;gap:10px;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reply" />
            <?php
              $content_name = 'message';
              $initial_value = '';
              $mode = 'ticket_admin';
              $attachments_enabled = true;
              $placeholder = t('ticket_reply_placeholder_admin');
              $draft_key = 'admin_ticket_' . (int)$ticketId;
              $content_type = 'ticket';
              $content_id = (int)$ticketId;
              include __DIR__ . '/../partials/editor/editor_widget.php';
            ?>
            <div style="display:flex;justify-content:flex-end;gap:10px;">
              <button class="admin-btn primary" type="submit"><?= e(t('send')) ?></button>
            </div>
          </form>
        </div>

      <?php else: ?>
        <div class="admin-card pad admin-fade">
          <div class="sub"><?= e(t('total')) ?>: <?= (int)$total ?></div>
          <div style="height:10px;"></div>
          <table class="admin-table">
            <thead>
              <tr>
                <th style="width:1%;"><?= e(t('id')) ?></th>
                <th style="min-width:280px;"><?= e(t('ticket_subject')) ?></th>
                <th style="min-width:160px;"><?= e(t('user')) ?></th>
                <th><?= e(t('status')) ?></th>
                <th style="min-width:180px;"><?= e(t('updated')) ?></th>
                <th style="width:1%;"><?= e(t('actions')) ?></th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$tickets): ?>
                <tr><td colspan="6" style="color:var(--admin-muted);"><?= e(t('no_tickets')) ?></td></tr>
              <?php endif; ?>
              <?php foreach ($tickets as $t): ?>
                <?php
                  $tid = (int)($t['id'] ?? 0);
                  $sub = (string)($t['subject'] ?? '');
                  $stt = (string)($t['status'] ?? 'open');
                  $uname = (string)($t['ticket_username'] ?? '');
                ?>
                <tr>
                  <td>#<?= (int)$tid ?></td>
                  <td style="font-weight:650;"><?= e($sub) ?></td>
                  <td><?= e($uname) ?> (#<?= (int)($t['user_id'] ?? 0) ?>)</td>
                  <td><span class="admin-badge <?= $stt === 'open' ? 'pub' : '' ?>"><?= e($stt === 'open' ? t('status_open') : t('status_closed')) ?></span></td>
                  <td><?= e((string)($t['updated_at'] ?? '')) ?></td>
                  <td style="white-space:nowrap;">
                    <a class="admin-btn primary" href="<?= e(function_exists('admin_url') ? admin_url('tickets', ['id' => $tid]) : url('admin/tickets.php?id=' . $tid)) ?>"><?= e(t('view')) ?></a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
