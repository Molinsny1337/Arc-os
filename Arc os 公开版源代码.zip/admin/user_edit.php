<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$me = current_user();
$pdo = db();
$pfx = table_prefix();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { http_response_code(400); exit(t('bad_user_id')); }

$stmt = $pdo->prepare("SELECT * FROM {$pfx}users WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$u) { http_response_code(404); exit(t('user_not_found')); }

// Only superadmin can edit admins/superadmin accounts.
$targetRole = (string)($u['role'] ?? 'user');
if (!is_superadmin() && in_array($targetRole, ['admin','superadmin'], true)) {
  http_response_code(403);
  exit('Forbidden');
}

$title = t('admin') . ' · ' . t('edit_user');
$active = 'users';

$ok = '';
$err = '';

// Identity groups
$allGroups = function_exists('arc_groups_all') ? arc_groups_all() : [];
$userGroupIds = function_exists('arc_user_group_ids') ? arc_user_group_ids((int)($u['id'] ?? 0)) : [];

function arc_update_user_id(PDO $pdo, string $pfx, int $oldId, int $newId): void {
  if ($oldId === $newId) return;

  $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE id=? LIMIT 1");
  $stmt->execute([$newId]);
  if ($stmt->fetchColumn()) throw new RuntimeException(t('id_taken'));

  $pdo->beginTransaction();
  try {
    $pdo->prepare("UPDATE {$pfx}posts SET author_id=? WHERE author_id=?")->execute([$newId, $oldId]);
    $pdo->prepare("UPDATE {$pfx}profile_comments SET profile_user_id=? WHERE profile_user_id=?")->execute([$newId, $oldId]);
    $pdo->prepare("UPDATE {$pfx}profile_comments SET author_id=? WHERE author_id=?")->execute([$newId, $oldId]);
    $pdo->prepare("UPDATE {$pfx}post_likes SET user_id=? WHERE user_id=?")->execute([$newId, $oldId]);
    $pdo->prepare("UPDATE {$pfx}users SET id=? WHERE id=?")->execute([$newId, $oldId]);
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_user_edit', 180, 300);
  try {
    $action = (string)($_POST['action'] ?? 'save');

    if ($action === 'delete_user') {
      if ((int)$me['id'] === (int)$u['id']) throw new RuntimeException(t('cannot_delete_self'));

      $delete_posts = isset($_POST['delete_posts']);
      $delete_comments = isset($_POST['delete_comments']);
      $delete_likes = isset($_POST['delete_likes']);

      $pdo->beginTransaction();
      try {
        if ($delete_posts) {
          $pdo->prepare("DELETE FROM {$pfx}posts WHERE author_id=?")->execute([(int)$u['id']]);
        }
        if ($delete_comments) {
          $pdo->prepare("DELETE FROM {$pfx}profile_comments WHERE profile_user_id=? OR author_id=?")->execute([(int)$u['id'], (int)$u['id']]);
        }
        if ($delete_likes) {
          $pdo->prepare("DELETE FROM {$pfx}post_likes WHERE user_id=?")->execute([(int)$u['id']]);
        }
        $pdo->prepare("DELETE FROM {$pfx}users WHERE id=?")->execute([(int)$u['id']]);
        $pdo->commit();
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
      }

      redirect(function_exists('admin_url') ? admin_url('users') : url('admin/users.php'));
    }

    // Save
    $username = trim((string)($_POST['username'] ?? $u['username']));
    $email = strtolower(trim((string)($_POST['email'] ?? $u['email'])));
    if ($username === '' || $email === '') throw new RuntimeException(t('missing_fields'));

    // Uniqueness checks (avoid raw SQL duplicate key errors)
    $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE username=? AND id<>? LIMIT 1");
    $st->execute([$username, $id]);
    if ($st->fetchColumn()) throw new RuntimeException(t('username_taken'));

    $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE email=? AND id<>? LIMIT 1");
    $st->execute([$email, $id]);
    if ($st->fetchColumn()) throw new RuntimeException(t('email_taken'));

    $can_post = (int)($_POST['can_post'] ?? (int)($u['can_post'] ?? 0));
    $is_verified = (int)($_POST['is_verified'] ?? (int)($u['is_verified'] ?? 0));
    $notify_likes = (int)($_POST['notify_likes'] ?? (int)($u['notify_likes'] ?? 0));
    $notify_profile_comments = (int)($_POST['notify_profile_comments'] ?? (int)($u['notify_profile_comments'] ?? 0));

    // Role: only superadmin can change, and cannot promote to superadmin unless already.
    $role = (string)($u['role'] ?? 'user');
    if (is_superadmin()) {
      $roleCandidate = (string)($_POST['role'] ?? $role);
      if (!in_array($roleCandidate, ['user','admin','superadmin'], true)) $roleCandidate = 'user';
      if ($roleCandidate === 'superadmin' && $targetRole !== 'superadmin') {
        throw new RuntimeException(t('cannot_promote_superadmin'));
      }
      $role = $roleCandidate;
    }

    // Avatar: URL or upload
    $avatar = trim((string)($_POST['avatar'] ?? (string)($u['avatar'] ?? '')));
    if (!empty($_FILES['avatar_upload']['name'])) {
      if (!is_dir(__DIR__ . '/../uploads/avatars')) @mkdir(__DIR__ . '/../uploads/avatars', 0775, true);
      $tmp = (string)($_FILES['avatar_upload']['tmp_name'] ?? '');
      $upErr = (int)($_FILES['avatar_upload']['error'] ?? 0);
      $size = (int)($_FILES['avatar_upload']['size'] ?? 0);
      if ($upErr !== UPLOAD_ERR_OK) throw new RuntimeException(t('upload_failed'));
      if ($size > 2 * 1024 * 1024) throw new RuntimeException(t('avatar_too_large'));

      $ext = detect_upload_image_ext($tmp, (string)($_FILES['avatar_upload']['name'] ?? ''));
      if ($ext === '') throw new RuntimeException(t('invalid_image_type'));

      $name = 'u' . (int)$u['id'] . '_' . time() . '.' . $ext;
      $dest = __DIR__ . '/../uploads/avatars/' . $name;
      if (!move_uploaded_file($tmp, $dest)) throw new RuntimeException(t('failed_save_avatar'));
      $avatar = base_path() . '/uploads/avatars/' . $name;
    }

    // Ban
    $is_banned = isset($_POST['is_banned']) ? 1 : 0;
    $banned_reason = trim((string)($_POST['banned_reason'] ?? ''));
    $banned_until = trim((string)($_POST['banned_until'] ?? ''));
    if ($is_banned === 0) { $banned_reason = ''; $banned_until = ''; }
    $bannedUntilDb = $banned_until !== '' ? $banned_until : null;
    $bannedByDb = $is_banned ? (int)$me['id'] : null;
    $bannedAtDb = $is_banned ? now_utc() : null;

    // Change id (superadmin only)
    $newId = (int)($_POST['new_id'] ?? (int)$u['id']);
    if ($newId !== (int)$u['id']) {
      if (!is_superadmin()) throw new RuntimeException(t('superadmin_only'));
      arc_update_user_id($pdo, $pfx, (int)$u['id'], $newId);
      $id = $newId;
    }

    // Optional password
    $newPass = (string)($_POST['password'] ?? '');
    if ($newPass !== '') {
      $hash = password_hash($newPass, PASSWORD_DEFAULT);
      $stmt = $pdo->prepare("UPDATE {$pfx}users
        SET username=?, email=?, role=?, can_post=?, is_verified=?, avatar=?,
            notify_likes=?, notify_profile_comments=?,
            is_banned=?, banned_reason=?, banned_until=?, banned_by=?, banned_at=?,
            password_hash=?
        WHERE id=?");
      $stmt->execute([$username, $email, $role, $can_post, $is_verified, $avatar,
        $notify_likes, $notify_profile_comments,
        $is_banned, $banned_reason !== '' ? $banned_reason : null, $bannedUntilDb, $bannedByDb, $bannedAtDb,
        $hash, $id]);
    } else {
      $stmt = $pdo->prepare("UPDATE {$pfx}users
        SET username=?, email=?, role=?, can_post=?, is_verified=?, avatar=?,
            notify_likes=?, notify_profile_comments=?,
            is_banned=?, banned_reason=?, banned_until=?, banned_by=?, banned_at=?
        WHERE id=?");
      $stmt->execute([$username, $email, $role, $can_post, $is_verified, $avatar,
        $notify_likes, $notify_profile_comments,
        $is_banned, $banned_reason !== '' ? $banned_reason : null, $bannedUntilDb, $bannedByDb, $bannedAtDb,
        $id]);
    }

    // Groups (superadmin only)
    if ((string)($_POST['group_ids_present'] ?? '') === '1') {
      require_superadmin();
      $gids = $_POST['group_ids'] ?? [];
      if (!is_array($gids)) $gids = [];
      $gids = array_map('intval', $gids);
      if (function_exists('arc_set_user_group_ids')) {
        arc_set_user_group_ids($id, $gids);
      }
    }

    // reload
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}users WHERE id=? LIMIT 1");
    $stmt->execute([$id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    $ok = t('saved');
  } catch (Throwable $e) {
    if ($e instanceof PDOException) {
      $info = $e->errorInfo ?? null;
      $errno = is_array($info) && isset($info[1]) ? (int)$info[1] : 0;
      $msg = (string)($info[2] ?? $e->getMessage());
      if ($errno === 1062) {
        if (stripos($msg, 'uniq_email') !== false) $err = t('email_taken');
        elseif (stripos($msg, 'uniq_username') !== false) $err = t('username_taken');
        else $err = t('error');
      } else {
        $err = $e->getMessage();
      }
    } else {
      $err = $e->getMessage();
    }
  }
}

// refresh groups for display
$allGroups = function_exists('arc_groups_all') ? arc_groups_all() : [];
$userGroupIds = function_exists('arc_user_group_ids') ? arc_user_group_ids((int)($u['id'] ?? 0)) : [];

$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('edit_user')) ?></h1>
          <div class="sub">ID: <?= (int)$u['id'] ?> · <?= e((string)$u['username']) ?> · <?= e((string)$u['role']) ?></div>
        </div>
        <div class="admin-actions">
          <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('users') : url('admin/users.php')) ?>"><?= e(t('back')) ?></a>
          <a class="admin-btn" href="<?= e(url('user.php?id='.(int)$u['id'])) ?>"><?= e(t('profile')) ?></a>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <form method="post" enctype="multipart/form-data" data-overlay="1" style="display:grid;gap:12px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save" />

          <div class="admin-grid" style="gap:12px;">
            <div class="admin-col-3">
              <label class="label">ID</label>
              <input class="input" name="new_id" value="<?= (int)$u['id'] ?>" <?= is_superadmin() ? '' : 'disabled' ?> />
              <?php if (!is_superadmin()): ?><div class="note"><?= e(t('superadmin_only')) ?></div><?php endif; ?>
            </div>

            <div class="admin-col-4">
              <label class="label"><?= e(t('username')) ?></label>
              <input class="input" name="username" value="<?= e((string)$u['username']) ?>" />
            </div>

            <div class="admin-col-5">
              <label class="label"><?= e(t('email')) ?></label>
              <input class="input" name="email" value="<?= e((string)$u['email']) ?>" />
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('role')) ?></label>
              <select class="input" name="role" <?= is_superadmin() ? '' : 'disabled' ?>>
                <?php foreach ((($targetRole === 'superadmin') ? ['user','admin','superadmin'] : ['user','admin']) as $r): ?>
                  <option value="<?= e($r) ?>" <?= ((string)($u['role'] ?? 'user') === $r) ? 'selected' : '' ?>><?= e(t('role_' . $r)) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="admin-col-12">
              <label class="label"><?= e(t('groups')) ?></label>
              <input type="hidden" name="group_ids_present" value="1" />
              <?php if (is_superadmin()): ?>
                <div style="display:flex;flex-wrap:wrap;gap:10px;">
                  <?php foreach ($allGroups as $g): ?>
                    <label style="display:flex;gap:8px;align-items:center;padding:8px 10px;border:1px solid rgba(0,0,0,.08);border-radius:12px;background:rgba(255,255,255,.7);">
                      <input type="checkbox" name="group_ids[]" value="<?= (int)($g['id'] ?? 0) ?>" <?= in_array((int)($g['id'] ?? 0), $userGroupIds, true) ? 'checked' : '' ?> />
                      <span><?= e((string)($g['name'] ?? '')) ?></span>
                      <span class="muted" style="font-size:12px;">(<?= e((string)($g['slug'] ?? '')) ?><?= ((int)($g['is_paid'] ?? 0) === 1) ? (' · ' . e(t('paid'))) : '' ?>)</span>
                    </label>
                  <?php endforeach; ?>
                  <?php if (!$allGroups): ?>
                    <div class="note"><?= e(t('no_groups_yet')) ?></div>
                  <?php endif; ?>
                </div>
              <?php else: ?>
                <div class="note"><?= e(t('superadmin_only')) ?> (<?= e(t('groups')) ?>)</div>
                <?php if ($allGroups): ?>
                  <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:8px;">
                    <?php foreach ($allGroups as $g): if (!in_array((int)($g['id'] ?? 0), $userGroupIds, true)) continue; ?>
                      <span class="admin-badge"><?= e((string)($g['slug'] ?? '')) ?></span>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('password')) ?></label>
              <input class="input" type="password" name="password" placeholder="<?= e(t('leave_blank_keep')) ?>" />
              <div class="note"><?= e(t('leave_blank_keep')) ?></div>
            </div>

            <div class="admin-col-6">
              <label class="label"><?= e(t('avatar')) ?> (URL)</label>
              <input class="input" name="avatar" value="<?= e((string)($u['avatar'] ?? '')) ?>" />
              <div class="note"><?= e(t('or_upload')) ?></div>
            </div>

            <div class="admin-col-6">
              <label class="label"><?= e(t('upload_avatar')) ?></label>
              <input class="input" type="file" name="avatar_upload" accept="image/*" />
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('can_post')) ?></label>
              <select class="input" name="can_post">
                <option value="0" <?= ((int)($u['can_post'] ?? 0) === 0) ? 'selected' : '' ?>>0</option>
                <option value="1" <?= ((int)($u['can_post'] ?? 0) === 1) ? 'selected' : '' ?>>1</option>
              </select>
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('is_verified')) ?></label>
              <select class="input" name="is_verified">
                <option value="0" <?= ((int)($u['is_verified'] ?? 0) === 0) ? 'selected' : '' ?>>0</option>
                <option value="1" <?= ((int)($u['is_verified'] ?? 0) === 1) ? 'selected' : '' ?>>1</option>
              </select>
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('notify_likes')) ?></label>
              <select class="input" name="notify_likes">
                <option value="0" <?= ((int)($u['notify_likes'] ?? 0) === 0) ? 'selected' : '' ?>>0</option>
                <option value="1" <?= ((int)($u['notify_likes'] ?? 0) === 1) ? 'selected' : '' ?>>1</option>
              </select>
            </div>

            <div class="admin-col-3">
              <label class="label"><?= e(t('notify_profile_comments')) ?></label>
              <select class="input" name="notify_profile_comments">
                <option value="0" <?= ((int)($u['notify_profile_comments'] ?? 0) === 0) ? 'selected' : '' ?>>0</option>
                <option value="1" <?= ((int)($u['notify_profile_comments'] ?? 0) === 1) ? 'selected' : '' ?>>1</option>
              </select>
            </div>

            <div class="admin-col-12">
              <label class="label"><?= e(t('ban')) ?></label>
              <label style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="is_banned" <?= ((int)($u['is_banned'] ?? 0) === 1) ? 'checked' : '' ?> />
                <span><?= e(t('banned_label')) ?></span>
              </label>
              <div class="note"><?= e(t('ban_hint')) ?></div>
            </div>

            <div class="admin-col-6">
              <label class="label"><?= e(t('banned_reason')) ?></label>
              <input class="input" name="banned_reason" value="<?= e((string)($u['banned_reason'] ?? '')) ?>" placeholder="<?= e(t('banned_reason_placeholder')) ?>" />
            </div>

            <div class="admin-col-6">
              <label class="label"><?= e(t('banned_until')) ?></label>
              <input class="input" name="banned_until" value="<?= e((string)($u['banned_until'] ?? '')) ?>" placeholder="YYYY-MM-DD HH:MM:SS" />
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;">
            <button class="admin-btn primary" type="submit"><?= e(t('save_changes')) ?></button>
          </div>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <h2 style="margin:0 0 10px; font-size:16px;"><?= e(t('danger_zone')) ?></h2>
        <form method="post" data-overlay="1" onsubmit="return confirm(<?= json_encode(t('delete_user_confirm')) ?>);">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete_user" />
          <label style="display:flex; gap:10px; align-items:center; margin:8px 0"><input type="checkbox" name="delete_posts" checked> <span><?= e(t('delete_posts')) ?></span></label>
          <label style="display:flex; gap:10px; align-items:center; margin:8px 0"><input type="checkbox" name="delete_comments" checked> <span><?= e(t('delete_comments')) ?></span></label>
          <label style="display:flex; gap:10px; align-items:center; margin:8px 0"><input type="checkbox" name="delete_likes" checked> <span><?= e(t('delete_likes')) ?></span></label>
          <div style="display:flex; justify-content:flex-end; margin-top:10px">
            <button class="admin-btn" type="submit" style="border-color:rgba(239,68,68,.35); color:#b91c1c;"><?= e(t('delete_user')) ?></button>
          </div>
        </form>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
