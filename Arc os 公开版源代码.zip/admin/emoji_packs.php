<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' - Emoji Packs';
$active = 'emoji_packs';
$err = '';
$msg = '';

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/../includes/services/EmojiService.php';

function arc_emoji_slug(string $title): string {
  $slug = slugify($title);
  $slug = preg_replace('/[^a-z0-9_-]/', '', $slug) ?? '';
  return $slug;
}

function arc_allowed_emoji(string $mime): bool {
  return in_array($mime, ['image/png','image/webp','image/gif'], true);
}

function arc_detect_mime(string $path): string {
  $mime = 'application/octet-stream';
  if (is_callable('finfo_open')) {
    $fi = @finfo_open(FILEINFO_MIME_TYPE);
    if ($fi) {
      $sn = @finfo_file($fi, $path);
      if (is_string($sn) && $sn !== '') $mime = $sn;
      @finfo_close($fi);
    }
  }
  return $mime;
}

function arc_store_emoji(PDO $pdo, string $pfx, int $packId, string $baseDir, string $origName, string $tmpPath, string $category, bool $isSticker): void {
  $mime = arc_detect_mime($tmpPath);
  if (!arc_allowed_emoji($mime)) return;

  $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
  $ext = preg_replace('/[^a-z0-9]/', '', $ext) ?? '';
  if (!in_array($ext, ['png','webp','gif'], true)) return;

  $short = pathinfo($origName, PATHINFO_FILENAME);
  $short = ArcOS\Services\EmojiService::sanitizeShortcode($short);
  if ($short === '') {
    $short = 'emoji_' . substr(bin2hex(random_bytes(6)), 0, 12);
  }

  $name = 'emoji_' . bin2hex(random_bytes(10)) . '.' . $ext;
  $rel = 'uploads/emojis/' . $baseDir . '/' . $name;
  $dest = __DIR__ . '/../' . $rel;
  $dir = dirname($dest);
  if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
    @file_put_contents($dir . '/index.html', '<!-- Arc OS -->');
  }

  if (!@move_uploaded_file($tmpPath, $dest) && !@rename($tmpPath, $dest)) return;

  $info = @getimagesize($dest);
  $w = is_array($info) ? (int)($info[0] ?? 0) : null;
  $h = is_array($info) ? (int)($info[1] ?? 0) : null;

  $pdo->prepare("INSERT INTO {$pfx}xf_emojis (shortcode, unicode, image_path, category, width, height, is_sticker, display_order)
    VALUES (?,?,?,?,?,?,?,0)")
    ->execute([$short, null, $rel, $category !== '' ? $category : null, $w, $h, $isSticker ? 1 : 0]);
  $emojiId = (int)$pdo->lastInsertId();
  if ($emojiId > 0) {
    $pdo->prepare("INSERT INTO {$pfx}xf_emoji_pack_items (pack_id, emoji_id) VALUES (?,?)")
      ->execute([$packId, $emojiId]);
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_emoji_packs', 60, 300);

  try {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'add_pack') {
      $titleIn = trim((string)($_POST['title'] ?? ''));
      $slugIn = trim((string)($_POST['slug'] ?? ''));
      $category = trim((string)($_POST['category'] ?? ''));
      $isSticker = isset($_POST['is_sticker']);
      $enabled = isset($_POST['is_enabled']) ? 1 : 0;
      if ($titleIn === '') throw new RuntimeException('Title required');
      $slug = $slugIn !== '' ? arc_emoji_slug($slugIn) : arc_emoji_slug($titleIn);
      if ($slug === '') throw new RuntimeException('Slug invalid');

      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_emoji_packs WHERE slug=? LIMIT 1");
      $stmt->execute([$slug]);
      if ($stmt->fetchColumn()) throw new RuntimeException('Slug exists');

      $pdo->prepare("INSERT INTO {$pfx}xf_emoji_packs (title, slug, is_enabled, display_order, created_at)
        VALUES (?,?,?,?,NOW())")
        ->execute([$titleIn, $slug, $enabled, 0]);
      $packId = (int)$pdo->lastInsertId();
      if ($packId <= 0) throw new RuntimeException('Create failed');

      // zip upload
      if (!empty($_FILES['zip_file']['tmp_name']) && is_uploaded_file($_FILES['zip_file']['tmp_name'])) {
        if (!class_exists('ZipArchive')) throw new RuntimeException('ZipArchive missing');
        $zip = new ZipArchive();
        if ($zip->open($_FILES['zip_file']['tmp_name']) === true) {
          $tmpDir = sys_get_temp_dir() . '/arc_emoji_' . bin2hex(random_bytes(5));
          @mkdir($tmpDir, 0775, true);
          for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!$stat || empty($stat['name'])) continue;
            $name = (string)$stat['name'];
            if (str_contains($name, '..')) continue;
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, ['png','webp','gif'], true)) continue;
            $tmpPath = $tmpDir . '/' . basename($name);
            copy('zip://' . $_FILES['zip_file']['tmp_name'] . '#' . $name, $tmpPath);
            if (is_file($tmpPath)) {
              arc_store_emoji($pdo, $pfx, $packId, $slug, basename($name), $tmpPath, $category, $isSticker);
            }
          }
          $zip->close();
        }
      }

      // multi file upload
      if (!empty($_FILES['images'])) {
        $files = $_FILES['images'];
        if (isset($files['name']) && is_array($files['name'])) {
          $count = count($files['name']);
          for ($i = 0; $i < $count; $i++) {
            $tmp = (string)($files['tmp_name'][$i] ?? '');
            $name = (string)($files['name'][$i] ?? '');
            if ($tmp === '' || !is_uploaded_file($tmp)) continue;
            arc_store_emoji($pdo, $pfx, $packId, $slug, $name, $tmp, $category, $isSticker);
          }
        }
      }

      $msg = 'Saved';
    }

    if ($action === 'toggle_pack') {
      $packId = (int)($_POST['pack_id'] ?? 0);
      $pdo->prepare("UPDATE {$pfx}xf_emoji_packs SET is_enabled=1-is_enabled WHERE id=?")
        ->execute([$packId]);
      $msg = 'Updated';
    }

    if ($action === 'delete_pack') {
      $packId = (int)($_POST['pack_id'] ?? 0);
      if ($packId > 0) {
        $stmt = $pdo->prepare("SELECT id, image_path FROM {$pfx}xf_emojis WHERE id IN (SELECT emoji_id FROM {$pfx}xf_emoji_pack_items WHERE pack_id=?)");
        $stmt->execute([$packId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $pdo->prepare("DELETE FROM {$pfx}xf_emoji_pack_items WHERE pack_id=?")->execute([$packId]);
        $pdo->prepare("DELETE FROM {$pfx}xf_emoji_packs WHERE id=?")->execute([$packId]);

        foreach ($rows as $r) {
          $eid = (int)($r['id'] ?? 0);
          $path = (string)($r['image_path'] ?? '');
          if ($eid <= 0) continue;
          $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_emoji_pack_items WHERE emoji_id=?");
          $stmt->execute([$eid]);
          if ((int)$stmt->fetchColumn() === 0) {
            $pdo->prepare("DELETE FROM {$pfx}xf_emojis WHERE id=?")->execute([$eid]);
            if ($path !== '') {
              $fs = __DIR__ . '/../' . ltrim($path, '/');
              if (is_file($fs)) @unlink($fs);
            }
          }
        }
      }
      $msg = 'Deleted';
    }

    if ($action === 'reorder') {
      $orders = $_POST['order'] ?? [];
      if (is_array($orders)) {
        foreach ($orders as $pid => $order) {
          $pid = (int)$pid;
          $order = (int)$order;
          $pdo->prepare("UPDATE {$pfx}xf_emoji_packs SET display_order=? WHERE id=?")
            ->execute([$order, $pid]);
        }
      }
      $msg = 'Saved';
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$packs = [];
try {
  $packs = $pdo->query("SELECT * FROM {$pfx}xf_emoji_packs ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1>Emoji Packs</h1>
          <div class="sub">Upload and manage emoji packs (png/webp/gif only).</div>
        </div>
      </div>

      <?php if ($msg): ?><div class="notice success admin-fade"><?= e($msg) ?></div><?php endif; ?>
      <?php if ($err): ?><div class="notice danger admin-fade"><?= e($err) ?></div><?php endif; ?>

      <section class="admin-card pad admin-fade" style="max-width:920px;">
        <h2 style="margin:0 0 10px 0;">Add Pack</h2>
        <form method="post" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="add_pack">
          <div class="grid">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Title</label>
              <input class="input" name="title" required />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Slug (optional)</label>
              <input class="input" name="slug" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Category</label>
              <input class="input" name="category" placeholder="smileys" />
            </div>
            <div class="field" style="grid-column: span 6;display:flex;gap:12px;align-items:center;">
              <label class="check" style="display:flex;gap:8px;align-items:center;">
                <input type="checkbox" name="is_sticker" />
                <span>Sticker pack</span>
              </label>
              <label class="check" style="display:flex;gap:8px;align-items:center;">
                <input type="checkbox" name="is_enabled" checked />
                <span>Enable</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Zip Upload</label>
              <input class="input" type="file" name="zip_file" accept=".zip" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Images</label>
              <input class="input" type="file" name="images[]" accept="image/png,image/webp,image/gif" multiple />
            </div>
          </div>
          <button class="admin-btn primary" type="submit">Create Pack</button>
        </form>
      </section>

      <section class="admin-card pad admin-fade" style="margin-top:16px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
          <h2 style="margin:0;">Existing Packs</h2>
          <form method="post" style="margin:0;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reorder">
            <button class="admin-btn" type="submit">Save Order</button>
          </form>
        </div>
        <div style="overflow:auto;margin-top:10px;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Slug</th>
                <th>Enabled</th>
                <th>Order</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($packs as $p): ?>
                <tr>
                  <td><?= e((string)($p['title'] ?? '')) ?></td>
                  <td><?= e((string)($p['slug'] ?? '')) ?></td>
                  <td><?= !empty($p['is_enabled']) ? 'Yes' : 'No' ?></td>
                  <td>
                    <form method="post" style="margin:0;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="reorder">
                      <input class="input" type="number" name="order[<?= (int)$p['id'] ?>]" value="<?= (int)($p['display_order'] ?? 0) ?>" />
                  </td>
                  <td style="white-space:nowrap;text-align:right;">
                      <button class="admin-btn" type="submit">Save</button>
                    </form>
                    <form method="post" style="margin:6px 0 0;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="toggle_pack">
                      <input type="hidden" name="pack_id" value="<?= (int)$p['id'] ?>">
                      <button class="admin-btn" type="submit"><?= !empty($p['is_enabled']) ? 'Disable' : 'Enable' ?></button>
                    </form>
                    <form method="post" style="margin:6px 0 0;">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="delete_pack">
                      <input type="hidden" name="pack_id" value="<?= (int)$p['id'] ?>">
                      <button class="admin-btn" type="submit">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$packs): ?>
                <tr><td colspan="5" class="muted"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
