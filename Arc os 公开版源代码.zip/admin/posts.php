<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('admin') . ' - ' . t('threads');
$pdo = db();
$pfx = table_prefix();

$err = '';
$active = 'threads';

$status = (string)($_GET['status'] ?? 'published');
if (!in_array($status, ['all','published','pending','deleted'], true)) $status = 'published';
$q = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset = ($page - 1) * $perPage;

$where = "WHERE p.type='forum'";
$params = [];
if ($status === 'published') {
  $where .= " AND p.status='published' AND p.is_deleted=0";
} elseif ($status === 'pending') {
  $where .= " AND p.review_state='pending'";
} elseif ($status === 'deleted') {
  $where .= " AND p.is_deleted=1";
}
if ($q !== '') {
  $where .= " AND p.title LIKE ?";
  $params[] = '%' . $q . '%';
}

$total = 0;
try {
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts p {$where}");
  $stmt->execute($params);
  $total = (int)($stmt->fetchColumn() ?: 0);
} catch (Throwable $e) {
  $total = 0;
}

$threads = [];
try {
  $sql = "SELECT p.id, p.title, p.slug, p.status, p.review_state, p.is_deleted, p.is_locked, p.is_sticky,
      p.reply_count, p.last_post_at,
      u.username AS author_username,
      f.title AS forum_title
    FROM {$pfx}posts p
    LEFT JOIN {$pfx}users u ON u.id=p.author_id
    LEFT JOIN {$pfx}forums f ON f.id=p.forum_id
    {$where}
    ORDER BY COALESCE(p.last_post_at, p.created_at) DESC
    LIMIT ? OFFSET ?";
  $stmt = $pdo->prepare($sql);
  $i = 1;
  foreach ($params as $param) {
    $stmt->bindValue($i++, $param, PDO::PARAM_STR);
  }
  $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
  $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
  $stmt->execute();
  $threads = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $threads = [];
}

$baseUrl = function_exists('admin_url') ? admin_url('posts') : url('admin/posts.php');
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('threads')) ?></h1>
          <div class="sub"><?= e(t('admin_threads_sub')) ?></div>
        </div>
        <div class="admin-actions">
          <a class="admin-btn" href="<?= e(url('forum_new.php')) ?>" data-transition="off"><?= e(t('new_thread')) ?></a>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>

      <div class="admin-fade" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;align-items:center;">
        <a class="admin-btn <?= $status==='published'?'primary':'' ?>" href="<?= e($baseUrl . '?status=published') ?>">Published</a>
        <a class="admin-btn <?= $status==='pending'?'primary':'' ?>" href="<?= e($baseUrl . '?status=pending') ?>">Pending</a>
        <a class="admin-btn <?= $status==='deleted'?'primary':'' ?>" href="<?= e($baseUrl . '?status=deleted') ?>">Deleted</a>
        <a class="admin-btn <?= $status==='all'?'primary':'' ?>" href="<?= e($baseUrl . '?status=all') ?>">All</a>
        <form method="get" action="<?= e($baseUrl) ?>" style="margin-left:auto;display:flex;gap:8px;align-items:center;">
          <input type="hidden" name="status" value="<?= e($status) ?>" />
          <input class="input" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search')) ?>" style="min-width:220px;" />
          <button class="admin-btn" type="submit"><?= e(t('search')) ?></button>
        </form>
      </div>

      <div class="admin-card pad admin-fade">
        <div style="overflow:auto;">
          <table class="admin-table">
            <thead>
              <tr>
                <th style="min-width:260px;"><?= e(t('title')) ?></th>
                <th><?= e(t('forum')) ?></th>
                <th><?= e(t('author')) ?></th>
                <th><?= e(t('replies')) ?></th>
                <th><?= e(t('status')) ?></th>
                <th style="min-width:180px;"><?= e(t('last_post')) ?></th>
                <th style="width:1%;"><?= e(t('actions')) ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($threads as $t): ?>
                <?php
                  $threadId = (int)($t['id'] ?? 0);
                  $isDeleted = (int)($t['is_deleted'] ?? 0) === 1;
                  $isLocked = (int)($t['is_locked'] ?? 0) === 1;
                  $isSticky = (int)($t['is_sticky'] ?? 0) === 1;
                  $viewUrl = url('forum_post.php?slug=' . urlencode((string)($t['slug'] ?? '')));
                ?>
                <tr>
                  <td><a href="<?= e($viewUrl) ?>" data-transition="off"><?= e((string)($t['title'] ?? '')) ?></a></td>
                  <td><?= e((string)($t['forum_title'] ?? '')) ?></td>
                  <td><?= e((string)($t['author_username'] ?? '')) ?></td>
                  <td><?= (int)($t['reply_count'] ?? 0) ?></td>
                  <td>
                    <?php if ($isDeleted): ?>
                      <span class="admin-badge draft">deleted</span>
                    <?php elseif (($t['review_state'] ?? '') === 'pending'): ?>
                      <span class="admin-badge">pending</span>
                    <?php else: ?>
                      <span class="admin-badge pub">published</span>
                    <?php endif; ?>
                  </td>
                  <td><?= e((string)($t['last_post_at'] ?? '')) ?></td>
                  <td>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                      <a class="admin-btn" href="<?= e($viewUrl) ?>" data-transition="off"><?= e(t('view')) ?></a>
                      <form method="post" action="<?= e(url('admin/thread_tools.php')) ?>" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= $threadId ?>" />
                        <input type="hidden" name="action" value="<?= $isLocked ? 'toggle_lock' : 'toggle_lock' ?>" />
                        <button class="admin-btn ghost" type="submit"><?= $isLocked ? 'Unlock' : 'Lock' ?></button>
                      </form>
                      <form method="post" action="<?= e(url('admin/thread_tools.php')) ?>" style="margin:0;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= $threadId ?>" />
                        <input type="hidden" name="action" value="<?= $isSticky ? 'toggle_sticky' : 'toggle_sticky' ?>" />
                        <button class="admin-btn ghost" type="submit"><?= $isSticky ? 'Unstick' : 'Stick' ?></button>
                      </form>
                      <?php if ($isDeleted): ?>
                        <form method="post" action="<?= e(url('forum_post_restore.php')) ?>" style="margin:0;">
                          <?= csrf_field() ?>
                          <input type="hidden" name="id" value="<?= $threadId ?>" />
                          <button class="admin-btn ghost" type="submit"><?= e(t('restore')) ?></button>
                        </form>
                      <?php else: ?>
                        <form method="post" action="<?= e(url('forum_post_delete.php')) ?>" style="margin:0;">
                          <?= csrf_field() ?>
                          <input type="hidden" name="id" value="<?= $threadId ?>" />
                          <button class="admin-btn ghost" type="submit"><?= e(t('delete')) ?></button>
                        </form>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$threads): ?>
                <tr><td colspan="7" style="color:var(--admin-muted);"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php
        if ($total > $perPage) {
          $base_url = $baseUrl;
          $query = ['status' => $status, 'q' => $q];
          $total_pages = (int)ceil($total / $perPage);
          $page = $page;
          include __DIR__ . '/../partials/xf/pager.php';
        }
      ?>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
  <script src="<?= e('assets/admin.js') ?>"></script>
</body>
</html>
