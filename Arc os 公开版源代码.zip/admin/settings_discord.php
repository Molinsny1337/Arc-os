<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();
require_once __DIR__ . '/../includes/services/CryptoService.php';
require_once __DIR__ . '/../includes/services/DiscordWebhookService.php';

$title = t('admin') . ' · Discord';
$active = 'discord';
$err = '';
$msg = '';

function bool_post(string $key): string {
  return isset($_POST[$key]) ? '1' : '0';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_discord', 60, 300);
  try {
    $action = (string)($_POST['action'] ?? 'save');
    $clientId = trim((string)($_POST['discord_client_id'] ?? ''));
    $clientSecret = trim((string)($_POST['discord_client_secret'] ?? ''));
    $redirectUri = trim((string)($_POST['discord_redirect_uri'] ?? ''));
    $allowRegister = bool_post('discord_allow_register');
    $showInMembers = bool_post('discord_show_in_members');

    $webhookEnabled = bool_post('discord_webhook_enabled');
    $webhookUrl = trim((string)($_POST['discord_webhook_url'] ?? ''));
    $eventNewThread = bool_post('discord_webhook_event_new_thread');
    $eventNewPost = bool_post('discord_webhook_event_new_post');
    $eventReport = bool_post('discord_webhook_event_report_created');
    $eventQueue = bool_post('discord_webhook_event_moderation_queue');
    $eventRegister = bool_post('discord_webhook_event_user_registered');

    $guildId = trim((string)($_POST['discord_guild_id'] ?? ''));
    $botToken = trim((string)($_POST['discord_bot_token'] ?? ''));

    if ($redirectUri === '') {
      $redirectUri = site_url('discord/callback');
    }

    set_setting('discord_client_id', $clientId);
    set_setting('discord_redirect_uri', $redirectUri);
    set_setting('discord_allow_register', $allowRegister);
    set_setting('discord_show_in_members', $showInMembers);

    if (isset($_POST['discord_client_secret_clear'])) {
      delete_setting('discord_client_secret_enc');
    } elseif ($clientSecret !== '') {
      $enc = ArcOS\Services\CryptoService::encrypt($clientSecret);
      if ($enc === '') throw new RuntimeException('Encrypt failed.');
      set_setting('discord_client_secret_enc', $enc);
    }

    set_setting('discord_webhook_enabled', $webhookEnabled);
    set_setting('discord_webhook_event_new_thread', $eventNewThread);
    set_setting('discord_webhook_event_new_post', $eventNewPost);
    set_setting('discord_webhook_event_report_created', $eventReport);
    set_setting('discord_webhook_event_moderation_queue', $eventQueue);
    set_setting('discord_webhook_event_user_registered', $eventRegister);

    if (isset($_POST['discord_webhook_clear'])) {
      delete_setting('discord_webhook_url_enc');
    } elseif ($webhookUrl !== '') {
      $enc = ArcOS\Services\CryptoService::encrypt($webhookUrl);
      if ($enc === '') throw new RuntimeException('Encrypt failed.');
      set_setting('discord_webhook_url_enc', $enc);
    }

    set_setting('discord_guild_id', $guildId);
    if (isset($_POST['discord_bot_token_clear'])) {
      delete_setting('discord_bot_token_enc');
    } elseif ($botToken !== '') {
      $enc = ArcOS\Services\CryptoService::encrypt($botToken);
      if ($enc === '') throw new RuntimeException('Encrypt failed.');
      set_setting('discord_bot_token_enc', $enc);
    }

    if ($action === 'test_webhook') {
      $ok = ArcOS\Services\DiscordWebhookService::send('test', [
        'title' => 'Arc OS Test',
        'description' => 'Discord webhook test from admin panel.',
        'url' => site_url('admin/settings_discord.php'),
        'author' => 'Admin',
      ]);
      $msg = $ok ? 'Webhook sent.' : 'Webhook failed. Check logs.';
    } else {
      $u = current_user();
      $hello = $u['username'] ?? 'Admin';
      $back = function_exists('admin_url') ? admin_url('settings_discord') : url('admin/settings_discord.php');
      redirect(url('transition.php') . '?hello=' . urlencode($hello) . '&msg=' . urlencode(t('saved')) . '&to=' . urlencode($back));
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$pdo = db();
$pfx = table_prefix();

$defaultRedirect = site_url('discord/callback');
$clientId = (string)get_setting('discord_client_id', '');
$redirectUri = (string)get_setting('discord_redirect_uri', $defaultRedirect);
$allowRegister = get_setting('discord_allow_register', '1') === '1';
$showInMembers = get_setting('discord_show_in_members', '0') === '1';

$secretSet = (string)get_setting('discord_client_secret_enc', '') !== '';

$webhookEnabled = get_setting('discord_webhook_enabled', '0') === '1';
$webhookSet = (string)get_setting('discord_webhook_url_enc', '') !== '';
$eventNewThread = get_setting('discord_webhook_event_new_thread', '1') === '1';
$eventNewPost = get_setting('discord_webhook_event_new_post', '1') === '1';
$eventReport = get_setting('discord_webhook_event_report_created', '1') === '1';
$eventQueue = get_setting('discord_webhook_event_moderation_queue', '1') === '1';
$eventRegister = get_setting('discord_webhook_event_user_registered', '1') === '1';

$guildId = (string)get_setting('discord_guild_id', '');
$botTokenSet = (string)get_setting('discord_bot_token_enc', '') !== '';

$webhookLogs = [];
$syncLogs = [];
try {
  $webhookLogs = $pdo->query("SELECT id, event, status, error, created_at FROM {$pfx}xf_webhook_log ORDER BY id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $webhookLogs = [];
}
try {
  $stmt = $pdo->prepare("SELECT l.id, l.user_id, l.status, l.error, l.created_at, u.username
    FROM {$pfx}xf_discord_sync_log l
    LEFT JOIN {$pfx}users u ON u.id=l.user_id
    ORDER BY l.id DESC
    LIMIT 30");
  $stmt->execute();
  $syncLogs = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $syncLogs = [];
}
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1>Discord</h1>
          <div class="sub">OAuth, webhook, and role sync</div>
        </div>
      </div>

      <?php if ($err): ?><div class="alert admin-fade"><?= e($err) ?></div><?php endif; ?>
      <?php if ($msg): ?><div class="admin-card pad admin-fade"><?= e($msg) ?></div><?php endif; ?>

      <form method="post" class="admin-fade" style="display:grid;gap:14px;max-width:980px;">
        <?= csrf_field() ?>

        <section class="admin-card pad">
          <div style="font-weight:700;">OAuth2 Login / Bind</div>
          <div class="sub">Scopes: identify, email (optional guilds if role sync enabled).</div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Client ID</label>
              <input class="input" name="discord_client_id" value="<?= e($clientId) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Client Secret <?= $secretSet ? '(configured)' : '' ?></label>
              <input class="input" name="discord_client_secret" value="" placeholder="<?= $secretSet ? 'Leave blank to keep' : '' ?>" />
              <label class="check" style="display:flex;gap:8px;align-items:center;margin-top:8px;">
                <input type="checkbox" name="discord_client_secret_clear" />
                <span>Clear stored secret</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label">Redirect URI</label>
              <input class="input" name="discord_redirect_uri" value="<?= e($redirectUri) ?>" />
              <div class="note">Default: <?= e($defaultRedirect) ?></div>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="check" style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="discord_allow_register" <?= $allowRegister ? 'checked' : '' ?> />
                <span>Allow Discord register</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="check" style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="discord_show_in_members" <?= $showInMembers ? 'checked' : '' ?> />
                <span>Show Discord badge in members</span>
              </label>
            </div>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;">Webhook</div>
          <div class="sub">Use a Discord channel webhook for notifications.</div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 12;">
              <label class="check" style="display:flex;gap:10px;align-items:center;">
                <input type="checkbox" name="discord_webhook_enabled" <?= $webhookEnabled ? 'checked' : '' ?> />
                <span>Enable webhook</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label">Webhook URL <?= $webhookSet ? '(configured)' : '' ?></label>
              <input class="input" name="discord_webhook_url" value="" placeholder="<?= $webhookSet ? 'Leave blank to keep' : '' ?>" />
              <label class="check" style="display:flex;gap:8px;align-items:center;margin-top:8px;">
                <input type="checkbox" name="discord_webhook_clear" />
                <span>Clear stored webhook URL</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 12;">
              <label class="label">Events</label>
              <div style="display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));">
                <label class="check" style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" name="discord_webhook_event_new_thread" <?= $eventNewThread ? 'checked' : '' ?> />
                  <span>New thread</span>
                </label>
                <label class="check" style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" name="discord_webhook_event_new_post" <?= $eventNewPost ? 'checked' : '' ?> />
                  <span>New reply</span>
                </label>
                <label class="check" style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" name="discord_webhook_event_report_created" <?= $eventReport ? 'checked' : '' ?> />
                  <span>New report</span>
                </label>
                <label class="check" style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" name="discord_webhook_event_moderation_queue" <?= $eventQueue ? 'checked' : '' ?> />
                  <span>Moderation queue</span>
                </label>
                <label class="check" style="display:flex;gap:8px;align-items:center;">
                  <input type="checkbox" name="discord_webhook_event_user_registered" <?= $eventRegister ? 'checked' : '' ?> />
                  <span>User registered</span>
                </label>
              </div>
            </div>
          </div>
        </section>

        <section class="admin-card pad">
          <div style="font-weight:700;">Role Sync (Optional)</div>
          <div class="sub">Requires a bot token with guild member intent and the guild ID.</div>
          <div class="grid" style="margin-top:12px;">
            <div class="field" style="grid-column: span 6;">
              <label class="label">Guild ID</label>
              <input class="input" name="discord_guild_id" value="<?= e($guildId) ?>" />
            </div>
            <div class="field" style="grid-column: span 6;">
              <label class="label">Bot Token <?= $botTokenSet ? '(configured)' : '' ?></label>
              <input class="input" name="discord_bot_token" value="" placeholder="<?= $botTokenSet ? 'Leave blank to keep' : '' ?>" />
              <label class="check" style="display:flex;gap:8px;align-items:center;margin-top:8px;">
                <input type="checkbox" name="discord_bot_token_clear" />
                <span>Clear stored bot token</span>
              </label>
            </div>
            <div class="field" style="grid-column: span 12;">
              <a class="admin-btn" href="<?= e(function_exists('admin_url') ? admin_url('discord_role_map') : url('admin/discord_role_map.php')) ?>">Manage role mapping</a>
            </div>
          </div>
        </section>

        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="admin-btn primary" type="submit" name="action" value="save"><?= e(t('save') ?? 'Save') ?></button>
          <button class="admin-btn" type="submit" name="action" value="test_webhook">Test webhook</button>
          <a class="admin-btn ghost" href="<?= e(function_exists('admin_url') ? admin_url('settings_discord') : url('admin/settings_discord.php')) ?>"><?= e(t('reset') ?? 'Reset') ?></a>
        </div>
      </form>

      <section class="admin-card pad" style="margin-top:16px;">
        <div style="font-weight:700;">Webhook Log</div>
        <div style="overflow:auto;margin-top:10px;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Event</th>
                <th>Status</th>
                <th>Error</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($webhookLogs as $row): ?>
                <tr>
                  <td><?= (int)$row['id'] ?></td>
                  <td><?= e((string)($row['event'] ?? '')) ?></td>
                  <td><?= e((string)($row['status'] ?? '')) ?></td>
                  <td><?= e((string)($row['error'] ?? '')) ?></td>
                  <td><?= e((string)($row['created_at'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$webhookLogs): ?>
                <tr><td colspan="5" class="muted"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>

      <section class="admin-card pad" style="margin-top:16px;">
        <div style="font-weight:700;">Role Sync Log</div>
        <div style="overflow:auto;margin-top:10px;">
          <table class="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>User</th>
                <th>Status</th>
                <th>Error</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($syncLogs as $row): ?>
                <tr>
                  <td><?= (int)$row['id'] ?></td>
                  <td><?= e((string)($row['username'] ?? '')) ?><?php if (!empty($row['user_id'])): ?> #<?= (int)$row['user_id'] ?><?php endif; ?></td>
                  <td><?= e((string)($row['status'] ?? '')) ?></td>
                  <td><?= e((string)($row['error'] ?? '')) ?></td>
                  <td><?= e((string)($row['created_at'] ?? '')) ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$syncLogs): ?>
                <tr><td colspan="5" class="muted"><?= e(t('no_data')) ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</body>
</html>
