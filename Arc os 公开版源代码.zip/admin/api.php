<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_admin();

$title = t('api');
$active = 'api';

$enabled = get_setting('api_enabled', '0') === '1';
$publicRead = get_setting('api_public_read', '1') === '1';
$masterKey = (string)get_setting('api_master_key', '');
$entitlementKey = (string)get_setting('api_entitlement_key', '');

$ok = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('admin_api', 60, 60);
  try {
    $action = (string)($_POST['action'] ?? 'save');
    if ($action === 'generate' || $action === 'generate_master') {
      $masterKey = random_token(32);
      set_setting('api_master_key', $masterKey);
      $ok = t('saved');
    } elseif ($action === 'generate_entitlement') {
      $entitlementKey = random_token(32);
      set_setting('api_entitlement_key', $entitlementKey);
      $ok = t('saved');
    } else {
      $enabled = isset($_POST['api_enabled']);
      $publicRead = isset($_POST['api_public_read']);
      $masterKey = trim((string)($_POST['api_master_key'] ?? $masterKey));
      $entitlementKey = trim((string)($_POST['api_entitlement_key'] ?? $entitlementKey));
      set_setting('api_enabled', $enabled ? '1' : '0');
      set_setting('api_public_read', $publicRead ? '1' : '0');
      set_setting('api_master_key', $masterKey);
      set_setting('api_entitlement_key', $entitlementKey);
      $ok = t('saved');
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$langCode = lang();
$baseApi = site_url('api.php');
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/../partials/head.php'; ?></head>
<body class="admin">
  <?php include __DIR__ . '/../partials/nav.php'; ?>

  <div class="admin-shell">
    <?php include __DIR__ . '/../partials/admin_sidebar.php'; ?>

    <main class="admin-main">
      <div class="admin-header admin-fade">
        <div>
          <h1><?= e(t('api')) ?></h1>
          <div class="sub"><?= e(t('api_sub')) ?></div>
        </div>
      </div>

      <?php if ($ok): ?>
        <div class="admin-card pad admin-fade"><div style="font-weight:650;"><?= e($ok) ?></div></div>
      <?php endif; ?>
      <?php if ($err): ?>
        <div class="admin-card pad admin-fade" style="border:1px solid rgba(239,68,68,.25); background:rgba(239,68,68,.06);">
          <div style="font-weight:650;color:#b91c1c;"><?= e(t('error')) ?></div>
          <div class="sub" style="margin-top:6px;color:#7f1d1d;"><?= e($err) ?></div>
        </div>
      <?php endif; ?>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <form method="post" style="display:grid;gap:12px;">
          <?= csrf_field() ?>

          <label style="display:flex;gap:10px;align-items:center;">
            <input type="checkbox" name="api_enabled" <?= $enabled ? 'checked' : '' ?> />
            <span><?= e(t('api_enabled')) ?></span>
          </label>

          <label style="display:flex;gap:10px;align-items:center;">
            <input type="checkbox" name="api_public_read" <?= $publicRead ? 'checked' : '' ?> />
            <span><?= e(t('api_public_read')) ?></span>
          </label>

          <div>
            <label class="label"><?= e(t('api_master_key')) ?></label>
            <input class="input" name="api_master_key" value="<?= e($masterKey) ?>" placeholder="<?= e(t('api_master_key_hint')) ?>" />
          </div>

          <div>
            <label class="label"><?= e(t('api_entitlement_key')) ?></label>
            <input class="input" name="api_entitlement_key" value="<?= e($entitlementKey) ?>" placeholder="<?= e(t('api_entitlement_key_hint')) ?>" />
            <div class="note"><?= e(t('api_entitlement_key_tip')) ?></div>
          </div>

          <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end;">
            <button class="admin-btn primary" type="submit"><?= e(t('save')) ?></button>
          </div>
        </form>

        <form method="post" style="margin-top:10px;display:flex;justify-content:flex-end" onsubmit="return confirm(<?= json_encode(t('api_generate_master_confirm')) ?>);">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="generate_master" />
          <button class="admin-btn" type="submit"><?= e(t('api_generate_key')) ?></button>
        </form>

        <form method="post" style="margin-top:10px;display:flex;justify-content:flex-end" onsubmit="return confirm(<?= json_encode(t('api_generate_entitlement_confirm')) ?>);">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="generate_entitlement" />
          <button class="admin-btn" type="submit"><?= e(t('api_generate_entitlement_key')) ?></button>
        </form>
      </div>

      <div class="admin-card pad admin-fade" style="margin-top:14px;">
        <div style="font-weight:700;margin-bottom:10px;"><?= e(t('api_examples')) ?></div>
        <div class="muted" style="margin-bottom:10px;"><?= e($baseApi) ?></div>

        <pre style="margin:0;white-space:pre-wrap;overflow:auto;background:rgba(0,0,0,.03);border:1px solid rgba(0,0,0,.08);padding:12px;border-radius:12px;"><code><?= e(
"# public read (if enabled)\n" .
"curl \"{$baseApi}?resource=forums\"\n\n" .
"# read with master key\n" .
"curl -H \"X-API-Key: {$masterKey}\" \"{$baseApi}?resource=posts&type=forum&limit=10\"\n\n" .
"# entitlement check (paid/groups)\n" .
"curl -H \"X-API-Key: {$entitlementKey}\" \"{$baseApi}?resource=entitlement&user=admin\"\n\n" .
"# update custom css\n" .
"curl -H \"X-API-Key: {$masterKey}\" -H \"Content-Type: application/json\" \\\n" .
"  -d '{\"css\":\"body{background:#fff}\"}' \"{$baseApi}?resource=custom_css\"\n"
) ?></code></pre>
      </div>
    </main>
  </div>

  <?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
