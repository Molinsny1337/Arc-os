<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/init.php';
require_installed();
require_login();
if (!is_admin()) { http_response_code(403); die('Forbidden'); }
require_post();
require_csrf();

$pdo = db();
$pfx = table_prefix();
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$action = (string)($_POST['action'] ?? '');
$back = $_SERVER['HTTP_REFERER'] ?? (base_path() . '/forum_post.php?id=' . $id);

if ($id <= 0) { header('Location: ' . $back); exit; }

try {
  if ($action === 'toggle_sticky') {
    $pdo->prepare("UPDATE {$pfx}posts SET is_sticky = 1 - is_sticky WHERE id=? AND type='forum'")->execute([$id]);
  } elseif ($action === 'toggle_lock') {
    $pdo->prepare("UPDATE {$pfx}posts SET is_locked = 1 - is_locked WHERE id=? AND type='forum'")->execute([$id]);
  }
} catch (Throwable $e) {}

header('Location: ' . $back);
exit;
