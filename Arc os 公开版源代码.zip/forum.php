<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/includes/modules/forum/ForumRepository.php';
require_once __DIR__ . '/includes/services/LayoutService.php';
require_once __DIR__ . '/includes/services/ReadStateService.php';
$forumRepo = new ArcOS\Modules\Forum\ForumRepository($pdo, $pfx);
$forums = $forumRepo->fetchNodes();
$latest = $forumRepo->fetchLatestThreads(12);
$latestMembers = $forumRepo->fetchLatestMembers(6);
$stats = $forumRepo->fetchStats();
$me = current_user();
$meId = (int)($me['id'] ?? 0);
$forumIds = array_map(function(array $r): int { return (int)($r['id'] ?? 0); }, $forums);
$readMap = $meId > 0 ? ArcOS\Services\ReadStateService::forumMap($pdo, $pfx, $meId, $forumIds) : [];

$title = site_name() . ' - ' . t('forum');
$layoutItems = arc_get_layout_setting_items('forum_layout', arc_forum_layout_default_items(), arc_forum_layout_allowed_ids());
$layoutService = new ArcOS\Services\LayoutService($pdo, $pfx);
$layoutConfig = $layoutService->getLayout('forum_home');
$layoutHidden = is_array($layoutConfig['hidden'] ?? null) ? $layoutConfig['hidden'] : [];
$layoutSidebarOrder = is_array($layoutConfig['blocks']['sidebar'] ?? null) ? $layoutConfig['blocks']['sidebar'] : [];
$layoutMainOrder = is_array($layoutConfig['blocks']['main'] ?? null) ? $layoutConfig['blocks']['main'] : [];
$sidebarWidth = $layoutService->sidebarWidth($layoutConfig, 280);
$__need_ui_layout = is_admin();
$__need_glass = true;
$__need_tooltip = true;
$langCode = function_exists('lang') ? lang() : 'zh-CN';
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body data-page-key="forum_home">
  <?php include __DIR__ . '/partials/nav.php'; ?>

<?php
  $layoutCanEdit = is_admin() ? '1' : '0';
  $layoutDefault = json_encode(arc_forum_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutDefault)) $layoutDefault = '[]';
  $layoutLabels = [];
  foreach (arc_forum_layout_allowed_ids() as $id) $layoutLabels[$id] = t('block_' . $id);
  $layoutLabelsJson = json_encode($layoutLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutLabelsJson)) $layoutLabelsJson = '{}';
  $layoutUi = [
    'edit' => t('layout_edit'),
    'done' => t('layout_done'),
    'reset' => t('reset'),
    'blocks' => t('layout_blocks'),
    'saved' => t('layout_saved'),
    'save_failed' => t('layout_save_failed'),
    'hide' => t('hide'),
    'show' => t('show'),
  ];
  $layoutUiJson = json_encode($layoutUi, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($layoutUiJson)) $layoutUiJson = '{}';

  $forumMainBlocks = [];
  $heroBlock = '';
  foreach ($layoutItems as $it) {
    $sid = (string)($it['id'] ?? '');
    $enabled = (bool)($it['enabled'] ?? true);
    if ($sid === '') continue;

    if ($sid === 'hero') {
      ob_start();
      ?>
      <header class="hero xf-hero reveal-group" data-arc-layout-item="1" data-id="hero" <?= $enabled ? '' : 'hidden' ?>>
        <div>
          <h1 class="reveal"><?= e(t('forum')) ?></h1>
          <p class="reveal"><?= e(t('forum_sub')) ?></p>
          <div class="xf-hero-actions reveal">
            <a class="btn primary" href="<?= e(url('forum_new.php')) ?>"><?= e(t('new_topic')) ?></a>
            <a class="btn" href="<?= e(url('members.php')) ?>"><?= e(t('members')) ?></a>
          </div>
        </div>
        <div class="card glass xf-hero-card reveal">
          <h3><?= e(t('new_topic')) ?></h3>
          <p><?= e(t('be_first')) ?></p>
          <a class="btn primary" href="<?= e(url('forum_new.php')) ?>"><?= e(t('new_topic')) ?></a>
        </div>
      </header>
      <?php
      $heroBlock = ob_get_clean();
    } elseif ($sid === 'forum_nodes') {
      ob_start();
      ?>
      <section class="section reveal-group layout-block" data-arc-layout-item="1" data-id="forum_nodes" data-block-id="main.forum_nodes" data-block-label="<?= e(t('forum_nodes')) ?>" <?= $enabled ? '' : 'hidden' ?>>
        <div class="card glass reveal">
          <div class="xf-section-head">
            <h2 class="section-title"><?= e(t('forum_nodes')) ?></h2>
            <a class="btn" href="<?= e(url('forum_new.php')) ?>"><?= e(t('new_topic')) ?></a>
          </div>
          <?php $nodes = $forums; $readMap = $readMap; include __DIR__ . '/partials/xf/node_list.php'; ?>
        </div>
      </section>
      <?php
      $forumMainBlocks['main.forum_nodes'] = ob_get_clean();
    } elseif ($sid === 'forum_latest') {
      ob_start();
      ?>
      <section class="section reveal-group layout-block" data-arc-layout-item="1" data-id="forum_latest" data-block-id="main.forum_latest" data-block-label="<?= e(t('latest_topics')) ?>" <?= $enabled ? '' : 'hidden' ?>>
        <div class="card glass reveal">
          <div class="xf-section-head">
            <h2 class="section-title"><?= e(t('latest_topics')) ?></h2>
            <a class="btn" href="<?= e(url('whats_new.php')) ?>"><?= e(t('whats_new')) ?></a>
          </div>
          <?php $threads = $latest; include __DIR__ . '/partials/xf/thread_list.php'; ?>
        </div>
      </section>
      <?php
      $forumMainBlocks['main.forum_latest'] = ob_get_clean();
    }
  }

  $forumMainBlocks = $layoutService->applyBlocks($forumMainBlocks, $layoutMainOrder, $layoutHidden);

  $sidebarBlocks = [];
  ob_start();
  ?>
  <div class="card glass reveal layout-block" data-block-id="sidebar.nodes" data-block-label="<?= e(t('forum_nodes')) ?>">
    <div class="xf-section-head">
      <h3 style="margin:0;font-size:14px"><?= e(t('forum_nodes')) ?></h3>
      <a class="btn" href="<?= e(url('forum_new.php')) ?>"><?= e(t('new_topic')) ?></a>
    </div>
    <?php $nodes = $forums; $readMap = $readMap; include __DIR__ . '/partials/xf/node_list.php'; ?>
  </div>
  <?php
  $sidebarBlocks['sidebar.nodes'] = ob_get_clean();

  ob_start();
  ?>
  <div class="card glass reveal layout-block" data-block-id="sidebar.search" data-block-label="<?= e(t('search')) ?>">
    <h3 style="margin:0 0 10px;font-size:14px"><?= e(t('search')) ?></h3>
    <form method="get" action="<?= e(url('search.php')) ?>" class="xf-search">
      <input class="input" name="q" placeholder="<?= e(t('search_placeholder')) ?>" />
      <button class="btn" type="submit"><?= e(t('search')) ?></button>
    </form>
  </div>
  <?php
  $sidebarBlocks['sidebar.search'] = ob_get_clean();

  ob_start();
  ?>
  <div class="card glass reveal layout-block" data-block-id="sidebar.members" data-block-label="<?= e(t('members')) ?>">
    <div class="xf-section-head">
      <h3 style="margin:0;font-size:14px"><?= e(t('members')) ?></h3>
      <a class="btn" href="<?= e(url('members.php')) ?>"><?= e(t('all')) ?></a>
    </div>
    <div class="xf-stack">
      <?php foreach ($latestMembers as $m): ?>
        <?php $user = $m; include __DIR__ . '/partials/xf/user_card.php'; ?>
      <?php endforeach; ?>
      <?php if (!$latestMembers): ?>
        <div class="xf-member-row">
          <span class="xf-avatar">?</span>
          <span>
            <div class="xf-node-title"><?= e(t('no_data')) ?></div>
            <div class="xf-meta"><?= e(t('members_sub')) ?></div>
          </span>
        </div>
      <?php endif; ?>
    </div>
  </div>
  <?php
  $sidebarBlocks['sidebar.members'] = ob_get_clean();

  ob_start();
  ?>
  <div class="card glass reveal layout-block" data-block-id="sidebar.stats" data-block-label="<?= e(t('stats')) ?>">
    <div class="xf-section-head">
      <?php $statsLabel = t('stats'); if ($statsLabel === 'stats') $statsLabel = '今日统计'; ?>
      <h3 style="margin:0;font-size:14px"><?= e($statsLabel) ?></h3>
    </div>
    <div class="xf-stack">
      <div class="xf-thread-row">
        <span class="xf-avatar" aria-hidden="true">T</span>
        <div style="min-width:0">
          <div class="xf-node-title"><?= e(t('threads')) ?></div>
          <?php $todayLabel = t('today'); if ($todayLabel === 'today') $todayLabel = '今日'; ?>
          <div class="xf-meta"><?= e($todayLabel) ?>: <?= (int)($stats['threads_today'] ?? 0) ?></div>
        </div>
        <div class="xf-stats"><strong><?= (int)($stats['threads_total'] ?? 0) ?></strong></div>
      </div>
      <div class="xf-thread-row">
        <span class="xf-avatar" aria-hidden="true">R</span>
        <div style="min-width:0">
          <div class="xf-node-title"><?= e(t('replies')) ?></div>
          <div class="xf-meta"><?= e($todayLabel) ?>: <?= (int)($stats['replies_today'] ?? 0) ?></div>
        </div>
        <div class="xf-stats"><strong><?= (int)($stats['replies_total'] ?? 0) ?></strong></div>
      </div>
      <div class="xf-thread-row">
        <span class="xf-avatar" aria-hidden="true">U</span>
        <div style="min-width:0">
          <div class="xf-node-title"><?= e(t('members')) ?></div>
          <div class="xf-meta"><?= e($todayLabel) ?>: <?= (int)($stats['members_today'] ?? 0) ?></div>
        </div>
        <div class="xf-stats"><strong><?= (int)($stats['members_total'] ?? 0) ?></strong></div>
      </div>
    </div>
  </div>
  <?php
  $sidebarBlocks['sidebar.stats'] = ob_get_clean();

  $sidebarBlocks = $layoutService->applyBlocks($sidebarBlocks, $layoutSidebarOrder, $layoutHidden);
?>

<main class="wrap xf-apple xf-forum-page"
  data-arc-layout-root="1"
  data-arc-can-edit="<?= e($layoutCanEdit) ?>"
  data-arc-layout-scope="forum_global"
  data-arc-save-url="<?= e(url('layout_save.php')) ?>"
  data-arc-csrf="<?= e(csrf_token()) ?>"
  data-arc-default="<?= e($layoutDefault) ?>"
  data-arc-labels="<?= e($layoutLabelsJson) ?>"
  data-arc-ui="<?= e($layoutUiJson) ?>"
>
  <?= $heroBlock ?>

  <div class="xf-layout" style="--sidebar-w: <?= (int)$sidebarWidth ?>px;">
    <aside class="xf-sidebar reveal-group" data-layout-zone="sidebar">
      <?php foreach ($sidebarBlocks as $block) { echo $block; } ?>
    </aside>
    <div class="layout-resizer" aria-hidden="true"></div>
    <div class="xf-main reveal-group" data-layout-zone="main">
      <?php foreach ($forumMainBlocks as $block) { echo $block; } ?>
    </div>
  </div>
</main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>



