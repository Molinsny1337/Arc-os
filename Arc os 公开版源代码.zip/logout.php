<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

arc_log('logout','user',(int)(current_user()['id'] ?? 0));
logout_now();
redirect(url('transition.php') . '?msg=' . urlencode('Signed out') . '&to=' . urlencode(url('index.php')));
