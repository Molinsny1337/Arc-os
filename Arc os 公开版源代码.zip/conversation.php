<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$me = current_user();
if (!$me) redirect(url('login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? url('conversations.php'))));
require_not_banned();
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';
require_once __DIR__ . '/includes/services/UploadService.php';

$pdo = db();
$pfx = table_prefix();
require_once __DIR__ . '/includes/conversations.php';

$cid = (int)($_GET['id'] ?? 0);
if ($cid <= 0 || !conv_user_can_access($pdo, $pfx, $cid, (int)$me['id'])) {
  http_response_code(404);
  $title = t('not_found');
  $__need_glass = true;
  include __DIR__ . '/partials/page_top.php';
  echo '<main class="wrap"><header class="hero reveal-group"><h1 class="reveal">' . e(t('not_found')) . '</h1></header></main>';
  include __DIR__ . '/partials/page_bottom.php';
  exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_post();
  require_csrf();
  arc_rate_limit('conv_reply', 60, 60);

  $msg = ArcOS\Services\BbCode::normalize((string)($_POST['message'] ?? ''));
  if ($msg !== '') {
    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}conversation_messages (conversation_id, user_id, message, created_at) VALUES (?,?,?,NOW())");
      $stmt->execute([$cid, (int)$me['id'], $msg]);
      $mid = (int)$pdo->lastInsertId();
      $pdo->prepare("UPDATE {$pfx}conversations SET last_message_id=?, last_message_at=NOW() WHERE id=?")->execute([$mid, $cid]);

      $draftKey = trim((string)($_POST['draft_key'] ?? ''));
      if ($draftKey !== '') {
        ArcOS\Services\UploadService::attachDraft($pdo, $pfx, (int)$me['id'], $draftKey, 'conversation', $mid);
      }
      ArcOS\Services\MentionService::syncMentions($pdo, $pfx, (int)$me['id'], 'conversation', $mid, $msg);
      $tags = ArcOS\Services\MentionService::extractTags($msg);
      ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'conversation', $mid, $tags);

      $ps = conv_participants($pdo, $pfx, $cid);
      foreach ($ps as $p) {
        $uid = (int)($p['id'] ?? 0);
        if ($uid > 0 && $uid !== (int)$me['id']) {
          arc_add_alert($uid, 'conversation_reply', $cid, (string)$me['username'], null);
        }
      }
      redirect(url('conversation.php?id=' . $cid));
    } catch (Throwable $e) {
      $err = t('send_failed');
    }
  }
}

// load conversation
$conv = null;
try {
  $stmt = $pdo->prepare("SELECT * FROM {$pfx}conversations WHERE id=? LIMIT 1");
  $stmt->execute([$cid]);
  $conv = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Throwable $e) {}

$participants = conv_participants($pdo, $pfx, $cid);
$messages = [];
try {
  $stmt = $pdo->prepare("SELECT m.*, u.username,u.display_name,u.avatar
    FROM {$pfx}conversation_messages m
    JOIN {$pfx}users u ON u.id=m.user_id
    WHERE m.conversation_id=? ORDER BY m.id ASC LIMIT 200");
  $stmt->execute([$cid]);
  $messages = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$pageTitle = $conv ? trim((string)($conv['title'] ?? '')) : '';
if ($pageTitle === '') $pageTitle = t('conversation') . ' #' . $cid;
$title = site_name() . ' - ' . $pageTitle;
$__need_glass = true;
$__need_editor = true;
?>
<?php include __DIR__ . '/partials/page_top.php'; ?>

<main class="wrap">
  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e($pageTitle) ?></h1>
      <p class="reveal xf-meta">
      <?= e(t('participants')) ?>:
      <?php foreach ($participants as $i => $p): ?>
        <?= $i ? ', ' : '' ?><a data-transition="off" href="<?= e(url('user.php?id=' . (int)$p['id'])) ?>"><?= e(display_name_of($p)) ?></a>
      <?php endforeach; ?>
      </p>
    </div>
    <div class="card glass xf-hero-card reveal">
      <div class="xf-meta"><?= e(t('messages')) ?>: <?= count($messages) ?></div>
    </div>
  </header>

  <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>

  <section class="section reveal-group">
    <div class="card glass reveal">
      <div class="xf-stack">
        <?php foreach ($messages as $m): ?>
          <?php $isMine = $me && (int)($m['user_id'] ?? 0) === (int)$me['id']; ?>
          <div class="xf-message<?= $isMine ? ' is-mine' : '' ?>">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:center">
              <div style="font-weight:700"><?= e(display_name_of($m)) ?></div>
              <div class="xf-meta"><?= e((string)($m['created_at'] ?? '')) ?></div>
            </div>
            <div style="margin-top:8px"><?= ArcOS\Services\BbCode::render((string)($m['message'] ?? ''), $pdo, $pfx) ?></div>
          </div>
        <?php endforeach; ?>
        <?php if (!$messages): ?><div class="muted"><?= e(t('no_data')) ?></div><?php endif; ?>
      </div>
    </div>
  </section>

  <section class="section reveal-group">
    <form class="form glass reveal" method="post" data-overlay="1">
      <?= csrf_field() ?>
      <div class="field">
        <label class="label"><?= e(t('reply')) ?></label>
        <?php
          $draftKey = 'conv_reply_' . (int)$cid . '_' . (int)($me['id'] ?? 0);
          $content_name = 'message';
          $initial_value = '';
          $mode = 'conversation';
          $attachments_enabled = true;
          $placeholder = t('content_placeholder');
          $content_id = (int)$cid;
          $draft_key = $draftKey;
          include __DIR__ . '/partials/editor/editor_widget.php';
        ?>
      </div>
      <button class="btn" type="submit"><?= e(t('send')) ?></button>
    </form>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
