<?php
declare(strict_types=1);
// Transition page must also work BEFORE installation.
// Therefore we only load full init (DB/settings) when installed.
require_once __DIR__ . '/includes/bootstrap.php';

$installed = is_installed();
if ($installed) {
  require_once __DIR__ . '/includes/init.php';
}

$to = $_GET['to'] ?? url('index.php');
$hello = $_GET['hello'] ?? '';
$msg = $_GET['msg'] ?? '';

// only allow same-origin relative URLs (very simple hardening)
$parsed = parse_url($to);
if (!empty($parsed['scheme']) || !empty($parsed['host'])) {
  $to = url('index.php');
}
// normalize: allow absolute path or relative
if (!str_starts_with($to, '/')) {
  $to = '/' . ltrim($to, '/');
  // base_path() exists in bootstrap.php (works pre-install too)
  $to = base_path() . $to;
}

// Display text
// Settings are available only after install.
if ($installed && function_exists('get_setting')) {
  $helloTpl = (string)get_setting('transition_hello_tpl', t('transition_hello_tpl_default'));
  $brandText = $hello !== '' ? tpl_render($helloTpl, ['name' => $hello]) : site_name();
  $hintText = (string)get_setting('transition_hint_text', t('transition_entering'));
  $minShow = (int)get_setting('transition_min_show_ms', '1200');
} else {
  // Pre-install fallback
  $brandText = $hello !== '' ? tpl_render(t('transition_hello_tpl_default'), ['name' => $hello]) : 'Arc OS';
  $hintText = $msg !== '' ? $msg : t('transition_entering');
  $minShow = 900;
}


// Optional click-origin for ripple
$x = null;
$y = null;
if (isset($_GET['x'], $_GET['y'])) {
  $rx = filter_var($_GET['x'], FILTER_VALIDATE_INT, ['options' => ['default' => null]]);
  $ry = filter_var($_GET['y'], FILTER_VALIDATE_INT, ['options' => ['default' => null]]);
  if ($rx !== null && $ry !== null) {
    // Clamp to a sane range (viewport-sized pixels)
    $x = max(0, min((int)$rx, 10000));
    $y = max(0, min((int)$ry, 10000));
  }
}

$styleVars = '';
if ($x !== null && $y !== null) {
  $styleVars = '--x: ' . $x . 'px; --y: ' . $y . 'px;';
}


?>
<!doctype html>
<html lang="<?= e(lang()) ?>" data-min-show="<?= (int)$minShow ?>"<?= $styleVars !== '' ? (' style="' . e($styleVars) . '"') : '' ?>>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <meta name="color-scheme" content="dark light" />
  <meta name="theme-color" content="#0b0b0c" />
  <title><?= e($hintText !== '' ? $hintText : t('transition_entering')) ?></title>
  <style>
    :root{
      --ease: cubic-bezier(.16,1,.3,1);
      --bg: #0b0b0c;
      --ink: rgba(245,245,247,.92);
      --paper: #ffffff;
      --dot: 12px;
      --scale: 220;
      --x: 50vw;
      --y: 50vh;
    }
    html{ background: var(--bg); }
    html,body{ height:100%; }
    body{
      margin:0;
      background: var(--bg);
      overflow:hidden;
      font-family: -apple-system, BlinkMacSystemFont, "Inter", "SF Pro Display", "Segoe UI", sans-serif;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    .stage{
      position:fixed;
      inset:0;
      display:grid;
      place-items:center;
      text-align:center;
      color: var(--ink);
      z-index:3;
      transition: opacity .35s var(--ease), transform .35s var(--ease);
      will-change: opacity, transform;
      pointer-events:none;
    }
    .brand{
      font-size: 20px;
      font-weight: 560;
      letter-spacing: .02em;
      animation: breathe 1.2s ease-in-out infinite;
    }
    .hint{
      margin-top: 10px;
      font-size: 12px;
      opacity: .55;
      letter-spacing: .10em;
      
    }
    @keyframes breathe{
      0%,100%{ opacity: .62; transform: scale(.985); }
      50%{ opacity: 1; transform: scale(1); }
    }
    .wipe{
      position:fixed;
      left: var(--x);
      top: var(--y);
      width: var(--dot);
      height: var(--dot);
      border-radius: 999px;
      transform: translate(-50%,-50%) scale(0.001);
      opacity: 0;
      pointer-events:none;
      will-change: transform, opacity;
      z-index:2;
    }
    .wipe.fill{ background: var(--paper); }
    .wipe.wave{
      z-index:1;
      background: radial-gradient(circle,
        rgba(255,255,255,0) 56%,
        rgba(255,255,255,.55) 64%,
        rgba(255,255,255,0) 72%);
    }

    body.go .stage{
      opacity: 0;
      transform: translateY(-6px);
    }
    body.go .wipe.fill{
      opacity: 1;
      animation: fill 820ms var(--ease) forwards;
    }
    body.go .wipe.wave{
      opacity: 1;
      animation: wave 920ms var(--ease) forwards;
    }

    @keyframes fill{
      from { transform: translate(-50%,-50%) scale(0.001); }
      to   { transform: translate(-50%,-50%) scale(var(--scale)); }
    }
    @keyframes wave{
      0%   { opacity: .55; transform: translate(-50%,-50%) scale(0.001); }
      60%  { opacity: .20; }
      100% { opacity: 0; transform: translate(-50%,-50%) scale(calc(var(--scale) * 1.06)); }
    }

    @media (prefers-reduced-motion: reduce){
      .brand{ animation: none; }
      .stage{ transition: none !important; }
      body.go .wipe{ animation: none !important; opacity: 0 !important; }
    }
  </style>
</head>
<body>
  <div class="stage" aria-label="<?= e(t('transition_entering_aria')) ?>">
    <div>
      <div class="brand" id="brand"><?= e($brandText) ?></div>
      <div class="hint" id="hint"><?= e($hintText) ?></div>
    </div>
  </div>
  <div class="wipe fill" aria-hidden="true"></div>
  <div class="wipe wave" aria-hidden="true"></div>

  <script>
    (function(){
      const to = <?= json_encode($to, JSON_UNESCAPED_SLASHES) ?>;

      function setScale(){
        const dot = 12;
        const diag = Math.hypot(innerWidth, innerHeight);
        const scale = (diag / dot) + 2;
        document.documentElement.style.setProperty("--scale", scale.toFixed(2));
      }
      setScale();
      addEventListener("resize", setScale);

      // small prefetch hint
      try {
        const u = new URL(to, location.href);
        const pre = document.createElement("link");
        pre.rel = "prefetch";
        u.hash = "";
        pre.href = u.href;
        document.head.appendChild(pre);
      } catch {}

      const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reduce) { location.replace(to); return; }

      const boot = performance.now();
      const MIN_SHOW_MS = parseInt(document.documentElement.dataset.minShow || '1200',10);
      const REVEAL_MS = 920;

      function start(){
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            document.body.classList.add("go");
            setTimeout(() => location.replace(to), REVEAL_MS);
          });
        });
      }

      addEventListener("load", () => {
        const elapsed = performance.now() - boot;
        const delay = Math.max(0, MIN_SHOW_MS - elapsed);
        setTimeout(start, delay);
      });
    })();
  </script>
</body>
</html>
