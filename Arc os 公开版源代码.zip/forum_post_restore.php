<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

require_once __DIR__ . '/includes/services/Permission.php';

$perm = new ArcOS\Services\Permission();
$me = current_user();
$meId = (int)($me['id'] ?? 0);

$id = (int)($_POST['id'] ?? 0);
$back = $_SERVER['HTTP_REFERER'] ?? url('forum.php');
if ($id <= 0) redirect($back);

$pdo = db();
$pfx = table_prefix();

$stmt = $pdo->prepare("SELECT id, author_id, forum_id, slug FROM {$pfx}posts WHERE id=? AND type='forum' LIMIT 1");
$stmt->execute([$id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) redirect($back);

$authorId = (int)($post['author_id'] ?? 0);
$forumId = (int)($post['forum_id'] ?? 0);

$canRestore = ($perm->can($me, 'delete_own_post') && $authorId === $meId) || is_admin();
if (!$canRestore) {
  http_response_code(403);
  exit('Forbidden');
}

try {
  $pdo->prepare("UPDATE {$pfx}posts SET is_deleted=0, deleted_by=NULL, deleted_at=NULL, delete_reason=NULL WHERE id=?")
    ->execute([$id]);
} catch (Throwable $e) {}

// Rebuild forum stats
if ($forumId > 0) {
  try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE type='forum' AND forum_id=? AND is_deleted=0");
    $stmt->execute([$forumId]);
    $threadCount = (int)($stmt->fetchColumn() ?: 0);

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments c
      JOIN {$pfx}posts p ON p.id=c.post_id
      WHERE p.forum_id=? AND p.type='forum' AND p.is_deleted=0 AND c.is_deleted=0 AND c.status='visible'");
    $stmt->execute([$forumId]);
    $msgCount = (int)($stmt->fetchColumn() ?: 0);

    $stmt = $pdo->prepare("SELECT id, last_post_at, last_post_user_id FROM {$pfx}posts
      WHERE type='forum' AND forum_id=? AND is_deleted=0
      ORDER BY COALESCE(last_post_at, created_at) DESC LIMIT 1");
    $stmt->execute([$forumId]);
    $lastThread = $stmt->fetch(PDO::FETCH_ASSOC);

    $pdo->prepare("UPDATE {$pfx}forums
      SET thread_count=?, message_count=?, last_post_at=?, last_post_id=?, last_post_user_id=?
      WHERE id=?")
      ->execute([
        $threadCount,
        $msgCount,
        $lastThread ? (string)($lastThread['last_post_at'] ?? '') : null,
        $lastThread ? (int)($lastThread['id'] ?? 0) : null,
        $lastThread ? (int)($lastThread['last_post_user_id'] ?? 0) : null,
        $forumId,
      ]);
  } catch (Throwable $e) {}
}

redirect(url('forum_post.php?slug=' . urlencode((string)($post['slug'] ?? ''))));
