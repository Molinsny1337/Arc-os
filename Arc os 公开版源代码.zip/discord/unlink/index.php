<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();

$me = current_user();
$pdo = db();
$pfx = table_prefix();

try {
  $stmt = $pdo->prepare("DELETE FROM {$pfx}xf_user_discord WHERE user_id=?");
  $stmt->execute([(int)$me['id']]);
} catch (Throwable $e) {}

redirect(url('account.php'));
