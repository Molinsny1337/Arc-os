<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/init.php';
require_installed();

require_once __DIR__ . '/../../includes/services/DiscordOAuthService.php';
require_once __DIR__ . '/../../includes/services/DiscordApiClient.php';
require_once __DIR__ . '/../../includes/services/CryptoService.php';
require_once __DIR__ . '/../../includes/services/DiscordWebhookService.php';

$title = 'Discord';
$langCode = function_exists('lang') ? lang() : 'zh-CN';

$error = (string)($_GET['error'] ?? '');
$code = (string)($_GET['code'] ?? '');
$state = (string)($_GET['state'] ?? '');

if ($error !== '') {
  $msg = (string)($_GET['error_description'] ?? $error);
  include __DIR__ . '/../../partials/page_top.php';
  echo '<main class="wrap" style="padding:40px 0"><div class="card" style="padding:20px">';
  echo '<h1 style="margin:0 0 8px">Discord error</h1>';
  echo '<p style="color:var(--muted);margin:0">' . e($msg) . '</p>';
  echo '</div></main>';
  include __DIR__ . '/../../partials/page_bottom.php';
  exit;
}

if ($code === '' || $state === '') {
  http_response_code(400);
  exit('Invalid request');
}

$sessState = (string)($_SESSION['discord_oauth_state'] ?? '');
if ($sessState === '' || !hash_equals($sessState, $state)) {
  http_response_code(403);
  exit('Invalid state');
}

$me = current_user();
$bindMode = ($me !== null) || (($_SESSION['discord_oauth_bind'] ?? '') === '1');
$next = (string)($_SESSION['discord_oauth_next'] ?? '');

unset($_SESSION['discord_oauth_state'], $_SESSION['discord_oauth_time'], $_SESSION['discord_oauth_bind']);

try {
  $token = ArcOS\Services\DiscordOAuthService::exchangeCode($code);
  $client = new ArcOS\Services\DiscordApiClient(8);
  $user = $client->get('/users/@me', [
    'Authorization' => 'Bearer ' . $token['access_token'],
  ]);

  $discordId = (string)($user['id'] ?? '');
  $discordUsername = (string)($user['username'] ?? '');
  $discordDiscriminator = (string)($user['discriminator'] ?? '');
  $discordAvatar = (string)($user['avatar'] ?? '');
  $discordEmail = (string)($user['email'] ?? '');
  $globalName = (string)($user['global_name'] ?? '');

  if ($discordId === '' || $discordUsername === '') {
    throw new RuntimeException('Discord user info missing.');
  }

  $pdo = db();
  $pfx = table_prefix();

  $accessEnc = ArcOS\Services\CryptoService::encrypt($token['access_token']);
  $refreshEnc = ArcOS\Services\CryptoService::encrypt($token['refresh_token']);
  if ($accessEnc === '' || $refreshEnc === '') {
    throw new RuntimeException('Token encryption failed.');
  }

  $expiresAt = gmdate('Y-m-d H:i:s', time() + (int)$token['expires_in']);

  $find = $pdo->prepare("SELECT user_id FROM {$pfx}xf_user_discord WHERE discord_user_id=? LIMIT 1");
  $find->execute([$discordId]);
  $boundUserId = (int)($find->fetchColumn() ?: 0);

  if ($bindMode && $me) {
    if ($boundUserId > 0 && $boundUserId !== (int)$me['id']) {
      throw new RuntimeException('This Discord account is already linked to another user.');
    }

    $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_user_discord
      (user_id, discord_user_id, discord_username, discord_discriminator, discord_avatar, discord_email, access_token_enc, refresh_token_enc, token_expires_at, connected_at, last_sync_at)
      VALUES (?,?,?,?,?,?,?,?,?,NOW(),NOW())
      ON DUPLICATE KEY UPDATE
        discord_user_id=VALUES(discord_user_id),
        discord_username=VALUES(discord_username),
        discord_discriminator=VALUES(discord_discriminator),
        discord_avatar=VALUES(discord_avatar),
        discord_email=VALUES(discord_email),
        access_token_enc=VALUES(access_token_enc),
        refresh_token_enc=VALUES(refresh_token_enc),
        token_expires_at=VALUES(token_expires_at),
        last_sync_at=NOW()");
    $stmt->execute([
      (int)$me['id'],
      $discordId,
      $discordUsername,
      $discordDiscriminator !== '0' ? $discordDiscriminator : null,
      $discordAvatar !== '' ? $discordAvatar : null,
      $discordEmail !== '' ? $discordEmail : null,
      $accessEnc,
      $refreshEnc,
      $expiresAt,
    ]);

    $to = url('account.php');
    redirect(url('transition.php') . '?hello=' . urlencode((string)($me['username'] ?? '')) . '&msg=' . urlencode('Discord linked') . '&to=' . urlencode($to));
  }

  if ($boundUserId > 0) {
    // login bound user
    $stmt = $pdo->prepare("SELECT id, username, display_name, email, role, is_verified, can_post, avatar, notify_likes, notify_profile_comments FROM {$pfx}users WHERE id=? LIMIT 1");
    $stmt->execute([$boundUserId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new RuntimeException('Account not found.');

    @session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$row['id'];
    $_SESSION['username'] = (string)$row['username'];
    $_SESSION['display_name'] = (string)($row['display_name'] ?? '');
    $_SESSION['email'] = (string)$row['email'];
    $_SESSION['role'] = (string)$row['role'];
    $_SESSION['is_verified'] = (int)$row['is_verified'];
    $_SESSION['can_post'] = (int)$row['can_post'];
    $_SESSION['avatar'] = (string)($row['avatar'] ?? '');
    $_SESSION['notify_likes'] = (int)($row['notify_likes'] ?? 0);
    $_SESSION['notify_profile_comments'] = (int)($row['notify_profile_comments'] ?? 0);
    if (in_array(($row['role'] ?? ''), ['admin','superadmin'], true)) {
      $_SESSION['can_post'] = 1;
      $_SESSION['is_verified'] = 1;
    }
    if (defined('APP_KEY') && APP_KEY !== '') {
      $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
    }

    $to = $next !== '' ? $next : url('index.php');
    redirect(url('transition.php') . '?hello=' . urlencode((string)$row['username']) . '&msg=' . urlencode(t('welcome_title')) . '&to=' . urlencode($to));
  }

  // If email matches an existing account, ask user to login and bind
  if ($discordEmail !== '') {
    $stmt = $pdo->prepare("SELECT id, username FROM {$pfx}users WHERE email=? LIMIT 1");
    $stmt->execute([$discordEmail]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
      include __DIR__ . '/../../partials/page_top.php';
      echo '<main class="wrap" style="padding:40px 0">';
      echo '<div class="card" style="padding:20px">';
      echo '<h1 style="margin:0 0 8px">' . e(t('login')) . '</h1>';
      echo '<p style="color:var(--muted)">An account with this email already exists. Please login and link Discord from your account settings.</p>';
      echo '<div style="margin-top:12px"><a class="btn" href="' . e(url('login.php')) . '">' . e(t('login')) . '</a></div>';
      echo '</div></main>';
      include __DIR__ . '/../../partials/page_bottom.php';
      exit;
    }
  }

  if (get_setting('discord_allow_register', '1') !== '1') {
    throw new RuntimeException('Registration via Discord is disabled.');
  }

  $baseName = $globalName !== '' ? $globalName : $discordUsername;
  $baseName = preg_replace('/[^A-Za-z0-9_\-]/', '', $baseName) ?? '';
  if ($baseName === '' || strlen($baseName) < 3) {
    $baseName = 'discord' . substr($discordId, -6);
  }
  if (strlen($baseName) > 32) $baseName = substr($baseName, 0, 32);

  $username = $baseName;
  $i = 1;
  $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE username=? LIMIT 1");
  while (true) {
    $stmt->execute([$username]);
    if (!$stmt->fetchColumn()) break;
    $i++;
    $username = substr($baseName, 0, 26) . $i;
  }

  $displayName = $globalName !== '' ? $globalName : $discordUsername;
  if (strlen($displayName) > 32) $displayName = substr($displayName, 0, 32);

  $pwd = bin2hex(random_bytes(16));
  $isVerified = $discordEmail !== '' ? 1 : 0;

  $stmt = $pdo->prepare("INSERT INTO {$pfx}users (username, display_name, email, password_hash, role, is_verified, verify_token, can_post, created_at, updated_at)
    VALUES (?,?,?,?, 'user', ?, NULL, 0, NOW(), NOW())");
  $stmt->execute([$username, $displayName !== '' ? $displayName : null, $discordEmail, password_hash($pwd, PASSWORD_DEFAULT), $isVerified]);
  $newUserId = (int)$pdo->lastInsertId();

  $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_user_discord
    (user_id, discord_user_id, discord_username, discord_discriminator, discord_avatar, discord_email, access_token_enc, refresh_token_enc, token_expires_at, connected_at, last_sync_at)
    VALUES (?,?,?,?,?,?,?,?,?,NOW(),NOW())");
  $stmt->execute([
    $newUserId,
    $discordId,
    $discordUsername,
    $discordDiscriminator !== '0' ? $discordDiscriminator : null,
    $discordAvatar !== '' ? $discordAvatar : null,
    $discordEmail !== '' ? $discordEmail : null,
    $accessEnc,
    $refreshEnc,
    $expiresAt,
  ]);

  // Notify webhook for new user
  ArcOS\Services\DiscordWebhookService::send('user_registered', [
    'title' => 'New User',
    'author' => $username,
    'description' => 'Registered via Discord',
    'url' => site_url('user.php?id=' . $newUserId),
  ]);

  @session_regenerate_id(true);
  $_SESSION['user_id'] = $newUserId;
  $_SESSION['username'] = $username;
  $_SESSION['display_name'] = (string)$displayName;
  $_SESSION['email'] = (string)$discordEmail;
  $_SESSION['role'] = 'user';
  $_SESSION['is_verified'] = $isVerified;
  $_SESSION['can_post'] = 0;
  $_SESSION['avatar'] = '';
  $_SESSION['notify_likes'] = 0;
  $_SESSION['notify_profile_comments'] = 0;

  if (defined('APP_KEY') && APP_KEY !== '') {
    $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
  }

  $to = $next !== '' ? $next : url('index.php');
  redirect(url('transition.php') . '?hello=' . urlencode($username) . '&msg=' . urlencode(t('welcome_title')) . '&to=' . urlencode($to));
} catch (Throwable $e) {
  include __DIR__ . '/../../partials/page_top.php';
  echo '<main class="wrap" style="padding:40px 0"><div class="card" style="padding:20px">';
  echo '<h1 style="margin:0 0 8px">Discord</h1>';
  echo '<p style="color:var(--muted);margin:0">' . e($e->getMessage()) . '</p>';
  echo '</div></main>';
  include __DIR__ . '/../../partials/page_bottom.php';
}
