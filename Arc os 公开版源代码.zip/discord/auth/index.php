<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/init.php';
require_installed();

require_once __DIR__ . '/../../includes/services/DiscordOAuthService.php';

if (!ArcOS\Services\DiscordOAuthService::isConfigured()) {
  http_response_code(503);
  $title = 'Discord';
  include __DIR__ . '/../../partials/welcome_head.php';
  echo '<main class="wrap" style="padding:40px 0"><div class="card" style="padding:20px">';
  echo '<h1 style="margin:0 0 8px">Discord not configured</h1>';
  echo '<p style="color:var(--muted);margin:0">Please contact the administrator.</p>';
  echo '</div></main>';
  include __DIR__ . '/../../partials/welcome_footer.php';
  exit;
}

$me = current_user();
$next = (string)($_GET['next'] ?? ($_POST['next'] ?? ''));
if ($next !== '' && !str_starts_with($next, base_path())) {
  $next = '';
}
if ($next !== '') {
  $_SESSION['discord_oauth_next'] = $next;
}

$state = bin2hex(random_bytes(16));
$_SESSION['discord_oauth_state'] = $state;
$_SESSION['discord_oauth_time'] = time();
$_SESSION['discord_oauth_bind'] = $me ? '1' : '0';

$includeGuilds = trim((string)get_setting('discord_guild_id', '')) !== '';
$url = ArcOS\Services\DiscordOAuthService::authUrl($state, $includeGuilds);
if ($url === '') {
  http_response_code(500);
  exit('OAuth configuration error');
}

redirect($url);
