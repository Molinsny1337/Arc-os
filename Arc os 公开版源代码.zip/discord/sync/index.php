<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();

require_once __DIR__ . '/../../includes/services/DiscordRoleSyncService.php';

$me = current_user();
$pdo = db();
$pfx = table_prefix();

try {
  ArcOS\Services\DiscordRoleSyncService::syncUser($pdo, $pfx, (int)$me['id']);
} catch (Throwable $e) {}

redirect(url('account.php'));
