<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/DiscordOAuthService.php';
require_once __DIR__ . '/includes/services/DiscordWebhookService.php';

$title = t('register') . ' - ' . site_name();
$err = '';
$ok = '';
$verifyLink = '';
$discordEnabled = ArcOS\Services\DiscordOAuthService::isConfigured();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('register', 12, 600);
  $username = trim($_POST['username'] ?? '');
  $display_name = trim($_POST['display_name'] ?? '');
  $email = strtolower(trim((string)($_POST['email'] ?? '')));
  $password = (string)($_POST['password'] ?? '');

  try {
    if (turnstile_required('register')) {
      $token = (string)($_POST['cf-turnstile-response'] ?? '');
      if (!verify_turnstile($token)) {
        throw new RuntimeException(t('captcha_failed'));
      }
    }

    if ($username === '' || $email === '' || $password === '') {
      throw new RuntimeException(t('fill_all'));
    }
    if ($display_name !== '' && (mb_strlen($display_name, 'UTF-8') > 32 || preg_match('/\s/u', $display_name))) {
      throw new RuntimeException(t('invalid_display_name'));
    }
    if (strlen($password) < 8) {
      throw new RuntimeException(t('password_min8'));
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new RuntimeException(t('invalid_email'));
    }

    $pdo = db();
    $pfx = table_prefix();

    // Uniqueness checks (avoid leaking raw SQL errors to users)
    $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE username=? LIMIT 1");
    $st->execute([$username]);
    if ($st->fetchColumn()) throw new RuntimeException(t('username_taken'));

    $st = $pdo->prepare("SELECT 1 FROM {$pfx}users WHERE email=? LIMIT 1");
    $st->execute([$email]);
    if ($st->fetchColumn()) throw new RuntimeException(t('email_taken'));

    $token = bin2hex(random_bytes(16)); // 32 chars
    $stmt = $pdo->prepare("INSERT INTO {$pfx}users (username, display_name, email, password_hash, role, is_verified, verify_token, can_post, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'user', 0, ?, 0, NOW(), NOW())");
    $stmt->execute([$username, $display_name === '' ? null : $display_name, $email, password_hash($password, PASSWORD_DEFAULT), $token]);
    $userId = (int)$pdo->lastInsertId();

    try {
      ArcOS\Services\DiscordWebhookService::send('user_registered', [
        'title' => 'New User',
        'author' => $username,
        'description' => 'Registered via form',
        'url' => site_url('user.php?id=' . $userId),
        'content_id' => $userId,
      ]);
    } catch (Throwable $e) {}

    $verifyLink = url('verify.php') . '?token=' . urlencode($token);
    $subject = 'Verify your email';
    $body = "Hi {$username},\n\nPlease verify your email:\n{$verifyLink}\n\nIf you didn't sign up, ignore this email.";
    $headers = "Content-Type: text/plain; charset=UTF-8\r\n";

    $sent = false;
    try {
      $sent = send_mail($email, $subject, $body);
    } catch (Throwable $e) { $sent = false; }

    $ok = $sent ? ''.t('register_success_sent').'' : ''.t('register_success_fallback').'';
  } catch (Throwable $e) {
    // graceful duplicate key fallback (race condition)
    if ($e instanceof PDOException) {
      $info = $e->errorInfo ?? null;
      $errno = is_array($info) && isset($info[1]) ? (int)$info[1] : 0;
      $msg = (string)($info[2] ?? $e->getMessage());
      if ($errno === 1062) {
        if (stripos($msg, 'uniq_email') !== false) $err = t('email_taken');
        elseif (stripos($msg, 'uniq_username') !== false) $err = t('username_taken');
        else $err = t('fill_all');
      } else {
        $err = $e->getMessage();
      }
    } else {
      $err = $e->getMessage();
    }
  }
}
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <div class="overlay">
    <div class="overlay-card">
      <div class="title"><?= e(t('creating_account')) ?></div>
      <div class="sub"><?= e(t('please_wait')) ?></div>
    </div>
  </div>

  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('register_title')) ?></h1>
      <p class="reveal"><?= e(t('register_sub')) ?></p>
    </header>

    <?php if ($err): ?><div class="alert reveal"><?= e($err) ?></div><?php endif; ?>
    <?php if ($ok): ?><div class="admin-card pad reveal" style="max-width:560px;margin:0 auto;"><?= e($ok) ?></div><?php endif; ?>

    <?php if ($verifyLink): ?>
      <div class="form reveal" style="margin-top:12px;">
        <div class="label"><?= e(t('register_verify_link_label')) ?></div>
        <input class="input" value="<?= e($verifyLink) ?>" onclick="this.select()" readonly />
      </div>
    <?php endif; ?>

    <section class="reveal-group">
      <form class="form reveal" method="post" data-overlay="1">
        <?= csrf_field() ?>
        <div class="field">
          <label class="label"><?= e(t('username')) ?></label>
          <input class="input" name="username" placeholder="<?= e(t('register_username_placeholder')) ?>" />
        </div>
        <div class="field">
          <label class="label"><?= e(t('display_name_optional')) ?></label>
          <input class="input" name="display_name" placeholder="<?= e(t('display_name_placeholder')) ?>" />
        </div>
        <div class="field">
          <label class="label"><?= e(t('email')) ?></label>
          <input class="input" name="email" placeholder="name@example.com" />
        </div>
        <div class="field">
          <label class="label"><?= e(t('password')) ?> (>= 8)</label>
          <input class="input" type="password" name="password" placeholder="********" />
        </div>
        <button class="btn" type="submit"><?= e(t('create_account')) ?></button>
        <?php if ($discordEnabled): ?>
          <a class="btn btn-discord" href="<?= e(url('discord/auth')) ?>" style="margin-left:8px"><?= e('Discord') ?></a>
        <?php endif; ?>
        <div class="note"><?= e(t('register_done_note')) ?></div>
      </form>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
