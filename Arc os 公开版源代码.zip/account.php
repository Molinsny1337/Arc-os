<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
// [ADDON] XenForo-like profile helpers
require_once __DIR__ . '/includes/profile_xf.php';
require_once __DIR__ . '/includes/services/ProfileService.php';
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/DiscordOAuthService.php';
require_installed();
require_login();

$me = current_user();
$pdo = db();
$pfx = table_prefix();

// [ADDON] load profile extras (cover/about fields)
$__profile_extras = [];
try { $__profile_extras = arc_fetch_profile_extras((int)$me['id']); } catch (Throwable $e) { $__profile_extras = []; }

$title = site_name() . ' - ' . t('account');

$success = '';
$error = '';

$reviewUserChangesSetting = get_setting('review_user_changes', '1') === '1';
$pendingReviews = ['username'=>null,'avatar'=>null];

// [ADDON] profile vars
$cover_url = (string)($__profile_extras['cover_url'] ?? '');
$cover_pos_x = arc_clamp_0_100($__profile_extras['cover_pos_x'] ?? null, 50);
$cover_pos_y = arc_clamp_0_100($__profile_extras['cover_pos_y'] ?? null, 50);
$user_title = (string)($__profile_extras['user_title'] ?? '');
$location = (string)($__profile_extras['location'] ?? '');
$website = (string)($__profile_extras['website'] ?? '');
$about_text = (string)($__profile_extras['about_text'] ?? '');

// XF-like profile data
$__profile_row = ArcOS\Services\ProfileService::getProfile($pdo, $pfx, (int)$me['id']);
$__profile_privacy = ArcOS\Services\ProfileService::privacy($__profile_row);
$about_bbcode = (string)($__profile_row['about_me_bbcode'] ?? '');
$signature_bbcode = (string)($__profile_row['signature_bbcode'] ?? '');
$profileFieldsEnabled = get_setting('profile_fields_enabled', '1') === '1';

// Custom profile fields
$profile_fields = [];
$profile_field_values = [];
if ($profileFieldsEnabled) {
  try {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_profile_fields WHERE editable=1 ORDER BY display_order ASC, field_id ASC");
    $stmt->execute();
    $profile_fields = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if ($profile_fields) {
      $ids = array_map(fn($r) => (int)($r['field_id'] ?? 0), $profile_fields);
      $ids = array_values(array_filter($ids, fn($v) => $v > 0));
      if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT field_id, value FROM {$pfx}xf_user_field_values WHERE user_id=? AND field_id IN ({$in})");
        $params = array_merge([(int)$me['id']], $ids);
        $stmt->execute($params);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $profile_field_values[(int)$row['field_id']] = (string)($row['value'] ?? '');
        }
      }
    }
  } catch (Throwable $e) {
    $profile_fields = [];
    $profile_field_values = [];
  }
}

// Discord binding status
$discord_row = [];
try {
  $stmt = $pdo->prepare("SELECT discord_user_id, discord_username, discord_discriminator, discord_avatar FROM {$pfx}xf_user_discord WHERE user_id=? LIMIT 1");
  $stmt->execute([(int)$me['id']]);
  $discord_row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $discord_row = [];
}
$discordEnabled = ArcOS\Services\DiscordOAuthService::isConfigured();

// Per-user profile design prefs (sidebar layout + safe CSS vars)
$__profile_prefs = function_exists('arc_profile_prefs_get') ? arc_profile_prefs_get((int)($me['id'] ?? 0)) : ['layout' => arc_profile_layout_default_items(), 'css_vars' => ''];
$__profile_layout_items = is_array($__profile_prefs['layout'] ?? null) ? $__profile_prefs['layout'] : arc_profile_layout_default_items();
$__profile_layout_json = json_encode($__profile_layout_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if (!is_string($__profile_layout_json)) $__profile_layout_json = '[]';
$__profile_css_vars = (string)($__profile_prefs['css_vars'] ?? '');
if (function_exists('arc_sanitize_profile_css_vars')) $__profile_css_vars = arc_sanitize_profile_css_vars($__profile_css_vars);

// Per-user UI layout cookie (home page blocks; only visible to this user/browser)
$__ui_layout_cookie = arc_get_user_ui_layout_cookie((int)($me['id'] ?? 0));
$__ui_layout_enabled = $__ui_layout_cookie !== null;
$__ui_layout_items = $__ui_layout_cookie ?: arc_home_layout_default_items();
$__ui_layout_json = json_encode($__ui_layout_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if (!is_string($__ui_layout_json)) $__ui_layout_json = '[]';

if ($reviewUserChangesSetting) {
  try {
    $pdo = db();
    $pfx = table_prefix();
    $stmt = $pdo->prepare("SELECT req_type, payload, created_at FROM {$pfx}review_requests WHERE user_id=? AND status='pending' ORDER BY created_at DESC");
    $stmt->execute([(int)($me['id'] ?? 0)]);
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $type = (string)($r['req_type'] ?? '');
      if (!isset($pendingReviews[$type]) || $pendingReviews[$type] === null) {
        $pendingReviews[$type] = $r;
      }
    }
  } catch (Throwable $e) {
    // ignore
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_csrf();
  arc_rate_limit('account_update', 10, 600);

  // UI layout cookie update (independent from DB update)
  $uiLayoutEnabledPost = isset($_POST['ui_layout_enable']);
  $uiLayoutItemsPost = null;
  if ($uiLayoutEnabledPost) {
    $raw = (string)($_POST['ui_layout_json'] ?? '');
    $j = json_decode($raw, true);
    $allowed = arc_home_layout_allowed_ids();
    $items = [];
    if (is_array($j)) {
      foreach ($j as $it) {
        if (!is_array($it)) continue;
        $id = (string)($it['id'] ?? '');
        if ($id === '' || !in_array($id, $allowed, true)) continue;
        $items[] = ['id' => $id, 'enabled' => (bool)($it['enabled'] ?? true)];
      }
    }
    $uiLayoutItemsPost = $items ?: arc_home_layout_default_items();
  }

  $notify_likes = isset($_POST['notify_likes']) ? 1 : 0;
  $notify_profile_comments = isset($_POST['notify_profile_comments']) ? 1 : 0;
  $display_name = trim((string)($_POST['display_name'] ?? ($me['display_name'] ?? '')));

  // XF profile fields
  $about_bbcode_post = ArcOS\Services\BbCode::normalize((string)($_POST['about_me'] ?? ''));
  $signature_bbcode_post = ArcOS\Services\BbCode::normalize((string)($_POST['signature'] ?? ''));
  if (mb_strlen($about_bbcode_post, 'UTF-8') > 8000) $about_bbcode_post = mb_substr($about_bbcode_post, 0, 8000, 'UTF-8');
  if (mb_strlen($signature_bbcode_post, 'UTF-8') > 4000) $signature_bbcode_post = mb_substr($signature_bbcode_post, 0, 4000, 'UTF-8');

  $privacy_post_on = (string)($_POST['privacy_post_on_profile'] ?? 'everyone');
  if (!in_array($privacy_post_on, ['everyone','followers','nobody'], true)) $privacy_post_on = 'everyone';
  $privacy_show_visitors = isset($_POST['privacy_show_visitors']) ? true : false;
  $privacy_show_followers = isset($_POST['privacy_show_followers']) ? true : false;
  $privacy_show_discord = isset($_POST['privacy_show_discord']) ? true : false;


  $reviewUserChanges = get_setting('review_user_changes', '1') === '1';
  $requestedNewUsername = trim((string)($_POST['new_username'] ?? ''));
  $avatarPath = $me['avatar'] ?? '';

  // 1) 优先使用前端裁切后的 base64（如果存在）
  $avatarBase64 = trim((string)($_POST['avatar_base64'] ?? ''));
  if ($avatarBase64 !== '' && str_starts_with($avatarBase64, 'data:image/')) {
    if (!is_dir(__DIR__ . '/uploads/avatars')) @mkdir(__DIR__ . '/uploads/avatars', 0775, true);
    // 只允许常见格式
    if (!preg_match('#^data:image/(png|jpeg|webp);base64,#i', $avatarBase64, $m)) {
      $error = t('invalid_image_type');
    } else {
      $bin = base64_decode(substr($avatarBase64, strpos($avatarBase64, ',') + 1), true);
      if ($bin === false || strlen($bin) <= 50) {
        $error = t('upload_failed');
      } elseif (strlen($bin) > 2 * 1024 * 1024) {
        $error = t('avatar_too_large');
      } else {
        $ext = strtolower($m[1]) === 'jpeg' ? 'jpg' : strtolower($m[1]);
        $name = 'u' . (int)$me['id'] . '_' . time() . '.' . $ext;
        $dest = __DIR__ . '/uploads/avatars/' . $name;
        if (@file_put_contents($dest, $bin) === false) {
          $error = t('failed_save_avatar');
        } else {
          $avatarPath = base_path() . '/uploads/avatars/' . $name;

        // [ADDON] cover upload (independent from avatar)
        if ($error === '' && isset($_FILES['cover']) && is_array($_FILES['cover'])) {
          $cErr = (int)($_FILES['cover']['error'] ?? UPLOAD_ERR_NO_FILE);
          if ($cErr !== UPLOAD_ERR_NO_FILE) {
            if ($cErr !== UPLOAD_ERR_OK) {
              $error = t('cover_upload_failed');
            } else {
              $cTmp = (string)($_FILES['cover']['tmp_name'] ?? '');
              $cOrig = (string)($_FILES['cover']['name'] ?? '');
              $cExt = '';
              $cOrigExt = strtolower(pathinfo($cOrig, PATHINFO_EXTENSION));
              if (in_array($cOrigExt, ['jpg','jpeg','png','gif','webp'], true)) {
                $cExt = $cOrigExt === 'jpeg' ? 'jpg' : $cOrigExt;
              }
              if ($cExt === '') {
                $error = t('cover_unsupported_type');
              } else {
                $coverName = 'u' . (int)$me['id'] . '_cover_' . time() . '.' . $cExt;
                $coverDir = __DIR__ . '/uploads/covers/';
                if (!is_dir($coverDir)) { @mkdir($coverDir, 0755, true); }
                if (!file_exists($coverDir . 'index.html')) {
                  @file_put_contents($coverDir . 'index.html', "<!doctype html><meta charset='utf-8'><title>403</title>");
                }
                $coverDest = $coverDir . $coverName;
                if (!move_uploaded_file($cTmp, $coverDest)) {
                  $error = t('cover_save_failed');
                } else {
                  $cover_url = base_path() . '/uploads/covers/' . $coverName;
                }
              }
            }
          }
        }

        }
      }
    }
  }

  // 2) 否则走传统文件上传
  if ($error === '' && !empty($_FILES['avatar']['name'])) {
    if (!is_dir(__DIR__ . '/uploads/avatars')) @mkdir(__DIR__ . '/uploads/avatars', 0775, true);
    $tmp = $_FILES['avatar']['tmp_name'] ?? '';
    $err = (int)($_FILES['avatar']['error'] ?? 0);
    $size = (int)($_FILES['avatar']['size'] ?? 0);

    if ($err !== UPLOAD_ERR_OK) {
      // 如果是没有选择文件，直接跳过，不报错
      if ($err === UPLOAD_ERR_NO_FILE) {
        // do nothing, keep old avatar
      } else {
        $error = t('upload_failed');
      }
    } elseif ($size > 2 * 1024 * 1024) {
      $error = t('avatar_too_large');
    } else {
      $ext = '';

      // 优先使用 fileinfo 检测 mime；某些主机会禁用 finfo_*，需要安全降级
      if (is_callable('finfo_open')) {
        try {
          $finfo = @finfo_open(FILEINFO_MIME_TYPE);
          $mime = $finfo ? (string)@finfo_file($finfo, $tmp) : '';
          if ($finfo) @finfo_close($finfo);
          if ($mime === 'image/jpeg') $ext = 'jpg';
          elseif ($mime === 'image/png') $ext = 'png';
          elseif ($mime === 'image/webp') $ext = 'webp';
          elseif ($mime === 'image/gif') $ext = 'gif';
        } catch (Throwable $e) {
          // ignore and fallback
        }
      }

      // 进一步降级：getimagesize
      if ($ext === '') {
        try {
          $info = @getimagesize($tmp);
          $mime = is_array($info) ? (string)($info['mime'] ?? '') : '';
          if ($mime === 'image/jpeg') $ext = 'jpg';
          elseif ($mime === 'image/png') $ext = 'png';
          elseif ($mime === 'image/webp') $ext = 'webp';
          elseif ($mime === 'image/gif') $ext = 'gif';
        } catch (Throwable $e) {}
      }

      if ($ext === '') {
        $origExt = strtolower(pathinfo($_FILES['avatar']['name'] ?? '', PATHINFO_EXTENSION));
        if (in_array($origExt, ['jpg','jpeg','png','gif','webp'], true)) {
          $ext = $origExt === 'jpeg' ? 'jpg' : $origExt;
        }
      }

      if ($ext === '') {
        $error = t('invalid_image_type');
      } else {
        $name = 'u' . (int)$me['id'] . '_' . time() . '.' . $ext;
        $dest = __DIR__ . '/uploads/avatars/' . $name;
        if (!move_uploaded_file($tmp, $dest)) {
          $error = t('failed_save_avatar');
        } else {
          $avatarPath = base_path() . '/uploads/avatars/' . $name;
        }
      }
    }
  }

  if ($error === '') {
    $pdo = db();
    $pfx = table_prefix();

    // 显示名称（账号与名字分开）：允许为空；长度限制避免滥用
    if ($display_name !== '') {
      if (mb_strlen($display_name, 'UTF-8') > 32 || preg_match('/\s/u', $display_name)) {
        $error = t('invalid_display_name');
      }
    }

    // 用户申请改名（需审核）
    if ($reviewUserChanges && $requestedNewUsername !== '' && $requestedNewUsername !== (string)($me['username'] ?? '')) {
      if (mb_strlen($requestedNewUsername) < 2 || mb_strlen($requestedNewUsername) > 32 || preg_match('/\s/u', $requestedNewUsername)) {
        $error = t('invalid_username');
      } else {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}review_requests WHERE user_id=? AND req_type='username' AND status='pending'");
        $stmt->execute([(int)$me['id']]);
        if ((int)$stmt->fetchColumn() > 0) {
          $error = t('username_change_pending');
        } else {
          $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users WHERE username=? AND id<>?");
          $stmt->execute([$requestedNewUsername, (int)$me['id']]);
          if ((int)$stmt->fetchColumn() > 0) {
            $error = t('username_taken');
          } else {
            $payload = json_encode(['username' => $requestedNewUsername], JSON_UNESCAPED_UNICODE);
            $stmt = $pdo->prepare("INSERT INTO {$pfx}review_requests (user_id, req_type, payload, status, created_at) VALUES (?, 'username', ?, 'pending', NOW())");
            $stmt->execute([(int)$me['id'], $payload]);
            $success = t('submitted_for_review');
          }
        }
      }
    }

    // 头像：如果开启审核，仍然立即更新头像（更像 XenForo 的“即时生效”体验），同时生成审核请求供管理员回滚/确认。
    if ($reviewUserChanges && ($avatarPath !== ($me['avatar'] ?? ''))) {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}review_requests WHERE user_id=? AND req_type='avatar' AND status='pending'");
      $stmt->execute([(int)$me['id']]);
      if ((int)$stmt->fetchColumn() > 0) {
        // 已有待审头像，避免堆垃圾文件：删除本次新上传
        $newPath = (string)$avatarPath;
        if ($newPath && strpos($newPath, '/uploads/avatars/') !== false) {
          $fs = __DIR__ . '/' . ltrim(str_replace(base_path(), '', $newPath), '/');
          if (is_file($fs)) @unlink($fs);
        }
        $error = t('avatar_change_pending');
      } else {
        $payload = json_encode(['avatar' => (string)$avatarPath, 'avatar_old' => (string)($me['avatar'] ?? '')], JSON_UNESCAPED_UNICODE);
        $stmt = $pdo->prepare("INSERT INTO {$pfx}review_requests (user_id, req_type, payload, status, created_at) VALUES (?, 'avatar', ?, 'pending', NOW())");
        $stmt->execute([(int)$me['id'], $payload]);
        if ($success === '') $success = t('submitted_for_review');
      }
    }

    if ($error === '') {
      $stmt = $pdo->prepare("UPDATE {$pfx}users SET display_name=?, avatar=?, notify_likes=?, notify_profile_comments=? WHERE id=?");
      $stmt->execute([$display_name === '' ? null : $display_name, $avatarPath, $notify_likes, $notify_profile_comments, (int)$me['id']]);

      refresh_session_user();

      // [ADDON] update about/cover fields (do NOT touch your original update)
      try {
        $cols = arc_user_table_columns();
        if ($cols) {
          // validate lengths lightly to avoid abuse
          if (mb_strlen($user_title, 'UTF-8') > 80) { $user_title = mb_substr($user_title, 0, 80, 'UTF-8'); }
          if (mb_strlen($location, 'UTF-8') > 120) { $location = mb_substr($location, 0, 120, 'UTF-8'); }
          if (mb_strlen($website, 'UTF-8') > 190) { $website = mb_substr($website, 0, 190, 'UTF-8'); }
          if (mb_strlen($about_text, 'UTF-8') > 5000) { $about_text = mb_substr($about_text, 0, 5000, 'UTF-8'); }

          $stmt2 = $pdo->prepare("UPDATE {$pfx}users SET user_title=?, location=?, website=?, about_text=?, cover_url=?, cover_pos_x=?, cover_pos_y=? WHERE id=?");
          $stmt2->execute([$user_title === '' ? null : $user_title,
                           $location === '' ? null : $location,
                           $website === '' ? null : $website,
                           $about_text === '' ? null : $about_text,
                           $cover_url === '' ? null : $cover_url,
                           $cover_pos_x, $cover_pos_y,
                           (int)$me['id']]);
        }
      } catch (Throwable $e) {}

      // XF user profile (about/signature/privacy/custom fields)
      try {
        $privacyJson = json_encode([
          'post_on_profile' => $privacy_post_on,
          'show_visitors' => $privacy_show_visitors,
          'show_followers' => $privacy_show_followers,
          'show_discord' => $privacy_show_discord,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($privacyJson)) $privacyJson = '{}';

        $stmtP = $pdo->prepare("INSERT INTO {$pfx}xf_user_profile
          (user_id, location, website, about_me_bbcode, signature_bbcode, cover_path, privacy_json, updated_at)
          VALUES (?,?,?,?,?,?,?,NOW())
          ON DUPLICATE KEY UPDATE
            location=VALUES(location),
            website=VALUES(website),
            about_me_bbcode=VALUES(about_me_bbcode),
            signature_bbcode=VALUES(signature_bbcode),
            cover_path=VALUES(cover_path),
            privacy_json=VALUES(privacy_json),
            updated_at=NOW()");
        $stmtP->execute([
          (int)$me['id'],
          $location === '' ? null : $location,
          $website === '' ? null : $website,
          $about_bbcode_post !== '' ? $about_bbcode_post : null,
          $signature_bbcode_post !== '' ? $signature_bbcode_post : null,
          $cover_url === '' ? null : $cover_url,
          $privacyJson,
        ]);

        // custom fields
        if ($profileFieldsEnabled && is_array($profile_fields)) {
          foreach ($profile_fields as $field) {
            $fid = (int)($field['field_id'] ?? 0);
            if ($fid <= 0) continue;
            $key = 'profile_field_' . $fid;
            $val = isset($_POST[$key]) ? trim((string)$_POST[$key]) : '';
            if (mb_strlen($val, 'UTF-8') > 5000) $val = mb_substr($val, 0, 5000, 'UTF-8');
            if ($val === '') {
              $pdo->prepare("DELETE FROM {$pfx}xf_user_field_values WHERE user_id=? AND field_id=?")
                ->execute([(int)$me['id'], $fid]);
            } else {
              $pdo->prepare("INSERT INTO {$pfx}xf_user_field_values (user_id, field_id, value)
                VALUES (?,?,?)
                ON DUPLICATE KEY UPDATE value=VALUES(value)")
                ->execute([(int)$me['id'], $fid, $val]);
            }
          }
        }
      } catch (Throwable $e) {}

      $me = current_user();
      if ($success === '') $success = t('saved');
      arc_log('account_update','user',(int)$me['id']);
    }
  }

  // Apply cookie after CSRF passed (even if profile update fails)
  try {
    arc_set_user_ui_layout_cookie((int)($me['id'] ?? 0), $uiLayoutItemsPost);
  } catch (Throwable $e) {}

  // Apply profile design prefs after CSRF passed (even if other updates fail)
  try {
    $uid = (int)($me['id'] ?? 0);
    if ($uid > 0 && function_exists('arc_profile_prefs_set')) {
      $layoutItemsPost = null;
      $rawLayout = (string)($_POST['profile_layout_json'] ?? '');
      $decoded = $rawLayout !== '' ? json_decode($rawLayout, true) : null;
      if (is_array($decoded)) {
        $layoutItemsPost = arc_layout_normalize_items($decoded, arc_profile_layout_default_items(), arc_profile_layout_allowed_ids());
      }

      $cssVarsPost = (string)($_POST['profile_css_vars'] ?? '');
      if (isset($_FILES['profile_css_file']) && is_array($_FILES['profile_css_file'])) {
        $fErr = (int)($_FILES['profile_css_file']['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($fErr === UPLOAD_ERR_OK) {
          $fTmp = (string)($_FILES['profile_css_file']['tmp_name'] ?? '');
          $fSize = (int)($_FILES['profile_css_file']['size'] ?? 0);
          if ($fTmp !== '' && is_file($fTmp) && $fSize > 0 && $fSize <= 16000) {
            $content = @file_get_contents($fTmp);
            if (is_string($content) && strpos($content, "\0") === false) {
              $cssVarsPost = $content;
            }
          }
        }
      }

      arc_profile_prefs_set($uid, $layoutItemsPost, $cssVarsPost);
    }
  } catch (Throwable $e) {}
}

// refresh UI layout display (may have changed this request)
$__ui_layout_cookie = arc_get_user_ui_layout_cookie((int)($me['id'] ?? 0));
$__ui_layout_enabled = $__ui_layout_cookie !== null;
$__ui_layout_items = $__ui_layout_cookie ?: arc_home_layout_default_items();
$__ui_layout_json = json_encode($__ui_layout_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if (!is_string($__ui_layout_json)) $__ui_layout_json = '[]';

// refresh profile prefs display (may have changed this request)
$__profile_prefs = function_exists('arc_profile_prefs_get') ? arc_profile_prefs_get((int)($me['id'] ?? 0)) : ['layout' => arc_profile_layout_default_items(), 'css_vars' => ''];
$__profile_layout_items = is_array($__profile_prefs['layout'] ?? null) ? $__profile_prefs['layout'] : arc_profile_layout_default_items();
$__profile_layout_json = json_encode($__profile_layout_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if (!is_string($__profile_layout_json)) $__profile_layout_json = '[]';
$__profile_css_vars = (string)($__profile_prefs['css_vars'] ?? '');
if (function_exists('arc_sanitize_profile_css_vars')) $__profile_css_vars = arc_sanitize_profile_css_vars($__profile_css_vars);

// refresh XF profile data
$__profile_row = ArcOS\Services\ProfileService::getProfile($pdo, $pfx, (int)$me['id']);
$__profile_privacy = ArcOS\Services\ProfileService::privacy($__profile_row);
$about_bbcode = (string)($__profile_row['about_me_bbcode'] ?? '');
$signature_bbcode = (string)($__profile_row['signature_bbcode'] ?? '');
if ($profileFieldsEnabled) {
  try {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_profile_fields WHERE editable=1 ORDER BY display_order ASC, field_id ASC");
    $stmt->execute();
    $profile_fields = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $profile_field_values = [];
    if ($profile_fields) {
      $ids = array_map(fn($r) => (int)($r['field_id'] ?? 0), $profile_fields);
      $ids = array_values(array_filter($ids, fn($v) => $v > 0));
      if ($ids) {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT field_id, value FROM {$pfx}xf_user_field_values WHERE user_id=? AND field_id IN ({$in})");
        $params = array_merge([(int)$me['id']], $ids);
        $stmt->execute($params);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $profile_field_values[(int)$row['field_id']] = (string)($row['value'] ?? '');
        }
      }
    }
  } catch (Throwable $e) {
    $profile_fields = [];
    $profile_field_values = [];
  }
} else {
  $profile_fields = [];
  $profile_field_values = [];
}

$__need_ui_layout = true;
$__need_glass = true;
$__need_editor = true;
include __DIR__ . '/partials/head.php';
include __DIR__ . '/partials/nav.php';
?>

<main class="container" style="padding-top:30px">
  <div class="card glass" style="max-width:760px;margin:0 auto">
    <h1 style="margin-top:0"><?= e(t('account')) ?></h1>
    <p style="color:var(--muted);margin-top:6px"><?= e(t('edit_profile')) ?></p>

    <?php if ($success): ?><div class="notice success"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice danger"><?= e($error) ?></div><?php endif; ?>

    <div style="margin-top:18px;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:16px;background:rgba(255,255,255,.6);">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
          <div style="font-weight:700;">Discord</div>
          <div class="sub"><?= e(t('account')) ?> · OAuth</div>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
          <?php if (!empty($discord_row)): ?>
            <?php
              $dName = (string)($discord_row['discord_username'] ?? '');
              $dDisc = (string)($discord_row['discord_discriminator'] ?? '');
              if ($dDisc !== '' && $dDisc !== '0') $dName .= '#' . $dDisc;
              $dAvatar = '';
              if (!empty($discord_row['discord_user_id']) && !empty($discord_row['discord_avatar'])) {
                $dAvatar = 'https://cdn.discordapp.com/avatars/' . rawurlencode((string)$discord_row['discord_user_id']) . '/' . rawurlencode((string)$discord_row['discord_avatar']) . '.png?size=64';
              }
            ?>
            <?php if ($dAvatar !== ''): ?>
              <img src="<?= e($dAvatar) ?>" alt="" style="width:34px;height:34px;border-radius:10px;border:1px solid var(--border);object-fit:cover;" />
            <?php endif; ?>
            <div style="font-weight:650;"><?= e($dName) ?></div>
          <?php else: ?>
            <div style="color:var(--muted);"><?= e(t('not_connected') ?? 'Not connected') ?></div>
          <?php endif; ?>
        </div>
      </div>

      <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;">
        <?php if (!$discordEnabled): ?>
          <div class="note">Discord is not configured.</div>
        <?php elseif (empty($discord_row)): ?>
          <a class="btn btn-discord" href="<?= e(url('discord/auth')) ?>"><?= e('Connect Discord') ?></a>
        <?php else: ?>
          <form method="post" action="<?= e(url('discord/unlink')) ?>" style="margin:0">
            <?= csrf_field() ?>
            <button class="btn" type="submit"><?= e('Unlink') ?></button>
          </form>
          <form method="post" action="<?= e(url('discord/sync')) ?>" style="margin:0">
            <?= csrf_field() ?>
            <button class="btn" type="submit"><?= e('Sync Roles') ?></button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <form method="post" enctype="multipart/form-data" class="form glass" style="margin-top:18px">
      <?= csrf_field() ?>
      <div class="row" style="gap:14px;align-items:center">
        <div id="avatarPreview" style="width:56px;height:56px;border-radius:999px;background:#f1f3f5;overflow:hidden;display:flex;align-items:center;justify-content:center;flex:0 0 auto">
          <?php if (!empty($me['avatar'])): ?>
            <img src="<?= e(arc_avatar_url((string)$me['avatar'])) ?>" alt="avatar" style="width:100%;height:100%;object-fit:cover">
          <?php else: ?>
            <span style="font-size:32px;font-weight:700;color:#b3b8bf"><?= e(mb_strtoupper(mb_substr((string)$me['username'], 0, 1))) ?></span>
          <?php endif; ?>
        </div>
        <div style="flex:1">
          <label class="label"><?= e(t('upload_avatar')) ?></label>
          <?php if (!empty($pendingReviews['avatar'])): ?>
            <div class="hint" style="margin-top:6px;color:#888;font-size:13px;"><?= e(t('avatar_review_pending')) ?></div>
          <?php endif; ?>

          <input id="avatarFile" type="file" name="avatar" accept="image/*" />
          <input type="hidden" name="avatar_base64" id="avatarBase64" value="" />
          <div style="margin-top:10px;color:var(--muted);font-size:13px"><?= e(t('avatar_support_tip')) ?></div>
          <div style="margin-top:8px;color:var(--muted);font-size:13px"><?= e(t('avatar_crop_tip')) ?></div>
        </div>
      </div>

      <hr style="margin:22px 0;border:none;border-top:1px solid #eef0f2"/>

      <h3 style="margin:0 0 10px"><?= e(t('profile_info')) ?></h3>
      <div style="margin:10px 0;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <label class="label"><?= e(t('display_name')) ?></label>
        <input type="text" name="display_name" value="<?= e((string)($me['display_name'] ?? '')) ?>" placeholder="<?= e(t('display_name_placeholder')) ?>" />
        <div style="margin-top:6px;color:var(--muted);font-size:13px"><?= e(t('display_name_note')) ?></div>
      </div>

      <div style="margin:10px 0 0;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <div style="font-weight:650;margin-bottom:8px;"><?= e(t('about')) ?></div>
        <?php
          $content_name = 'about_me';
          $initial_value = $about_bbcode;
          $mode = 'profile_about';
          $placeholder = t('about') . '...';
          $attachments_enabled = false;
          $mentions_enabled = true;
          $tags_enabled = true;
          $full_screen_enabled = false;
          $min_height = 140;
          include __DIR__ . '/partials/editor/editor_widget.php';
        ?>
      </div>

      <div style="margin:10px 0 0;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <div style="font-weight:650;margin-bottom:8px;"><?= e(t('signature') ?? 'Signature') ?></div>
        <?php
          $content_name = 'signature';
          $initial_value = $signature_bbcode;
          $mode = 'profile_signature';
          $placeholder = 'Signature...';
          $attachments_enabled = false;
          $mentions_enabled = false;
          $tags_enabled = false;
          $full_screen_enabled = false;
          $min_height = 120;
          include __DIR__ . '/partials/editor/editor_widget.php';
        ?>
      </div>

      <?php if (!empty($profile_fields)): ?>
        <div style="margin:10px 0 0;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
          <div style="font-weight:650;margin-bottom:8px;"><?= e(t('profile_fields') ?? 'Profile fields') ?></div>
          <div class="grid" style="gap:12px;">
            <?php foreach ($profile_fields as $field): ?>
              <?php
                $fid = (int)($field['field_id'] ?? 0);
                if ($fid <= 0) continue;
                $ftype = (string)($field['field_type'] ?? 'text');
                $fval = (string)($profile_field_values[$fid] ?? '');
                $fname = 'profile_field_' . $fid;
                $choices = [];
                $rawChoices = (string)($field['field_choices_json'] ?? '');
                if ($rawChoices !== '') {
                  $decoded = json_decode($rawChoices, true);
                  if (is_array($decoded)) $choices = $decoded;
                }
              ?>
              <div class="field" style="grid-column: span 12;">
                <label class="label"><?= e((string)($field['title'] ?? 'Field')) ?></label>
                <?php if ($ftype === 'textarea'): ?>
                  <textarea class="input" name="<?= e($fname) ?>" rows="3"><?= e($fval) ?></textarea>
                <?php elseif ($ftype === 'select'): ?>
                  <select class="input" name="<?= e($fname) ?>">
                    <option value=""><?= e(t('not_selected')) ?></option>
                    <?php foreach ($choices as $opt): ?>
                      <?php $opt = (string)$opt; ?>
                      <option value="<?= e($opt) ?>" <?= $opt === $fval ? 'selected' : '' ?>><?= e($opt) ?></option>
                    <?php endforeach; ?>
                  </select>
                <?php else: ?>
                  <input class="input" name="<?= e($fname) ?>" value="<?= e($fval) ?>" />
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>

      <div style="margin:10px 0 0;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <div style="font-weight:650;margin-bottom:8px;"><?= e(t('privacy') ?? 'Privacy') ?></div>
        <div class="field">
          <label class="label"><?= e(t('profile_posts') ?? 'Profile posts') ?></label>
          <select class="input" name="privacy_post_on_profile">
            <?php $pp = (string)($__profile_privacy['post_on_profile'] ?? 'everyone'); ?>
            <option value="everyone" <?= $pp === 'everyone' ? 'selected' : '' ?>>Everyone</option>
            <option value="followers" <?= $pp === 'followers' ? 'selected' : '' ?>>Followers</option>
            <option value="nobody" <?= $pp === 'nobody' ? 'selected' : '' ?>>Nobody</option>
          </select>
        </div>
        <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
          <input type="checkbox" name="privacy_show_visitors" <?= !empty($__profile_privacy['show_visitors']) ? 'checked' : '' ?> />
          <span><?= e(t('show_visitors') ?? 'Show visitors') ?></span>
        </label>
        <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
          <input type="checkbox" name="privacy_show_followers" <?= !empty($__profile_privacy['show_followers']) ? 'checked' : '' ?> />
          <span><?= e(t('show_followers') ?? 'Show followers') ?></span>
        </label>
        <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
          <input type="checkbox" name="privacy_show_discord" <?= !empty($__profile_privacy['show_discord']) ? 'checked' : '' ?> />
          <span><?= e('Show Discord') ?></span>
        </label>
      </div>

      <h3 style="margin:0 0 10px"><?= e(t('notifications')) ?></h3>
      <?php if ($reviewUserChangesSetting): ?>
      <div style="margin-top:16px;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <label class="label"><?= e(t('request_username_change')) ?></label>
        <input type="text" name="new_username" value="" placeholder="<?= e((string)($me['username'] ?? '')) ?>" />
        <?php if (!empty($pendingReviews['username'])): ?>
          <div class="hint" style="margin-top:6px;color:#888;font-size:13px;"><?= e(t('username_review_pending')) ?></div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
        <input type="checkbox" name="notify_likes" <?= (int)($me['notify_likes'] ?? 0) === 1 ? 'checked' : '' ?> />
        <span><?= e(t('notify_likes')) ?></span>
      </label>
      <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
        <input type="checkbox" name="notify_profile_comments" <?= (int)($me['notify_profile_comments'] ?? 0) === 1 ? 'checked' : '' ?> />
        <span><?= e(t('notify_profile_comments')) ?></span>
      </label>

      <hr style="margin:22px 0;border:none;border-top:1px solid #eef0f2"/>

      <h3 style="margin:0 0 10px"><?= e(t('tickets')) ?></h3>
      <div style="color:var(--muted);font-size:13px;margin-bottom:10px;">
        <?= e(t('tickets_sub')) ?>
      </div>
      <div style="display:flex;gap:10px;align-items:center;justify-content:flex-end;">
        <a class="btn" href="<?= e(url('tickets.php')) ?>"><?= e(t('my_tickets')) ?></a>
      </div>

      <hr style="margin:22px 0;border:none;border-top:1px solid #eef0f2"/>

      <h3 style="margin:0 0 10px"><?= e(t('personal_layout')) ?></h3>
      <div style="color:var(--muted);font-size:13px;margin-bottom:10px;">
        <?= e(t('personal_layout_sub')) ?>
      </div>

      <label style="display:flex;gap:10px;align-items:center;margin:10px 0">
        <input type="checkbox" name="ui_layout_enable" id="uiLayoutEnable" <?= $__ui_layout_enabled ? 'checked' : '' ?> />
        <span><?= e(t('enable_custom_home_layout')) ?></span>
      </label>
      <input type="hidden" name="ui_layout_json" id="uiLayoutJson" value="<?= e($__ui_layout_json) ?>" data-default="<?= e(json_encode(arc_home_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>" />

      <?php
      $__ui_labels = [
          'hero' => t('home_block_hero'),
          'forum_nodes' => t('home_block_forum_nodes'),
          'latest_topics' => t('home_block_latest_topics'),
          'today_stats' => t('home_block_today_stats'),
          'new_members' => t('home_block_new_members'),
          'custom_html' => t('home_block_custom_html'),
        ];
      ?>
      <div style="border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);padding:12px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
          <div style="font-weight:650;"><?= e(t('home_blocks')) ?></div>
          <button type="button" class="btn" id="uiLayoutReset" style="padding:8px 12px;"><?= e(t('reset')) ?></button>
        </div>
        <ul id="uiLayoutList" class="arc-sortable" style="list-style:none;padding:0;margin:10px 0 0;">
          <?php foreach ($__ui_layout_items as $__it): $id = (string)($__it['id'] ?? ''); if ($id === '') continue; ?>
            <li class="arc-sortable-item" data-id="<?= e($id) ?>">
              <div class="arc-sortable-row">
                <span class="arc-sortable-handle" title="<?= e(t('drag')) ?>" aria-hidden="true">::</span>
                <label style="display:flex;gap:10px;align-items:center;flex:1;margin:0;">
                  <input type="checkbox" class="ui-enabled" <?= (!isset($__it['enabled']) || $__it['enabled']) ? 'checked' : '' ?> />
                  <span><?= e($__ui_labels[$id] ?? $id) ?></span>
                </label>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <hr style="margin:22px 0;border:none;border-top:1px solid #eef0f2"/>

      <h3 style="margin:0 0 10px"><?= e(t('profile')) ?> · <?= e(t('layout_edit')) ?></h3>
      <div style="color:var(--muted);font-size:13px;margin-bottom:10px;">
        <?= e(t('layout_blocks')) ?> + <?= e(t('hide')) ?>/<?= e(t('show')) ?> · <?= e(t('layout_edit')) ?> in <?= e(t('profile')) ?>
      </div>

      <?php
        $__profile_labels = [
          'about' => t('about'),
          'latest' => t('latest_content'),
          'trophies' => t('trophies'),
          'reactions' => t('recent_reactions'),
          'visitors' => t('recent_visitors'),
        ];
      ?>
      <input type="hidden" name="profile_layout_json" id="profileLayoutJson" value="<?= e($__profile_layout_json) ?>" data-default="<?= e(json_encode(arc_profile_layout_default_items(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>" />
      <div style="border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);padding:12px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
          <div style="font-weight:650;"><?= e(t('layout_blocks')) ?></div>
          <button type="button" class="btn" id="profileLayoutReset" style="padding:8px 12px;"><?= e(t('reset')) ?></button>
        </div>
        <ul id="profileLayoutList" class="arc-sortable" style="list-style:none;padding:0;margin:10px 0 0;">
          <?php foreach ($__profile_layout_items as $__it): $id = (string)($__it['id'] ?? ''); if ($id === '') continue; ?>
            <li class="arc-sortable-item" data-id="<?= e($id) ?>">
              <div class="arc-sortable-row">
                <span class="arc-sortable-handle" title="<?= e(t('drag')) ?>" aria-hidden="true">::</span>
                <label style="display:flex;gap:10px;align-items:center;flex:1;margin:0;">
                  <input type="checkbox" class="profile-enabled" <?= (!isset($__it['enabled']) || $__it['enabled']) ? 'checked' : '' ?> />
                  <span><?= e($__profile_labels[$id] ?? $id) ?></span>
                </label>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div style="margin-top:14px;padding:14px;border:1px solid rgba(0,0,0,.08);border-radius:14px;background:rgba(255,255,255,.6);">
        <label class="label"><?= e(t('custom_css')) ?> (<?= e(t('profile')) ?>)</label>
        <div class="hint" style="margin:6px 0 10px;color:var(--muted);font-size:13px;">
          仅支持安全的 CSS 变量（每行 <code>--var: value;</code>），只作用于你的个人主页（不会影响别人）。
        </div>
        <textarea class="input" name="profile_css_vars" rows="8" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;" placeholder="--xf-accent: #3b82f6;&#10;--xf-card-radius: 18px;&#10;--xf-cover-height: 260px;"><?= e($__profile_css_vars) ?></textarea>
        <div style="margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
          <input type="file" name="profile_css_file" accept=".css,.txt,text/css,text/plain" />
          <div class="hint" style="color:var(--muted);font-size:13px;"><?= e(t('optional')) ?>：上传文件会覆盖上方文本</div>
        </div>
        <div class="hint" style="margin-top:10px;color:var(--muted);font-size:13px;">
          Allowed vars: <code>--xf-accent</code> <code>--xf-card-radius</code> <code>--xf-cover-height</code> <code>--xf-avatar-size</code> <code>--xf-card-bg</code> <code>--xf-card-border</code> <code>--xf-muted</code> <code>--xf-text</code> <code>--xf-font</code>
        </div>
      </div>

      <div style="display:flex;gap:10px;align-items:center;justify-content:flex-end;margin-top:18px">
        <a class="btn" data-transition="1" href="<?= e(base_path()) ?>/user.php?id=<?= (int)$me['id'] ?>"><?= e(t('profile')) ?></a>
        <button class="btn primary" type="submit"><?= e(t('save_changes')) ?></button>
      </div>
    </form>
  </div>
</main>

<?php /*
(() => {
  const enable = document.getElementById('uiLayoutEnable');
  const list = document.getElementById('uiLayoutList');
  const json = document.getElementById('uiLayoutJson');
  const reset = document.getElementById('uiLayoutReset');
  if (!enable || !list || !json || !reset) return;

  const DEFAULT = <?= json_encode(arc_home_layout_default_items(), JSON_UNESCAPED_SLASHES) ?>;
  const esc = (s) => (window.CSS && CSS.escape) ? CSS.escape(s) : (s || '').replace(/[^a-zA-Z0-9_-]/g, '\\\\$&');

  function serialize() {
    const items = [];
    list.querySelectorAll('li[data-id]').forEach(li => {
      const id = li.getAttribute('data-id') || '';
      const cb = li.querySelector('input.ui-enabled');
      items.push({ id, enabled: cb ? !!cb.checked : true });
    });
    json.value = JSON.stringify(items);
    list.style.opacity = enable.checked ? '1' : '.55';
    list.style.pointerEvents = enable.checked ? 'auto' : 'none';
  }

  function resetToDefault() {
    for (const it of DEFAULT) {
      const el = list.querySelector(`li[data-id="${esc(it.id)}"]`);
      if (el) list.appendChild(el);
      const cb = el ? el.querySelector('input.ui-enabled') : null;
      if (cb) cb.checked = !!it.enabled;
    }
    enable.checked = true;
    serialize();
  }

  let dragging = null;
  list.addEventListener('dragstart', (e) => {
    const li = e.target && e.target.closest ? e.target.closest('li[data-id]') : null;
    if (!li) return;
    dragging = li;
    li.style.opacity = '.6';
    if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move';
  });
  list.addEventListener('dragend', () => {
    if (dragging) dragging.style.opacity = '1';
    dragging = null;
    serialize();
  });
  list.addEventListener('dragover', (e) => {
    if (!dragging) return;
    e.preventDefault();
    const items = [...list.querySelectorAll('li[data-id]')].filter(x => x !== dragging);
    let after = null;
    for (const el of items) {
      const box = el.getBoundingClientRect();
      if (e.clientY < box.top + box.height / 2) { after = el; break; }
    }
    if (!after) list.appendChild(dragging);
    else list.insertBefore(dragging, after);
  });

  list.addEventListener('change', (e) => {
    if (e.target && e.target.classList && e.target.classList.contains('ui-enabled')) serialize();
  });
  enable.addEventListener('change', serialize);
  reset.addEventListener('click', resetToDefault);

  serialize();
})();
*/ ?>

<!-- Avatar crop modal (no CDN, pure Canvas) -->
<style>
  /* 兜底：就算 CSS 被浏览器缓存了，也要让裁切窗口正常显示 */
  body.modal-open{overflow:hidden;}
  #avatarCropModal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:9999;}
  #avatarCropModal.open{display:flex;}
  #avatarCropModal .arc-modal-backdrop{position:absolute;inset:0;background:rgba(2,6,23,.45);backdrop-filter: blur(6px);}
  #avatarCropModal .arc-modal-card{position:relative;width:min(520px, calc(100vw - 24px));border-radius:24px;background:#fff;border:1px solid rgba(148,163,184,.35);box-shadow:0 30px 70px rgba(2,6,23,.25);overflow:hidden;}
  #avatarCropModal .arc-modal-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid rgba(148,163,184,.18);} 
  #avatarCropModal .arc-modal-body{padding:14px 16px;display:grid;gap:12px;}
  #avatarCropModal .arc-modal-foot{display:flex;justify-content:flex-end;gap:10px;padding:14px 16px;border-top:1px solid rgba(148,163,184,.18);} 
  #avatarCropModal .arc-crop-wrap{display:flex;align-items:center;justify-content:center;padding:10px;background:rgba(148,163,184,.12);border-radius:20px;border:1px solid rgba(148,163,184,.22);} 
  #avatarCropModal canvas{border-radius:18px;max-width:100%;height:auto;background:#f1f3f5;touch-action:none;}
  @media (max-width: 520px){
    #avatarCropModal .arc-modal-card{width:calc(100vw - 18px);border-radius:20px;}
  }
</style>
<div class="arc-modal" id="avatarCropModal" aria-hidden="true">
  <div class="arc-modal-backdrop" data-close></div>
  <div class="arc-modal-card">
    <div class="arc-modal-head">
      <div style="font-weight:900"><?= e(t('crop_avatar')) ?></div>
      <button class="btn" type="button" data-close><?= e(t('close')) ?></button>
    </div>
    <div class="arc-modal-body">
      <div class="arc-crop-wrap">
        <canvas id="cropCanvas" width="360" height="360"></canvas>
      </div>
      <div class="arc-crop-controls">
        <label style="display:flex;gap:10px;align-items:center">
          <span style="color:var(--muted);font-size:13px"><?= e(t('zoom')) ?></span>
          <input id="cropZoom" type="range" min="10" max="300" value="100" />
        </label>
        <div style="color:var(--muted);font-size:13px"><?= e(t('drag_zoom_tip')) ?></div>
      </div>
    </div>
    <div class="arc-modal-foot">
      <button class="btn" type="button" id="cropCancel"><?= e(t('cancel')) ?></button>
      <button class="btn primary" type="button" id="cropApply"><?= e(t('use_this_crop')) ?></button>
    </div>
  </div>
</div>

<script>
(() => {
  const fileInput = document.getElementById('avatarFile');
  const modal = document.getElementById('avatarCropModal');
  const canvas = document.getElementById('cropCanvas');
  const zoom = document.getElementById('cropZoom');
  const base64Input = document.getElementById('avatarBase64');
  const preview = document.getElementById('avatarPreview');
  const ctx = canvas ? canvas.getContext('2d') : null;

  if (!fileInput || !modal || !canvas || !ctx || !zoom || !base64Input || !preview) return;

  let img = new Image();
  let state = { ready:false, scale:1, dx:0, dy:0, dragging:false, lastX:0, lastY:0, iw:0, ih:0 };
  const W = canvas.width, H = canvas.height;

  function open(){
    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
    document.body.classList.add('modal-open');
  }
  function close(){
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
    state.dragging=false;
    document.body.classList.remove('modal-open');
  }

  function coverScale(iw, ih){
    // scale so the square is fully covered
    return Math.max(W/iw, H/ih);
  }

  function redraw(){
    ctx.clearRect(0,0,W,H);
    if (!state.ready) {
      ctx.fillStyle = '#f1f3f5';
      ctx.fillRect(0,0,W,H);
      ctx.fillStyle = '#9aa3ad';
      ctx.font = '14px system-ui';
      ctx.fillText(<?= json_encode(t('loading_image'), JSON_UNESCAPED_UNICODE) ?>, 18, 28);
      return;
    }
    ctx.fillStyle = '#f1f3f5';
    ctx.fillRect(0,0,W,H);
    const s = state.scale;
    ctx.drawImage(img, state.dx, state.dy, state.iw*s, state.ih*s);

    // dim outside a circular preview area (final avatar is round)
    const r = Math.min(W,H) * 0.42;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.35)';
    ctx.fillRect(0,0,W,H);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(W/2, H/2, r, 0, Math.PI*2);
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.arc(W/2, H/2, r, 0, Math.PI*2);
    ctx.strokeStyle = 'rgba(255,255,255,.9)';
    ctx.lineWidth = 3;
    ctx.stroke();

    // subtle border
    ctx.strokeStyle = 'rgba(0,0,0,.08)';
    ctx.lineWidth = 2;
    ctx.strokeRect(1,1,W-2,H-2);
  }

  function clamp(){
    const s = state.scale;
    const rw = state.iw*s;
    const rh = state.ih*s;
    // ensure image covers the square
    const minX = W - rw;
    const minY = H - rh;
    if (rw < W) state.dx = (W - rw) / 2;
    else state.dx = Math.min(0, Math.max(minX, state.dx));
    if (rh < H) state.dy = (H - rh) / 2;
    else state.dy = Math.min(0, Math.max(minY, state.dy));
  }

  function loadFile(file){
    const reader = new FileReader();
    reader.onload = () => {
      img = new Image();
      img.onload = () => {
        state.iw = img.naturalWidth || img.width;
        state.ih = img.naturalHeight || img.height;
        const base = coverScale(state.iw, state.ih);
        state.scale = base * (parseInt(zoom.value,10) / 100);
        state.dx = (W - state.iw*state.scale)/2;
        state.dy = (H - state.ih*state.scale)/2;
        state.ready = true;
        clamp();
        redraw();
        open();
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  }

  fileInput.addEventListener('change', () => {
    const f = fileInput.files && fileInput.files[0];
    if (!f) return;
    base64Input.value = '';
    loadFile(f);
  });

  zoom.addEventListener('input', () => {
    if (!state.ready) return;
    const base = coverScale(state.iw, state.ih);
    state.scale = base * (parseInt(zoom.value,10) / 100);
    clamp();
    redraw();
  });

  canvas.addEventListener('mousedown', (e) => {
    if (!state.ready) return;
    state.dragging = true;
    state.lastX = e.clientX;
    state.lastY = e.clientY;
  });
  window.addEventListener('mousemove', (e) => {
    if (!state.dragging) return;
    const dx = e.clientX - state.lastX;
    const dy = e.clientY - state.lastY;
    state.lastX = e.clientX;
    state.lastY = e.clientY;
    state.dx += dx;
    state.dy += dy;
    clamp();
    redraw();
  });
  window.addEventListener('mouseup', () => { state.dragging = false; });

  // touch
  canvas.addEventListener('touchstart', (e) => {
    if (!state.ready) return;
    const t = e.touches[0];
    if (!t) return;
    state.dragging = true;
    state.lastX = t.clientX;
    state.lastY = t.clientY;
  }, {passive:true});
  window.addEventListener('touchmove', (e) => {
    if (!state.dragging) return;
    const t = e.touches[0];
    if (!t) return;
    const dx = t.clientX - state.lastX;
    const dy = t.clientY - state.lastY;
    state.lastX = t.clientX;
    state.lastY = t.clientY;
    state.dx += dx;
    state.dy += dy;
    clamp();
    redraw();
  }, {passive:true});
  window.addEventListener('touchend', () => { state.dragging = false; });

  // close handlers
  modal.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', close));
  document.getElementById('cropCancel')?.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });

  document.getElementById('cropApply')?.addEventListener('click', () => {
    if (!state.ready) return;
    // export 256x256
    const out = document.createElement('canvas');
    out.width = 256; out.height = 256;
    const octx = out.getContext('2d');
    if (!octx) return;
    // map current view to output
    const s = state.scale;
    // source rectangle in original image coordinates
    const sx = (0 - state.dx) / s;
    const sy = (0 - state.dy) / s;
    const sw = W / s;
    const sh = H / s;
    octx.imageSmoothingEnabled = true;
    octx.drawImage(img, sx, sy, sw, sh, 0, 0, 256, 256);
    let dataUrl = '';
    try {
      dataUrl = out.toDataURL('image/webp', 0.86);
    } catch (e) { dataUrl = ''; }
    if (!dataUrl || !dataUrl.startsWith('data:image/webp')) {
      dataUrl = out.toDataURL('image/png', 0.92);
    }
    base64Input.value = dataUrl;
    // update preview
    preview.innerHTML = '';
    const im = document.createElement('img');
    im.src = dataUrl;
    im.alt = 'avatar';
    im.style.width = '100%';
    im.style.height = '100%';
    im.style.objectFit = 'cover';
    preview.appendChild(im);
    close();
  });

  redraw();
})();
</script>

<?php include __DIR__ . '/partials/foot.php'; ?>
