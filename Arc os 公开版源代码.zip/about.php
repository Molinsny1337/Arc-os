<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$title = site_name() . ' · ' . t('about');
$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head><?php include __DIR__ . '/partials/head.php'; ?></head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>
  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('about_title')) ?></h1>
      <p class="reveal"><?= e(t('about_sub')) ?></p>
    </header>

    <section class="section reveal-group">
      <div class="card reveal">
        <h2><?= e(t('about_card_title')) ?></h2>
        <p><?= e(t('about_card_body')) ?></p>
      </div>
    </section>
  </main>
  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>

