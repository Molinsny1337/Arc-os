<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

function arc_layout_json($data, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store');
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

require_post();
require_csrf();
arc_rate_limit('layout_save', 240, 60);

$me = current_user();
if (!$me) arc_layout_json(['ok' => false, 'error' => 'not_logged_in'], 401);

$raw = file_get_contents('php://input') ?: '';
$j = json_decode($raw, true);
if (!is_array($j)) arc_layout_json(['ok' => false, 'error' => 'invalid_json'], 400);

$scope = trim((string)($j['scope'] ?? ''));
$clear = !empty($j['clear']);
$itemsIn = $j['items'] ?? null;

$scopes = [
  'home_user' => [
    'type' => 'cookie',
    'allowed' => arc_home_layout_allowed_ids(),
    'default' => arc_home_layout_default_items(),
  ],
  'home_global' => [
    'type' => 'setting',
    'key' => 'home_layout',
    'allowed' => arc_home_layout_allowed_ids(),
    'default' => arc_home_layout_default_items(),
  ],
  'profile_user' => [
    'type' => 'profile_prefs',
    'allowed' => arc_profile_layout_allowed_ids(),
    'default' => arc_profile_layout_default_items(),
  ],
  'forum_global' => [
    'type' => 'setting',
    'key' => 'forum_layout',
    'allowed' => arc_forum_layout_allowed_ids(),
    'default' => arc_forum_layout_default_items(),
  ],
  'whats_new_global' => [
    'type' => 'setting',
    'key' => 'whats_new_layout',
    'allowed' => arc_whats_new_layout_allowed_ids(),
    'default' => arc_whats_new_layout_default_items(),
  ],
  'members_global' => [
    'type' => 'setting',
    'key' => 'members_layout',
    'allowed' => arc_members_layout_allowed_ids(),
    'default' => arc_members_layout_default_items(),
  ],
  'admin_dashboard_global' => [
    'type' => 'setting',
    'key' => 'admin_dashboard_layout',
    'allowed' => arc_admin_dashboard_layout_allowed_ids(),
    'default' => arc_admin_dashboard_layout_default_items(),
  ],
];

if ($scope === '' || !isset($scopes[$scope])) arc_layout_json(['ok' => false, 'error' => 'unknown_scope'], 400);
$cfg = $scopes[$scope];

/** @var array<int, string> $allowed */
$allowed = $cfg['allowed'];
/** @var array<int, array{id:string, enabled:bool}> $default */
$default = $cfg['default'];

if ($cfg['type'] === 'cookie') {
  $uid = (int)($me['id'] ?? 0);
  if ($uid <= 0) arc_layout_json(['ok' => false, 'error' => 'invalid_user'], 400);

  if ($clear) {
    arc_set_user_ui_layout_cookie($uid, null);
    arc_layout_json(['ok' => true, 'items' => null]);
  }

  if (!is_array($itemsIn)) arc_layout_json(['ok' => false, 'error' => 'invalid_items'], 400);
  $items = arc_layout_normalize_items($itemsIn, $default, $allowed);
  arc_set_user_ui_layout_cookie($uid, $items);
  arc_layout_json(['ok' => true, 'items' => $items]);
}

if ($cfg['type'] === 'profile_prefs') {
  $uid = (int)($me['id'] ?? 0);
  if ($uid <= 0) arc_layout_json(['ok' => false, 'error' => 'invalid_user'], 400);

  // Lazily load profile prefs helpers only when needed.
  require_once __DIR__ . '/includes/profile_xf.php';

  if ($clear) {
    $items = arc_profile_layout_default_items();
    arc_profile_prefs_set($uid, $items, null);
    arc_layout_json(['ok' => true, 'items' => $items]);
  }

  if (!is_array($itemsIn)) arc_layout_json(['ok' => false, 'error' => 'invalid_items'], 400);
  $items = arc_layout_normalize_items($itemsIn, $default, $allowed);
  arc_profile_prefs_set($uid, $items, null);
  arc_layout_json(['ok' => true, 'items' => $items]);
}

// setting scope => admin only
if (!is_admin()) arc_layout_json(['ok' => false, 'error' => 'forbidden'], 403);
if (!isset($cfg['key']) || !is_string($cfg['key']) || $cfg['key'] === '') arc_layout_json(['ok' => false, 'error' => 'invalid_scope'], 400);

if (!is_array($itemsIn)) arc_layout_json(['ok' => false, 'error' => 'invalid_items'], 400);
$items = arc_layout_normalize_items($itemsIn, $default, $allowed);
set_setting($cfg['key'], json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
arc_layout_json(['ok' => true, 'items' => $items]);
