Arc OS 部署说明（重要，不然你会一直看到旧文件）

1) 先把服务器上旧目录彻底删掉或重命名：
   /www/wwwroot/hgvps.cn/apple-ripple-php-blog-pro  （你现在用的那个）

2) 把本 zip 解压到你想要的目录（解压后里面就是 index.php / admin / assets 等文件，而不是再套一层文件夹）。

3) 确保 PHP 有写权限：config.php、uploads/、logs/（如果有）、以及 install 时需要写入的目录。

4) 如果你只是覆盖解压而不删旧目录，浏览器会继续加载你之前那堆“语言链接/下拉”，然后你会来骂我。合理。
