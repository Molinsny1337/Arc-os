<?php
declare(strict_types=1);

/**
 * Cloudflare Turnstile 集成
 * - 仅客户端小组件不等于保护，必须做服务端 siteverify 校验
 *   (Cloudflare 官方文档也强调必须服务端验证)。
 */

function turnstile_configured(): bool {
  $en = (string)get_setting('turnstile_enabled', '0');
  if ($en !== '1') return false;
  $key = (string)get_setting('turnstile_site_key', '');
  $sec = (string)get_setting('turnstile_secret_key', '');
  return $key !== '' && $sec !== '';
}

function turnstile_required(string $where): bool {
  // 是否“要求”该场景必须通过 Turnstile（即使管理员忘了填 key，也要阻止以免形同虚设）
  $en = (string)get_setting('turnstile_enabled', '0');
  if ($en !== '1') return false;
  $where = strtolower(trim($where));
  if ($where === 'admin')    return (string)get_setting('turnstile_on_admin', '0') === '1';
  if ($where === 'register') return (string)get_setting('turnstile_on_register', '0') === '1';
  if ($where === 'login')    return (string)get_setting('turnstile_on_login', '0') === '1';
  if ($where === 'post')     return (string)get_setting('turnstile_on_post', '0') === '1';
  if ($where === 'comment')  return (string)get_setting('turnstile_on_comment', '0') === '1';
  if ($where === 'content')  return (string)get_setting('turnstile_on_content', '0') === '1';
  return false;
}

function turnstile_enabled(string $where): bool {
  // where: 'login','register','admin','post','comment','content'
  if (!turnstile_configured()) return false;

  $where = strtolower(trim($where));
  if ($where === 'admin')    return (string)get_setting('turnstile_on_admin', '0') === '1';
  if ($where === 'register') return (string)get_setting('turnstile_on_register', '0') === '1';
  if ($where === 'post')     return (string)get_setting('turnstile_on_post', '0') === '1';
  if ($where === 'comment')  return (string)get_setting('turnstile_on_comment', '0') === '1';
  if ($where === 'content')  return turnstile_enabled('post') || turnstile_enabled('comment');

  // default: login
  return (string)get_setting('turnstile_on_login', '0') === '1';
}

function turnstile_site_key(): string {
  return (string)get_setting('turnstile_site_key', '');
}

function turnstile_script_tag(): string {
  if (!turnstile_configured()) return '';
  // 官方脚本： https://challenges.cloudflare.com/turnstile/v0/api.js
  return '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
}

function turnstile_widget(string $where, string $theme = 'light'): string {
  if (!turnstile_enabled($where)) return '';
  $theme = ($theme === 'dark') ? 'dark' : 'light';
  $key = turnstile_site_key();
  if ($key === '') return '';
  // data-language=auto: 自动按浏览器语言
  return '<div class="cf-turnstile" data-sitekey="' . e($key) . '" data-theme="' . $theme . '" data-language="auto"></div>';
}

/**
 * 校验 Turnstile（服务端）
 * - 读取 POST 的 cf-turnstile-response
 * - 调用 siteverify
 */
function turnstile_verify_request(): bool {
  // 从 POST 里取 Turnstile token（服务端必须校验）
  if (!turnstile_configured()) return false; // 未配置就当校验失败（否则等于没开）
  $token = (string)($_POST['cf-turnstile-response'] ?? '');
  if ($token === '') return false;
  return turnstile_verify_token($token);
}

function turnstile_verify_token(string $token, string $ip = ''): bool {
  $secret = (string)get_setting('turnstile_secret_key', '');
  if ($secret === '') return false;

  $fields = [
    'secret' => $secret,
    'response' => $token,
  ];
  if ($ip !== '') $fields['remoteip'] = $ip;

  $data = http_build_query($fields);

  $opts = [
    'http' => [
      'method' => 'POST',
      'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
      'content' => $data,
      'timeout' => 6,
    ]
  ];
  $ctx = stream_context_create($opts);
  $resp = @file_get_contents('https://challenges.cloudflare.com/turnstile/v0/siteverify', false, $ctx);
  if ($resp === false) return false;
  $json = json_decode($resp, true);
  return is_array($json) && !empty($json['success']);
}


// 兼容旧代码：之前页面调用 verify_turnstile($token)
function verify_turnstile(string $token, string $ip = ''): bool {
  $ip = $ip !== '' ? $ip : client_ip();
  return turnstile_verify_token($token, $ip);
}
