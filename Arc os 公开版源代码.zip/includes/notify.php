<?php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/mailer.php';

function admin_notify(string $subjectTplKey, string $bodyTplKey, array $vars): void {
  $to = trim((string)get_setting('admin_notify_email', ''));
  if ($to === '') return;

  $subjectTpl = (string)get_setting($subjectTplKey, '');
  $bodyTpl = (string)get_setting($bodyTplKey, '');
  if ($subjectTpl === '' || $bodyTpl === '') return;

  $vars = array_merge([
    'site_name' => site_name(),
  ], $vars);

  $subject = tpl_render($subjectTpl, $vars);
  $body = tpl_render($bodyTpl, $vars);
  @send_mail($to, $subject, $body);
}

function user_notify_like(array $targetUser, array $actorUser, array $post): void {
  if ((int)($targetUser['notify_likes'] ?? 0) !== 1) return;
  $to = (string)($targetUser['email'] ?? '');
  if ($to === '') return;

  $subjectTpl = (string)get_setting('tpl_like_subject', '[{{site_name}}] New like');
  $bodyTpl = (string)get_setting('tpl_like_body', "Hi {{username}},\n\n{{actor}} liked your post.\n{{url}}\n\n— {{site_name}}");

  $vars = [
    'site_name' => site_name(),
    'username' => (string)($targetUser['username'] ?? ''),
    'actor' => (string)($actorUser['username'] ?? ''),
    'post_title' => (string)($post['title'] ?? ''),
    'url' => (string)($post['url'] ?? ''),
  ];
  @send_mail($to, tpl_render($subjectTpl, $vars), tpl_render($bodyTpl, $vars));
}

function user_notify_profile_comment(array $targetUser, array $actorUser, string $content, string $url): void {
  if ((int)($targetUser['notify_profile_comments'] ?? 0) !== 1) return;
  $to = (string)($targetUser['email'] ?? '');
  if ($to === '') return;

  $subjectTpl = (string)get_setting('tpl_profile_comment_subject', '[{{site_name}}] New comment');
  $bodyTpl = (string)get_setting('tpl_profile_comment_body', "Hi {{username}},\n\n{{actor}} commented.\n\n{{content}}\n\n{{url}}\n\n— {{site_name}}");

  $vars = [
    'site_name' => site_name(),
    'username' => (string)($targetUser['username'] ?? ''),
    'actor' => (string)($actorUser['username'] ?? ''),
    'content' => $content,
    'url' => $url,
  ];
  @send_mail($to, tpl_render($subjectTpl, $vars), tpl_render($bodyTpl, $vars));
}
