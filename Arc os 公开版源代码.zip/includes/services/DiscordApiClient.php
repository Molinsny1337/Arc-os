<?php
declare(strict_types=1);

namespace ArcOS\Services;

use RuntimeException;

final class DiscordApiClient {
  private string $baseUrl = 'https://discord.com/api/v10';
  private int $timeout;

  public function __construct(int $timeoutSeconds = 8) {
    $this->timeout = max(3, $timeoutSeconds);
  }

  /**
   * @param array<string,string> $headers
   * @return array<string,mixed>
   */
  public function get(string $path, array $headers = []): array {
    return $this->request('GET', $path, null, $headers);
  }

  /**
   * @param array<string,mixed> $data
   * @param array<string,string> $headers
   * @return array<string,mixed>
   */
  public function post(string $path, array $data, array $headers = []): array {
    return $this->request('POST', $path, $data, $headers);
  }

  /**
   * @param array<string,mixed>|null $data
   * @param array<string,string> $headers
   * @return array<string,mixed>
   */
  private function request(string $method, string $path, ?array $data, array $headers): array {
    $url = str_starts_with($path, 'http') ? $path : $this->baseUrl . $path;

    $ch = curl_init();
    if ($ch === false) {
      throw new RuntimeException('CURL_NOT_AVAILABLE');
    }

    $httpHeaders = [
      'Accept: application/json',
    ];
    foreach ($headers as $k => $v) {
      $httpHeaders[] = $k . ': ' . $v;
    }

    $opts = [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_TIMEOUT => $this->timeout,
      CURLOPT_CONNECTTIMEOUT => $this->timeout,
      CURLOPT_HTTPHEADER => $httpHeaders,
      CURLOPT_CUSTOMREQUEST => $method,
    ];

    if ($data !== null) {
      $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($payload)) $payload = '{}';
      $opts[CURLOPT_POSTFIELDS] = $payload;
      $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
    }

    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($raw === false) {
      throw new RuntimeException('CURL_ERROR:' . $err);
    }

    $decoded = json_decode((string)$raw, true);
    if (!is_array($decoded)) $decoded = [];

    if ($code >= 400) {
      $msg = isset($decoded['message']) ? (string)$decoded['message'] : 'HTTP_' . $code;
      throw new RuntimeException('DISCORD_API:' . $msg);
    }

    return $decoded;
  }
}
