<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class EmojiService {
  /**
   * Ensure a default emoji pack exists (unicode-only baseline + optional sticker).
   */
  public static function seedDefaults(PDO $pdo, string $pfx): void {
    try {
      $cnt = (int)$pdo->query("SELECT COUNT(*) FROM {$pfx}xf_emoji_packs")->fetchColumn();
      if ($cnt > 0) return;
    } catch (Throwable $e) {
      return;
    }

    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_emoji_packs (title, slug, is_enabled, display_order, created_at)
        VALUES ('Core', 'core', 1, 0, NOW())")->execute();
      $packId = (int)$pdo->lastInsertId();
      if ($packId <= 0) return;

      $base = [
        ['shortcode' => 'smile', 'unicode' => '😀', 'category' => 'smileys'],
        ['shortcode' => 'grin', 'unicode' => '😁', 'category' => 'smileys'],
        ['shortcode' => 'joy', 'unicode' => '😂', 'category' => 'smileys'],
        ['shortcode' => 'wink', 'unicode' => '😉', 'category' => 'smileys'],
        ['shortcode' => 'heart', 'unicode' => '❤️', 'category' => 'symbols'],
        ['shortcode' => 'thumbsup', 'unicode' => '👍', 'category' => 'people'],
        ['shortcode' => 'clap', 'unicode' => '👏', 'category' => 'people'],
        ['shortcode' => 'fire', 'unicode' => '🔥', 'category' => 'symbols'],
        ['shortcode' => 'sparkles', 'unicode' => '✨', 'category' => 'symbols'],
        ['shortcode' => 'rocket', 'unicode' => '🚀', 'category' => 'objects'],
      ];

      $order = 0;
      foreach ($base as $row) {
        $pdo->prepare("INSERT INTO {$pfx}xf_emojis (shortcode, unicode, image_path, category, width, height, is_sticker, display_order)
          VALUES (?,?,?,?,NULL,NULL,0,?)")
          ->execute([
            (string)$row['shortcode'],
            (string)$row['unicode'],
            null,
            (string)$row['category'],
            $order++,
          ]);
        $emojiId = (int)$pdo->lastInsertId();
        if ($emojiId > 0) {
          $pdo->prepare("INSERT INTO {$pfx}xf_emoji_pack_items (pack_id, emoji_id) VALUES (?,?)")
            ->execute([$packId, $emojiId]);
        }
      }

      $stickerPath = self::ensureDefaultSticker();
      if ($stickerPath !== '') {
        $size = @getimagesize(__DIR__ . '/../../' . $stickerPath);
        $w = is_array($size) ? (int)($size[0] ?? 0) : null;
        $h = is_array($size) ? (int)($size[1] ?? 0) : null;
        $pdo->prepare("INSERT INTO {$pfx}xf_emojis (shortcode, unicode, image_path, category, width, height, is_sticker, display_order)
          VALUES (?,?,?,?,?,?,1,?)")
          ->execute(['arc_sticker', null, $stickerPath, 'stickers', $w, $h, $order++]);
        $emojiId = (int)$pdo->lastInsertId();
        if ($emojiId > 0) {
          $pdo->prepare("INSERT INTO {$pfx}xf_emoji_pack_items (pack_id, emoji_id) VALUES (?,?)")
            ->execute([$packId, $emojiId]);
        }
      }
    } catch (Throwable $e) {
      // ignore seeding errors
    }
  }

  /**
   * @return array<int,array<string,mixed>>
   */
  public static function listPacks(PDO $pdo, string $pfx, bool $includeDisabled = false): array {
    self::seedDefaults($pdo, $pfx);
    $where = $includeDisabled ? '' : 'WHERE is_enabled=1';
    try {
      $packs = $pdo->query("SELECT id, title, slug, is_enabled, display_order
        FROM {$pfx}xf_emoji_packs {$where}
        ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
      foreach ($packs as &$pack) {
        $pid = (int)($pack['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT e.* FROM {$pfx}xf_emoji_pack_items i
          JOIN {$pfx}xf_emojis e ON e.id=i.emoji_id
          WHERE i.pack_id=?
          ORDER BY e.display_order ASC, e.id ASC");
        $stmt->execute([$pid]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($items as &$it) {
          $it['image_url'] = self::publicUrl((string)($it['image_path'] ?? ''));
        }
        unset($it);
        $pack['emojis'] = $items;
      }
      unset($pack);
      return $packs;
    } catch (Throwable $e) {
      return [];
    }
  }

  /**
   * @return array<string,array<string,mixed>>
   */
  public static function emojiIndex(PDO $pdo, string $pfx): array {
    self::seedDefaults($pdo, $pfx);
    try {
      $rows = $pdo->query("SELECT id, shortcode, unicode, image_path, is_sticker FROM {$pfx}xf_emojis")->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $out = [];
      foreach ($rows as $r) {
        $code = (string)($r['shortcode'] ?? '');
        if ($code === '') continue;
        $out[$code] = [
          'id' => (int)($r['id'] ?? 0),
          'shortcode' => $code,
          'unicode' => (string)($r['unicode'] ?? ''),
          'image' => self::publicUrl((string)($r['image_path'] ?? '')),
          'is_sticker' => (int)($r['is_sticker'] ?? 0) === 1 ? 1 : 0,
        ];
      }
      return $out;
    } catch (Throwable $e) {
      return [];
    }
  }

  public static function emojiByShortcode(PDO $pdo, string $pfx, string $shortcode): ?array {
    $shortcode = self::sanitizeShortcode($shortcode);
    if ($shortcode === '') return null;
    try {
      $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_emojis WHERE shortcode=? LIMIT 1");
      $stmt->execute([$shortcode]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      return $row ?: null;
    } catch (Throwable $e) {
      return null;
    }
  }

  public static function emojiById(PDO $pdo, string $pfx, int $id): ?array {
    if ($id <= 0) return null;
    try {
      $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_emojis WHERE id=? LIMIT 1");
      $stmt->execute([$id]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      return $row ?: null;
    } catch (Throwable $e) {
      return null;
    }
  }

  public static function sanitizeShortcode(string $code): string {
    $code = strtolower(trim($code));
    if (!preg_match('/^[a-z0-9_-]{1,64}$/', $code)) return '';
    return $code;
  }

  public static function publicUrl(string $path): string {
    $path = trim($path);
    if ($path === '') return '';
    if (!self::isSafePath($path)) return '';
    if (function_exists('url')) {
      return url(ltrim($path, '/'));
    }
    return '/' . ltrim($path, '/');
  }

  public static function isSafePath(string $path): bool {
    $path = trim($path);
    if ($path === '') return false;
    if (preg_match('~^(https?:)?//~i', $path)) return false;
    if (str_starts_with($path, 'data:')) return false;
    if (str_contains($path, '..')) return false;
    return true;
  }

  private static function ensureDefaultSticker(): string {
    $rel = 'uploads/emojis/default/arc_sticker.png';
    $fs = __DIR__ . '/../../' . $rel;
    if (is_file($fs)) return $rel;
    if (!function_exists('imagecreatetruecolor')) return '';

    $dir = dirname($fs);
    if (!is_dir($dir)) {
      @mkdir($dir, 0775, true);
      @file_put_contents($dir . '/index.html', '<!-- Arc OS -->');
    }

    $img = @imagecreatetruecolor(96, 96);
    if (!$img) return '';
    $bg = imagecolorallocate($img, 245, 247, 250);
    $accent = imagecolorallocate($img, 10, 132, 255);
    imagefilledrectangle($img, 0, 0, 96, 96, $bg);
    imagefilledellipse($img, 48, 48, 70, 70, $accent);
    $white = imagecolorallocate($img, 255, 255, 255);
    imagestring($img, 5, 30, 42, 'ARC', $white);
    imagepng($img, $fs);
    imagedestroy($img);
    return is_file($fs) ? $rel : '';
  }
}
