<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class FeatureGate {
  private const PRO_FEATURES = ['favicon', 'admin_path', 'mail', 'moderation', 'custom_css'];
  private const BUSINESS_FEATURES = ['favicon', 'admin_path', 'mail', 'moderation', 'custom_css'];

  public static function enabled(string $feature): bool {
    $feature = strtolower(trim($feature));
    if ($feature === '') return false;
    if (!class_exists(LicenseService::class)) return false;

    $state = LicenseService::loadLocalState();
    $status = strtolower((string)($state['status'] ?? 'invalid'));
    if (!in_array($status, ['valid', 'grace'], true)) return false;

    $tier = strtolower((string)($state['tier'] ?? 'free'));
    if ($tier === 'business') return self::featureAllowed($feature, self::BUSINESS_FEATURES, $state);
    if ($tier === 'pro') return self::featureAllowed($feature, self::PRO_FEATURES, $state);
    return false;
  }

  public static function deny(string $feature, ?string $message = null): void {
    $msg = $message ?? 'Feature not available on current license.';
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
      'ok' => false,
      'error' => 'feature_disabled',
      'feature' => $feature,
      'message' => $msg,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  public static function isFree(): bool {
    if (!class_exists(LicenseService::class)) return true;
    $state = LicenseService::loadLocalState();
    $tier = strtolower((string)($state['tier'] ?? 'free'));
    $status = strtolower((string)($state['status'] ?? 'invalid'));
    if (!in_array($status, ['valid', 'grace'], true)) return true;
    return $tier === 'free';
  }

  /**
   * @param array<string,mixed> $state
   */
  private static function featureAllowed(string $feature, array $defaults, array $state): bool {
    $features = $state['features'] ?? [];
    if (is_array($features)) {
      foreach ($features as $f) {
        if (strtolower((string)$f) === $feature) return true;
      }
    }
    return in_array($feature, $defaults, true);
  }
}
