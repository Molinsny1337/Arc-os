<?php
declare(strict_types=1);

namespace ArcOS\Services;

require_once __DIR__ . '/CryptoService.php';
require_once __DIR__ . '/DiscordApiClient.php';

use PDO;
use Throwable;

final class DiscordRoleSyncService {
  public static function syncUser(PDO $pdo, string $pfx, int $userId): bool {
    if ($userId <= 0) return false;

    $guildId = trim((string)get_setting('discord_guild_id', ''));
    $botEnc = (string)get_setting('discord_bot_token_enc', '');
    $bot = CryptoService::decrypt($botEnc);
    if ($guildId === '' || $bot === '') return false;

    $stmt = $pdo->prepare("SELECT discord_user_id FROM {$pfx}xf_user_discord WHERE user_id=? LIMIT 1");
    $stmt->execute([$userId]);
    $discordUserId = (string)($stmt->fetchColumn() ?: '');
    if ($discordUserId === '') return false;

    $client = new DiscordApiClient(8);
    $roles = [];
    try {
      $data = $client->get('/guilds/' . rawurlencode($guildId) . '/members/' . rawurlencode($discordUserId), [
        'Authorization' => 'Bot ' . $bot,
      ]);
      $roles = isset($data['roles']) && is_array($data['roles']) ? $data['roles'] : [];
    } catch (Throwable $e) {
      self::log($pdo, $pfx, $userId, 'failed', $e->getMessage());
      return false;
    }

    // Map Discord role IDs to group IDs
    $stmt = $pdo->prepare("SELECT role_id, group_id FROM {$pfx}xf_discord_role_map");
    $stmt->execute();
    $map = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $roleSet = [];
    foreach ($roles as $r) {
      if (is_string($r)) $roleSet[$r] = true;
    }

    $mappedGroups = [];
    $allMappedGroups = [];
    foreach ($map as $row) {
      $rid = (string)($row['role_id'] ?? '');
      $gid = (int)($row['group_id'] ?? 0);
      if ($rid === '' || $gid <= 0) continue;
      $allMappedGroups[$gid] = true;
      if (isset($roleSet[$rid])) $mappedGroups[$gid] = true;
    }

    // Fetch current groups
    $stmt = $pdo->prepare("SELECT group_id FROM {$pfx}user_groups WHERE user_id=?");
    $stmt->execute([$userId]);
    $current = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
    $currentSet = [];
    foreach ($current as $gid) $currentSet[(int)$gid] = true;

    // Add missing
    foreach ($mappedGroups as $gid => $_) {
      if (!isset($currentSet[$gid])) {
        $pdo->prepare("INSERT IGNORE INTO {$pfx}user_groups (user_id, group_id, created_at) VALUES (?,?,NOW())")
          ->execute([$userId, $gid]);
      }
    }

    // Remove groups mapped but not present in roles
    foreach ($currentSet as $gid => $_) {
      if (isset($allMappedGroups[$gid]) && !isset($mappedGroups[$gid])) {
        $pdo->prepare("DELETE FROM {$pfx}user_groups WHERE user_id=? AND group_id=?")
          ->execute([$userId, $gid]);
      }
    }

    $pdo->prepare("UPDATE {$pfx}xf_user_discord SET last_sync_at=NOW() WHERE user_id=?")
      ->execute([$userId]);
    self::log($pdo, $pfx, $userId, 'ok', '');
    return true;
  }

  private static function log(PDO $pdo, string $pfx, int $userId, string $status, string $error): void {
    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_discord_sync_log (user_id, status, error, created_at)
        VALUES (?,?,?,NOW())")
        ->execute([$userId, $status, $error !== '' ? $error : null]);
    } catch (Throwable $e) {}
  }
}
