<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class MailService {
  /**
   * Queue an email for background delivery.
   */
  public static function queue(PDO $pdo, string $pfx, string $toEmail, string $subject, string $htmlBody, ?string $textBody = null): bool {
    if (class_exists(FeatureGate::class) && !FeatureGate::enabled('mail')) return false;
    $toEmail = trim($toEmail);
    if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) return false;
    $subject = trim($subject);
    if ($subject === '') $subject = 'Notification';
    $htmlBody = (string)$htmlBody;
    $textBody = $textBody !== null ? (string)$textBody : null;
    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_mail_queue
        (to_email, subject, html_body, text_body, status, attempts, created_at)
        VALUES (?, ?, ?, ?, 'pending', 0, NOW())");
      $stmt->execute([$toEmail, $subject, $htmlBody, $textBody]);
      return true;
    } catch (Throwable $e) {
      self::logError($e->getMessage());
      return false;
    }
  }

  /**
   * Deliver queued emails (worker).
   * @return array{sent:int,failed:int}
   */
  public static function sendQueued(PDO $pdo, string $pfx, int $limit = 10): array {
    if (class_exists(FeatureGate::class) && !FeatureGate::enabled('mail')) {
      return ['sent' => 0, 'failed' => 0];
    }
    $limit = max(1, min(200, $limit));
    $sent = 0;
    $failed = 0;

    $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_mail_queue
      WHERE status='pending' AND (next_attempt_at IS NULL OR next_attempt_at <= NOW())
      ORDER BY created_at ASC
      LIMIT ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    foreach ($rows as $row) {
      $queueId = (int)($row['id'] ?? 0);
      if ($queueId <= 0) continue;

      $to = (string)($row['to_email'] ?? '');
      $subject = (string)($row['subject'] ?? '');
      $html = (string)($row['html_body'] ?? '');
      $text = (string)($row['text_body'] ?? '');
      $attempts = (int)($row['attempts'] ?? 0);

      $error = '';
      $ok = self::deliver($to, $subject, $html, $text !== '' ? $text : null, $error);
      $attempts++;

      if ($ok) {
        $sent++;
        self::updateQueue($pdo, $pfx, $queueId, 'sent', $attempts, null, null, null);
        self::logQueue($pdo, $pfx, $queueId, $to, $subject, 'sent', null);
      } else {
        $failed++;
        $nextDelay = self::backoffSeconds($attempts);
        $nextAttempt = $attempts >= 3 ? null : gmdate('Y-m-d H:i:s', time() + $nextDelay);
        $status = $attempts >= 3 ? 'failed' : 'pending';
        self::updateQueue($pdo, $pfx, $queueId, $status, $attempts, $error, gmdate('Y-m-d H:i:s'), $nextAttempt);
        self::logQueue($pdo, $pfx, $queueId, $to, $subject, 'failed', $error);
      }
    }

    return ['sent' => $sent, 'failed' => $failed];
  }

  /**
   * Deliver a single email immediately (used for test send).
   */
  public static function deliver(string $toEmail, string $subject, string $htmlBody, ?string $textBody, ?string &$error = null): bool {
    $error = null;
    if (class_exists(FeatureGate::class) && !FeatureGate::enabled('mail')) {
      $error = 'Mail disabled';
      return false;
    }
    $cfg = self::config();
    $subject = self::sanitizeHeader($subject);
    $toEmail = trim($toEmail);
    if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
      $error = 'Invalid recipient';
      return false;
    }

    $textBody = $textBody !== null && $textBody !== '' ? $textBody : self::htmlToText($htmlBody);

    if ($cfg['mode'] === 'smtp') {
      if ($cfg['host'] === '' || $cfg['port'] <= 0) {
        $error = 'SMTP not configured';
        return false;
      }
      if (!function_exists('smtp_send_message')) {
        $error = 'SMTP transport unavailable';
        return false;
      }
      $ok = smtp_send_message(
        $cfg['host'],
        $cfg['port'],
        $cfg['user'],
        $cfg['pass'],
        $cfg['from_email'],
        $cfg['from_name'],
        $toEmail,
        $subject,
        $htmlBody,
        $textBody,
        $cfg['reply_to'],
        $cfg['enc']
      );
      if (!$ok) $error = 'SMTP send failed';
      return $ok;
    }

    $boundary = 'arc-mixed-' . bin2hex(random_bytes(6));
    $headers = self::buildHeaders($cfg['from_email'], $cfg['from_name'], $cfg['reply_to'], $boundary);
    $body = self::buildBody($textBody, $htmlBody, $boundary);
    $ok = @mail($toEmail, $subject, $body, implode("\r\n", $headers));
    if (!$ok) $error = 'mail() failed';
    return $ok;
  }

  /**
   * @return array{mode:string,host:string,port:int,user:string,pass:string,enc:string,from_email:string,from_name:string,reply_to:string}
   */
  private static function config(): array {
    $mode = (string)get_setting('mail_mode', 'mail');
    $host = trim((string)get_setting('smtp_host', ''));
    $port = (int)get_setting('smtp_port', '587');
    $user = trim((string)get_setting('smtp_user', ''));
    $passEnc = (string)get_setting('smtp_pass_enc', '');
    $pass = $passEnc !== '' ? CryptoService::decrypt($passEnc) : (string)get_setting('smtp_pass', '');
    $enc = (string)get_setting('smtp_enc', 'tls');
    $fromEmail = trim((string)get_setting('smtp_from', $user));
    if ($fromEmail === '') $fromEmail = $user;
    $fromName = trim((string)get_setting('smtp_from_name', 'Arc OS'));
    $replyTo = trim((string)get_setting('smtp_reply_to', ''));

    return [
      'mode' => $mode === 'smtp' ? 'smtp' : 'mail',
      'host' => $host,
      'port' => $port > 0 ? $port : 587,
      'user' => $user,
      'pass' => $pass,
      'enc' => $enc === 'none' ? 'none' : 'tls',
      'from_email' => $fromEmail,
      'from_name' => $fromName,
      'reply_to' => $replyTo,
    ];
  }

  private static function updateQueue(PDO $pdo, string $pfx, int $id, string $status, int $attempts, ?string $error, ?string $lastAttempt, ?string $nextAttempt): void {
    $stmt = $pdo->prepare("UPDATE {$pfx}xf_mail_queue
      SET status=?, attempts=?, last_error=?, last_attempt_at=?, next_attempt_at=?, sent_at=IF(?='sent', NOW(), sent_at)
      WHERE id=?");
    $stmt->execute([$status, $attempts, $error, $lastAttempt, $nextAttempt, $status, $id]);
  }

  private static function logQueue(PDO $pdo, string $pfx, int $queueId, string $to, string $subject, string $status, ?string $error): void {
    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_mail_log (queue_id, to_email, subject, status, error, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())");
      $stmt->execute([$queueId, $to, $subject, $status, $error]);
    } catch (Throwable $e) {
      self::logError($e->getMessage());
    }
  }

  private static function backoffSeconds(int $attempts): int {
    return match (true) {
      $attempts <= 1 => 60,
      $attempts === 2 => 300,
      default => 900,
    };
  }

  private static function sanitizeHeader(string $value): string {
    return trim(str_replace(["\r", "\n"], '', $value));
  }

  private static function htmlToText(string $html): string {
    $txt = strip_tags($html);
    $txt = preg_replace('/\s+/', ' ', $txt ?? '');
    return trim((string)$txt);
  }

  /**
   * @return string[]
   */
  private static function buildHeaders(string $fromEmail, string $fromName, string $replyTo, string $boundary): array {
    $headers = [
      'MIME-Version: 1.0',
      'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
      'From: ' . self::formatAddress($fromEmail, $fromName),
    ];
    if ($replyTo !== '') {
      $headers[] = 'Reply-To: ' . self::formatAddress($replyTo, '');
    }
    return $headers;
  }

  private static function formatAddress(string $email, string $name): string {
    $email = self::sanitizeHeader($email);
    $name = self::sanitizeHeader($name);
    if ($name === '') return $email;
    return '"' . addslashes($name) . '" <' . $email . '>';
  }

  private static function buildBody(string $textBody, string $htmlBody, string $boundary): string {
    $parts = [];
    $parts[] = "--{$boundary}";
    $parts[] = "Content-Type: text/plain; charset=UTF-8";
    $parts[] = "Content-Transfer-Encoding: base64\r\n";
    $parts[] = chunk_split(base64_encode($textBody));
    $parts[] = "--{$boundary}";
    $parts[] = "Content-Type: text/html; charset=UTF-8";
    $parts[] = "Content-Transfer-Encoding: base64\r\n";
    $parts[] = chunk_split(base64_encode($htmlBody));
    $parts[] = "--{$boundary}--";
    return implode("\r\n", $parts);
  }

  private static function logError(string $message): void {
    $path = __DIR__ . '/../../logs/mail.log';
    @file_put_contents($path, '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n", FILE_APPEND);
  }
}
