<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class LayoutService {
  private PDO $pdo;
  private string $pfx;

  public function __construct(PDO $pdo, string $pfx) {
    $this->pdo = $pdo;
    $this->pfx = $pfx;
  }

  /**
   * @return array<string, mixed>|null
   */
  public function getLayout(string $pageKey): ?array {
    $pageKey = trim($pageKey);
    if ($pageKey === '') return null;
    try {
      $stmt = $this->pdo->prepare("SELECT layout_json FROM {$this->pfx}xf_layout_settings WHERE scope='global' AND page_key=? LIMIT 1");
      $stmt->execute([$pageKey]);
      $json = (string)($stmt->fetchColumn() ?: '');
      if ($json === '') return null;
      $layout = json_decode($json, true);
      return is_array($layout) ? $layout : null;
    } catch (Throwable $e) {
      return null;
    }
  }

  /**
   * @param array<string, string> $blocksById
   * @param array<int, string> $order
   * @param array<int, string> $hidden
   * @return array<int, string>
   */
  public function applyBlocks(array $blocksById, array $order, array $hidden = []): array {
    if (!$blocksById) return [];
    $hiddenSet = [];
    foreach ($hidden as $hid) {
      $hid = (string)$hid;
      if ($hid !== '') $hiddenSet[$hid] = true;
    }
    $out = [];
    $used = [];
    foreach ($order as $id) {
      $id = (string)$id;
      if ($id === '' || isset($hiddenSet[$id]) || !isset($blocksById[$id])) continue;
      $out[] = $blocksById[$id];
      $used[$id] = true;
    }
    foreach ($blocksById as $id => $html) {
      if (isset($used[$id]) || isset($hiddenSet[$id])) continue;
      $out[] = $html;
    }
    return $out;
  }

  /**
   * @param array<string, mixed>|null $layout
   */
  public function sidebarWidth(?array $layout, int $fallback = 280): int {
    $w = (int)($layout['columns']['sidebarWidth'] ?? 0);
    if ($w < 200) $w = $fallback;
    return $w;
  }
}
