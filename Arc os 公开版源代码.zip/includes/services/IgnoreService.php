<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class IgnoreService {
  public static function isIgnored(PDO $pdo, string $pfx, int $userId, int $otherUserId): bool {
    if ($userId <= 0 || $otherUserId <= 0) return false;
    try {
      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_user_ignore WHERE user_id=? AND ignored_user_id=? LIMIT 1");
      $stmt->execute([$userId, $otherUserId]);
      return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
      return false;
    }
  }

  public static function ignore(PDO $pdo, string $pfx, int $userId, int $otherUserId): void {
    if ($userId <= 0 || $otherUserId <= 0 || $userId === $otherUserId) return;
    try {
      $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_user_ignore (user_id, ignored_user_id, created_at) VALUES (?,?,NOW())")
        ->execute([$userId, $otherUserId]);
    } catch (Throwable $e) {}
  }

  public static function unignore(PDO $pdo, string $pfx, int $userId, int $otherUserId): void {
    if ($userId <= 0 || $otherUserId <= 0) return;
    try {
      $pdo->prepare("DELETE FROM {$pfx}xf_user_ignore WHERE user_id=? AND ignored_user_id=?")
        ->execute([$userId, $otherUserId]);
    } catch (Throwable $e) {}
  }
}
