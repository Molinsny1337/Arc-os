<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class WatchService {
  public static function isWatchingThread(PDO $pdo, string $pfx, int $userId, int $threadId): bool {
    if ($userId <= 0 || $threadId <= 0) return false;
    try {
      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_thread_watches WHERE user_id=? AND thread_id=? LIMIT 1");
      $stmt->execute([$userId, $threadId]);
      return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
      return false;
    }
  }

  public static function toggleThread(PDO $pdo, string $pfx, int $userId, int $threadId): bool {
    if ($userId <= 0 || $threadId <= 0) return false;
    try {
      if (self::isWatchingThread($pdo, $pfx, $userId, $threadId)) {
        $pdo->prepare("DELETE FROM {$pfx}xf_thread_watches WHERE user_id=? AND thread_id=?")
          ->execute([$userId, $threadId]);
        return false;
      }
      $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_thread_watches (user_id, thread_id, created_at) VALUES (?,?,NOW())")
        ->execute([$userId, $threadId]);
      return true;
    } catch (Throwable $e) {
      return false;
    }
  }

  public static function isWatchingForum(PDO $pdo, string $pfx, int $userId, int $forumId): bool {
    if ($userId <= 0 || $forumId <= 0) return false;
    try {
      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_forum_watches WHERE user_id=? AND forum_id=? LIMIT 1");
      $stmt->execute([$userId, $forumId]);
      return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
      return false;
    }
  }

  public static function toggleForum(PDO $pdo, string $pfx, int $userId, int $forumId): bool {
    if ($userId <= 0 || $forumId <= 0) return false;
    try {
      if (self::isWatchingForum($pdo, $pfx, $userId, $forumId)) {
        $pdo->prepare("DELETE FROM {$pfx}xf_forum_watches WHERE user_id=? AND forum_id=?")
          ->execute([$userId, $forumId]);
        return false;
      }
      $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_forum_watches (user_id, forum_id, created_at) VALUES (?,?,NOW())")
        ->execute([$userId, $forumId]);
      return true;
    } catch (Throwable $e) {
      return false;
    }
  }
}
