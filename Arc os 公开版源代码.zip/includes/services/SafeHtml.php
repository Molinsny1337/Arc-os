<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class SafeHtml {
  public static function sanitize(string $html): string {
    if (function_exists('arc_sanitize_richtext')) return arc_sanitize_richtext($html);
    return htmlspecialchars($html, ENT_QUOTES);
  }

  public static function render(string $html): string {
    if (function_exists('arc_render_richtext')) return arc_render_richtext($html);
    return self::sanitize($html);
  }
}