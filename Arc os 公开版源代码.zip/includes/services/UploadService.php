<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class UploadService {
  /**
   * @param array<string,mixed> $files
   * @return array<int,array<string,mixed>>
   */
  public static function handleUploads(PDO $pdo, string $pfx, array $user, array $files, string $draftKey, string $contentType = 'draft'): array {
    if ($draftKey === '') return [];
    $normalized = self::normalizeFiles($files);
    if (!$normalized) return [];

    $out = [];
    foreach ($normalized as $file) {
      $item = self::handleSingle($pdo, $pfx, $user, $file, $draftKey, $contentType);
      if ($item) $out[] = $item;
    }
    return $out;
  }

  /**
   * @param array{tmp_name:string,name:string,size:int,error:int,type:string} $file
   * @return array<string,mixed>|null
   */
  public static function handleSingle(PDO $pdo, string $pfx, array $user, array $file, string $draftKey, string $contentType = 'draft'): ?array {
    $uid = (int)($user['id'] ?? 0);
    if ($uid <= 0) return null;
    if ($draftKey === '') return null;

    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    $tmp = (string)($file['tmp_name'] ?? '');
    $orig = trim((string)($file['name'] ?? ''));
    $size = (int)($file['size'] ?? 0);
    if ($tmp === '' || !is_uploaded_file($tmp)) return null;
    if ($size <= 0) return null;

    $max = 20 * 1024 * 1024;
    if ($size > $max) return null;

    $mime = self::detectMime($tmp, $orig);
    if (!self::isAllowedMime($mime)) return null;

    $ext = self::sanitizeExt($orig, $mime);
    if ($ext === '') return null;

    $subdir = date('Y/m');
    $baseDir = __DIR__ . '/../../uploads/attachments/' . $subdir;
    self::ensureDir($baseDir);

    $name = 'att_' . bin2hex(random_bytes(10)) . '.' . $ext;
    $relPath = 'uploads/attachments/' . $subdir . '/' . $name;
    $dest = __DIR__ . '/../../' . $relPath;

    if (!@move_uploaded_file($tmp, $dest)) return null;

    $isImage = str_starts_with($mime, 'image/');
    $width = null;
    $height = null;
    $thumbRel = null;
    $thumbWidth = null;
    $thumbHeight = null;
    if ($isImage) {
      self::stripExif($dest, $mime);
      $info = @getimagesize($dest);
      if (is_array($info)) {
        $width = (int)($info[0] ?? 0);
        $height = (int)($info[1] ?? 0);
      }
      $thumbName = 'thumb_' . $name;
      $thumbRel = 'uploads/attachments/' . $subdir . '/' . $thumbName;
      $thumbPath = __DIR__ . '/../../' . $thumbRel;
      self::ensureDir(dirname($thumbPath));
      $thumbSize = self::createThumbnail($dest, $thumbPath, 360, 360, $mime);
      if (is_array($thumbSize)) {
        $thumbWidth = (int)($thumbSize[0] ?? 0) ?: null;
        $thumbHeight = (int)($thumbSize[1] ?? 0) ?: null;
      }
      if ($thumbWidth === null || $thumbHeight === null) {
        $thumbRel = null;
      }
    }

    $hash = '';
    try {
      $hash = hash_file('sha256', $dest) ?: '';
    } catch (Throwable $e) {
      $hash = '';
    }

    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_attachment_data (user_id, file_name, file_path, file_hash, mime, size_bytes, width, height, thumb_path, thumb_width, thumb_height, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())")
        ->execute([$uid, $orig, $relPath, $hash, $mime, $size, $width, $height, $thumbRel, $thumbWidth, $thumbHeight]);
      $dataId = (int)$pdo->lastInsertId();

      $pdo->prepare("INSERT INTO {$pfx}xf_attachments (data_id, user_id, content_type, content_id, temp_key, created_at)
        VALUES (?,?,?,?,?,NOW())")
        ->execute([$dataId, $uid, $contentType, 0, $draftKey]);
      $attId = (int)$pdo->lastInsertId();

      $thumbUrl = $thumbRel ? url('attachment.php?id=' . $attId . '&thumb=1') : null;
      return [
        'attachment_id' => $attId,
        'file_name' => $orig,
        'size' => $size,
        'is_image' => $isImage ? 1 : 0,
        'url' => url('attachment.php?id=' . $attId),
        'thumb_url' => $thumbUrl,
      ];
    } catch (Throwable $e) {
      @unlink($dest);
      if (!empty($thumbRel)) {
        @unlink(__DIR__ . '/../../' . $thumbRel);
      }
      return null;
    }
  }

  public static function attachDraft(PDO $pdo, string $pfx, int $userId, string $draftKey, string $contentType, int $contentId): void {
    if ($userId <= 0 || $draftKey === '' || $contentId <= 0) return;
    try {
      $pdo->prepare("UPDATE {$pfx}xf_attachments
        SET content_type=?, content_id=?, temp_key=NULL
        WHERE user_id=? AND temp_key=?")
        ->execute([$contentType, $contentId, $userId, $draftKey]);
    } catch (Throwable $e) {}
  }

  /**
   * @return array<string,mixed>|null
   */
  public static function fetchAttachment(PDO $pdo, string $pfx, int $attachmentId): ?array {
    if ($attachmentId <= 0) return null;
    try {
      $stmt = $pdo->prepare("SELECT a.id, a.data_id, d.file_name, d.file_path, d.mime, d.size_bytes, d.width, d.height,
        d.thumb_path, d.thumb_width, d.thumb_height
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.id=? LIMIT 1");
      $stmt->execute([$attachmentId]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$row) return null;
      $row['is_image'] = str_starts_with((string)$row['mime'], 'image/') ? 1 : 0;
      return $row;
    } catch (Throwable $e) {
      return null;
    }
  }

  /**
   * @param array<int,int> $ids
   * @return array<int,array<string,mixed>>
   */
  public static function fetchAttachments(PDO $pdo, string $pfx, array $ids): array {
    $ids = array_values(array_filter(array_map('intval', $ids), function(int $v): bool { return $v > 0; }));
    if (!$ids) return [];
    $in = implode(',', array_fill(0, count($ids), '?'));
    try {
      $stmt = $pdo->prepare("SELECT a.id, a.data_id, d.file_name, d.file_path, d.mime, d.size_bytes, d.width, d.height,
        d.thumb_path, d.thumb_width, d.thumb_height
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.id IN ({$in})");
      $stmt->execute($ids);
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $out = [];
      foreach ($rows as $row) {
        $row['is_image'] = str_starts_with((string)$row['mime'], 'image/') ? 1 : 0;
        $out[(int)$row['id']] = $row;
      }
      return $out;
    } catch (Throwable $e) {
      return [];
    }
  }

  public static function deleteAttachment(PDO $pdo, string $pfx, int $attachmentId, int $userId): bool {
    if ($attachmentId <= 0 || $userId <= 0) return false;
    try {
      $stmt = $pdo->prepare("SELECT a.id, a.data_id, d.file_path, d.thumb_path
        FROM {$pfx}xf_attachments a
        JOIN {$pfx}xf_attachment_data d ON d.id=a.data_id
        WHERE a.id=? AND a.user_id=? LIMIT 1");
      $stmt->execute([$attachmentId, $userId]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$row) return false;

      $dataId = (int)$row['data_id'];
      $filePath = (string)$row['file_path'];
      $thumbPath = (string)($row['thumb_path'] ?? '');

      $pdo->prepare("DELETE FROM {$pfx}xf_attachments WHERE id=? AND user_id=?")
        ->execute([$attachmentId, $userId]);

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_attachments WHERE data_id=?");
      $stmt->execute([$dataId]);
      $left = (int)$stmt->fetchColumn();
      if ($left <= 0) {
        $pdo->prepare("DELETE FROM {$pfx}xf_attachment_data WHERE id=?")
          ->execute([$dataId]);
        $fs = __DIR__ . '/../../' . ltrim($filePath, '/');
        if ($filePath !== '' && is_file($fs)) {
          @unlink($fs);
        }
        if ($thumbPath !== '') {
          $thumbFs = __DIR__ . '/../../' . ltrim($thumbPath, '/');
          if (is_file($thumbFs)) @unlink($thumbFs);
        }
      }
      return true;
    } catch (Throwable $e) {
      return false;
    }
  }

  private static function stripExif(string $path, string $mime): void {
    if ($mime !== 'image/jpeg') return;
    if (!function_exists('imagecreatefromjpeg') || !function_exists('imagejpeg')) return;
    $img = @imagecreatefromjpeg($path);
    if (!$img) return;
    @imagejpeg($img, $path, 90);
    imagedestroy($img);
  }

  /**
   * @return array<int,int>|null
   */
  private static function createThumbnail(string $src, string $dest, int $maxW, int $maxH, string $mime): ?array {
    if (!function_exists('getimagesize')) return null;
    $info = @getimagesize($src);
    if (!is_array($info)) return null;
    $w = (int)($info[0] ?? 0);
    $h = (int)($info[1] ?? 0);
    if ($w <= 0 || $h <= 0) return null;

    $ratio = min($maxW / $w, $maxH / $h, 1);
    $nw = max(1, (int)round($w * $ratio));
    $nh = max(1, (int)round($h * $ratio));

    $srcImg = null;
    if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) $srcImg = @imagecreatefromjpeg($src);
    if ($mime === 'image/png' && function_exists('imagecreatefrompng')) $srcImg = @imagecreatefrompng($src);
    if ($mime === 'image/gif' && function_exists('imagecreatefromgif')) $srcImg = @imagecreatefromgif($src);
    if ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) $srcImg = @imagecreatefromwebp($src);
    if (!$srcImg) return null;

    $dstImg = @imagecreatetruecolor($nw, $nh);
    if (!$dstImg) {
      imagedestroy($srcImg);
      return null;
    }

    if ($mime === 'image/png' || $mime === 'image/gif') {
      imagecolortransparent($dstImg, imagecolorallocatealpha($dstImg, 0, 0, 0, 127));
      imagealphablending($dstImg, false);
      imagesavealpha($dstImg, true);
    }

    @imagecopyresampled($dstImg, $srcImg, 0, 0, 0, 0, $nw, $nh, $w, $h);

    $ok = false;
    if ($mime === 'image/jpeg' && function_exists('imagejpeg')) $ok = @imagejpeg($dstImg, $dest, 85);
    if ($mime === 'image/png' && function_exists('imagepng')) $ok = @imagepng($dstImg, $dest, 6);
    if ($mime === 'image/gif' && function_exists('imagegif')) $ok = @imagegif($dstImg, $dest);
    if ($mime === 'image/webp' && function_exists('imagewebp')) $ok = @imagewebp($dstImg, $dest, 82);

    imagedestroy($srcImg);
    imagedestroy($dstImg);

    if (!$ok || !is_file($dest)) return null;
    return [$nw, $nh];
  }

  /**
   * @param array<string,mixed> $files
   * @return array<int,array{tmp_name:string,name:string,size:int,error:int,type:string}>
   */
  private static function normalizeFiles(array $files): array {
    $out = [];
    if (isset($files['name']) && is_array($files['name'])) {
      $count = count($files['name']);
      for ($i = 0; $i < $count; $i++) {
        $out[] = [
          'name' => (string)($files['name'][$i] ?? ''),
          'type' => (string)($files['type'][$i] ?? ''),
          'tmp_name' => (string)($files['tmp_name'][$i] ?? ''),
          'error' => (int)($files['error'][$i] ?? UPLOAD_ERR_NO_FILE),
          'size' => (int)($files['size'][$i] ?? 0),
        ];
      }
    } elseif (isset($files['name'])) {
      $out[] = [
        'name' => (string)($files['name'] ?? ''),
        'type' => (string)($files['type'] ?? ''),
        'tmp_name' => (string)($files['tmp_name'] ?? ''),
        'error' => (int)($files['error'] ?? UPLOAD_ERR_NO_FILE),
        'size' => (int)($files['size'] ?? 0),
      ];
    }
    return $out;
  }

  private static function ensureDir(string $dir): void {
    if (is_dir($dir)) return;
    @mkdir($dir, 0775, true);
    $idx = rtrim($dir, '/\\') . '/index.html';
    if (!is_file($idx)) {
      @file_put_contents($idx, '<!-- Arc OS -->');
    }
  }

  private static function detectMime(string $tmp, string $name): string {
    $mime = 'application/octet-stream';
    if (is_callable('finfo_open') && is_callable('finfo_file') && is_callable('finfo_close')) {
      try {
        $fi = @finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) {
          $sn = @finfo_file($fi, $tmp);
          if (is_string($sn) && $sn !== '') $mime = $sn;
          @finfo_close($fi);
        }
      } catch (Throwable $e) {}
    } elseif (function_exists('mime_content_type')) {
      $sn = @mime_content_type($tmp);
      if (is_string($sn) && $sn !== '') $mime = $sn;
    }
    if ($mime === 'application/octet-stream') {
      $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
      if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) $mime = 'image/' . ($ext === 'jpg' ? 'jpeg' : $ext);
      if ($ext === 'pdf') $mime = 'application/pdf';
      if ($ext === 'zip') $mime = 'application/zip';
      if ($ext === 'txt') $mime = 'text/plain';
    }
    return $mime;
  }

  private static function sanitizeExt(string $name, string $mime): string {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $ext = preg_replace('/[^a-z0-9]/', '', $ext) ?? '';
    if ($ext === '') {
      $map = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        'application/pdf' => 'pdf',
        'text/plain' => 'txt',
        'application/zip' => 'zip',
      ];
      $ext = $map[$mime] ?? '';
    }
    $allowed = ['jpg','jpeg','png','gif','webp','pdf','txt','zip'];
    if (!in_array($ext, $allowed, true)) return '';
    return $ext === 'jpeg' ? 'jpg' : $ext;
  }

  private static function isAllowedMime(string $mime): bool {
    $allow = [
      'image/jpeg','image/png','image/gif','image/webp',
      'application/pdf','text/plain','application/zip'
    ];
    return in_array($mime, $allow, true);
  }
}
