<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class SearchService {
  /**
   * @return array{total:int,rows:array<int,array<string,mixed>>}
   */
  public static function searchThreads(PDO $pdo, string $pfx, string $q, string $user, int $forumId, int $page, int $perPage): array {
    $q = trim($q);
    $user = trim($user);
    $page = max(1, $page);
    $perPage = max(1, min(50, $perPage));
    $offset = ($page - 1) * $perPage;

    $where = "WHERE p.type='forum' AND p.status='published' AND p.is_deleted=0";
    $params = [];

    if ($q !== '') {
      $where .= " AND (p.title LIKE ? OR p.content LIKE ?)";
      $like = '%' . $q . '%';
      $params[] = $like;
      $params[] = $like;
    }
    if ($user !== '') {
      $where .= " AND (u.username LIKE ? OR u.display_name LIKE ?)";
      $likeU = '%' . $user . '%';
      $params[] = $likeU;
      $params[] = $likeU;
    }
    if ($forumId > 0) {
      $where .= " AND p.forum_id=?";
      $params[] = $forumId;
    }

    $total = 0;
    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts p LEFT JOIN {$pfx}users u ON u.id=p.author_id {$where}");
      $stmt->execute($params);
      $total = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    $rows = [];
    try {
      $sql = "SELECT p.id, p.title, p.slug, p.created_at, p.reply_count, p.view_count, p.last_post_at,
          u.username AS author_username, u.display_name AS author_display,
          f.title AS forum_title,
          lu.username AS last_post_username
        FROM {$pfx}posts p
        LEFT JOIN {$pfx}users u ON u.id=p.author_id
        LEFT JOIN {$pfx}users lu ON lu.id=p.last_post_user_id
        LEFT JOIN {$pfx}forums f ON f.id=p.forum_id
        {$where}
        ORDER BY COALESCE(p.last_post_at, p.created_at) DESC
        LIMIT ? OFFSET ?";
      $stmt = $pdo->prepare($sql);
      $i = 1;
      foreach ($params as $param) {
        if (is_int($param)) $stmt->bindValue($i++, $param, PDO::PARAM_INT);
        else $stmt->bindValue($i++, $param, PDO::PARAM_STR);
      }
      $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
      $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
      $stmt->execute();
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      $rows = [];
    }

    return ['total' => $total, 'rows' => $rows];
  }

  /**
   * @return array{total:int,rows:array<int,array<string,mixed>>}
   */
  public static function searchPosts(PDO $pdo, string $pfx, string $q, string $user, int $forumId, int $page, int $perPage): array {
    $q = trim($q);
    $user = trim($user);
    $page = max(1, $page);
    $perPage = max(1, min(50, $perPage));
    $offset = ($page - 1) * $perPage;

    $where = "WHERE c.is_deleted=0 AND (c.status='visible' OR c.status IS NULL) AND p.type='forum' AND p.status='published' AND p.is_deleted=0";
    $params = [];

    if ($q !== '') {
      $where .= " AND c.content LIKE ?";
      $params[] = '%' . $q . '%';
    }
    if ($user !== '') {
      $where .= " AND (u.username LIKE ? OR u.display_name LIKE ?)";
      $likeU = '%' . $user . '%';
      $params[] = $likeU;
      $params[] = $likeU;
    }
    if ($forumId > 0) {
      $where .= " AND p.forum_id=?";
      $params[] = $forumId;
    }

    $total = 0;
    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments c
        JOIN {$pfx}posts p ON p.id=c.post_id
        LEFT JOIN {$pfx}users u ON u.id=c.author_id {$where}");
      $stmt->execute($params);
      $total = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    $rows = [];
    try {
      $sql = "SELECT c.id, c.post_id, c.content, c.created_at,
          p.title, p.slug,
          u.username AS author_username, u.display_name AS author_display
        FROM {$pfx}post_comments c
        JOIN {$pfx}posts p ON p.id=c.post_id
        LEFT JOIN {$pfx}users u ON u.id=c.author_id
        {$where}
        ORDER BY c.created_at DESC
        LIMIT ? OFFSET ?";
      $stmt = $pdo->prepare($sql);
      $i = 1;
      foreach ($params as $param) {
        if (is_int($param)) $stmt->bindValue($i++, $param, PDO::PARAM_INT);
        else $stmt->bindValue($i++, $param, PDO::PARAM_STR);
      }
      $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
      $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
      $stmt->execute();
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      $rows = [];
    }

    return ['total' => $total, 'rows' => $rows];
  }

  /**
   * @return array{total:int,rows:array<int,array<string,mixed>>}
   */
  public static function searchUsers(PDO $pdo, string $pfx, string $q, int $page, int $perPage): array {
    $q = trim($q);
    $page = max(1, $page);
    $perPage = max(1, min(50, $perPage));
    $offset = ($page - 1) * $perPage;

    $where = '';
    $params = [];
    if ($q !== '') {
      $where = "WHERE u.username LIKE ? OR u.display_name LIKE ?";
      $like = '%' . $q . '%';
      $params = [$like, $like];
    }

    $total = 0;
    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users u {$where}");
      $stmt->execute($params);
      $total = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    $rows = [];
    try {
      $stmt = $pdo->prepare("SELECT u.id, u.username, u.display_name, u.avatar, u.created_at
        FROM {$pfx}users u {$where}
        ORDER BY u.id DESC
        LIMIT ? OFFSET ?");
      $i = 1;
      foreach ($params as $param) {
        $stmt->bindValue($i++, $param, PDO::PARAM_STR);
      }
      $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
      $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
      $stmt->execute();
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      $rows = [];
    }

    return ['total' => $total, 'rows' => $rows];
  }
}
