<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class ModerationService {
  public static function queueEnabled(): bool {
    if (class_exists(FeatureGate::class) && !FeatureGate::enabled('moderation')) return false;
    return function_exists('get_setting') ? get_setting('review_posts', '1') === '1' : false;
  }
}
