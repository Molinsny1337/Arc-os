<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class MentionService {
  /**
   * @return array<int,array<string,mixed>>
   */
  public static function suggestUsers(PDO $pdo, string $pfx, string $q, int $limit = 8): array {
    $q = trim($q);
    if ($q === '' || strlen($q) < 2) return [];
    $limit = max(1, min(20, $limit));
    try {
      $stmt = $pdo->prepare("SELECT id, username, display_name, avatar FROM {$pfx}users WHERE username LIKE ? OR display_name LIKE ? ORDER BY username ASC LIMIT {$limit}");
      $like = $q . '%';
      $stmt->execute([$like, $like]);
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  /**
   * @return array<int,string>
   */
  public static function suggestTags(PDO $pdo, string $pfx, string $q, int $limit = 8): array {
    $q = trim($q);
    if ($q === '' || strlen($q) < 1) return [];
    $limit = max(1, min(20, $limit));
    try {
      $stmt = $pdo->prepare("SELECT tag FROM {$pfx}xf_tags WHERE tag LIKE ? ORDER BY tag ASC LIMIT {$limit}");
      $stmt->execute([$q . '%']);
      return $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  /**
   * @return array<int,int>
   */
  public static function extractMentionIds(string $bbcode): array {
    $ids = [];
    if (preg_match_all('/\[user=([0-9]{1,10})\]/i', $bbcode, $m)) {
      foreach ($m[1] as $id) {
        $ids[] = (int)$id;
      }
    }
    $ids = array_values(array_unique(array_filter($ids, function(int $v): bool { return $v > 0; })));
    return $ids;
  }

  /**
   * @return array<int,string>
   */
  public static function extractMentionNames(string $bbcode): array {
    $txt = strip_tags($bbcode);
    preg_match_all('/(^|\s)@([A-Za-z0-9_\-]{2,32})\b/u', $txt, $m);
    $out = [];
    if (!empty($m[2])) {
      foreach ($m[2] as $name) {
        $name = (string)$name;
        if (!in_array($name, $out, true)) $out[] = $name;
      }
    }
    return $out;
  }

  /**
   * @return array<int,string>
   */
  public static function extractTags(string $bbcode): array {
    $out = [];
    if (preg_match_all('/\[tag\](.*?)\[\/tag\]/i', $bbcode, $m)) {
      foreach ($m[1] as $tag) {
        $tag = trim((string)$tag);
        if ($tag !== '' && !in_array($tag, $out, true)) $out[] = $tag;
      }
    }
    if (preg_match_all('/(^|\s)#([\pL\pN_\-]{1,32})/u', $bbcode, $m2)) {
      foreach ($m2[2] as $tag) {
        $tag = trim((string)$tag);
        if ($tag !== '' && !in_array($tag, $out, true)) $out[] = $tag;
      }
    }
    return $out;
  }

  public static function syncMentions(PDO $pdo, string $pfx, int $fromUserId, string $contentType, int $contentId, string $bbcode): void {
    if ($fromUserId <= 0 || $contentId <= 0) return;
    $ids = self::extractMentionIds($bbcode);
    $names = self::extractMentionNames($bbcode);

    if ($names) {
      $in = implode(',', array_fill(0, count($names), '?'));
      try {
        $stmt = $pdo->prepare("SELECT id, username FROM {$pfx}users WHERE username IN ({$in})");
        $stmt->execute($names);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $r) {
          $uid = (int)($r['id'] ?? 0);
          if ($uid > 0) $ids[] = $uid;
        }
      } catch (Throwable $e) {}
    }

    $ids = array_values(array_unique(array_filter($ids, function(int $v) use ($fromUserId): bool {
      return $v > 0 && $v !== $fromUserId;
    })));
    if (!$ids) return;

    foreach ($ids as $uid) {
      try {
        $pdo->prepare("INSERT INTO {$pfx}xf_mention_log (user_id, from_user_id, content_type, content_id, created_at)
          VALUES (?,?,?,?,NOW())")
          ->execute([$uid, $fromUserId, $contentType, $contentId]);
      } catch (Throwable $e) {}

      if (function_exists('arc_create_alert')) {
        arc_create_alert($uid, $fromUserId, 'mention', $contentType, $contentId, []);
      } elseif (function_exists('arc_add_alert')) {
        arc_add_alert($uid, 'mention', $contentId, '', null);
      }
    }
  }

  /**
   * @param array<int,string> $tags
   */
  public static function syncTags(PDO $pdo, string $pfx, string $contentType, int $contentId, array $tags): void {
    if ($contentId <= 0 || !$tags) return;
    $tags = array_values(array_unique(array_filter($tags, function(string $t): bool {
      $t = trim($t);
      return $t !== '' && (bool)preg_match('/^[\pL\pN_\-]{1,32}$/u', $t);
    })));
    if (!$tags) return;

    foreach ($tags as $tag) {
      try {
        $pdo->prepare("INSERT INTO {$pfx}xf_tags (tag, created_at) VALUES (?, NOW())")
          ->execute([$tag]);
      } catch (Throwable $e) {
        // ignore duplicates
      }

      try {
        $stmt = $pdo->prepare("SELECT id FROM {$pfx}xf_tags WHERE tag=? LIMIT 1");
        $stmt->execute([$tag]);
        $tagId = (int)$stmt->fetchColumn();
        if ($tagId > 0) {
          $pdo->prepare("INSERT INTO {$pfx}xf_content_tags (tag_id, content_type, content_id, created_at) VALUES (?,?,?,NOW())")
            ->execute([$tagId, $contentType, $contentId]);
        }
      } catch (Throwable $e) {}
    }
  }
}