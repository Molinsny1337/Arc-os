<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;

final class AttachmentService {
  public static function upload(PDO $pdo, string $pfx, array $user, int $postId, string $field = 'file'): array {
    if (function_exists('arc_handle_attachments_upload')) {
      return arc_handle_attachments_upload($pdo, $pfx, $user, $postId, $field);
    }
    return [];
  }
}