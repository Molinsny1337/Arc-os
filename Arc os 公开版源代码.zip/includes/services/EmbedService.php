<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class EmbedService {
  public static function render(string $url, string $type = ''): string {
    $url = trim($url);
    if ($url === '') return '';
    $type = strtolower(trim($type));

    $yt = self::youtubeId($url, $type);
    if ($yt !== '') {
      $src = 'https://www.youtube.com/embed/' . $yt;
      return self::iframe($src);
    }

    $bv = self::bilibiliId($url, $type);
    if ($bv !== '') {
      if (str_starts_with($bv, 'av')) {
        $src = 'https://player.bilibili.com/player.html?aid=' . substr($bv, 2);
      } else {
        $src = 'https://player.bilibili.com/player.html?bvid=' . $bv;
      }
      return self::iframe($src);
    }

    return '';
  }

  private static function youtubeId(string $url, string $type): string {
    if ($type !== '' && $type !== 'youtube' && $type !== 'yt') return '';

    $id = '';
    $parts = parse_url($url);
    $host = strtolower((string)($parts['host'] ?? ''));
    if (str_contains($host, 'youtu.be')) {
      $path = trim((string)($parts['path'] ?? ''), '/');
      $id = $path;
    } elseif (str_contains($host, 'youtube.com')) {
      parse_str((string)($parts['query'] ?? ''), $q);
      $id = (string)($q['v'] ?? '');
    }

    $id = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id) ?? '';
    if (strlen($id) < 6) return '';
    return $id;
  }

  private static function bilibiliId(string $url, string $type): string {
    if ($type !== '' && $type !== 'bilibili' && $type !== 'bili') return '';

    $parts = parse_url($url);
    $host = strtolower((string)($parts['host'] ?? ''));
    if (!str_contains($host, 'bilibili.com') && !str_contains($host, 'b23.tv')) return '';

    $path = trim((string)($parts['path'] ?? ''), '/');
    if (preg_match('/(BV[0-9A-Za-z]+)/', $path, $m)) {
      return $m[1];
    }
    if (preg_match('/av([0-9]+)/i', $path, $m)) {
      return 'av' . $m[1];
    }
    return '';
  }

  private static function iframe(string $src): string {
    $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
    return '<div class="bb-media"><iframe src="' . $src . '" loading="lazy" allowfullscreen referrerpolicy="no-referrer"></iframe></div>';
  }
}
