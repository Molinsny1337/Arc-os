<?php
declare(strict_types=1);

namespace ArcOS\Services;

use Throwable;

final class LicenseService {
  private const STATE_TABLE = 'arc_license_state';
  private const STATE_ID = 1;
  private const CHECK_INTERVAL = 43200;
  private const DEFAULT_GRACE_DAYS = 7;

  private static bool $loaded = false;
  /** @var array<string,mixed> */
  private static array $state = [];
  private static bool $recheckScheduled = false;

  /**
   * @return array<string,mixed>
   */
  public static function loadLocalState(): array {
    if (self::$loaded) return self::$state;
    self::$loaded = true;

    $state = self::defaultState();
    $domain = self::currentDomain();
    $state['domain_bound'] = $domain;

    $row = self::loadRow();
    if ($row) {
      $state = array_merge($state, $row);
    }

    $siteId = self::getOrCreateSiteId($row);
    if ($siteId !== '') $state['site_id'] = $siteId;
    if ($state['site_id'] === '' && $siteId !== '') $state['site_id'] = $siteId;

    if ($state['license_blob'] === '') {
      $fileBlob = self::loadLicenseBlobFile();
      if ($fileBlob !== '') $state['license_blob'] = $fileBlob;
    }

    $verify = self::verifyLicenseBlob($state['license_blob'], $domain, (string)$state['site_id']);
    if ($verify['ok']) {
      $payload = $verify['payload'];
      $state = self::mergePayloadIntoState($state, $payload);
    }

    $state = self::computeStatus($state, (bool)$verify['ok']);
    self::persistState($state);
    self::writeSiteIdFile((string)$state['site_id']);

    self::$state = $state;
    return $state;
  }

  /**
   * @return array<string,mixed>
   */
  public static function getState(): array {
    return self::loadLocalState();
  }

  public static function getSiteId(): string {
    $state = self::loadLocalState();
    return (string)($state['site_id'] ?? '');
  }

  public static function normalizeDomain(string $host): string {
    $host = strtolower(trim($host));
    if ($host === '') return '';
    if (str_contains($host, '/')) {
      $parts = parse_url($host);
      $host = strtolower((string)($parts['host'] ?? $host));
    }

    if (preg_match('/^\\[(.+)\\](?::\\d+)?$/', $host, $m)) {
      $host = (string)$m[1];
    } else {
      $host = preg_replace('/:\\d+$/', '', $host) ?? $host;
    }

    $host = rtrim($host, '.');
    if ($host === '') return '';
    if (filter_var($host, FILTER_VALIDATE_IP)) return '';
    if (!preg_match('/^[a-z0-9.-]+$/', $host)) return '';
    return $host;
  }

  /**
   * @return array{ok:bool,payload:array<string,mixed>,error_code:string,message:string}
   */
  public static function verifyLicenseBlob(string $blob, ?string $expectedDomain = null, ?string $expectedSiteId = null): array {
    $blob = trim($blob);
    if ($blob === '') {
      return ['ok' => false, 'payload' => [], 'error_code' => 'license_blob_missing', 'message' => 'Missing license blob'];
    }

    $parsed = self::parseLicenseBlob($blob);
    if (!$parsed['ok']) {
      return ['ok' => false, 'payload' => [], 'error_code' => (string)$parsed['error_code'], 'message' => (string)$parsed['message']];
    }

    $payload = $parsed['payload'];
    if (!is_array($payload)) {
      return ['ok' => false, 'payload' => [], 'error_code' => 'payload_invalid', 'message' => 'Payload invalid'];
    }

    if ($expectedDomain !== null && $expectedDomain !== '') {
      $pDomain = self::normalizeDomain((string)($payload['domain'] ?? ''));
      if ($pDomain === '' || $pDomain !== $expectedDomain) {
        return ['ok' => false, 'payload' => [], 'error_code' => 'domain_mismatch', 'message' => 'Domain mismatch'];
      }
    }

    if ($expectedSiteId !== null && $expectedSiteId !== '') {
      $pSite = (string)($payload['site_id'] ?? '');
      if ($pSite === '' || $pSite !== $expectedSiteId) {
        return ['ok' => false, 'payload' => [], 'error_code' => 'site_id_mismatch', 'message' => 'Site ID mismatch'];
      }
    }

    return ['ok' => true, 'payload' => $payload, 'error_code' => '', 'message' => ''];
  }

  /**
   * @return array{ok:bool,error_code:string,message:string}
   */
  public static function importLicenseBlob(string $blob): array {
    $state = self::loadLocalState();
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $verify = self::verifyLicenseBlob($blob, $domain, (string)($state['site_id'] ?? ''));
    if (!$verify['ok']) return ['ok' => false, 'error_code' => $verify['error_code'], 'message' => $verify['message']];

    self::saveLicenseBlob($blob);
    self::persistPayload($verify['payload']);
    set_setting('license_blob_downloaded_at', gmdate('Y-m-d H:i:s'));
    self::log('license_blob_imported', ['size' => strlen($blob)]);
    self::refreshLocalState();
    return ['ok' => true, 'error_code' => '', 'message' => ''];
  }

  /**
   * @return array{ok:bool,error_code:string,message:string,data:array<string,mixed>}
   */
  public static function activate(string $licenseKey, string $accountToken, ?string $fingerprint = null): array {
    $state = self::loadLocalState();
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $siteId = (string)($state['site_id'] ?? '');
    $client = new LicenseApiClient();
    $res = $client->activate($licenseKey, $accountToken, $domain, $siteId, $fingerprint);
    if (!$res['ok']) {
      self::log('activate_failed', ['code' => $res['error_code']]);
      set_setting('license_last_error', $res['error_code'] . ':' . $res['message']);
      return ['ok' => false, 'error_code' => $res['error_code'], 'message' => $res['message'], 'data' => $res['data']];
    }

    $data = $res['data'];
    $blob = (string)($data['license_blob'] ?? '');
    if ($blob === '') {
      return ['ok' => false, 'error_code' => 'missing_license_blob', 'message' => 'Missing license_blob', 'data' => $data];
    }

    $verify = self::verifyLicenseBlob($blob, $domain, $siteId);
    if (!$verify['ok']) {
      return ['ok' => false, 'error_code' => $verify['error_code'], 'message' => $verify['message'], 'data' => $data];
    }

    self::saveAccountToken($accountToken);
    if (!empty($data['refresh_token'])) {
      self::saveRefreshToken((string)$data['refresh_token']);
    }
    self::saveLicenseBlob($blob);
    self::persistPayload($verify['payload']);
    self::persistFromApi($data, true);
    set_setting('license_blob_downloaded_at', gmdate('Y-m-d H:i:s'));
    self::log('activate_ok', ['tier' => (string)($data['tier'] ?? '')]);
    self::refreshLocalState();
    return ['ok' => true, 'error_code' => '', 'message' => '', 'data' => $data];
  }

  /**
   * @return array{ok:bool,error_code:string,message:string,data:array<string,mixed>}
   */
  public static function refreshNow(): array {
    $state = self::loadLocalState();
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $siteId = (string)($state['site_id'] ?? '');
    $refreshToken = self::decryptToken((string)($state['refresh_token_enc'] ?? ''));
    if ($refreshToken === '') {
      return ['ok' => false, 'error_code' => 'refresh_token_missing', 'message' => 'Missing refresh token', 'data' => []];
    }
    $client = new LicenseApiClient();
    $res = $client->refresh($refreshToken, $domain, $siteId);
    if (!$res['ok']) {
      self::log('refresh_failed', ['code' => $res['error_code']]);
      set_setting('license_last_error', $res['error_code'] . ':' . $res['message']);
      return ['ok' => false, 'error_code' => $res['error_code'], 'message' => $res['message'], 'data' => $res['data']];
    }

    $data = $res['data'];
    if (!empty($data['license_blob'])) {
      $blob = (string)$data['license_blob'];
      $verify = self::verifyLicenseBlob($blob, $domain, $siteId);
      if ($verify['ok']) {
        self::saveLicenseBlob($blob);
        self::persistPayload($verify['payload']);
      }
    }

    $statusRes = self::statusNow();
    self::persistFromApi($data, $statusRes['ok']);
    self::refreshLocalState();
    if (!$statusRes['ok']) {
      return ['ok' => false, 'error_code' => $statusRes['error_code'], 'message' => $statusRes['message'], 'data' => $statusRes['data']];
    }
    return ['ok' => true, 'error_code' => '', 'message' => '', 'data' => $data];
  }

  /**
   * @return array{ok:bool,error_code:string,message:string,data:array<string,mixed>}
   */
  public static function statusNow(): array {
    $state = self::loadLocalState();
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $siteId = (string)($state['site_id'] ?? '');
    $accountToken = self::decryptToken((string)($state['account_token_enc'] ?? ''));
    if ($accountToken === '') {
      return ['ok' => false, 'error_code' => 'account_token_missing', 'message' => 'Missing account token', 'data' => []];
    }

    $client = new LicenseApiClient();
    $res = $client->status($accountToken, $domain, $siteId);
    if (!$res['ok']) {
      self::log('status_failed', ['code' => $res['error_code']]);
      set_setting('license_last_error', $res['error_code'] . ':' . $res['message']);
      return ['ok' => false, 'error_code' => $res['error_code'], 'message' => $res['message'], 'data' => $res['data']];
    }

    self::persistFromApi($res['data'], true);
    self::persistStatusCheckSuccess();
    self::refreshLocalState();
    return ['ok' => true, 'error_code' => '', 'message' => '', 'data' => $res['data']];
  }

  /**
   * @return array{ok:bool,error_code:string,message:string,data:array<string,mixed>}
   */
  public static function downloadNow(): array {
    $state = self::loadLocalState();
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $siteId = (string)($state['site_id'] ?? '');
    $accountToken = self::decryptToken((string)($state['account_token_enc'] ?? ''));
    if ($accountToken === '') {
      return ['ok' => false, 'error_code' => 'account_token_missing', 'message' => 'Missing account token', 'data' => []];
    }
    $client = new LicenseApiClient();
    $res = $client->download($accountToken, $domain, $siteId);
    if (!$res['ok']) {
      self::log('download_failed', ['code' => $res['error_code']]);
      set_setting('license_last_error', $res['error_code'] . ':' . $res['message']);
      return ['ok' => false, 'error_code' => $res['error_code'], 'message' => $res['message'], 'data' => $res['data']];
    }

    $data = $res['data'];
    $blob = (string)($data['license_blob'] ?? '');
    if ($blob === '') {
      return ['ok' => false, 'error_code' => 'missing_license_blob', 'message' => 'Missing license_blob', 'data' => $data];
    }

    $verify = self::verifyLicenseBlob($blob, $domain, $siteId);
    if (!$verify['ok']) {
      return ['ok' => false, 'error_code' => $verify['error_code'], 'message' => $verify['message'], 'data' => $data];
    }
    self::saveLicenseBlob($blob);
    self::persistPayload($verify['payload']);
    self::persistFromApi($data, true);
    self::persistStatusCheckSuccess();
    set_setting('license_blob_downloaded_at', gmdate('Y-m-d H:i:s'));
    self::refreshLocalState();
    return ['ok' => true, 'error_code' => '', 'message' => '', 'data' => $data];
  }

  public static function clearLicense(): void {
    self::saveAccountToken('');
    self::saveRefreshToken('');
    self::saveLicenseBlob('');
    self::persistPayload([]);
    self::persistState([
      'tier' => 'free',
      'features_json' => '[]',
      'expires_at' => null,
      'grace_until' => null,
      'status' => 'invalid',
    ]);
    set_setting('license_last_error', '');
    self::log('license_cleared');
    self::refreshLocalState();
  }

  public static function maybeScheduleRecheck(): void {
    if (self::$recheckScheduled) return;
    $state = self::loadLocalState();
    $nextAt = self::toTimestamp($state['next_check_at'] ?? null);
    if ($nextAt > 0 && time() < $nextAt) return;

    self::$recheckScheduled = true;
    register_shutdown_function(function (): void {
      if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request();
      }
      self::runRecheck();
    });
  }

  /**
   * @return array{ok:bool,status:string,grace_until:?string}
   */
  public static function testEvaluate(array $payload, int $lastCheckAt, ?int $now = null): array {
    $state = self::defaultState();
    $state = self::mergePayloadIntoState($state, $payload);
    $state['last_check_at'] = $lastCheckAt > 0 ? gmdate('Y-m-d H:i:s', $lastCheckAt) : null;
    $tmpNow = $now ?? time();
    $computed = self::computeStatus($state, true, $tmpNow);
    return ['ok' => true, 'status' => (string)$computed['status'], 'grace_until' => $computed['grace_until']];
  }

  public static function saveAccountToken(string $token): void {
    self::loadLocalState();
    $enc = $token !== '' ? Crypto::encrypt($token) : '';
    self::persistState(['account_token_enc' => $enc]);
  }

  public static function saveRefreshToken(string $token): void {
    self::loadLocalState();
    $enc = $token !== '' ? Crypto::encrypt($token) : '';
    self::persistState(['refresh_token_enc' => $enc]);
  }

  private static function runRecheck(): void {
    $state = self::loadLocalState();
    $refreshToken = self::decryptToken((string)($state['refresh_token_enc'] ?? ''));
    $accountToken = self::decryptToken((string)($state['account_token_enc'] ?? ''));
    $domain = (string)($state['domain_bound'] ?? self::currentDomain());
    $siteId = (string)($state['site_id'] ?? '');

    if ($refreshToken === '' || $accountToken === '') {
      self::persistNextCheck();
      return;
    }

    $client = new LicenseApiClient();
    $lastError = '';
    $refreshRes = $client->refresh($refreshToken, $domain, $siteId);
    if ($refreshRes['ok']) {
      if (!empty($refreshRes['data']['license_blob'])) {
        $blob = (string)$refreshRes['data']['license_blob'];
        $verify = self::verifyLicenseBlob($blob, $domain, $siteId);
        if ($verify['ok']) {
          self::saveLicenseBlob($blob);
          self::persistPayload($verify['payload']);
        }
      }
    } else {
      self::log('scheduled_refresh_failed', ['code' => $refreshRes['error_code']]);
      $lastError = $refreshRes['error_code'] . ':' . $refreshRes['message'];
    }

    $statusRes = $client->status($accountToken, $domain, $siteId);
    if ($statusRes['ok']) {
      self::persistFromApi($statusRes['data'], true);
      self::persistStatusCheckSuccess();
    } else {
      self::log('scheduled_status_failed', ['code' => $statusRes['error_code']]);
      $lastError = $statusRes['error_code'] . ':' . $statusRes['message'];
    }

    if ($refreshRes['ok']) {
      self::persistFromApi($refreshRes['data'], $statusRes['ok']);
    }

    if (function_exists('set_setting')) {
      set_setting('license_last_error', $lastError);
    }

    self::persistNextCheck();
    self::refreshLocalState();
  }

  private static function persistStatusCheckSuccess(): void {
    $now = gmdate('Y-m-d H:i:s');
    $next = gmdate('Y-m-d H:i:s', time() + self::CHECK_INTERVAL);
    self::persistState([
      'last_check_at' => $now,
      'next_check_at' => $next,
    ]);
  }

  private static function persistNextCheck(): void {
    $next = gmdate('Y-m-d H:i:s', time() + self::CHECK_INTERVAL);
    self::persistState(['next_check_at' => $next]);
  }

  /**
   * @param array<string,mixed> $payload
   */
  private static function persistPayload(array $payload): void {
    if (!$payload) return;
    $tier = strtolower((string)($payload['tier'] ?? ''));
    $features = $payload['features'] ?? [];
    if (!is_array($features)) $features = [];

    $expiresAt = self::parseTime($payload['expires_at'] ?? null);
    $graceDays = (int)($payload['grace_days'] ?? self::DEFAULT_GRACE_DAYS);
    $graceUntil = $expiresAt > 0 ? $expiresAt + max(0, $graceDays) * 86400 : 0;

    self::persistState([
      'tier' => $tier !== '' ? $tier : 'free',
      'features_json' => json_encode(array_values($features), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]',
      'expires_at' => $expiresAt > 0 ? gmdate('Y-m-d H:i:s', $expiresAt) : null,
      'grace_until' => $graceUntil > 0 ? gmdate('Y-m-d H:i:s', $graceUntil) : null,
    ]);
  }

  /**
   * @param array<string,mixed> $data
   */
  private static function persistFromApi(array $data, bool $statusOk): void {
    if (!$data) return;
    $tier = strtolower((string)($data['tier'] ?? ''));
    $features = $data['features'] ?? [];
    if (!is_array($features)) $features = [];

    $expiresAt = self::parseTime($data['expires_at'] ?? null);
    $graceDays = (int)($data['grace_days'] ?? self::DEFAULT_GRACE_DAYS);
    $graceUntil = $expiresAt > 0 ? $expiresAt + max(0, $graceDays) * 86400 : 0;

    $nextCheckIn = (int)($data['next_check_in'] ?? 0);
    $nextCheck = $nextCheckIn > 0 ? (time() + min($nextCheckIn, self::CHECK_INTERVAL)) : (time() + self::CHECK_INTERVAL);

    $fields = [
      'tier' => $tier !== '' ? $tier : 'free',
      'features_json' => json_encode(array_values($features), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]',
      'expires_at' => $expiresAt > 0 ? gmdate('Y-m-d H:i:s', $expiresAt) : null,
      'grace_until' => $graceUntil > 0 ? gmdate('Y-m-d H:i:s', $graceUntil) : null,
      'next_check_at' => gmdate('Y-m-d H:i:s', $nextCheck),
    ];

    if ($statusOk) {
      $fields['last_check_at'] = gmdate('Y-m-d H:i:s');
    }

    self::persistState($fields);
  }

  /**
   * @return array<string,mixed>
   */
  private static function computeStatus(array $state, bool $licenseOk, ?int $nowOverride = null): array {
    $now = $nowOverride ?? time();
    if (!$licenseOk) {
      $state['status'] = 'invalid';
      return $state;
    }

    $accountTokenEnc = (string)($state['account_token_enc'] ?? '');
    if ($accountTokenEnc === '') {
      $state['status'] = 'invalid';
      return $state;
    }

    $expiresAt = self::toTimestamp($state['expires_at'] ?? null);
    $lastCheck = self::toTimestamp($state['last_check_at'] ?? null);
    if ($lastCheck <= 0) {
      $state['status'] = 'invalid';
      return $state;
    }
    $graceDays = (int)($state['grace_days'] ?? self::DEFAULT_GRACE_DAYS);
    if ($graceDays <= 0) $graceDays = self::DEFAULT_GRACE_DAYS;

    $licenseExpired = $expiresAt > 0 && $now > $expiresAt;
    $accountFresh = $lastCheck > 0 && ($now - $lastCheck) <= self::CHECK_INTERVAL;
    $accountStale = !$accountFresh;

    if (!$licenseExpired && $accountFresh) {
      $state['status'] = 'valid';
      return $state;
    }

    $graceUntil = 0;
    if ($licenseExpired && $expiresAt > 0) {
      $graceUntil = $expiresAt + ($graceDays * 86400);
    }
    if ($accountStale) {
      $accGrace = $lastCheck > 0 ? ($lastCheck + ($graceDays * 86400)) : ($now + ($graceDays * 86400));
      $graceUntil = $graceUntil > 0 ? min($graceUntil, $accGrace) : $accGrace;
    }

    if ($graceUntil > 0 && $now <= $graceUntil) {
      $state['status'] = 'grace';
      $state['grace_until'] = gmdate('Y-m-d H:i:s', $graceUntil);
      return $state;
    }

    $state['status'] = 'invalid';
    return $state;
  }

  /**
   * @return array<string,mixed>
   */
  private static function mergePayloadIntoState(array $state, array $payload): array {
    $tier = strtolower((string)($payload['tier'] ?? 'free'));
    $features = $payload['features'] ?? [];
    if (!is_array($features)) $features = [];
    $expiresAt = self::parseTime($payload['expires_at'] ?? null);
    $graceDays = (int)($payload['grace_days'] ?? self::DEFAULT_GRACE_DAYS);
    $graceUntil = $expiresAt > 0 ? $expiresAt + max(0, $graceDays) * 86400 : 0;

    $state['tier'] = $tier !== '' ? $tier : 'free';
    $state['features_json'] = json_encode(array_values($features), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]';
    $state['features'] = array_values($features);
    $state['expires_at'] = $expiresAt > 0 ? gmdate('Y-m-d H:i:s', $expiresAt) : null;
    $state['grace_until'] = $graceUntil > 0 ? gmdate('Y-m-d H:i:s', $graceUntil) : null;
    $state['grace_days'] = $graceDays;
    return $state;
  }

  /**
   * @return array{ok:bool,payload:array<string,mixed>,error_code:string,message:string}
   */
  private static function parseLicenseBlob(string $blob): array {
    if (substr_count($blob, '.') === 2) {
      $parts = explode('.', $blob);
      if (count($parts) === 3) {
        $headerJson = self::b64url_decode($parts[0]);
        $payloadJson = self::b64url_decode($parts[1]);
        $sig = self::b64url_decode($parts[2]);
        $header = $headerJson !== '' ? json_decode($headerJson, true) : null;
        $payload = $payloadJson !== '' ? json_decode($payloadJson, true) : null;
        if (!is_array($payload)) return ['ok' => false, 'payload' => [], 'error_code' => 'payload_invalid', 'message' => 'Payload invalid'];

        $alg = is_array($header) ? strtolower((string)($header['alg'] ?? '')) : '';
        $signingInput = $parts[0] . '.' . $parts[1];
        if (!self::verifySignature($alg, $signingInput, $sig)) {
          return ['ok' => false, 'payload' => [], 'error_code' => 'signature_invalid', 'message' => 'Signature invalid'];
        }
        return ['ok' => true, 'payload' => $payload, 'error_code' => '', 'message' => ''];
      }
    }

    $raw = $blob;
    if (!str_starts_with(ltrim($raw), '{')) {
      $decoded = self::b64url_decode($raw);
      if ($decoded !== '' && str_starts_with(ltrim($decoded), '{')) $raw = $decoded;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
      return ['ok' => false, 'payload' => [], 'error_code' => 'blob_invalid', 'message' => 'Blob invalid'];
    }

    $payloadRaw = $data['payload'] ?? null;
    $sigRaw = (string)($data['signature'] ?? '');
    $alg = strtolower((string)($data['alg'] ?? ''));
    if ($sigRaw === '') {
      return ['ok' => false, 'payload' => [], 'error_code' => 'signature_missing', 'message' => 'Signature missing'];
    }

    $payload = null;
    $payloadJson = '';
    if (is_string($payloadRaw)) {
      $payloadJson = $payloadRaw;
      if (!str_starts_with(ltrim($payloadRaw), '{')) {
        $decoded = self::b64url_decode($payloadRaw);
        if ($decoded !== '') $payloadJson = $decoded;
      }
      $payload = json_decode($payloadJson, true);
    } elseif (is_array($payloadRaw)) {
      $payload = $payloadRaw;
      $payloadJson = self::canonicalJson($payload);
    }

    if (!is_array($payload)) {
      return ['ok' => false, 'payload' => [], 'error_code' => 'payload_invalid', 'message' => 'Payload invalid'];
    }

    $sig = self::b64url_decode($sigRaw);
    $canon = self::canonicalJson($payload);
    $inputs = [];
    if ($canon !== '') $inputs[] = $canon;
    if ($canon !== '') $inputs[] = self::b64url_encode($canon);
    if ($payloadJson !== '' && $payloadJson !== $canon) $inputs[] = $payloadJson;

    foreach ($inputs as $input) {
      if (self::verifySignature($alg, $input, $sig)) {
        return ['ok' => true, 'payload' => $payload, 'error_code' => '', 'message' => ''];
      }
    }

    return ['ok' => false, 'payload' => [], 'error_code' => 'signature_invalid', 'message' => 'Signature invalid'];
  }

  private static function verifySignature(string $alg, string $input, string $sig): bool {
    $keys = self::getPublicKeys();
    $wantEd = ($alg === 'eddsa' || $alg === 'ed25519');
    $wantRsa = ($alg === 'rs256' || $alg === 'rsa' || $alg === 'rsa256');

    if ($wantEd || $alg === '') {
      foreach ($keys['ed25519'] as $key) {
        if (self::verifyEd25519($input, $sig, $key)) return true;
      }
    }
    if ($wantRsa || $alg === '') {
      foreach ($keys['rsa'] as $key) {
        if (self::verifyRsa($input, $sig, $key)) return true;
      }
    }
    return false;
  }

  private static function verifyEd25519(string $input, string $sig, string $pubKey): bool {
    if (!function_exists('sodium_crypto_sign_verify_detached')) return false;
    if ($pubKey === '' || $sig === '') return false;
    return sodium_crypto_sign_verify_detached($sig, $input, $pubKey);
  }

  private static function verifyRsa(string $input, string $sig, string $pubKey): bool {
    if ($pubKey === '' || !function_exists('openssl_verify')) return false;
    $pem = $pubKey;
    if (!str_contains($pem, 'BEGIN PUBLIC KEY')) {
      $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(trim($pem), 64, "\n") . "-----END PUBLIC KEY-----\n";
    }
    $ok = @openssl_verify($input, $sig, $pem, OPENSSL_ALGO_SHA256);
    return $ok === 1;
  }

  /**
   * @return array{ed25519:string[],rsa:string[]}
   */
  private static function getPublicKeys(): array {
    $raw = function_exists('get_setting') ? (string)get_setting('license_center_public_key', '') : '';
    $raw = trim($raw);
    $keys = ['ed25519' => [], 'rsa' => []];
    if ($raw === '') return $keys;

    if (str_contains($raw, 'BEGIN PUBLIC KEY')) {
      $keys['rsa'][] = $raw;
      return $keys;
    }

    if (preg_match('/^[A-Fa-f0-9]{64}$/', $raw)) {
      $bin = hex2bin($raw);
      if ($bin !== false) $keys['ed25519'][] = $bin;
      return $keys;
    }

    $bin = base64_decode($raw, true);
    if ($bin === false) $bin = self::b64url_decode($raw);
    if (is_string($bin) && strlen($bin) === 32) {
      $keys['ed25519'][] = $bin;
      return $keys;
    }

    $keys['rsa'][] = $raw;
    return $keys;
  }

  private static function canonicalJson($data): string {
    $norm = self::canonicalize($data);
    $json = json_encode($norm, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return is_string($json) ? $json : '';
  }

  private static function canonicalize($value) {
    if (is_array($value)) {
      $isList = array_keys($value) === range(0, count($value) - 1);
      if ($isList) {
        $out = [];
        foreach ($value as $v) $out[] = self::canonicalize($v);
        return $out;
      }
      $out = [];
      $keys = array_keys($value);
      sort($keys, SORT_STRING);
      foreach ($keys as $k) {
        $out[$k] = self::canonicalize($value[$k]);
      }
      return $out;
    }
    return $value;
  }

  private static function saveLicenseBlob(string $blob): void {
    $blob = trim($blob);
    $dir = self::licenseBlobDir();
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = self::licenseBlobPath();
    if ($blob === '') {
      if (is_file($file)) @unlink($file);
      self::persistState(['license_blob' => null]);
      return;
    }
    @file_put_contents($file, $blob, LOCK_EX);
    self::persistState(['license_blob' => $blob]);
  }

  /**
   * @return array<string,mixed>
   */
  private static function defaultState(): array {
    return [
      'site_id' => '',
      'domain_bound' => '',
      'tier' => 'free',
      'features_json' => '[]',
      'features' => [],
      'license_blob' => '',
      'account_token_enc' => '',
      'refresh_token_enc' => '',
      'last_check_at' => null,
      'next_check_at' => null,
      'expires_at' => null,
      'grace_until' => null,
      'status' => 'invalid',
      'grace_days' => self::DEFAULT_GRACE_DAYS,
    ];
  }

  /**
   * @return array<string,mixed>|null
   */
  private static function loadRow(): ?array {
    if (!function_exists('db_try') || !function_exists('table_prefix')) return null;
    $pdo = db_try();
    if (!$pdo) return null;
    $table = table_prefix() . self::STATE_TABLE;
    if (!self::tableExists($pdo, $table)) return null;
    try {
      $stmt = $pdo->prepare("SELECT * FROM {$table} WHERE id=? LIMIT 1");
      $stmt->execute([self::STATE_ID]);
      $row = $stmt->fetch();
      if (!is_array($row)) return null;
      $row['features'] = [];
      $raw = (string)($row['features_json'] ?? '');
      $decoded = $raw !== '' ? json_decode($raw, true) : null;
      if (is_array($decoded)) $row['features'] = $decoded;
      return $row;
    } catch (Throwable $e) {
      return null;
    }
  }

  /**
   * @param array<string,mixed>|null $row
   */
  private static function getOrCreateSiteId(?array $row): string {
    $existing = '';
    if (is_array($row) && !empty($row['site_id'])) {
      $existing = (string)$row['site_id'];
    }
    if ($existing !== '') return $existing;

    $file = self::siteIdPath();
    if (is_file($file)) {
      $sid = trim((string)@file_get_contents($file));
      if (self::isUuid($sid)) return $sid;
    }

    $new = self::uuidv4();
    self::writeSiteIdFile($new);
    self::persistState(['site_id' => $new]);
    return $new;
  }

  private static function writeSiteIdFile(string $siteId): void {
    if ($siteId === '' || !self::isUuid($siteId)) return;
    $file = self::siteIdPath();
    if (is_file($file)) return;
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    @file_put_contents($file, $siteId, LOCK_EX);
  }

  /**
   * @param array<string,mixed> $fields
   */
  private static function persistState(array $fields): void {
    if (!function_exists('db_try') || !function_exists('table_prefix')) return;
    $pdo = db_try();
    if (!$pdo) return;
    $table = table_prefix() . self::STATE_TABLE;
    if (!self::tableExists($pdo, $table)) return;

    $allowed = [
      'id', 'site_id', 'domain_bound', 'tier', 'features_json', 'license_blob',
      'account_token_enc', 'refresh_token_enc', 'last_check_at', 'next_check_at',
      'expires_at', 'grace_until', 'status',
    ];
    $fields = array_intersect_key($fields, array_flip($allowed));
    if (!$fields) return;

    $fields['id'] = self::STATE_ID;
    $cols = array_keys($fields);
    $set = [];
    foreach ($cols as $col) {
      if ($col === 'id') continue;
      $set[] = "`{$col}`=VALUES(`{$col}`)";
    }
    $placeholders = implode(',', array_fill(0, count($cols), '?'));
    $updates = implode(',', $set);
    $sql = "INSERT INTO {$table} (`" . implode('`,`', $cols) . "`) VALUES ({$placeholders}) ON DUPLICATE KEY UPDATE {$updates}";
    $vals = [];
    foreach ($cols as $col) {
      $vals[] = $fields[$col];
    }
    try {
      $stmt = $pdo->prepare($sql);
      $stmt->execute($vals);
    } catch (Throwable $e) {
      // ignore
    }
  }

  private static function tableExists($pdo, string $table): bool {
    try {
      $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
      $row = $stmt ? $stmt->fetchColumn() : false;
      return (bool)$row;
    } catch (Throwable $e) {
      return false;
    }
  }

  private static function refreshLocalState(): void {
    self::$loaded = false;
    self::$state = [];
    self::loadLocalState();
  }

  private static function currentDomain(): string {
    $host = (string)($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
    $domain = self::normalizeDomain($host);
    if ($domain !== '') return $domain;
    if (function_exists('get_setting')) {
      $siteUrl = (string)get_setting('site_url', '');
      if ($siteUrl !== '') {
        $p = parse_url($siteUrl);
        $h = (string)($p['host'] ?? '');
        $domain = self::normalizeDomain($h);
        if ($domain !== '') return $domain;
      }
    }
    return '';
  }

  private static function loadLicenseBlobFile(): string {
    $file = self::licenseBlobPath();
    if (!is_file($file)) return '';
    return trim((string)@file_get_contents($file));
  }

  private static function licenseBlobDir(): string {
    return __DIR__ . '/../../data/license';
  }

  private static function licenseBlobPath(): string {
    return self::licenseBlobDir() . '/license.blob';
  }

  private static function siteIdPath(): string {
    return __DIR__ . '/../../data/site_id';
  }

  private static function parseTime($value): int {
    if (is_int($value)) return $value;
    if (is_numeric($value)) return (int)$value;
    $str = trim((string)$value);
    if ($str === '') return 0;
    $ts = strtotime($str);
    return $ts !== false ? $ts : 0;
  }

  private static function toTimestamp($value): int {
    if ($value === null) return 0;
    if (is_int($value)) return $value;
    if (is_string($value) && $value !== '') {
      $ts = strtotime($value);
      return $ts !== false ? $ts : 0;
    }
    return 0;
  }

  private static function isUuid(string $v): bool {
    return (bool)preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $v);
  }

  private static function uuidv4(): string {
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    $hex = bin2hex($data);
    return sprintf('%s-%s-%s-%s-%s',
      substr($hex, 0, 8),
      substr($hex, 8, 4),
      substr($hex, 12, 4),
      substr($hex, 16, 4),
      substr($hex, 20, 12)
    );
  }

  private static function decryptToken(string $enc): string {
    if ($enc === '') return '';
    return Crypto::decrypt($enc);
  }

  private static function b64url_encode(string $raw): string {
    if (function_exists('arc_b64url_encode')) return arc_b64url_encode($raw);
    $b64 = base64_encode($raw);
    return str_replace(['+', '/', '='], ['-', '_', ''], $b64);
  }

  private static function b64url_decode(string $b64url): string {
    if (function_exists('arc_b64url_decode')) return arc_b64url_decode($b64url);
    $b64 = str_replace(['-', '_'], ['+', '/'], $b64url);
    $pad = strlen($b64) % 4;
    if ($pad) $b64 .= str_repeat('=', 4 - $pad);
    $out = base64_decode($b64, true);
    return $out === false ? '' : $out;
  }

  private static function log(string $event, array $meta = []): void {
    $path = __DIR__ . '/../../logs/license.log';
    $dir = dirname($path);
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $safe = [];
    foreach ($meta as $k => $v) {
      $safe[$k] = is_scalar($v) ? (string)$v : json_encode($v);
    }
    $line = '[' . gmdate('Y-m-d H:i:s') . '] ' . $event;
    if ($safe) $line .= ' ' . json_encode($safe, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    @file_put_contents($path, $line . "\n", FILE_APPEND);
  }
}
