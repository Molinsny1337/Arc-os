<?php
declare(strict_types=1);

namespace ArcOS\Services;

require_once __DIR__ . '/CryptoService.php';

use PDO;
use Throwable;

final class DiscordWebhookService {
  private const THROTTLE_SECONDS = 60;

  /**
   * @param array<string,mixed> $payload
   */
  public static function send(string $event, array $payload): bool {
    if (!function_exists('get_setting')) return false;
    if (get_setting('discord_webhook_enabled', '0') !== '1') return false;

    $eventKey = self::eventSettingKey($event);
    if ($eventKey !== '' && get_setting($eventKey, '0') !== '1') return false;

    $urlEnc = (string)get_setting('discord_webhook_url_enc', '');
    $url = CryptoService::decrypt($urlEnc);
    if ($url === '') return false;

    $throttleKey = self::throttleKey($event, $payload);
    if ($throttleKey !== '' && self::isThrottled($throttleKey)) return false;

    $embed = self::buildEmbed($event, $payload);
    $data = ['embeds' => [$embed]];

    $ok = false;
    $err = '';
    $resp = '';

    try {
      $ch = curl_init();
      if ($ch === false) throw new \RuntimeException('CURL_NOT_AVAILABLE');

      $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($json)) $json = '{}';

      curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
          'Content-Type: application/json',
          'Accept: application/json',
        ],
        CURLOPT_POSTFIELDS => $json,
      ]);

      $respRaw = curl_exec($ch);
      $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
      $curlErr = curl_error($ch);
      curl_close($ch);

      if ($respRaw === false) throw new \RuntimeException('CURL_ERROR:' . $curlErr);
      if ($code >= 400) throw new \RuntimeException('HTTP_' . $code);

      $ok = true;
      $resp = is_string($respRaw) ? substr($respRaw, 0, 500) : '';
    } catch (Throwable $e) {
      $err = $e->getMessage();
    }

    if ($throttleKey !== '') self::markThrottle($throttleKey);
    self::log($event, $ok ? 'sent' : 'failed', $err, $resp);

    return $ok;
  }

  /**
   * @param array<string,mixed> $payload
   * @return array<string,mixed>
   */
  private static function buildEmbed(string $event, array $payload): array {
    $title = trim((string)($payload['title'] ?? ''));
    $desc = trim((string)($payload['description'] ?? ''));
    $url = trim((string)($payload['url'] ?? ''));
    $author = trim((string)($payload['author'] ?? ''));
    $avatar = trim((string)($payload['avatar_url'] ?? ''));
    $color = (int)($payload['color'] ?? 0x1D9BF0);

    if ($title === '') $title = self::eventLabel($event);

    $fields = [];
    $channel = trim((string)($payload['channel'] ?? ''));
    if ($channel !== '') $fields[] = ['name' => 'Channel', 'value' => $channel, 'inline' => true];
    $thread = trim((string)($payload['thread'] ?? ''));
    if ($thread !== '') $fields[] = ['name' => 'Thread', 'value' => $thread, 'inline' => true];
    $summary = trim((string)($payload['summary'] ?? ''));
    if ($summary !== '') $fields[] = ['name' => 'Summary', 'value' => $summary, 'inline' => false];

    $embed = [
      'title' => $title,
      'description' => $desc !== '' ? $desc : null,
      'url' => $url !== '' ? $url : null,
      'color' => $color,
      'fields' => $fields,
      'timestamp' => gmdate('c'),
    ];

    if ($author !== '') {
      $embed['author'] = [
        'name' => $author,
        'icon_url' => $avatar !== '' ? $avatar : null,
      ];
    }

    return array_filter($embed, function($v): bool { return $v !== null; });
  }

  private static function eventSettingKey(string $event): string {
    $map = [
      'new_thread' => 'discord_webhook_event_new_thread',
      'new_post' => 'discord_webhook_event_new_post',
      'report_created' => 'discord_webhook_event_report_created',
      'moderation_queue' => 'discord_webhook_event_moderation_queue',
      'user_registered' => 'discord_webhook_event_user_registered',
    ];
    return $map[$event] ?? '';
  }

  private static function eventLabel(string $event): string {
    $map = [
      'new_thread' => 'New Thread',
      'new_post' => 'New Reply',
      'report_created' => 'New Report',
      'moderation_queue' => 'Moderation Queue',
      'user_registered' => 'New User',
    ];
    return $map[$event] ?? $event;
  }

  /**
   * @param array<string,mixed> $payload
   */
  private static function throttleKey(string $event, array $payload): string {
    $id = (string)($payload['thread_id'] ?? ($payload['content_id'] ?? ''));
    if ($id === '') return '';
    return $event . '_' . $id;
  }

  private static function isThrottled(string $key): bool {
    $dir = __DIR__ . '/../../storage/discord_throttle';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = $dir . '/' . hash('sha256', $key) . '.txt';
    if (!is_file($file)) return false;
    $ts = (int)@filemtime($file);
    return $ts > 0 && (time() - $ts) < self::THROTTLE_SECONDS;
  }

  private static function markThrottle(string $key): void {
    $dir = __DIR__ . '/../../storage/discord_throttle';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $file = $dir . '/' . hash('sha256', $key) . '.txt';
    @file_put_contents($file, '1');
  }

  private static function log(string $event, string $status, string $error, string $response): void {
    if (!function_exists('db')) return;
    try {
      $pdo = db();
      $pfx = table_prefix();
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_webhook_log (event, status, error, response_snippet, created_at)
        VALUES (?,?,?,?,NOW())");
      $stmt->execute([$event, $status, $error !== '' ? $error : null, $response !== '' ? $response : null]);
    } catch (Throwable $e) {
      // ignore
    }
  }
}
