<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class Csrf {
  public static function token(): string {
    return function_exists('csrf_token') ? (string)csrf_token() : '';
  }

  public static function field(): string {
    return function_exists('csrf_field') ? (string)csrf_field() : '';
  }

  public static function check(): void {
    if (function_exists('require_csrf')) {
      require_csrf();
    }
  }
}