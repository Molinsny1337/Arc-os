<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

require_once __DIR__ . '/BbCode.php';

final class EditorDraftService {
  public static function save(PDO $pdo, string $pfx, int $userId, string $draftKey, string $contentType, int $contentId, string $bbcode, array $attachments = []): void {
    if ($userId <= 0 || $draftKey === '') return;
    $bbcode = BbCode::normalize($bbcode);
    $attachmentsJson = json_encode(array_values($attachments), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($attachmentsJson)) $attachmentsJson = '[]';
    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_drafts (draft_key, user_id, content_type, content_id, bbcode, attachments_json, created_at, updated_at)
        VALUES (?,?,?,?,?,?,NOW(),NOW())
        ON DUPLICATE KEY UPDATE bbcode=VALUES(bbcode), attachments_json=VALUES(attachments_json), updated_at=NOW()")
        ->execute([$draftKey, $userId, $contentType, $contentId, $bbcode, $attachmentsJson]);
    } catch (Throwable $e) {}
  }

  /**
   * @return array<string,mixed>|null
   */
  public static function load(PDO $pdo, string $pfx, int $userId, string $draftKey): ?array {
    if ($userId <= 0 || $draftKey === '') return null;
    try {
      $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_drafts WHERE draft_key=? AND user_id=? LIMIT 1");
      $stmt->execute([$draftKey, $userId]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if (!$row) return null;
      $row['attachments'] = [];
      if (!empty($row['attachments_json'])) {
        $tmp = json_decode((string)$row['attachments_json'], true);
        if (is_array($tmp)) $row['attachments'] = $tmp;
      }
      return $row;
    } catch (Throwable $e) {
      return null;
    }
  }
}
