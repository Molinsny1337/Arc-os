<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class Crypto {
  private const PREFIX_GCM = 'gcm:';
  private const PREFIX_CBC = 'cbc:';

  public static function encrypt(string $plain): string {
    if ($plain === '') return '';
    $key = self::key();
    if ($key === '') return '';

    if (function_exists('openssl_encrypt')) {
      $iv = random_bytes(12);
      $tag = '';
      $cipher = @openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
      if (is_string($cipher) && $cipher !== '' && $tag !== '') {
        return self::PREFIX_GCM
          . self::b64url($iv) . ':'
          . self::b64url($tag) . ':'
          . self::b64url($cipher);
      }

      $iv = random_bytes(16);
      $cipher = @openssl_encrypt($plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
      if (is_string($cipher) && $cipher !== '') {
        $mac = hash_hmac('sha256', $iv . $cipher, $key, true);
        return self::PREFIX_CBC
          . self::b64url($iv) . ':'
          . self::b64url($mac) . ':'
          . self::b64url($cipher);
      }
    }

    return '';
  }

  public static function decrypt(string $enc): string {
    $enc = trim($enc);
    if ($enc === '') return '';
    $key = self::key();
    if ($key === '') return '';

    if (str_starts_with($enc, self::PREFIX_GCM)) {
      $payload = substr($enc, strlen(self::PREFIX_GCM));
      $parts = explode(':', $payload);
      if (count($parts) !== 3) return '';
      [$ivB64, $tagB64, $ctB64] = $parts;
      $iv = self::b64url_decode($ivB64);
      $tag = self::b64url_decode($tagB64);
      $ct = self::b64url_decode($ctB64);
      if ($iv === '' || $tag === '' || $ct === '') return '';
      $plain = @openssl_decrypt($ct, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
      return is_string($plain) ? $plain : '';
    }

    if (str_starts_with($enc, self::PREFIX_CBC)) {
      $payload = substr($enc, strlen(self::PREFIX_CBC));
      $parts = explode(':', $payload);
      if (count($parts) !== 3) return '';
      [$ivB64, $macB64, $ctB64] = $parts;
      $iv = self::b64url_decode($ivB64);
      $mac = self::b64url_decode($macB64);
      $ct = self::b64url_decode($ctB64);
      if ($iv === '' || $mac === '' || $ct === '') return '';
      $calc = hash_hmac('sha256', $iv . $ct, $key, true);
      if (!hash_equals($mac, $calc)) return '';
      $plain = @openssl_decrypt($ct, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
      return is_string($plain) ? $plain : '';
    }

    return '';
  }

  private static function key(): string {
    if (!defined('APP_KEY') || APP_KEY === '') return '';
    return hash('sha256', APP_KEY, true);
  }

  private static function b64url(string $raw): string {
    if (function_exists('arc_b64url_encode')) return arc_b64url_encode($raw);
    $b64 = base64_encode($raw);
    return str_replace(['+', '/', '='], ['-', '_', ''], $b64);
  }

  private static function b64url_decode(string $b64): string {
    if (function_exists('arc_b64url_decode')) return arc_b64url_decode($b64);
    $b64 = str_replace(['-', '_'], ['+', '/'], $b64);
    $pad = strlen($b64) % 4;
    if ($pad) $b64 .= str_repeat('=', 4 - $pad);
    $out = base64_decode($b64, true);
    return $out === false ? '' : $out;
  }
}
