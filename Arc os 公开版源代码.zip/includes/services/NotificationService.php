<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class NotificationService {
  public static function add(int $userId, int $fromUserId, string $type, string $objectType, int $objectId, array $data = []): void {
    if (function_exists('arc_create_alert')) {
      arc_create_alert($userId, $fromUserId, $type, $objectType, $objectId, $data);
    }
  }

  public static function unreadCount(int $userId): int {
    return function_exists('arc_alert_unread_count') ? (int)arc_alert_unread_count($userId) : 0;
  }

  public static function markRead(int $userId, ?int $maxId = null): void {
    if (function_exists('arc_mark_alerts_read')) arc_mark_alerts_read($userId, $maxId);
  }

  public static function listAlerts(int $userId, int $limit = 80): array {
    return function_exists('arc_list_alerts') ? (array)arc_list_alerts($userId, $limit) : [];
  }
}