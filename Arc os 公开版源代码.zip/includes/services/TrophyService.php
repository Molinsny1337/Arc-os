<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class TrophyService {
  public static function syncUser(PDO $pdo, string $pfx, int $userId): void {
    if ($userId <= 0) return;

    $stats = self::userStats($pdo, $pfx, $userId);
    if (!$stats) return;

    $stmt = $pdo->prepare("SELECT id, criteria_json FROM {$pfx}trophies ORDER BY display_order ASC, points DESC, id ASC");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    if (!$rows) return;

    $has = [];
    $stmt = $pdo->prepare("SELECT trophy_id FROM {$pfx}user_trophies WHERE user_id=?");
    $stmt->execute([$userId]);
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN, 0) as $tid) {
      $has[(int)$tid] = true;
    }

    foreach ($rows as $row) {
      $tid = (int)($row['id'] ?? 0);
      if ($tid <= 0 || isset($has[$tid])) continue;
      $criteria = (string)($row['criteria_json'] ?? '');
      if ($criteria === '') continue;
      $decoded = json_decode($criteria, true);
      if (!is_array($decoded)) continue;
      if (!self::meetsCriteria($decoded, $stats)) continue;
      try {
        $pdo->prepare("INSERT IGNORE INTO {$pfx}user_trophies (user_id, trophy_id, awarded_at) VALUES (?,?,NOW())")
          ->execute([$userId, $tid]);
      } catch (Throwable $e) {}
    }
  }

  /**
   * @return array<string,int>
   */
  private static function userStats(PDO $pdo, string $pfx, int $userId): array {
    try {
      $stmt = $pdo->prepare("SELECT created_at FROM {$pfx}users WHERE id=? LIMIT 1");
      $stmt->execute([$userId]);
      $created = (string)($stmt->fetchColumn() ?: '');
      $days = $created !== '' ? (int)floor((time() - strtotime($created)) / 86400) : 0;

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE author_id=? AND status='published'");
      $stmt->execute([$userId]);
      $threads = (int)$stmt->fetchColumn();

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE author_id=? AND is_deleted=0");
      $stmt->execute([$userId]);
      $replies = (int)$stmt->fetchColumn();

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_profile_posts WHERE author_user_id=? AND is_deleted=0");
      $stmt->execute([$userId]);
      $profilePosts = (int)$stmt->fetchColumn();

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_profile_post_comments WHERE user_id=? AND is_deleted=0");
      $stmt->execute([$userId]);
      $profileComments = (int)$stmt->fetchColumn();

      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_likes pl JOIN {$pfx}posts p ON p.id=pl.post_id WHERE p.author_id=?");
      $stmt->execute([$userId]);
      $reactions = (int)$stmt->fetchColumn();

      return [
        'messages' => $threads + $replies + $profilePosts + $profileComments,
        'reactions' => $reactions,
        'days' => $days,
      ];
    } catch (Throwable $e) {
      return [];
    }
  }

  /**
   * @param array<string,mixed> $criteria
   * @param array<string,int> $stats
   */
  private static function meetsCriteria(array $criteria, array $stats): bool {
    $map = [
      'messages' => 'messages',
      'reaction_score' => 'reactions',
      'reactions' => 'reactions',
      'days' => 'days',
      'registered_days' => 'days',
    ];
    foreach ($criteria as $k => $v) {
      if (!isset($map[$k])) continue;
      $need = (int)$v;
      $statKey = $map[$k];
      $have = (int)($stats[$statKey] ?? 0);
      if ($have < $need) return false;
    }
    return true;
  }
}
