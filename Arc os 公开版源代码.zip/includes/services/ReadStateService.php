<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class ReadStateService {
  public static function markThread(PDO $pdo, string $pfx, int $userId, int $threadId, ?string $lastPostAt = null): void {
    if ($userId <= 0 || $threadId <= 0) return;
    $ts = $lastPostAt && trim($lastPostAt) !== '' ? $lastPostAt : null;
    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_thread_reads (user_id, thread_id, last_read_at)
        VALUES (?, ?, COALESCE(?, NOW()))
        ON DUPLICATE KEY UPDATE last_read_at = GREATEST(last_read_at, COALESCE(VALUES(last_read_at), NOW()))")
        ->execute([$userId, $threadId, $ts]);
    } catch (Throwable $e) {}
  }

  public static function markForum(PDO $pdo, string $pfx, int $userId, int $forumId, ?string $lastPostAt = null): void {
    if ($userId <= 0 || $forumId <= 0) return;
    $ts = $lastPostAt && trim($lastPostAt) !== '' ? $lastPostAt : null;
    try {
      $pdo->prepare("INSERT INTO {$pfx}xf_forum_reads (user_id, forum_id, last_read_at)
        VALUES (?, ?, COALESCE(?, NOW()))
        ON DUPLICATE KEY UPDATE last_read_at = GREATEST(last_read_at, COALESCE(VALUES(last_read_at), NOW()))")
        ->execute([$userId, $forumId, $ts]);
    } catch (Throwable $e) {}
  }

  /**
   * @param array<int,int> $threadIds
   * @return array<int,string>
   */
  public static function threadMap(PDO $pdo, string $pfx, int $userId, array $threadIds): array {
    $threadIds = array_values(array_filter(array_map('intval', $threadIds), function(int $v): bool { return $v > 0; }));
    if ($userId <= 0 || !$threadIds) return [];
    $in = implode(',', array_fill(0, count($threadIds), '?'));
    try {
      $stmt = $pdo->prepare("SELECT thread_id, last_read_at FROM {$pfx}xf_thread_reads
        WHERE user_id=? AND thread_id IN ({$in})");
      $stmt->execute(array_merge([$userId], $threadIds));
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $out = [];
      foreach ($rows as $r) {
        $out[(int)$r['thread_id']] = (string)($r['last_read_at'] ?? '');
      }
      return $out;
    } catch (Throwable $e) {
      return [];
    }
  }

  /**
   * @param array<int,int> $forumIds
   * @return array<int,string>
   */
  public static function forumMap(PDO $pdo, string $pfx, int $userId, array $forumIds): array {
    $forumIds = array_values(array_filter(array_map('intval', $forumIds), function(int $v): bool { return $v > 0; }));
    if ($userId <= 0 || !$forumIds) return [];
    $in = implode(',', array_fill(0, count($forumIds), '?'));
    try {
      $stmt = $pdo->prepare("SELECT forum_id, last_read_at FROM {$pfx}xf_forum_reads
        WHERE user_id=? AND forum_id IN ({$in})");
      $stmt->execute(array_merge([$userId], $forumIds));
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $out = [];
      foreach ($rows as $r) {
        $out[(int)$r['forum_id']] = (string)($r['last_read_at'] ?? '');
      }
      return $out;
    } catch (Throwable $e) {
      return [];
    }
  }
}
