<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;

final class ReactionService {
  public static function types(): array {
    return function_exists('arc_reaction_types') ? arc_reaction_types() : [];
  }

  public static function summary(PDO $pdo, string $pfx, int $postId): array {
    return function_exists('arc_reaction_summary') ? arc_reaction_summary($pdo, $pfx, $postId) : [];
  }

  public static function userReactions(PDO $pdo, string $pfx, int $postId, int $userId): array {
    return function_exists('arc_user_reactions') ? arc_user_reactions($pdo, $pfx, $postId, $userId) : [];
  }
}