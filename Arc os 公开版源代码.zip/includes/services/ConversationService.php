<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;

final class ConversationService {
  public static function create(PDO $pdo, string $pfx, int $creatorId, array $participantIds, string $title, string $message): int {
    if (function_exists('conv_create')) {
      return (int)conv_create($pdo, $pfx, $creatorId, $participantIds, $title, $message);
    }
    return 0;
  }

  public static function canAccess(PDO $pdo, string $pfx, int $convId, int $userId): bool {
    return function_exists('conv_user_can_access') ? (bool)conv_user_can_access($pdo, $pfx, $convId, $userId) : false;
  }

  public static function participants(PDO $pdo, string $pfx, int $convId): array {
    return function_exists('conv_participants') ? (array)conv_participants($pdo, $pfx, $convId) : [];
  }
}