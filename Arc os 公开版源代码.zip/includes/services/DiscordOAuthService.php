<?php
declare(strict_types=1);

namespace ArcOS\Services;

require_once __DIR__ . '/CryptoService.php';

use RuntimeException;

final class DiscordOAuthService {
  private const AUTH_URL = 'https://discord.com/api/oauth2/authorize';
  private const TOKEN_URL = 'https://discord.com/api/oauth2/token';

  public static function isConfigured(): bool {
    $clientId = trim((string)get_setting('discord_client_id', ''));
    $secretEnc = (string)get_setting('discord_client_secret_enc', '');
    $redirect = trim((string)get_setting('discord_redirect_uri', ''));
    if ($clientId === '' || $secretEnc === '' || $redirect === '') return false;
    $secret = CryptoService::decrypt($secretEnc);
    return $secret !== '';
  }

  public static function authUrl(string $state, bool $includeGuilds = false): string {
    $clientId = trim((string)get_setting('discord_client_id', ''));
    $redirect = trim((string)get_setting('discord_redirect_uri', ''));
    if ($clientId === '' || $redirect === '') return '';

    $scope = ['identify', 'email'];
    if ($includeGuilds) $scope[] = 'guilds';
    $params = [
      'client_id' => $clientId,
      'redirect_uri' => $redirect,
      'response_type' => 'code',
      'scope' => implode(' ', $scope),
      'state' => $state,
      'prompt' => 'consent',
    ];
    return self::AUTH_URL . '?' . http_build_query($params);
  }

  /**
   * @return array{access_token:string,refresh_token:string,expires_in:int}
   */
  public static function exchangeCode(string $code): array {
    return self::tokenRequest([
      'grant_type' => 'authorization_code',
      'code' => $code,
    ]);
  }

  /**
   * @return array{access_token:string,refresh_token:string,expires_in:int}
   */
  public static function refreshToken(string $refreshToken): array {
    return self::tokenRequest([
      'grant_type' => 'refresh_token',
      'refresh_token' => $refreshToken,
    ]);
  }

  /**
   * @param array<string,string> $params
   * @return array{access_token:string,refresh_token:string,expires_in:int}
   */
  private static function tokenRequest(array $params): array {
    $clientId = trim((string)get_setting('discord_client_id', ''));
    $secretEnc = (string)get_setting('discord_client_secret_enc', '');
    $redirect = trim((string)get_setting('discord_redirect_uri', ''));
    $secret = CryptoService::decrypt($secretEnc);

    if ($clientId === '' || $secret === '' || $redirect === '') {
      throw new RuntimeException('DISCORD_NOT_CONFIGURED');
    }

    $payload = array_merge($params, [
      'client_id' => $clientId,
      'client_secret' => $secret,
      'redirect_uri' => $redirect,
    ]);

    $ch = curl_init();
    if ($ch === false) throw new RuntimeException('CURL_NOT_AVAILABLE');

    curl_setopt_array($ch, [
      CURLOPT_URL => self::TOKEN_URL,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_CONNECTTIMEOUT => 10,
      CURLOPT_POST => true,
      CURLOPT_HTTPHEADER => [
        'Content-Type: application/x-www-form-urlencoded',
        'Accept: application/json',
      ],
      CURLOPT_POSTFIELDS => http_build_query($payload),
    ]);

    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($raw === false) throw new RuntimeException('CURL_ERROR:' . $err);

    $decoded = json_decode((string)$raw, true);
    if (!is_array($decoded)) $decoded = [];

    if ($code >= 400) {
      $msg = isset($decoded['error_description']) ? (string)$decoded['error_description'] : 'HTTP_' . $code;
      throw new RuntimeException('DISCORD_TOKEN:' . $msg);
    }

    $access = (string)($decoded['access_token'] ?? '');
    $refresh = (string)($decoded['refresh_token'] ?? '');
    $expires = (int)($decoded['expires_in'] ?? 0);
    if ($access === '' || $refresh === '') throw new RuntimeException('DISCORD_TOKEN_INVALID');

    return [
      'access_token' => $access,
      'refresh_token' => $refresh,
      'expires_in' => $expires > 0 ? $expires : 3600,
    ];
  }
}
