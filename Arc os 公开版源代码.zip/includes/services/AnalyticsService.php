<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class AnalyticsService {
  public static function recordFromRequest(PDO $pdo, string $pfx): void {
    if (PHP_SAPI === 'cli') return;
    if (!function_exists('get_setting')) return;
    if (get_setting('analytics_enabled', '1') !== '1') return;

    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (!in_array($method, ['GET', 'HEAD'], true)) return;

    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path = (string)(parse_url($uri, PHP_URL_PATH) ?? '/');
    if ($path === '') $path = '/';

    if (self::isStaticPath($path)) return;

    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    $isBot = self::isBot($ua);
    $sessionId = (string)session_id();

    $window = (int)get_setting('analytics_dedupe_window', '60');
    if ($window < 10) $window = 10;
    if ($window > 300) $window = 300;

    try {
      $stmt = $pdo->prepare("SELECT created_at FROM {$pfx}xf_analytics_events WHERE session_id=? AND path=? ORDER BY id DESC LIMIT 1");
      $stmt->execute([$sessionId, $path]);
      $last = (string)($stmt->fetchColumn() ?: '');
      if ($last !== '' && strtotime($last) !== false) {
        $delta = time() - (int)strtotime($last);
        if ($delta >= 0 && $delta < $window) return;
      }
    } catch (Throwable $e) {}

    $ip = self::clientIp();
    $ipHash = self::hashValue($ip);
    $uaHash = self::hashValue($ua);
    $userId = function_exists('current_user') && current_user() ? (int)(current_user()['id'] ?? 0) : null;
    $ref = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($ref !== '') {
      $ref = substr($ref, 0, 255);
    }

    $routeType = self::routeType($path);

    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_analytics_events
        (created_at, path, route_type, user_id, session_id, ip_hash, ua_hash, referrer, is_bot)
        VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?, ?)");
      $stmt->execute([
        $path,
        $routeType,
        $userId ?: null,
        $sessionId,
        $ipHash,
        $uaHash,
        $ref !== '' ? $ref : null,
        $isBot ? 1 : 0,
      ]);
    } catch (Throwable $e) {}
  }

  /**
   * @return array<string,int>
   */
  public static function summarizeToday(PDO $pdo, string $pfx): array {
    $out = [
      'pv' => 0,
      'uv' => 0,
      'registrations' => 0,
      'threads' => 0,
      'replies' => 0,
      'active_users' => 0,
      'attachments' => 0,
      'attachments_bytes' => 0,
      'errors' => 0,
      'online' => 0,
    ];

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_analytics_events WHERE is_bot=0 AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['pv'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(DISTINCT CASE WHEN session_id<>'' THEN session_id ELSE CONCAT(ip_hash,':',ua_hash) END)
        FROM {$pfx}xf_analytics_events WHERE is_bot=0 AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['uv'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users WHERE DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['registrations'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}posts WHERE type='forum' AND status='published' AND is_deleted=0 AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['threads'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}post_comments WHERE is_deleted=0 AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['replies'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM (
          SELECT author_id AS user_id FROM {$pfx}posts WHERE type='forum' AND status='published' AND DATE(created_at)=CURDATE()
          UNION
          SELECT author_id FROM {$pfx}post_comments WHERE DATE(created_at)=CURDATE()
          UNION
          SELECT user_id FROM {$pfx}post_reactions WHERE DATE(created_at)=CURDATE()
          UNION
          SELECT user_id FROM {$pfx}conversation_messages WHERE DATE(created_at)=CURDATE()
          UNION
          SELECT author_id FROM {$pfx}profile_posts WHERE DATE(created_at)=CURDATE()
          UNION
          SELECT author_id FROM {$pfx}profile_post_comments WHERE DATE(created_at)=CURDATE()
        ) t WHERE user_id IS NOT NULL");
      $stmt->execute();
      $out['active_users'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*), COALESCE(SUM(size_bytes),0) FROM {$pfx}xf_attachment_data WHERE DATE(created_at)=CURDATE()");
      $stmt->execute();
      $row = $stmt->fetch(PDO::FETCH_NUM);
      if ($row) {
        $out['attachments'] = (int)($row[0] ?? 0);
        $out['attachments_bytes'] = (int)($row[1] ?? 0);
      }
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}logs WHERE action='php_error' AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $out['errors'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    try {
      $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}users WHERE last_active >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
      $stmt->execute();
      $out['online'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {}

    return $out;
  }

  /**
   * @return array<string,mixed>
   */
  public static function timeseries(PDO $pdo, string $pfx, string $range): array {
    $range = strtolower(trim($range));
    if (!in_array($range, ['today', '7d', '30d'], true)) $range = 'today';

    $points = [];
    $bar = [];
    $labels = [];

    if ($range === 'today') {
      $labels = self::hourLabels();
      $points = array_fill(0, 24, ['pv' => 0, 'uv' => 0]);
      $bar = array_fill(0, 24, ['threads' => 0, 'replies' => 0]);

      try {
        $stmt = $pdo->prepare("SELECT HOUR(created_at) h,
          COUNT(*) pv,
          COUNT(DISTINCT CASE WHEN session_id<>'' THEN session_id ELSE CONCAT(ip_hash,':',ua_hash) END) uv
          FROM {$pfx}xf_analytics_events
          WHERE is_bot=0 AND DATE(created_at)=CURDATE()
          GROUP BY h");
        $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $h = (int)($row['h'] ?? 0);
          if ($h < 0 || $h > 23) continue;
          $points[$h] = ['pv' => (int)$row['pv'], 'uv' => (int)$row['uv']];
        }
      } catch (Throwable $e) {}

      try {
        $stmt = $pdo->prepare("SELECT HOUR(created_at) h, COUNT(*) c FROM {$pfx}posts
          WHERE type='forum' AND status='published' AND is_deleted=0 AND DATE(created_at)=CURDATE()
          GROUP BY h");
        $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $h = (int)($row['h'] ?? 0);
          if ($h < 0 || $h > 23) continue;
          $bar[$h]['threads'] = (int)$row['c'];
        }
      } catch (Throwable $e) {}

      try {
        $stmt = $pdo->prepare("SELECT HOUR(created_at) h, COUNT(*) c FROM {$pfx}post_comments
          WHERE is_deleted=0 AND DATE(created_at)=CURDATE()
          GROUP BY h");
        $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $h = (int)($row['h'] ?? 0);
          if ($h < 0 || $h > 23) continue;
          $bar[$h]['replies'] = (int)$row['c'];
        }
      } catch (Throwable $e) {}
    } else {
      $days = $range === '7d' ? 7 : 30;
      $labels = self::dateLabels($days);
      $points = array_fill(0, $days, ['pv' => 0, 'uv' => 0]);
      $bar = array_fill(0, $days, ['threads' => 0, 'replies' => 0]);

      $start = date('Y-m-d', strtotime('-' . ($days - 1) . ' days'));

      try {
        $stmt = $pdo->prepare("SELECT DATE(created_at) d,
          COUNT(*) pv,
          COUNT(DISTINCT CASE WHEN session_id<>'' THEN session_id ELSE CONCAT(ip_hash,':',ua_hash) END) uv
          FROM {$pfx}xf_analytics_events
          WHERE is_bot=0 AND created_at >= ?
          GROUP BY d ORDER BY d ASC");
        $stmt->execute([$start]);
        $map = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $map[(string)$row['d']] = ['pv' => (int)$row['pv'], 'uv' => (int)$row['uv']];
        }
        foreach ($labels as $i => $d) {
          if (isset($map[$d])) $points[$i] = $map[$d];
        }
      } catch (Throwable $e) {}

      try {
        $stmt = $pdo->prepare("SELECT DATE(created_at) d, COUNT(*) c FROM {$pfx}posts
          WHERE type='forum' AND status='published' AND is_deleted=0 AND created_at >= ?
          GROUP BY d ORDER BY d ASC");
        $stmt->execute([$start]);
        $map = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $map[(string)$row['d']] = (int)$row['c'];
        }
        foreach ($labels as $i => $d) {
          if (isset($map[$d])) $bar[$i]['threads'] = $map[$d];
        }
      } catch (Throwable $e) {}

      try {
        $stmt = $pdo->prepare("SELECT DATE(created_at) d, COUNT(*) c FROM {$pfx}post_comments
          WHERE is_deleted=0 AND created_at >= ?
          GROUP BY d ORDER BY d ASC");
        $stmt->execute([$start]);
        $map = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
          $map[(string)$row['d']] = (int)$row['c'];
        }
        foreach ($labels as $i => $d) {
          if (isset($map[$d])) $bar[$i]['replies'] = $map[$d];
        }
      } catch (Throwable $e) {}
    }

    return [
      'labels' => $labels,
      'line' => $points,
      'bar' => $bar,
      'routes' => self::routeBreakdown($pdo, $pfx, $range),
    ];
  }

  /**
   * @return array<int,array{label:string,value:int}>
   */
  public static function routeBreakdown(PDO $pdo, string $pfx, string $range): array {
    $range = strtolower(trim($range));
    if (!in_array($range, ['today', '7d', '30d'], true)) $range = 'today';
    $start = $range === 'today' ? date('Y-m-d') : date('Y-m-d', strtotime('-' . ($range === '7d' ? 6 : 29) . ' days'));
    try {
      $stmt = $pdo->prepare("SELECT route_type, COUNT(*) c FROM {$pfx}xf_analytics_events
        WHERE is_bot=0 AND created_at >= ?
        GROUP BY route_type ORDER BY c DESC LIMIT 8");
      $stmt->execute([$start]);
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $out = [];
      foreach ($rows as $r) {
        $out[] = ['label' => (string)($r['route_type'] ?? ''), 'value' => (int)($r['c'] ?? 0)];
      }
      return $out;
    } catch (Throwable $e) {
      return [];
    }
  }

  private static function isStaticPath(string $path): bool {
    $path = strtolower($path);
    if (str_contains($path, '/assets/') || str_contains($path, '/uploads/') || str_contains($path, '/storage/')) return true;
    if (str_contains($path, '/ajax/') || str_contains($path, '/tools/')) return true;
    return (bool)preg_match('/\\.(css|js|png|jpg|jpeg|gif|webp|svg|ico|map|woff2?)$/', $path);
  }

  private static function routeType(string $path): string {
    $path = strtolower($path);
    if (str_contains($path, '/admin') || defined('ADMIN_ENTRY')) return 'admin';
    if (str_contains($path, 'forum_post.php')) return 'thread';
    if (str_contains($path, 'forum_view.php')) return 'forum_view';
    if (str_contains($path, 'forum.php')) return 'forum_home';
    if (str_contains($path, 'user.php')) return 'profile';
    if (str_contains($path, 'members.php')) return 'members';
    if (str_contains($path, 'whats_new.php')) return 'whats_new';
    if (str_contains($path, 'search.php')) return 'search';
    if (str_contains($path, 'conversation')) return 'conversation';
    if (str_contains($path, 'notifications.php')) return 'notifications';
    if (str_contains($path, 'page.php')) return 'page';
    if ($path === '/' || str_contains($path, 'index.php')) return 'home';
    return 'other';
  }

  private static function isBot(string $ua): bool {
    $ua = strtolower($ua);
    if ($ua === '') return false;
    $raw = (string)(function_exists('get_setting') ? get_setting('analytics_bot_keywords', '') : '');
    $keywords = array_filter(array_map('trim', explode(',', $raw)));
    if (!$keywords) {
      $keywords = ['bot','spider','crawl','slurp','facebookexternalhit','telegrambot'];
    }
    foreach ($keywords as $kw) {
      if ($kw !== '' && str_contains($ua, $kw)) return true;
    }
    return false;
  }

  private static function hashValue(string $value): string {
    if ($value === '') return hash('sha256', '');
    if (defined('APP_KEY') && APP_KEY !== '') {
      return hash_hmac('sha256', $value, APP_KEY);
    }
    return hash('sha256', $value);
  }

  private static function clientIp(): string {
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip === '' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $ip = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0] ?? '');
    }
    return $ip;
  }

  /**
   * @return array<int,string>
   */
  private static function hourLabels(): array {
    $labels = [];
    for ($i = 0; $i < 24; $i++) {
      $labels[] = str_pad((string)$i, 2, '0', STR_PAD_LEFT) . ':00';
    }
    return $labels;
  }

  /**
   * @return array<int,string>
   */
  private static function dateLabels(int $days): array {
    $labels = [];
    for ($i = $days - 1; $i >= 0; $i--) {
      $labels[] = date('Y-m-d', strtotime('-' . $i . ' days'));
    }
    return $labels;
  }
}
