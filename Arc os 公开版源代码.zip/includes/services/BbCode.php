<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;

require_once __DIR__ . '/SafeHtml.php';
require_once __DIR__ . '/EmbedService.php';
require_once __DIR__ . '/UploadService.php';
require_once __DIR__ . '/EmojiService.php';

final class BbCode {
  public static function normalize(string $bbcode): string {
    $bbcode = str_replace(["\r\n", "\r"], "\n", $bbcode);
    $bbcode = trim($bbcode);
    if (strlen($bbcode) > 200000) {
      $bbcode = substr($bbcode, 0, 200000);
    }
    return $bbcode;
  }

  public static function plainText(string $input): string {
    $input = self::normalize($input);
    if ($input === '') return '';
    if (self::looksLikeHtml($input)) {
      $txt = strip_tags($input);
      $txt = preg_replace('/\s+/', ' ', $txt) ?? '';
      return trim($txt);
    }
    $txt = preg_replace('/\[[\/?][a-zA-Z][^\]]*\]/', '', $input) ?? '';
    $txt = preg_replace('/\s+/', ' ', $txt) ?? '';
    return trim($txt);
  }

  public static function render(string $input, ?PDO $pdo = null, ?string $pfx = null): string {
    $input = self::normalize($input);
    if ($input === '') return '';
    if (self::looksLikeHtml($input)) {
      return SafeHtml::render($input);
    }

    $escaped = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    $tokens = [];

    // Protect code blocks from further parsing.
    $escaped = self::extractTag($escaped, 'code', function(string $content, string $attr): string {
      $lang = preg_replace('/[^a-zA-Z0-9_+\-]/', '', $attr);
      $cls = $lang !== '' ? ' class="language-' . $lang . '"' : '';
      return '<pre class="bb-code"><code' . $cls . '>' . $content . '</code></pre>';
    }, $tokens);

    $escaped = self::extractTag($escaped, 'icode', function(string $content, string $attr): string {
      return '<code class="bb-icode">' . $content . '</code>';
    }, $tokens);

    $escaped = self::replaceQuotes($escaped);
    $escaped = self::replaceSpoilers($escaped);
    $escaped = self::replaceLists($escaped);

    $escaped = self::replaceTables($escaped);

    $escaped = self::replaceAlign($escaped);

    $escaped = self::replaceSimpleTags($escaped);
    $escaped = self::replaceColor($escaped);
    $escaped = self::replaceSize($escaped);

    $escaped = self::replaceUrls($escaped);
    $escaped = self::replaceImages($escaped);
    $escaped = self::replaceMedia($escaped);
    $escaped = self::replaceUsers($escaped);
    $escaped = self::replaceTags($escaped);
    $escaped = self::replaceAttachments($escaped, $pdo, $pfx);
    $escaped = self::replaceEmojis($escaped, $pdo, $pfx);

    $escaped = self::replaceHr($escaped);

    // Convert line breaks to <br> before restoring code blocks.
    $escaped = nl2br($escaped);

    foreach ($tokens as $key => $html) {
      $escaped = str_replace($key, $html, $escaped);
    }

    return $escaped;
  }

  private static function looksLikeHtml(string $input): bool {
    return (bool)preg_match('/<[^>]+>/', $input);
  }

  private static function extractTag(string $text, string $tag, callable $builder, array &$tokens): string {
    $pattern = '/\[' . preg_quote($tag, '/') . '(?:=([^\]]{0,32}))?\](.*?)\[\/' . preg_quote($tag, '/') . '\]/is';
    return (string)preg_replace_callback($pattern, function(array $m) use ($builder, &$tokens): string {
      $attr = isset($m[1]) ? (string)$m[1] : '';
      $content = isset($m[2]) ? (string)$m[2] : '';
      $html = $builder($content, $attr);
      $key = '[[BBCODE_' . count($tokens) . ']]';
      $tokens[$key] = $html;
      return $key;
    }, $text);
  }

  private static function replaceSimpleTags(string $text): string {
    $map = [
      'b' => 'strong',
      'i' => 'em',
      'u' => 'u',
      's' => 's',
    ];
    foreach ($map as $bb => $tag) {
      $text = (string)preg_replace('/\[' . $bb . '\](.*?)\[\/' . $bb . '\]/is', '<' . $tag . '>$1</' . $tag . '>', $text);
    }
    return $text;
  }

  private static function replaceAlign(string $text): string {
    $aligns = ['left', 'center', 'right', 'justify'];
    foreach ($aligns as $a) {
      $text = (string)preg_replace('/\[' . $a . '\](.*?)\[\/' . $a . '\]/is', '<div class="bb-align bb-' . $a . '">$1</div>', $text);
    }
    return $text;
  }

  private static function replaceColor(string $text): string {
    return (string)preg_replace_callback('/\[color=([^\]]{1,24})\](.*?)\[\/color\]/is', function(array $m): string {
      $color = htmlspecialchars_decode((string)$m[1], ENT_QUOTES);
      $color = self::sanitizeColor($color);
      if ($color === '') return $m[2];
      return '<span style="color:' . $color . '">' . $m[2] . '</span>';
    }, $text);
  }

  private static function replaceSize(string $text): string {
    return (string)preg_replace_callback('/\[size=([^\]]{1,6})\](.*?)\[\/size\]/is', function(array $m): string {
      $size = htmlspecialchars_decode((string)$m[1], ENT_QUOTES);
      $size = self::sanitizeSize($size);
      if ($size === '') return $m[2];
      return '<span style="font-size:' . $size . 'px">' . $m[2] . '</span>';
    }, $text);
  }

  private static function replaceUrls(string $text): string {
    return (string)preg_replace_callback('/\[url(?:=([^\]]+))?\](.*?)\[\/url\]/is', function(array $m): string {
      $href = $m[1] ?? '';
      $label = $m[2] ?? '';
      $href = trim((string)htmlspecialchars_decode($href !== '' ? $href : $label, ENT_QUOTES));
      $label = $label !== '' ? (string)$label : $href;
      if (!self::isSafeUrl($href)) return $label;
      $hrefEsc = htmlspecialchars($href, ENT_QUOTES, 'UTF-8');
      return '<a href="' . $hrefEsc . '" target="_blank" rel="nofollow ugc noopener">' . $label . '</a>';
    }, $text);
  }

  private static function replaceImages(string $text): string {
    return (string)preg_replace_callback('/\[img\](.*?)\[\/img\]/is', function(array $m): string {
      $src = trim((string)htmlspecialchars_decode((string)$m[1], ENT_QUOTES));
      if (!self::isSafeUrl($src)) return '';
      $srcEsc = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
      return '<img src="' . $srcEsc . '" alt="" loading="lazy">';
    }, $text);
  }

  private static function replaceMedia(string $text): string {
    return (string)preg_replace_callback('/\[media(?:=([^\]]+))?\](.*?)\[\/media\]/is', function(array $m): string {
      $type = trim((string)htmlspecialchars_decode((string)($m[1] ?? ''), ENT_QUOTES));
      $url = trim((string)htmlspecialchars_decode((string)($m[2] ?? ''), ENT_QUOTES));
      if ($url === '') return '';
      $html = EmbedService::render($url, $type);
      if ($html === '') {
        $safe = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
        return '<a href="' . $safe . '" target="_blank" rel="nofollow ugc noopener">' . $safe . '</a>';
      }
      return $html;
    }, $text);
  }

  private static function replaceUsers(string $text): string {
    return (string)preg_replace_callback('/\[user(?:=([0-9]{1,10}))?\](.*?)\[\/user\]/is', function(array $m): string {
      $uid = isset($m[1]) ? (int)$m[1] : 0;
      $name = trim((string)$m[2]);
      if ($name === '') return '';
      $label = '@' . $name;
      if ($uid > 0) {
        $href = htmlspecialchars(url('user.php?id=' . $uid), ENT_QUOTES, 'UTF-8');
        return '<a class="bb-user" href="' . $href . '">' . $label . '</a>';
      }
      return '<span class="bb-user">' . $label . '</span>';
    }, $text);
  }

  private static function replaceTags(string $text): string {
    return (string)preg_replace_callback('/\[tag\](.*?)\[\/tag\]/is', function(array $m): string {
      $tag = trim((string)$m[1]);
      if ($tag === '') return '';
      $safe = htmlspecialchars($tag, ENT_QUOTES, 'UTF-8');
      $href = htmlspecialchars(url('search.php?q=%23' . urlencode($tag)), ENT_QUOTES, 'UTF-8');
      return '<a class="bb-tag" href="' . $href . '">#' . $safe . '</a>';
    }, $text);
  }

  private static function replaceAttachments(string $text, ?PDO $pdo, ?string $pfx): string {
    return (string)preg_replace_callback('/\[attach\]([0-9]{1,18})\[\/attach\]/i', function(array $m) use ($pdo, $pfx): string {
      $id = (int)$m[1];
      if ($id <= 0) return '';
      if ($pdo && $pfx && class_exists('ArcOS\\Services\\UploadService')) {
        $info = UploadService::fetchAttachment($pdo, (string)$pfx, $id);
        if ($info) {
          $url = htmlspecialchars(url('attachment.php?id=' . $id), ENT_QUOTES, 'UTF-8');
          if (!empty($info['is_image'])) {
            return '<img class="bb-attach" src="' . $url . '" alt="" loading="lazy">';
          }
          $name = htmlspecialchars((string)($info['file_name'] ?? ('file-' . $id)), ENT_QUOTES, 'UTF-8');
          return '<a class="bb-attach" href="' . $url . '" target="_blank" rel="nofollow ugc noopener">' . $name . '</a>';
        }
      }
      $fallback = htmlspecialchars(url('attachment.php?id=' . $id), ENT_QUOTES, 'UTF-8');
      return '<a class="bb-attach" href="' . $fallback . '" target="_blank" rel="nofollow ugc noopener">Attachment #' . $id . '</a>';
    }, $text);
  }

  private static function replaceEmojis(string $text, ?PDO $pdo, ?string $pfx): string {
    $text = (string)preg_replace_callback('/\\[emoji=([^\\]]{1,64})\\]/i', function(array $m) use ($pdo, $pfx): string {
      $codeRaw = (string)($m[1] ?? '');
      $code = \ArcOS\Services\EmojiService::sanitizeShortcode($codeRaw);
      if ($code === '') return '';
      if ($pdo && $pfx) {
        $row = \ArcOS\Services\EmojiService::emojiByShortcode($pdo, $pfx, $code);
        if (is_array($row)) {
          $unicode = trim((string)($row['unicode'] ?? ''));
          if ($unicode !== '') return htmlspecialchars($unicode, ENT_QUOTES, 'UTF-8');
          $path = (string)($row['image_path'] ?? '');
          $url = \ArcOS\Services\EmojiService::publicUrl($path);
          if ($url !== '') {
            $safe = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
            $alt = htmlspecialchars(':' . $code . ':', ENT_QUOTES, 'UTF-8');
            return '<img class="bb-emoji" src="' . $safe . '" alt="' . $alt . '" loading="lazy">';
          }
        }
      }
      return htmlspecialchars(':' . $code . ':', ENT_QUOTES, 'UTF-8');
    }, $text);

    $text = (string)preg_replace_callback('/\\[sticker=([0-9]{1,18})\\]/i', function(array $m) use ($pdo, $pfx): string {
      $id = (int)($m[1] ?? 0);
      if ($id <= 0 || !$pdo || !$pfx) return '';
      $row = \ArcOS\Services\EmojiService::emojiById($pdo, $pfx, $id);
      if (!is_array($row)) return '';
      $path = (string)($row['image_path'] ?? '');
      $url = \ArcOS\Services\EmojiService::publicUrl($path);
      if ($url === '') return '';
      $safe = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
      $alt = htmlspecialchars('[sticker]', ENT_QUOTES, 'UTF-8');
      return '<img class="bb-sticker" src="' . $safe . '" alt="' . $alt . '" loading="lazy">';
    }, $text);

    return $text;
  }

  private static function replaceQuotes(string $text): string {
    $text = (string)preg_replace_callback('/\[quote(?:=([^\]]{0,80}))?\]/i', function(array $m): string {
      $meta = isset($m[1]) ? trim((string)htmlspecialchars_decode((string)$m[1], ENT_QUOTES)) : '';
      if ($meta !== '') {
        $meta = htmlspecialchars($meta, ENT_QUOTES, 'UTF-8');
        return '<blockquote class="bb-quote"><div class="bb-quote-meta">Quote: ' . $meta . '</div>';
      }
      return '<blockquote class="bb-quote">';
    }, $text);
    $text = (string)preg_replace('/\[\/quote\]/i', '</blockquote>', $text);
    return $text;
  }

  private static function replaceSpoilers(string $text): string {
    $text = (string)preg_replace_callback('/\[spoiler(?:=([^\]]{0,80}))?\]/i', function(array $m): string {
      $label = isset($m[1]) ? trim((string)htmlspecialchars_decode((string)$m[1], ENT_QUOTES)) : '';
      if ($label === '') $label = 'Spoiler';
      $label = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
      return '<details class="bb-spoiler"><summary>' . $label . '</summary><div class="bb-spoiler-body">';
    }, $text);
    $text = (string)preg_replace('/\[\/spoiler\]/i', '</div></details>', $text);
    return $text;
  }

  private static function replaceLists(string $text): string {
    return (string)preg_replace_callback('/\[list(?:=([^\]]{0,3}))?\](.*?)\[\/list\]/is', function(array $m): string {
      $type = strtolower(trim((string)($m[1] ?? '')));
      $inner = (string)($m[2] ?? '');
      $items = preg_split('/\[\*\]/', $inner) ?: [];
      $items = array_values(array_filter(array_map('trim', $items), function(string $v): bool { return $v !== ''; }));
      $tag = ($type === '1' || $type === 'ol' || $type === 'a') ? 'ol' : 'ul';
      $out = '<' . $tag . ' class="bb-list">';
      foreach ($items as $it) {
        $out .= '<li>' . $it . '</li>';
      }
      $out .= '</' . $tag . '>';
      return $out;
    }, $text);
  }

  private static function replaceTables(string $text): string {
    $text = str_ireplace(['[table]', '[/table]'], ['<table class="bb-table">', '</table>'], $text);
    $text = str_ireplace(['[tr]', '[/tr]'], ['<tr>', '</tr>'], $text);
    $text = str_ireplace(['[th]', '[/th]'], ['<th>', '</th>'], $text);
    $text = str_ireplace(['[td]', '[/td]'], ['<td>', '</td>'], $text);
    return $text;
  }

  private static function replaceHr(string $text): string {
    return (string)preg_replace('/\[hr\]/i', '<hr>', $text);
  }

  private static function sanitizeColor(string $color): string {
    $color = trim($color);
    if ($color === '') return '';
    if (preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) return $color;
    if (preg_match('/^rgba?\([0-9\s.,%]+\)$/', $color)) return $color;
    if (preg_match('/^hsla?\([0-9\s.,%]+\)$/', $color)) return $color;
    return '';
  }

  private static function sanitizeSize(string $size): string {
    $size = trim($size);
    if ($size === '') return '';
    if (preg_match('/^[0-9]{1,3}$/', $size)) {
      $n = (int)$size;
      if ($n >= 8 && $n <= 48) return (string)$n;
    }
    return '';
  }

  private static function isSafeUrl(string $url): bool {
    $url = trim($url);
    if ($url === '') return false;
    if (preg_match('~^\s*(javascript|data):~i', $url)) return false;
    if (preg_match('~^https?://~i', $url)) return true;
    if (str_starts_with($url, '//')) return false;
    if (str_starts_with($url, '/')) return true;
    if (preg_match('~^[a-z][a-z0-9+.-]*:~i', $url)) return false;
    return true;
  }
}
