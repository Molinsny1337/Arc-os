<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class Permission {
  private array $roleMap = [
    'guest' => [
      'view_forum', 'view_threads', 'view_profiles', 'view_members', 'view_search',
    ],
    'registered' => [
      'view_forum', 'view_threads', 'view_profiles', 'view_members', 'view_search',
      'post_thread', 'reply_thread', 'edit_own_post', 'delete_own_post',
      'upload_attachment', 'react', 'view_notifications',
      'post_profile', 'start_conversation',
      'watch_thread', 'watch_forum', 'bookmark', 'report',
    ],
    'moderator' => [
      'view_forum', 'view_threads', 'view_profiles', 'view_members', 'view_search',
      'post_thread', 'reply_thread', 'edit_own_post', 'delete_own_post',
      'upload_attachment', 'react', 'view_notifications',
      'post_profile', 'start_conversation',
      'watch_thread', 'watch_forum', 'bookmark', 'report',
      'view_moderation_queue', 'approve_content', 'soft_delete', 'manage_reports',
    ],
    'admin' => [
      'view_forum', 'view_threads', 'view_profiles', 'view_members', 'view_search',
      'post_thread', 'reply_thread', 'edit_own_post', 'delete_own_post',
      'upload_attachment', 'react', 'view_notifications',
      'post_profile', 'start_conversation',
      'watch_thread', 'watch_forum', 'bookmark', 'report',
      'view_moderation_queue', 'approve_content', 'soft_delete', 'hard_delete', 'ban_user',
      'manage_forums', 'manage_users', 'manage_settings', 'manage_layout',
      'manage_emojis', 'manage_attachments', 'manage_prefixes', 'manage_reports', 'manage_posts',
    ],
  ];

  public function can(?array $user, string $perm, array $context = []): bool {
    $role = $this->resolveRole($user);
    if ($role === 'admin') return true;
    $perms = $this->roleMap[$role] ?? [];
    return in_array($perm, $perms, true);
  }

  public function requirePerm(?array $user, string $perm, array $context = []): void {
    if ($this->can($user, $perm, $context)) return;
    $this->deny($perm, $context);
  }

  public function deny(string $perm, array $context = []): void {
    $isJson = (bool)($context['json'] ?? false);
    $code = isset($context['status']) ? (int)$context['status'] : 403;
    http_response_code($code);
    if ($isJson) {
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok' => false, 'error' => 'PERMISSION_DENIED', 'perm' => $perm], JSON_UNESCAPED_UNICODE);
      exit;
    }
    $title = function_exists('t') ? t('permission_denied') : 'Permission denied';
    if (!headers_sent()) header('Content-Type: text/html; charset=utf-8');
    echo '<main class="wrap" style="padding:40px 0"><div class="card" style="padding:20px">';
    echo '<h1 style="margin:0 0 10px">' . htmlspecialchars($title, ENT_QUOTES) . '</h1>';
    echo '<p style="color:rgba(0,0,0,0.6);margin:0">' . htmlspecialchars($perm, ENT_QUOTES) . '</p>';
    echo '</div></main>';
    exit;
  }

  private function resolveRole(?array $user): string {
    if (!$user) return 'guest';
    $role = (string)($user['role'] ?? 'registered');
    if ($role === 'superadmin' || $role === 'admin') return 'admin';
    if ($role === 'moderator') return 'moderator';
    return 'registered';
  }
}
