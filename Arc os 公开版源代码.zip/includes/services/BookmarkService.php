<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class BookmarkService {
  public static function isBookmarked(PDO $pdo, string $pfx, int $userId, string $type, int $contentId): bool {
    if ($userId <= 0 || $contentId <= 0) return false;
    $type = trim($type);
    if ($type === '') return false;
    try {
      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_bookmarks WHERE user_id=? AND content_type=? AND content_id=? LIMIT 1");
      $stmt->execute([$userId, $type, $contentId]);
      return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
      return false;
    }
  }

  public static function toggle(PDO $pdo, string $pfx, int $userId, string $type, int $contentId): bool {
    if ($userId <= 0 || $contentId <= 0) return false;
    $type = trim($type);
    if ($type === '') return false;
    try {
      if (self::isBookmarked($pdo, $pfx, $userId, $type, $contentId)) {
        $pdo->prepare("DELETE FROM {$pfx}xf_bookmarks WHERE user_id=? AND content_type=? AND content_id=?")
          ->execute([$userId, $type, $contentId]);
        return false;
      }
      $pdo->prepare("INSERT IGNORE INTO {$pfx}xf_bookmarks (user_id, content_type, content_id, created_at) VALUES (?,?,?,NOW())")
        ->execute([$userId, $type, $contentId]);
      return true;
    } catch (Throwable $e) {
      return false;
    }
  }
}
