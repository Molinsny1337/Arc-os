<?php
declare(strict_types=1);

namespace ArcOS\Services;

require_once __DIR__ . '/DiscordWebhookService.php';

use PDO;
use Throwable;

final class ReportService {
  public static function create(PDO $pdo, string $pfx, int $userId, string $type, int $contentId, string $reason, string $details = ''): bool {
    if ($userId <= 0 || $contentId <= 0) return false;
    $type = trim($type);
    $reason = trim($reason);
    if ($type === '' || $reason === '') return false;
    if (strlen($reason) > 255) $reason = substr($reason, 0, 255);
    if (strlen($details) > 5000) $details = substr($details, 0, 5000);

    try {
      $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_reports WHERE user_id=? AND content_type=? AND content_id=? AND status='open' LIMIT 1");
      $stmt->execute([$userId, $type, $contentId]);
      if ($stmt->fetchColumn()) return false;

      $pdo->prepare("INSERT INTO {$pfx}xf_reports (content_type, content_id, user_id, reason, details, status, created_at)
        VALUES (?,?,?,?,?,'open',NOW())")
        ->execute([$type, $contentId, $userId, $reason, $details]);

      $url = '';
      if (function_exists('admin_url')) {
        $url = admin_url('review_center');
      } elseif (function_exists('url')) {
        $url = url('admin/review_center.php');
      }
      DiscordWebhookService::send('report_created', [
        'title' => 'New Report',
        'author' => 'User #' . $userId,
        'description' => $reason,
        'summary' => $details,
        'url' => $url,
        'content_id' => $contentId,
        'channel' => strtoupper($type),
      ]);
      return true;
    } catch (Throwable $e) {
      return false;
    }
  }
}
