<?php
declare(strict_types=1);

namespace ArcOS\Services;

final class LicenseApiClient {
  private string $baseUrl;
  private int $timeout;

  public function __construct(?string $baseUrl = null, int $timeoutSeconds = 2) {
    $this->timeout = max(1, min(2, $timeoutSeconds));
    $raw = $baseUrl;
    if ($raw === null && function_exists('get_setting')) {
      $raw = (string)get_setting('license_center_base_url', '');
    }
    $this->baseUrl = self::validateBaseUrl((string)$raw);
  }

  public function isConfigured(): bool {
    return $this->baseUrl !== '';
  }

  public static function validateBaseUrl(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (!preg_match('~^https://~i', $url)) return '';
    $parts = parse_url($url);
    if (!is_array($parts)) return '';
    $host = strtolower((string)($parts['host'] ?? ''));
    if ($host === '' || $host === 'localhost') return '';
    if (str_ends_with($host, '.local') || str_ends_with($host, '.internal')) return '';
    if (str_contains($host, '@')) return '';

    if (filter_var($host, FILTER_VALIDATE_IP)) {
      if (!self::isPublicIp($host)) return '';
    } else {
      $ips = self::resolveIps($host);
      if (!$ips) return '';
      foreach ($ips as $ip) {
        if (!self::isPublicIp($ip)) return '';
      }
    }

    $port = isset($parts['port']) ? (int)$parts['port'] : 443;
    $path = (string)($parts['path'] ?? '');
    $base = 'https://' . $host;
    if ($port !== 443 && $port > 0) {
      $base .= ':' . $port;
    }
    if ($path !== '') {
      $base .= '/' . ltrim(rtrim($path, '/'), '/');
    }
    return $base;
  }

  /**
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  public function activate(string $licenseKey, string $accountToken, string $domain, string $siteId, ?string $fingerprint = null): array {
    $payload = [
      'license_key' => $licenseKey,
      'account_token' => $accountToken,
      'domain' => $domain,
      'site_id' => $siteId,
    ];
    if ($fingerprint !== null && $fingerprint !== '') {
      $payload['fingerprint'] = $fingerprint;
    }
    return $this->request('POST', '/api/v1/license/activate', $payload, []);
  }

  /**
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  public function refresh(string $refreshToken, string $domain, string $siteId): array {
    $payload = [
      'refresh_token' => $refreshToken,
      'domain' => $domain,
      'site_id' => $siteId,
    ];
    return $this->request('POST', '/api/v1/license/refresh', $payload, []);
  }

  /**
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  public function download(string $accountToken, string $domain, string $siteId): array {
    $query = http_build_query(['domain' => $domain, 'site_id' => $siteId]);
    $headers = ['Authorization' => 'Bearer ' . $accountToken];
    return $this->request('GET', '/api/v1/license/download?' . $query, null, $headers);
  }

  /**
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  public function status(string $accountToken, string $domain, string $siteId): array {
    $query = http_build_query(['domain' => $domain, 'site_id' => $siteId]);
    $headers = ['Authorization' => 'Bearer ' . $accountToken];
    return $this->request('GET', '/api/v1/license/status?' . $query, null, $headers);
  }

  /**
   * @param array<string,mixed>|null $data
   * @param array<string,string> $headers
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  private function request(string $method, string $path, ?array $data, array $headers): array {
    if ($this->baseUrl === '') {
      return ['ok' => false, 'data' => [], 'error_code' => 'base_url_invalid', 'message' => 'Base URL invalid', 'http_code' => 0];
    }
    $url = rtrim($this->baseUrl, '/') . $path;

    $attempts = 0;
    $delayMs = 150;
    $last = ['ok' => false, 'data' => [], 'error_code' => 'network_error', 'message' => 'Network error', 'http_code' => 0];

    while ($attempts < 3) {
      $attempts++;
      $res = $this->doRequest($method, $url, $data, $headers);
      $last = $res;
      if ($res['ok']) return $res;
      $code = (int)($res['http_code'] ?? 0);
      if ($code > 0 && $code < 500) break;
      if ($attempts >= 3) break;
      usleep($delayMs * 1000);
      $delayMs *= 2;
    }

    return $last;
  }

  /**
   * @param array<string,mixed>|null $data
   * @param array<string,string> $headers
   * @return array{ok:bool,data:array,error_code:string,message:string,http_code:int}
   */
  private function doRequest(string $method, string $url, ?array $data, array $headers): array {
    if (!function_exists('curl_init')) {
      return ['ok' => false, 'data' => [], 'error_code' => 'curl_unavailable', 'message' => 'CURL unavailable', 'http_code' => 0];
    }

    $ch = curl_init();
    if ($ch === false) {
      return ['ok' => false, 'data' => [], 'error_code' => 'curl_unavailable', 'message' => 'CURL unavailable', 'http_code' => 0];
    }

    $httpHeaders = [
      'Accept: application/json',
    ];
    foreach ($headers as $k => $v) {
      $httpHeaders[] = $k . ': ' . $v;
    }

    $opts = [
      CURLOPT_URL => $url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_TIMEOUT => $this->timeout,
      CURLOPT_CONNECTTIMEOUT => $this->timeout,
      CURLOPT_HTTPHEADER => $httpHeaders,
      CURLOPT_CUSTOMREQUEST => $method,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
    ];

    if ($data !== null) {
      $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if (!is_string($payload)) $payload = '{}';
      $opts[CURLOPT_POSTFIELDS] = $payload;
      $opts[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
    }

    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($raw === false) {
      return ['ok' => false, 'data' => [], 'error_code' => 'curl_error', 'message' => $err !== '' ? $err : 'CURL error', 'http_code' => 0];
    }

    $decoded = json_decode((string)$raw, true);
    if (!is_array($decoded)) $decoded = [];

    if ($code >= 400) {
      $errCode = isset($decoded['error_code']) ? (string)$decoded['error_code'] : 'http_' . $code;
      $msg = isset($decoded['message']) ? (string)$decoded['message'] : ('HTTP ' . $code);
      return ['ok' => false, 'data' => $decoded, 'error_code' => $errCode, 'message' => $msg, 'http_code' => $code];
    }

    return ['ok' => true, 'data' => $decoded, 'error_code' => '', 'message' => '', 'http_code' => $code];
  }

  /**
   * @return string[]
   */
  private static function resolveIps(string $host): array {
    $ips = [];
    $v4 = @gethostbynamel($host);
    if (is_array($v4)) {
      foreach ($v4 as $ip) $ips[] = $ip;
    }
    if (function_exists('dns_get_record')) {
      $records = @dns_get_record($host, DNS_AAAA);
      if (is_array($records)) {
        foreach ($records as $r) {
          if (!empty($r['ipv6'])) $ips[] = (string)$r['ipv6'];
        }
      }
    }
    return array_values(array_unique($ips));
  }

  private static function isPublicIp(string $ip): bool {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;
    $flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
    return (bool)filter_var($ip, FILTER_VALIDATE_IP, $flags);
  }
}
