<?php
declare(strict_types=1);

namespace ArcOS\Services;

use PDO;
use Throwable;

final class ProfileService {
  /**
   * @return array<string,mixed>
   */
  public static function getProfile(PDO $pdo, string $pfx, int $userId): array {
    if ($userId <= 0) return [];
    try {
      $stmt = $pdo->prepare("SELECT * FROM {$pfx}xf_user_profile WHERE user_id=? LIMIT 1");
      $stmt->execute([$userId]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if (is_array($row)) return $row;
    } catch (Throwable $e) {}
    return [];
  }

  /**
   * @param array<string,mixed> $profile
   * @return array<string,mixed>
   */
  public static function privacy(array $profile): array {
    $defaults = [
      'post_on_profile' => 'everyone',
      'show_visitors' => true,
      'show_followers' => true,
      'show_discord' => true,
    ];
    $raw = (string)($profile['privacy_json'] ?? '');
    if ($raw === '') return $defaults;
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) return $defaults;

    $out = $defaults;
    foreach ($defaults as $k => $v) {
      if (array_key_exists($k, $decoded)) $out[$k] = $decoded[$k];
    }
    return $out;
  }

  public static function canPostOnProfile(PDO $pdo, string $pfx, int $viewerId, int $profileUserId): bool {
    if ($profileUserId <= 0) return false;
    if (function_exists('get_setting') && get_setting('profile_posts_enabled', '1') !== '1') return false;
    if ($viewerId === $profileUserId) return true;

    try {
      $stmt = $pdo->prepare("SELECT allow_profile_posts FROM {$pfx}users WHERE id=? LIMIT 1");
      $stmt->execute([$profileUserId]);
      $allow = (int)($stmt->fetchColumn() ?? 1);
      if ($allow === 0) return false;
    } catch (Throwable $e) {}

    $profile = self::getProfile($pdo, $pfx, $profileUserId);
    $privacy = self::privacy($profile);
    $mode = (string)($privacy['post_on_profile'] ?? 'everyone');
    if ($mode === 'nobody') return false;
    if ($mode === 'followers') {
      if ($viewerId <= 0) return false;
      try {
        $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}xf_user_follow WHERE follower_id=? AND followed_id=? LIMIT 1");
        $stmt->execute([$viewerId, $profileUserId]);
        return (bool)$stmt->fetchColumn();
      } catch (Throwable $e) {
        return false;
      }
    }
    return true;
  }

  public static function recordVisit(PDO $pdo, string $pfx, int $profileUserId, int $visitorId): void {
    if ($profileUserId <= 0 || $visitorId <= 0 || $profileUserId === $visitorId) return;
    if (function_exists('get_setting') && get_setting('profile_visitors_enabled', '1') !== '1') return;
    $profile = self::getProfile($pdo, $pfx, $profileUserId);
    $privacy = self::privacy($profile);
    if (isset($privacy['show_visitors']) && !$privacy['show_visitors']) return;

    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}xf_profile_visitors (user_id, visitor_user_id, visited_at)
        VALUES (?,?,NOW())
        ON DUPLICATE KEY UPDATE visited_at=VALUES(visited_at)");
      $stmt->execute([$profileUserId, $visitorId]);
    } catch (Throwable $e) {}
  }
}
