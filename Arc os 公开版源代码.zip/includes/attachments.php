<?php
declare(strict_types=1);

function arc_is_image_mime(string $mime): bool {
  return str_starts_with($mime, 'image/');
}

function arc_ensure_dir(string $dir): void {
  if (!is_dir($dir)) @mkdir($dir, 0775, true);
  // protect directory listing
  $idx = rtrim($dir,'/') . '/index.html';
  if (!is_file($idx)) @file_put_contents($idx, "<!-- Arc OS -->");
}

function arc_handle_attachments_upload(PDO $pdo, string $pfx, array $me, int $postId, string $field='attachments'): array {
  $saved = [];
  if (!isset($_FILES[$field]) || !is_array($_FILES[$field]['name'])) return $saved;

  $base = __DIR__ . '/../uploads/attachments';
  arc_ensure_dir($base);

  $names = $_FILES[$field]['name'];
  $tmp   = $_FILES[$field]['tmp_name'];
  $errs  = $_FILES[$field]['error'];
  $sizes = $_FILES[$field]['size'];
  $types = $_FILES[$field]['type'];

  $max = 20 * 1024 * 1024; // 20MB per file, because you said size doesn't matter.
  $allowed = [
    'image/jpeg','image/png','image/webp','image/gif',
    'application/pdf','text/plain','application/zip',
    'application/x-zip-compressed',
    'application/octet-stream'
  ];

  for ($i=0; $i<count($names); $i++) {
    if (($errs[$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
    $orig = (string)$names[$i];
    $size = (int)($sizes[$i] ?? 0);
    if ($size <= 0 || $size > $max) continue;

    $tmpf = (string)($tmp[$i] ?? '');
    if ($tmpf === '' || !is_uploaded_file($tmpf)) continue;

    $mime = (string)($types[$i] ?? 'application/octet-stream');
    // best-effort mime sniff
    if (function_exists('finfo_open')) {
      try {
        $fi = finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) {
          $sn = finfo_file($fi, $tmpf);
          if (is_string($sn) && $sn !== '') $mime = $sn;
          finfo_close($fi);
        }
      } catch (Throwable $e) {}
    }
    if (!in_array($mime, $allowed, true) && !arc_is_image_mime($mime)) {
      // allow weird mimes if it's actually an image
      continue;
    }

    $ext = pathinfo($orig, PATHINFO_EXTENSION);
    $ext = preg_replace('/[^a-zA-Z0-9]+/', '', (string)$ext);
    $ext = $ext ? ('.' . strtolower($ext)) : '';
    $stored = 'att_' . $postId . '_' . bin2hex(random_bytes(8)) . $ext;

    $dest = $base . '/' . $stored;
    if (!@move_uploaded_file($tmpf, $dest)) continue;

    $isImg = arc_is_image_mime($mime) ? 1 : 0;

    try {
      $stmt = $pdo->prepare("INSERT INTO {$pfx}post_attachments (post_id, user_id, original_name, stored_name, mime, size_bytes, is_image, created_at)
        VALUES (?,?,?,?,?,?,?,NOW())");
      $stmt->execute([$postId, (int)$me['id'], $orig, $stored, $mime, $size, $isImg]);
      $saved[] = [
        'original' => $orig,
        'stored' => $stored,
        'mime' => $mime,
        'is_image' => $isImg,
        'size' => $size,
      ];
    } catch (Throwable $e) {
      // ignore
    }
  }

  return $saved;
}

function arc_list_attachments(PDO $pdo, string $pfx, int $postId): array {
  try {
    $stmt = $pdo->prepare("SELECT * FROM {$pfx}post_attachments WHERE post_id=? ORDER BY id ASC");
    $stmt->execute([$postId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {
    return [];
  }
}

function arc_attachment_url(string $stored): string {
  return url('uploads/attachments/' . rawurlencode($stored));
}
