<?php
declare(strict_types=1);

/**
 * XenForo-like profile helpers (ADD-ON).
 * 只提供“补字段/取字段”的薄封装，避免大改现有页面逻辑。
 */

function arc_user_table_columns(): array {
  static $cols = null;
  if (is_array($cols)) return $cols;

  try {
    $pdo = db();
    $pfx = table_prefix();
    $stmt = $pdo->query("SHOW COLUMNS FROM `{$pfx}users`");
    $cols = [];
    foreach ($stmt as $row) {
      if (isset($row['Field'])) $cols[(string)$row['Field']] = true;
    }
    return $cols;
  } catch (Throwable $e) {
    $cols = [];
    return $cols;
  }
}

/**
 * 从 users 表补充抓取一些“个人主页”相关字段（存在才抓，不存在就忽略）。
 */
function arc_fetch_profile_extras(int $userId): array {
  if ($userId <= 0) return [];
  $cols = arc_user_table_columns();
  if (!$cols) return [];

  $want = [
    'display_name','created_at','last_active',
    // xenforo-like additions
    'cover_url','cover_pos_x','cover_pos_y',
    'user_title','about_text','location','website',
  ];

  $select = [];
  foreach ($want as $c) {
    if (isset($cols[$c])) $select[] = $c;
  }
  if (!$select) return [];

  $pdo = db();
  $pfx = table_prefix();
  $sql = "SELECT " . implode(", ", array_map(fn($c)=>"`{$c}`", $select)) . " FROM `{$pfx}users` WHERE id=? LIMIT 1";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([$userId]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  return is_array($row) ? $row : [];
}

function arc_normalize_cover_url(?string $coverUrl): string {
  $coverUrl = trim((string)$coverUrl);
  if ($coverUrl === '') return '';
  // allow absolute or site-relative
  if (preg_match('~^https?://~i', $coverUrl)) return $coverUrl;
  if (str_starts_with($coverUrl, '/')) return $coverUrl;
  return base_path() . '/' . ltrim($coverUrl, '/');
}

function arc_clamp_0_100($v, int $default = 50): int {
  if ($v === null || $v === '') return $default;
  $n = (int)$v;
  if ($n < 0) return 0;
  if ($n > 100) return 100;
  return $n;
}

// ---------------------------------------------------------------------------
// Per-user profile design (safe CSS vars + sidebar layout)
// ---------------------------------------------------------------------------

function arc_profile_prefs_ensure_table(): void {
  static $done = false;
  if ($done) return;
  $done = true;

  try {
    $pdo = db();
    $pfx = table_prefix();
    $pdo->exec("CREATE TABLE IF NOT EXISTS {$pfx}user_profile_prefs (
      user_id INT UNSIGNED NOT NULL,
      layout_json TEXT NULL,
      css_vars TEXT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {
    // ignore
  }
}

/**
 * @return array{layout: array<int, array{id:string, enabled:bool}>, css_vars: string}
 */
function arc_profile_prefs_get(int $userId): array {
  arc_profile_prefs_ensure_table();
  $layout = arc_profile_layout_default_items();
  $cssVars = '';

  if ($userId <= 0) return ['layout' => $layout, 'css_vars' => $cssVars];

  try {
    $pdo = db();
    $pfx = table_prefix();
    $st = $pdo->prepare("SELECT layout_json, css_vars FROM {$pfx}user_profile_prefs WHERE user_id=? LIMIT 1");
    $st->execute([$userId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (is_array($row)) {
      $j = (string)($row['layout_json'] ?? '');
      $decoded = $j !== '' ? json_decode($j, true) : null;
      if (is_array($decoded)) {
        $layout = arc_layout_normalize_items($decoded, arc_profile_layout_default_items(), arc_profile_layout_allowed_ids());
      }
      $cssVars = (string)($row['css_vars'] ?? '');
      $cssVars = function_exists('arc_sanitize_profile_css_vars') ? arc_sanitize_profile_css_vars($cssVars) : $cssVars;
    }
  } catch (Throwable $e) {}

  return ['layout' => $layout, 'css_vars' => $cssVars];
}

/**
 * @param array<int, array{id:string, enabled:bool}>|null $layoutItems
 */
function arc_profile_prefs_set(int $userId, ?array $layoutItems, ?string $cssVars): void {
  if ($userId <= 0) return;
  arc_profile_prefs_ensure_table();

  $layoutJson = null;
  if (is_array($layoutItems)) {
    $layoutItems = arc_layout_normalize_items($layoutItems, arc_profile_layout_default_items(), arc_profile_layout_allowed_ids());
    $layoutJson = json_encode($layoutItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  }

  $cssOut = null;
  if (is_string($cssVars)) {
    $cssOut = function_exists('arc_sanitize_profile_css_vars') ? arc_sanitize_profile_css_vars($cssVars) : $cssVars;
  }

  try {
    $pdo = db();
    $pfx = table_prefix();
    $pdo->prepare("INSERT INTO {$pfx}user_profile_prefs (user_id, layout_json, css_vars, updated_at)
      VALUES (?, ?, ?, NOW())
      ON DUPLICATE KEY UPDATE layout_json=COALESCE(VALUES(layout_json), layout_json),
                              css_vars=COALESCE(VALUES(css_vars), css_vars),
                              updated_at=NOW()")
      ->execute([$userId, $layoutJson, $cssOut]);
  } catch (Throwable $e) {}
}
