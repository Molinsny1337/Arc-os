<?php
declare(strict_types=1);

function conv_user_can_access(PDO $pdo, string $pfx, int $convId, int $userId): bool {
  try {
    $stmt = $pdo->prepare("SELECT 1 FROM {$pfx}conversation_participants WHERE conversation_id=? AND user_id=? AND is_left=0 LIMIT 1");
    $stmt->execute([$convId, $userId]);
    return (bool)$stmt->fetchColumn();
  } catch (Throwable $e) {
    return false;
  }
}

function conv_participants(PDO $pdo, string $pfx, int $convId): array {
  try {
    $stmt = $pdo->prepare("SELECT u.id,u.username,u.display_name,u.avatar
      FROM {$pfx}conversation_participants cp
      JOIN {$pfx}users u ON u.id=cp.user_id
      WHERE cp.conversation_id=? AND cp.is_left=0
      ORDER BY u.username ASC");
    $stmt->execute([$convId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) { return []; }
}

function conv_create(PDO $pdo, string $pfx, int $creatorId, array $userIds, string $title, string $firstMessage): int {
  $pdo->beginTransaction();
  try {
    $stmt = $pdo->prepare("INSERT INTO {$pfx}conversations (title, creator_id, created_at, last_message_at) VALUES (?,?,NOW(),NOW())");
    $stmt->execute([$title ?: null, $creatorId]);
    $convId = (int)$pdo->lastInsertId();

    $all = array_values(array_unique(array_merge([$creatorId], $userIds)));
    $stmtP = $pdo->prepare("INSERT INTO {$pfx}conversation_participants (conversation_id, user_id, joined_at) VALUES (?,?,NOW())");
    foreach ($all as $uid) $stmtP->execute([$convId, (int)$uid]);

    $stmtM = $pdo->prepare("INSERT INTO {$pfx}conversation_messages (conversation_id, user_id, message, created_at) VALUES (?,?,?,NOW())");
    $stmtM->execute([$convId, $creatorId, $firstMessage]);
    $msgId = (int)$pdo->lastInsertId();

    $pdo->prepare("UPDATE {$pfx}conversations SET last_message_id=?, last_message_at=NOW() WHERE id=?")->execute([$msgId, $convId]);

    $pdo->commit();
    return $convId;
  } catch (Throwable $e) {
    $pdo->rollBack();
    return 0;
  }
}
