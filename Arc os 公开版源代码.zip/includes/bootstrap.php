<?php
declare(strict_types=1);

// Minimal bootstrap for pages that may run BEFORE installation.
// Provides: session, BASE_PATH, helpers (url/e/redirect/slugify), i18n (t/lang).

// IMPORTANT: some pages (e.g. transition.php) include bootstrap.php first and then init.php.
// If we start session here with the default PHPSESSID, init.php can no longer change it,
// which re-introduces the "reinstall keeps old login" issue. So we use the same
// per-install session scheme as init.php.

if (!function_exists('arc_is_https')) {
  function arc_is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
    return false;
  }
}

if (!function_exists('arc_session_configure_and_start')) {
  function arc_session_configure_and_start(): void {
    $cfgFile = __DIR__ . '/config.php';
    $appKey = '';
    if (is_file($cfgFile)) {
      $cfg = require $cfgFile;
      if (is_array($cfg) && !empty($cfg['app_key'])) {
        $appKey = (string)$cfg['app_key'];
      }
    }

    if ($appKey !== '' && !defined('APP_KEY')) {
      define('APP_KEY', $appKey);
    }

    if (session_status() === PHP_SESSION_ACTIVE) {
      // signature validation even when session already active
      if (defined('APP_KEY') && APP_KEY !== '') {
        $expected = hash_hmac('sha256', session_id(), APP_KEY);
        $sig = $_SESSION['_sig'] ?? null;
        if (!is_string($sig) || !hash_equals($sig, $expected)) {
          $_SESSION = [];
          @session_regenerate_id(true);
        }
        $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
      }
      return;
    }

    if ($appKey !== '') {
      $name = 'ARCOSSESSID_' . substr(hash('sha256', $appKey), 0, 12);
      @session_name($name);
    }

    // project-local session storage
    $sessDir = realpath(__DIR__ . '/../storage') ?: (__DIR__ . '/../storage');
    $sessPath = $sessDir . '/sessions';
    if (!is_dir($sessPath)) {
      @mkdir($sessPath, 0700, true);
    }
    if (is_dir($sessPath) && is_writable($sessPath)) {
      @session_save_path($sessPath);
    }

    $secure = arc_is_https();
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.cookie_secure', $secure ? '1' : '0');
    @ini_set('session.cookie_samesite', 'Lax');

    if (function_exists('session_set_cookie_params')) {
      $params = session_get_cookie_params();
      $path = $params['path'] ?? '/';
      if (!$path) $path = '/';
      @session_set_cookie_params([
        'lifetime' => 0,
        'path' => $path,
        'domain' => $params['domain'] ?? '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
      ]);
    }

    @session_start();

    if (defined('APP_KEY') && APP_KEY !== '') {
      $expected = hash_hmac('sha256', session_id(), APP_KEY);
      $sig = $_SESSION['_sig'] ?? null;
      if (!is_string($sig) || !hash_equals($sig, $expected)) {
        $_SESSION = [];
        @session_regenerate_id(true);
      }
      $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
    }
  }
}

arc_session_configure_and_start();

if (!function_exists('str_starts_with')) {
  function str_starts_with(string $haystack, string $needle): bool {
    return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
  }
}
if (!function_exists('str_contains')) {
  function str_contains(string $haystack, string $needle): bool {
    return $needle === '' || strpos($haystack, $needle) !== false;
  }
}

// Compute BASE_PATH robustly
$docRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
$docRootReal = $docRoot ? realpath($docRoot) : false;
$projectRoot = realpath(__DIR__ . '/..'); // includes/.. => project root
$basePath = '';
if ($docRootReal && $projectRoot && str_starts_with($projectRoot, $docRootReal)) {
  $rel = substr($projectRoot, strlen($docRootReal));
  $rel = str_replace('\\', '/', $rel);
  $basePath = rtrim($rel, '/');
  if ($basePath === '/') $basePath = '';
}
if (!defined('BASE_PATH')) { define('BASE_PATH', $basePath); }

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/i18n.php';
lang();


/**
 * Detect whether the site is installed.
 * Safe to call before installation: returns false if config.php is missing or DB is unreachable.
 */
if (!function_exists('is_installed')) {
  function is_installed(): bool {
    $cfgFile = __DIR__ . '/config.php';
    if (!is_file($cfgFile)) return false;

    // Load DB helpers only if config exists
    require_once __DIR__ . '/db.php';

    try {
      $pdo = db();
      $pfx = table_prefix();
      $like = $pfx . "settings";
      $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($like));
      $row = $stmt ? $stmt->fetchColumn() : false;
      return (bool)$row;
    } catch (Throwable $e) {
      return false;
    }
  }
}
