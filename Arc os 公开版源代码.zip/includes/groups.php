<?php
declare(strict_types=1);

/**
 * Identity groups (used for paid entitlements and other membership flags).
 *
 * Tables:
 * - {$pfx}groups
 * - {$pfx}user_groups
 */

/**
 * @return array<int, array{id:int, slug:string, name:string, is_paid:int}>
 */
function arc_groups_all(): array {
  if (!function_exists('db') || !function_exists('table_prefix')) return [];
  $pdo = db();
  $pfx = table_prefix();
  $tG = $pfx . 'groups';
  try {
    $rows = $pdo->query("SELECT id, slug, name, is_paid FROM {$tG} ORDER BY is_paid DESC, name ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $out = [];
    foreach ($rows as $r) {
      $out[] = [
        'id' => (int)($r['id'] ?? 0),
        'slug' => (string)($r['slug'] ?? ''),
        'name' => (string)($r['name'] ?? ''),
        'is_paid' => (int)($r['is_paid'] ?? 0),
      ];
    }
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}

/**
 * @return array<int, string> group slugs
 */
function arc_user_group_slugs(int $userId): array {
  if ($userId <= 0 || !function_exists('db') || !function_exists('table_prefix')) return [];
  $pdo = db();
  $pfx = table_prefix();
  $tUG = $pfx . 'user_groups';
  $tG = $pfx . 'groups';
  try {
    $stmt = $pdo->prepare("SELECT g.slug
      FROM {$tUG} ug
      JOIN {$tG} g ON g.id = ug.group_id
      WHERE ug.user_id = ?
      ORDER BY g.is_paid DESC, g.slug ASC");
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $out = [];
    foreach ($rows as $r) {
      $s = (string)($r['slug'] ?? '');
      if ($s !== '') $out[] = $s;
    }
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}

function arc_is_paid_user(int $userId): bool {
  if ($userId <= 0 || !function_exists('db') || !function_exists('table_prefix')) return false;
  $pdo = db();
  $pfx = table_prefix();
  $tUG = $pfx . 'user_groups';
  $tG = $pfx . 'groups';
  try {
    $stmt = $pdo->prepare("SELECT 1
      FROM {$tUG} ug
      JOIN {$tG} g ON g.id = ug.group_id
      WHERE ug.user_id = ? AND g.is_paid = 1
      LIMIT 1");
    $stmt->execute([$userId]);
    return (bool)$stmt->fetchColumn();
  } catch (Throwable $e) {
    return false;
  }
}

/**
 * Replace a user's group memberships.
 * @param array<int, int> $groupIds
 */
function arc_set_user_group_ids(int $userId, array $groupIds): void {
  if ($userId <= 0 || !function_exists('db') || !function_exists('table_prefix')) return;
  $pdo = db();
  $pfx = table_prefix();
  $tUG = $pfx . 'user_groups';
  $tG = $pfx . 'groups';

  $ids = [];
  foreach ($groupIds as $gid) {
    $gid = (int)$gid;
    if ($gid > 0) $ids[$gid] = true;
  }
  $ids = array_keys($ids);

  $pdo->beginTransaction();
  try {
    $pdo->prepare("DELETE FROM {$tUG} WHERE user_id=?")->execute([$userId]);
    if ($ids) {
      // ensure groups exist
      $in = implode(',', array_fill(0, count($ids), '?'));
      $stmt = $pdo->prepare("SELECT id FROM {$tG} WHERE id IN ({$in})");
      $stmt->execute($ids);
      $valid = [];
      while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $valid[(int)($r['id'] ?? 0)] = true;
      }
      $ins = $pdo->prepare("INSERT INTO {$tUG} (user_id, group_id, created_at) VALUES (?, ?, NOW())");
      foreach ($ids as $gid) {
        if (!isset($valid[$gid])) continue;
        $ins->execute([$userId, $gid]);
      }
    }
    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }
}

/**
 * @return array<int, int>
 */
function arc_user_group_ids(int $userId): array {
  if ($userId <= 0 || !function_exists('db') || !function_exists('table_prefix')) return [];
  $pdo = db();
  $pfx = table_prefix();
  $tUG = $pfx . 'user_groups';
  try {
    $stmt = $pdo->prepare("SELECT group_id FROM {$tUG} WHERE user_id=? ORDER BY group_id ASC");
    $stmt->execute([$userId]);
    $out = [];
    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $out[] = (int)($r['group_id'] ?? 0);
    }
    return array_values(array_filter($out, fn($x) => $x > 0));
  } catch (Throwable $e) {
    return [];
  }
}

