<?php
declare(strict_types=1);

function arc_extract_mentions(string $html_or_text, int $max = 12): array {
  $txt = html_entity_decode(strip_tags($html_or_text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
  preg_match_all('/(^|\s)@([A-Za-z0-9_\-]{2,32})\b/u', $txt, $m);
  $out = [];
  if (!empty($m[2])) {
    foreach ($m[2] as $n) {
      $n = (string)$n;
      if (!in_array($n, $out, true)) $out[] = $n;
      if (count($out) >= $max) break;
    }
  }
  return $out;
}

function arc_users_by_usernames(array $usernames): array {
  $usernames = array_values(array_filter(array_map('strval', $usernames)));
  if (!$usernames) return [];
  try {
    $pdo = db();
    $pfx = table_prefix();
    $in = implode(',', array_fill(0, count($usernames), '?'));
    $stmt = $pdo->prepare("SELECT id, username FROM {$pfx}users WHERE username IN ({$in})");
    $stmt->execute($usernames);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $map = [];
    foreach ($rows as $r) $map[(string)$r['username']] = (int)$r['id'];
    return $map;
  } catch (Throwable $e) { return []; }
}
