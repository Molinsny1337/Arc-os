<?php
declare(strict_types=1);

function trophy_total_points(PDO $pdo, string $pfx, int $userId): int {
  try {
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(t.points),0) FROM {$pfx}user_trophies ut JOIN {$pfx}trophies t ON t.id=ut.trophy_id WHERE ut.user_id=?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
  } catch (Throwable $e) { return 0; }
}

function trophy_list_for_user(PDO $pdo, string $pfx, int $userId, int $limit=12): array {
  try {
    $stmt = $pdo->prepare("SELECT t.*, ut.awarded_at FROM {$pfx}user_trophies ut JOIN {$pfx}trophies t ON t.id=ut.trophy_id
      WHERE ut.user_id=? ORDER BY ut.awarded_at DESC, t.points DESC LIMIT ?");
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) { return []; }
}
