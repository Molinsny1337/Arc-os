<?php
declare(strict_types=1);
require_once __DIR__ . '/smtp.php';
require_once __DIR__ . '/services/MailService.php';

function send_mail(string $toEmail, string $subject, string $body, ?string $textBody = null): bool {
  if (class_exists('ArcOS\\Services\\FeatureGate') && !ArcOS\Services\FeatureGate::enabled('mail')) {
    return false;
  }
  try {
    if (function_exists('db') && function_exists('table_prefix')) {
      $pdo = db();
      $pfx = table_prefix();
      return ArcOS\Services\MailService::queue($pdo, $pfx, $toEmail, $subject, $body, $textBody);
    }
  } catch (Throwable $e) {
    // fall through to direct send
  }

  $headers = "From: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'localhost');
  return @mail($toEmail, $subject, $body, $headers);
}
