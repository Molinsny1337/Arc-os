<?php
declare(strict_types=1);

// ---- mbstring polyfills (avoid white-screen on servers without mbstring) ----
if (!function_exists('mb_substr')) {
  function mb_substr(string $str, int $start, ?int $length = null, ?string $encoding = null): string {
    return $length === null ? substr($str, $start) : substr($str, $start, $length);
  }
}
if (!function_exists('mb_strtolower')) {
  function mb_strtolower(string $str, ?string $encoding = null): string {
    return strtolower($str);
  }
}
if (!function_exists('mb_strtoupper')) {
  function mb_strtoupper(string $str, ?string $encoding = null): string {
    return strtoupper($str);
  }
}
// ---------------------------------------------------------------


function e(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function base_path(): string {
  return defined('BASE_PATH') ? BASE_PATH : '';
}

/** 生成站内 URL（自动兼容子目录部署） */
function url(string $path): string {
  $bp = base_path();
  $p = '/' . ltrim($path, '/');
  return $bp . $p;
}

function admin_path_value(): string {
  if (!function_exists('config')) return 'admin';
  $cfg = config();
  $path = strtolower(trim((string)($cfg['admin_path'] ?? 'admin')));
  if (!preg_match('/^[a-z0-9_-]{3,32}$/', $path)) return 'admin';
  return $path;
}

function admin_entry_url(): string {
  $path = admin_path_value();
  return url($path . '.php');
}

/**
 * Build an admin URL through the entry script (custom admin path).
 * Fallback to /admin/*.php when entry file is missing.
 */
function admin_url(string $page = 'index', array $params = []): string {
  $page = trim($page);
  if ($page === '') $page = 'index';
  $page = preg_replace('/\.php$/i', '', $page) ?? 'index';
  if ($page === '') $page = 'index';

  $entry = admin_path_value();
  $entryFile = __DIR__ . '/../' . $entry . '.php';
  if (!is_file($entryFile)) {
    return url('admin/' . $page . '.php') . ($params ? ('?' . http_build_query($params)) : '');
  }

  $params = array_merge(['p' => $page], $params);
  return admin_entry_url() . '?' . http_build_query($params);
}

/**
 * @return array<string,string>
 */
function arc_admin_entry_routes(): array {
  return [
    'index' => 'admin/index.php',
    'login' => 'admin/login.php',
    'posts' => 'admin/posts.php',
    'post_edit' => 'admin/post_edit.php',
    'review_center' => 'admin/review_center.php',
    'links' => 'admin/links.php',
    'users' => 'admin/users.php',
    'user_edit' => 'admin/user_edit.php',
    'bans' => 'admin/bans.php',
    'trophies' => 'admin/trophies.php',
    'groups' => 'admin/groups.php',
    'tickets' => 'admin/tickets.php',
    'logs' => 'admin/logs.php',
    'api' => 'admin/api.php',
    'appearance' => 'admin/appearance.php',
    'layouts' => 'admin/layouts.php',
    'settings' => 'admin/settings.php',
    'settings_license' => 'admin/settings_license.php',
    'settings_mail' => 'admin/settings_mail.php',
    'mail_queue' => 'admin/mail_queue.php',
    'settings_discord' => 'admin/settings_discord.php',
    'discord_role_map' => 'admin/discord_role_map.php',
    'profile_fields' => 'admin/profile_fields.php',
    'emoji_packs' => 'admin/emoji_packs.php',
    'upgrade' => 'admin/upgrade.php',
    'thread_tools' => 'admin/thread_tools.php',
  ];
}

function arc_build_admin_entry_php(): string {
  $routes = arc_admin_entry_routes();
  $lines = [];
  $lines[] = "<?php";
  $lines[] = "declare(strict_types=1);";
  $lines[] = "define('ADMIN_ENTRY', true);";
  $lines[] = "require_once __DIR__ . '/includes/init.php';";
  $lines[] = "require_installed();";
  $lines[] = "";
  $lines[] = "\$page = (string)(\$_GET['p'] ?? 'index');";
  $lines[] = "\$page = preg_replace('/[^a-zA-Z0-9_-]/', '', \$page) ?? 'index';";
  $lines[] = "\$routes = [";
  foreach ($routes as $key => $path) {
    $lines[] = "  '" . $key . "' => __DIR__ . '/" . $path . "',";
  }
  $lines[] = "];";
  $lines[] = "if (!isset(\$routes[\$page])) {";
  $lines[] = "  http_response_code(404);";
  $lines[] = "  exit('Not Found');";
  $lines[] = "}";
  $lines[] = "require \$routes[\$page];";
  $lines[] = "";
  return implode(\"\\n\", $lines);
}

function arc_update_admin_entry_file(?string $adminPath = null): void {
  $adminPath = $adminPath ?? admin_path_value();
  $adminPath = strtolower(trim((string)$adminPath));
  if ($adminPath === '' || $adminPath === 'admin') return;
  $entryFile = __DIR__ . '/../' . $adminPath . '.php';
  if (!is_file($entryFile)) return;
  $raw = @file_get_contents($entryFile);
  if (is_string($raw) && str_contains($raw, 'settings_license')) return;
  $php = arc_build_admin_entry_php();
  @file_put_contents($entryFile, $php, LOCK_EX);
}

function redirect(string $to): void {
  header('Location: ' . $to);
  exit;
}

function now_utc(): string {
  return gmdate('Y-m-d H:i:s');
}

/** 简单 slugify（中文保留为 - 分隔的 urlencoded 也行；这里做最简英文） */
function slugify(string $text): string {
  $text = trim($text);
  $text = mb_strtolower($text, 'UTF-8');
  // 替换非字母数字为 -
  $text = preg_replace('/[^\pL\pN]+/u', '-', $text) ?? '';
  $text = trim($text, '-');
  if ($text === '') $text = 'post-' . substr(md5((string)microtime(true)), 0, 8);
  return $text;
}

/**
 * 为 posts.slug 生成唯一值（按 type 维度唯一）。
 * 解决同标题导致的 UNIQUE(slug, type) 冲突。
 */
function unique_post_slug(string $titleOrSlug, string $type, ?int $excludeId = null): string {
  $base = slugify($titleOrSlug);
  if (!function_exists('db') || !function_exists('table_prefix') || !function_exists('is_installed') || !is_installed()) {
    return $base;
  }
  try {
    $pdo = db();
    $pfx = table_prefix();
    $t = $pfx . 'posts';

    $check = function(string $slug) use ($pdo, $t, $type, $excludeId): bool {
      if ($excludeId !== null && $excludeId > 0) {
        $st = $pdo->prepare("SELECT 1 FROM {$t} WHERE slug=? AND type=? AND id<>? LIMIT 1");
        $st->execute([$slug, $type, $excludeId]);
      } else {
        $st = $pdo->prepare("SELECT 1 FROM {$t} WHERE slug=? AND type=? LIMIT 1");
        $st->execute([$slug, $type]);
      }
      return (bool)$st->fetchColumn();
    };

    if (!$check($base)) return $base;

    for ($i = 2; $i <= 50; $i++) {
      $cand = $base . '-' . $i;
      if (!$check($cand)) return $cand;
    }

    // 最后兜底：随机后缀
    return $base . '-' . substr(md5((string)microtime(true) . random_token(8)), 0, 6);
  } catch (Throwable $e) {
    return $base;
  }
}


function random_token(int $len = 32): string {
  $bytes = random_bytes($len);
  return bin2hex($bytes); // 2*len chars
}


function tpl_render(string $tpl, array $vars): string {
  foreach ($vars as $k => $v) {
    $tpl = str_replace('{{' . $k . '}}', (string)$v, $tpl);
  }
  return $tpl;
}

function site_name(): string {
  if (!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) {
    if (function_exists('get_setting')) {
    return (string)get_setting('site_name', 'Arc OS');
    }
  }
  return 'Arc OS';
}

function site_url(string $path = ''): string {
  $configured = '';
  if (!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) {
    if (function_exists('get_setting')) {
      try { $configured = trim((string)get_setting('site_url', '')); } catch (Throwable $e) { $configured = ''; }
    }
  }

  if ($configured !== '' && preg_match('~^https?://~i', $configured)) {
    $base = rtrim($configured, '/');
  } else {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $base = rtrim($scheme . '://' . $host . base_path(), '/');
  }
  $p = ltrim($path, '/');
  return $p ? ($base . '/' . $p) : $base . '/';
}

/**
 * 展示名：优先 display_name，其次 username。
 * 传入可为数据库行或 current_user() 的数组。
 */
function display_name_of(?array $u): string {
  if (!$u) return '';
  $dn = trim((string)($u['display_name'] ?? ''));
  if ($dn !== '') return $dn;
  return (string)($u['username'] ?? '');
}

/**
 * 在线工作人员（仿 XenForo：last_active 在 N 分钟内）
 * @return array<int, array{ id:int, username:string, role:string, avatar:?string }>
 */
function staff_online(int $minutes = 5): array {
  if (!function_exists('db') || !function_exists('table_prefix')) return [];
  try {
    $pdo = db();
    $pfx = table_prefix();
    $min = max(1, $minutes);
    $stmt = $pdo->prepare("SELECT id, username, role, avatar FROM {$pfx}users\n      WHERE role IN ('admin','superadmin')\n        AND last_active IS NOT NULL\n        AND last_active >= DATE_SUB(NOW(), INTERVAL {$min} MINUTE)\n      ORDER BY role='superadmin' DESC, username ASC");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $out = [];
    foreach ($rows as $r) {
      $out[] = [
        'id' => (int)($r['id'] ?? 0),
        'username' => (string)($r['username'] ?? ''),
        'role' => (string)($r['role'] ?? 'admin'),
        'avatar' => isset($r['avatar']) ? (string)$r['avatar'] : null,
      ];
    }
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}


// ---- install detection ----
if (!function_exists('is_installed')) {
  function is_installed(): bool {
    $cfgPath = __DIR__ . '/config.php';
    if (!is_file($cfgPath)) return false;
    $cfg = require $cfgPath;
    if (!is_array($cfg)) return false;

    $name = trim((string)($cfg['name'] ?? ''));
    $user = trim((string)($cfg['user'] ?? ''));
    if ($name === '' || $user === '') return false;

    // Verify DB reachable and schema present
    require_once __DIR__ . '/db.php';
    try {
      $pdo = db();
      $pfx = table_prefix();
      $like = $pfx . "settings";
      $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($like));
      $row = $stmt ? $stmt->fetchColumn() : false;
      return (bool)$row;
    } catch (Throwable $e) {
      return false;
    }
  }
}

/**
 * 识别上传图片扩展名（兼容：服务器未开启 fileinfo 扩展）
 * @return string '' 表示无法识别或不允许
 */
function detect_upload_image_ext(string $tmpPath, string $origName = ''): string {
  if ($tmpPath === '' || !is_file($tmpPath)) return '';

  // 1) fileinfo（若可用）
  // 某些主机把 finfo_* 放进 disable_functions，function_exists 依然会返回 true，调用就会直接炸。
  // 所以这里只信 is_callable。
  if (is_callable('finfo_open') && is_callable('finfo_file') && is_callable('finfo_close')) {
    try {
      $finfo = @finfo_open(FILEINFO_MIME_TYPE);
      $mime = $finfo ? (string)@finfo_file($finfo, $tmpPath) : '';
      if ($finfo) @finfo_close($finfo);
      $ext = mime_to_image_ext($mime);
      if ($ext !== '') return $ext;
    } catch (Throwable $e) {
      // 忽略，继续降级
    }
  }

  // 2) mime_content_type（某些主机有这个，但没 fileinfo）
  if (function_exists('mime_content_type')) {
    $mime = (string)@mime_content_type($tmpPath);
    $ext = mime_to_image_ext($mime);
    if ($ext !== '') return $ext;
  }

  // 3) getimagesize（最通用）
  $info = @getimagesize($tmpPath);
  if (is_array($info) && isset($info[2])) {
    $type = (int)$info[2];
    if ($type === IMAGETYPE_JPEG) return 'jpg';
    if ($type === IMAGETYPE_PNG) return 'png';
    if ($type === IMAGETYPE_GIF) return 'gif';
    if (defined('IMAGETYPE_WEBP') && $type === IMAGETYPE_WEBP) return 'webp';
  }

  // 4) 最后兜底：仅信任文件扩展名（并且只允许白名单）
  $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
  if (in_array($ext, ['jpg','jpeg','png','gif','webp'], true)) {
    return $ext === 'jpeg' ? 'jpg' : $ext;
  }
  return '';
}

function mime_to_image_ext(string $mime): string {
  $mime = strtolower(trim($mime));
  if ($mime === 'image/jpeg') return 'jpg';
  if ($mime === 'image/png') return 'png';
  if ($mime === 'image/webp') return 'webp';
  if ($mime === 'image/gif') return 'gif';
  return '';
}

// ---------------------------------------------------------------------------
// 安全基础设施（服务端校验，不靠前端自觉）
// ---------------------------------------------------------------------------

function arc_base_origin(): string {
  $u = site_url('');
  $p = parse_url($u);
  $scheme = $p['scheme'] ?? 'http';
  $host = $p['host'] ?? ($_SERVER['HTTP_HOST'] ?? 'localhost');
  $port = $p['port'] ?? null;
  if ($port && !in_array((int)$port, [80, 443], true)) {
    return $scheme . '://' . $host . ':' . $port;
  }
  return $scheme . '://' . $host;
}

/**
 * Normalize an avatar URL and append a cache-busting version for local uploads.
 */
function arc_avatar_url(?string $avatar): string {
  $avatar = trim((string)$avatar);
  $base = function_exists('base_path') ? (string)base_path() : '';

  if ($avatar === '') {
    $fallback = ($base !== '' ? $base : '') . '/assets/avatar.svg';
    return $fallback;
  }

  $url = $avatar;
  // allow absolute url
  if (!preg_match('#^https?://#i', $url)) {
    if ($base !== '' && !str_starts_with($url, $base)) {
      $url = rtrim($base, '/') . '/' . ltrim($url, '/');
    } elseif ($base === '' && !str_starts_with($url, '/')) {
      $url = '/' . ltrim($url, '/');
    }

    // local file cache-busting
    $parts = parse_url($url);
    $path = (string)($parts['path'] ?? $url);
    $rel = $base !== '' ? ltrim(str_replace($base, '', $path), '/') : ltrim($path, '/');
    if ($rel !== '' && !str_contains($url, 'v=')) {
      static $mtimeCache = [];
      if (!array_key_exists($rel, $mtimeCache)) {
        $fs = __DIR__ . '/../' . $rel;
        $mtimeCache[$rel] = (is_file($fs) ? (int)@filemtime($fs) : 0);
      }
      $v = (int)$mtimeCache[$rel];
      if ($v > 0) {
        $url .= (str_contains($url, '?') ? '&' : '?') . 'v=' . $v;
      }
    }
  }

  return $url;
}

/**
 * Sanitize user-provided profile theme variables (CSS vars only).
 * Output is a list of `--var: value;` lines without braces/selectors.
 */
function arc_sanitize_profile_css_vars(string $raw): string {
  $raw = str_replace(["\r\n", "\r"], "\n", $raw);
  $raw = trim($raw);
  if ($raw === '') return '';

  // hard limits
  if (strlen($raw) > 8000) $raw = substr($raw, 0, 8000);

  // deny obvious dangerous patterns (best-effort)
  $deny = ['@import', 'url(', 'expression(', '</style', '<script', '</script', '{', '}', ';{', 'behavior:', '-moz-binding'];
  foreach ($deny as $bad) {
    if (stripos($raw, $bad) !== false) {
      // Continue; we will only accept strict `--var: value;` lines anyway.
      break;
    }
  }

  // Only allow known variables to keep it safe and scoped.
  $allowed = [
    '--xf-accent' => true,
    '--xf-card-radius' => true,
    '--xf-cover-height' => true,
    '--xf-avatar-size' => true,
    '--xf-card-bg' => true,
    '--xf-card-border' => true,
    '--xf-muted' => true,
    '--xf-text' => true,
    '--xf-font' => true,
  ];

  $out = [];
  $lines = explode("\n", $raw);
  $count = 0;
  foreach ($lines as $line) {
    $line = trim($line);
    if ($line === '') continue;
    if ($count >= 40) break;

    if (!preg_match('/^(--[a-zA-Z0-9_-]{1,40})\\s*:\\s*([^;]{1,180})\\s*;\\s*$/', $line, $m)) continue;
    $name = (string)$m[1];
    $val = trim((string)$m[2]);

    if (!isset($allowed[$name])) continue;

    $low = strtolower($val);
    if (str_contains($low, 'url(') || str_contains($low, '@import') || str_contains($low, 'expression(') || str_contains($low, '{') || str_contains($low, '}') || str_contains($low, '<') || str_contains($low, '>')) {
      continue;
    }

    // value validation (simple, safe subset)
    $isColor = (bool)preg_match('/^(#[0-9a-fA-F]{3,8}|rgba?\\([0-9\\s.,%]+\\)|hsla?\\([0-9\\s.,%]+\\)|transparent|currentColor)$/', $val);
    $isLen = (bool)preg_match('/^[0-9.]+(px|rem|em|%)$/', $val);
    $isFont = (bool)preg_match('/^[a-zA-Z0-9 ,\"\\-]+$/', $val);
    if (!($isColor || $isLen || $isFont)) continue;

    $out[] = $name . ': ' . $val . ';';
    $count++;
  }

  return implode("\n", $out);
}

// ---------------------------------------------------------------------------
// Per-user UI layout (cookie only; does not affect others)
// ---------------------------------------------------------------------------

/**
 * Normalize a layout item list from user/settings JSON.
 * Accepts either string IDs or objects {id, enabled}.
 *
 * @param mixed $items
 * @param array<int, string> $allowedIds
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_layout_sanitize_items($items, array $allowedIds): array {
  if (!is_array($items)) return [];
  $out = [];
  $seen = [];
  foreach ($items as $it) {
    $id = '';
    $enabled = true;
    if (is_string($it)) {
      $id = trim($it);
      $enabled = true;
    } elseif (is_array($it)) {
      $id = (string)($it['id'] ?? '');
      $enabled = (bool)($it['enabled'] ?? true);
    } else {
      continue;
    }
    if ($id === '' || !in_array($id, $allowedIds, true)) continue;
    if (isset($seen[$id])) continue;
    $seen[$id] = true;
    $out[] = ['id' => $id, 'enabled' => $enabled];
  }
  return $out;
}

/**
 * Ensure the layout includes all allowed IDs (exactly once) by appending any missing
 * items in default order.
 *
 * @param array<int, array{id:string, enabled:bool}> $items
 * @param array<int, array{id:string, enabled:bool}> $defaultItems
 * @param array<int, string> $allowedIds
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_layout_normalize_items(array $items, array $defaultItems, array $allowedIds): array {
  $items = arc_layout_sanitize_items($items, $allowedIds);

  $defaultEnabled = [];
  $defaultOrder = [];
  foreach (arc_layout_sanitize_items($defaultItems, $allowedIds) as $it) {
    $defaultOrder[] = (string)$it['id'];
    $defaultEnabled[(string)$it['id']] = (bool)$it['enabled'];
  }

  $seen = [];
  foreach ($items as $it) $seen[(string)$it['id']] = true;

  foreach ($defaultOrder as $id) {
    if (!isset($seen[$id])) {
      $items[] = ['id' => $id, 'enabled' => (bool)($defaultEnabled[$id] ?? true)];
      $seen[$id] = true;
    }
  }

  // Any remaining allowed IDs that are not in defaults (future-proof).
  foreach ($allowedIds as $id) {
    if (!isset($seen[$id])) {
      $items[] = ['id' => $id, 'enabled' => true];
      $seen[$id] = true;
    }
  }

  return $items;
}

function arc_b64url_encode(string $raw): string {
  $b64 = base64_encode($raw);
  $b64 = str_replace(['+', '/', '='], ['-', '_', ''], $b64);
  return $b64;
}

function arc_b64url_decode(string $b64url): string {
  $b64 = str_replace(['-', '_'], ['+', '/'], $b64url);
  $pad = strlen($b64) % 4;
  if ($pad) $b64 .= str_repeat('=', 4 - $pad);
  $out = base64_decode($b64, true);
  return $out === false ? '' : $out;
}

function arc_ui_layout_cookie_name(int $userId): string {
  $salt = defined('APP_KEY') && APP_KEY !== '' ? substr(hash('sha256', APP_KEY), 0, 8) : 'site';
  return 'arc_ui_layout_' . $salt . '_' . max(0, $userId);
}

/**
 * @return array<int, array{id:string, enabled:bool}>|null
 */
function arc_get_user_ui_layout_cookie(int $userId): ?array {
  $name = arc_ui_layout_cookie_name($userId);
  $raw = (string)($_COOKIE[$name] ?? '');
  if ($raw === '') return null;

  $json = arc_b64url_decode($raw);
  if ($json === '') return null;

  $data = json_decode($json, true);
  if (!is_array($data)) return null;

  $allowed = arc_home_layout_allowed_ids();
  $out = arc_layout_sanitize_items($data, $allowed);
  return $out ? $out : null;
}

/**
 * @param array<int, array{id:string, enabled:bool}>|null $items
 */
function arc_set_user_ui_layout_cookie(int $userId, ?array $items): void {
  $name = arc_ui_layout_cookie_name($userId);
  $path = base_path();
  if ($path === '') $path = '/';
  $secure = function_exists('arc_is_https') ? arc_is_https() : (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

  if (!$items) {
    @setcookie($name, '', [
      'expires' => time() - 3600,
      'path' => $path,
      'secure' => $secure,
      'httponly' => true,
      'samesite' => 'Lax',
    ]);
    unset($_COOKIE[$name]);
    return;
  }

  $payload = json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  if (!is_string($payload)) return;

  $val = arc_b64url_encode($payload);
  // Cookie size protection: don't set if too large.
  if (strlen($val) > 3000) return;

  @setcookie($name, $val, [
    'expires' => time() + 365 * 24 * 3600,
    'path' => $path,
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
  $_COOKIE[$name] = $val;
}

/**
 * IDs of home page blocks that support per-user ordering.
 * @return array<int, string>
 */
function arc_home_layout_allowed_ids(): array {
  return ['hero', 'forum_nodes', 'latest_topics', 'today_stats', 'new_members', 'custom_html'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_home_layout_default_items(): array {
  return [
    ['id' => 'hero', 'enabled' => true],
    ['id' => 'forum_nodes', 'enabled' => true],
    ['id' => 'latest_topics', 'enabled' => true],
    ['id' => 'today_stats', 'enabled' => true],
    ['id' => 'new_members', 'enabled' => true],
    ['id' => 'custom_html', 'enabled' => false],
  ];
}

/**
 * Get a global (admin-configured) layout from settings, sanitized + normalized.
 *
 * @param array<int, array{id:string, enabled:bool}> $defaultItems
 * @param array<int, string> $allowedIds
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_get_layout_setting_items(string $settingKey, array $defaultItems, array $allowedIds): array {
  $raw = (string)get_setting($settingKey, '');
  $decoded = $raw !== '' ? json_decode($raw, true) : null;
  $items = is_array($decoded) ? arc_layout_sanitize_items($decoded, $allowedIds) : [];
  if (!$items) $items = arc_layout_sanitize_items($defaultItems, $allowedIds);
  return arc_layout_normalize_items($items, $defaultItems, $allowedIds);
}

/**
 * Forum page layout (admin-configurable).
 * @return array<int, string>
 */
function arc_forum_layout_allowed_ids(): array {
  return ['hero', 'forum_nodes', 'forum_latest'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_forum_layout_default_items(): array {
  return [
    ['id' => 'hero', 'enabled' => true],
    ['id' => 'forum_nodes', 'enabled' => true],
    ['id' => 'forum_latest', 'enabled' => true],
  ];
}

/**
 * What's new page layout (admin-configurable).
 * @return array<int, string>
 */
function arc_whats_new_layout_allowed_ids(): array {
  return ['hero', 'whats_new_list'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_whats_new_layout_default_items(): array {
  return [
    ['id' => 'hero', 'enabled' => true],
    ['id' => 'whats_new_list', 'enabled' => true],
  ];
}

/**
 * Members page layout (admin-configurable).
 * @return array<int, string>
 */
function arc_members_layout_allowed_ids(): array {
  return ['hero', 'members_list'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_members_layout_default_items(): array {
  return [
    ['id' => 'hero', 'enabled' => true],
    ['id' => 'members_list', 'enabled' => true],
  ];
}

/**
 * Profile sidebar layout (per-user, DB-stored).
 * @return array<int, string>
 */
function arc_profile_layout_allowed_ids(): array {
  return ['about', 'latest', 'trophies', 'reactions', 'visitors'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_profile_layout_default_items(): array {
  return [
    ['id' => 'about', 'enabled' => true],
    ['id' => 'latest', 'enabled' => true],
    ['id' => 'trophies', 'enabled' => true],
    ['id' => 'reactions', 'enabled' => true],
    ['id' => 'visitors', 'enabled' => true],
  ];
}

/**
 * Admin dashboard layout (admin-configurable).
 * @return array<int, string>
 */
function arc_admin_dashboard_layout_allowed_ids(): array {
  return ['kpis', 'latest_posts', 'quick_links'];
}

/**
 * @return array<int, array{id:string, enabled:bool}>
 */
function arc_admin_dashboard_layout_default_items(): array {
  return [
    ['id' => 'kpis', 'enabled' => true],
    ['id' => 'latest_posts', 'enabled' => true],
    ['id' => 'quick_links', 'enabled' => true],
  ];
}

function csrf_token(): string {
  if (empty($_SESSION['_csrf']) || !is_string($_SESSION['_csrf']) || strlen((string)$_SESSION['_csrf']) < 32) {
    $_SESSION['_csrf'] = random_token(32);
  }
  return (string)$_SESSION['_csrf'];
}

function csrf_field(): string {
  return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(?string $token): bool {
  if (!is_string($token) || $token === '') return false;
  $expected = $_SESSION['_csrf'] ?? '';
  if (!is_string($expected) || $expected === '') return false;
  return hash_equals($expected, $token);
}

/**
 * CSRF + 同源校验：任何会写数据的 POST 都应该调用这个。
 * 说明：SameSite=Lax 只能挡一部分，CSRF token 才是正经做法。
 */
function require_csrf(): void {
  // Origin/Referer 同源校验（有就严格检查；没有就只靠 token）
  $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
  $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
  $base = arc_base_origin();

  // Tolerate http/https mismatches and reverse proxies by validating same-host
  // instead of strict origin string prefix matching.
  $baseHost = (string)(parse_url($base, PHP_URL_HOST) ?? '');
  $reqHost = (string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ($_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? '')));
  $reqHost = preg_replace('/:\\d+$/', '', $reqHost) ?? $reqHost;

  $allowedHosts = [];
  foreach ([$baseHost, $reqHost] as $h) {
    $h = strtolower(trim((string)$h));
    if ($h !== '') $allowedHosts[$h] = true;
  }

  $sameHost = function(string $url) use ($allowedHosts): bool {
    $h = (string)(parse_url($url, PHP_URL_HOST) ?? '');
    if ($h === '') return true; // can't parse => don't block; token still required
    $h = strtolower(trim((string)$h));
    return isset($allowedHosts[$h]);
  };

  if ($origin !== '') {
    if (!$sameHost($origin)) {
      http_response_code(403);
      exit('Forbidden');
    }
  } elseif ($referer !== '') {
    if (!$sameHost($referer)) {
      http_response_code(403);
      exit('Forbidden');
    }
  }

  $token = (string)($_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
  if (!csrf_verify($token)) {
    http_response_code(403);
    exit('Forbidden');
  }
}

function require_post(): void {
  if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
  }
}

function client_ip(): string {
  // 不信任 X-Forwarded-For（太容易伪造），除非你有可信反代链路。
  return (string)($_SERVER['REMOTE_ADDR'] ?? '');
}

/**
 * 简单限流（基于文件）：挡住脚本小子乱刷。
 */
function arc_rate_limit(string $bucket, int $limit, int $windowSeconds = 60): void {
  $bucket = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $bucket) ?? 'bucket';
  $ip = client_ip();
  $key = hash('sha256', $bucket . '|' . $ip);
  $dir = __DIR__ . '/../storage/ratelimit';
  if (!is_dir($dir)) @mkdir($dir, 0700, true);
  $file = $dir . '/' . $key . '.json';
  $now = time();

  $data = ['reset' => $now + $windowSeconds, 'count' => 0];
  if (is_file($file)) {
    $raw = @file_get_contents($file);
    $j = $raw ? json_decode($raw, true) : null;
    if (is_array($j) && isset($j['reset'], $j['count'])) {
      $data['reset'] = (int)$j['reset'];
      $data['count'] = (int)$j['count'];
    }
  }

  if ($data['reset'] <= $now) {
    $data = ['reset' => $now + $windowSeconds, 'count' => 0];
  }
  $data['count']++;

  @file_put_contents($file, json_encode($data), LOCK_EX);

  if ($data['count'] > $limit) {
    http_response_code(429);
    header('Retry-After: ' . max(1, $data['reset'] - $now));
    exit('Too Many Requests');
  }
}

/**
 * 基础安全响应头（别让页面被 iframe 钓鱼）。
 */
function arc_send_security_headers(): void {
  if (headers_sent()) return;
  header('X-Frame-Options: DENY');
  header('X-Content-Type-Options: nosniff');
  header('Referrer-Policy: strict-origin-when-cross-origin');
  header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
}
