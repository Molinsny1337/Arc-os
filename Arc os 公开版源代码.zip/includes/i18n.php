<?php
declare(strict_types=1);

if (!function_exists('str_contains')) {
  function str_contains(string $haystack, string $needle): bool {
    return $needle === '' || strpos($haystack, $needle) !== false;
  }
}

/**
 * Minimal i18n dictionary with safe fallbacks.
 * Missing keys fall back to key text to avoid hard failures.
 */
function supported_langs(): array {
  return [
    'zh-CN' => ['name' => '????', 'flag' => 'CN'],
    'zh-HK' => ['name' => '????', 'flag' => 'HK'],
    'en' => ['name' => 'English', 'flag' => 'EN'],
    'ru' => ['name' => '???????', 'flag' => 'RU'],
  ];
}


function normalize_lang(string $lang): string {
  $lang = trim($lang);
  $map = [
    'zh' => 'zh-CN',
    'zh-cn' => 'zh-CN',
    'zh-hans' => 'zh-CN',
    'zh-hk' => 'zh-HK',
    'zh-tw' => 'zh-HK',
    'zh-hant' => 'zh-HK',
    'en-us' => 'en',
    'en-gb' => 'en',
    'ru-ru' => 'ru',
  ];
  $l = strtolower($lang);
  if (isset($map[$l])) return $map[$l];
  $langs = supported_langs();
  return isset($langs[$lang]) ? $lang : 'en';
}

function detect_lang(): string {
  if (isset($_GET['lang'])) {
    $lang = normalize_lang((string)$_GET['lang']);
    $_SESSION['lang'] = $lang;
    @setcookie('lang', $lang, time() + 86400 * 365, '/');
    return $lang;
  }

  if (!empty($_SESSION['lang'])) return normalize_lang((string)$_SESSION['lang']);
  if (!empty($_COOKIE['lang'])) return normalize_lang((string)$_COOKIE['lang']);

  if (!defined('ARC_PREINSTALL') || ARC_PREINSTALL !== true) {
    if (function_exists('get_setting')) {
      $site = get_setting('site_lang', 'zh-CN');
      if ($site) return normalize_lang((string)$site);
    }
  }

  $al = (string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '');
  if ($al) {
    $first = explode(',', $al)[0] ?? '';
    if ($first) return normalize_lang($first);
  }
  return 'en';
}

function humanize_key(string $key): string {
  $key = str_replace(['_', '-'], ' ', $key);
  $key = preg_replace('/\s+/', ' ', $key) ?? $key;
  $key = trim($key);
  if ($key === '') return '';
  return strtoupper($key[0]) . substr($key, 1);
}

function lang(): string {
  static $lang = null;
  if ($lang !== null) return $lang;
  $lang = detect_lang();
  return $lang;
}

function t(string $key): string {
  static $dict = null;
  if ($dict === null) {
    $dataFile = __DIR__ . '/i18n_data.php';
    $dict = is_file($dataFile) ? require $dataFile : [];
    if (!is_array($dict)) $dict = [];
    if (!isset($dict['en']) || !is_array($dict['en'])) $dict['en'] = [];
    if (!isset($dict['zh-CN']) || !is_array($dict['zh-CN'])) $dict['zh-CN'] = [];
    if (!isset($dict['zh-HK'])) $dict['zh-HK'] = $dict['zh-CN'];
    if (!isset($dict['ru'])) $dict['ru'] = $dict['en'];
  }

  $l = lang();
  if (isset($dict[$l][$key])) return (string)$dict[$l][$key];
  if (isset($dict['en'][$key])) return (string)$dict['en'][$key];
  if (isset($dict['zh-CN'][$key])) return (string)$dict['zh-CN'][$key];
  return humanize_key($key);
}

