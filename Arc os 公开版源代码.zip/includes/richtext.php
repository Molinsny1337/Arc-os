<?php
declare(strict_types=1);

/**
 * Arc OS Rich Text (very small, allowlist-based HTML sanitizer)
 * Goal: allow links + images + basic formatting, block XSS.
 */

function arc_sanitize_richtext(string $html): string {
  $html = trim($html);
  if ($html === '') return '';

  // quick strip null bytes
  $html = str_replace("\0", '', $html);

  $allowed = [
    'a'=>true,'b'=>true,'strong'=>true,'i'=>true,'em'=>true,'u'=>true,'s'=>true,
    'p'=>true,'br'=>true,'div'=>true,'span'=>true,
    'ul'=>true,'ol'=>true,'li'=>true,
    'blockquote'=>true,'code'=>true,'pre'=>true,
    'h1'=>true,'h2'=>true,'h3'=>true,
    'img'=>true,
  ];
  $allowedAttr = [
    'a' => ['href'=>true,'title'=>true,'target'=>true,'rel'=>true],
    'img' => ['src'=>true,'alt'=>true,'title'=>true,'width'=>true,'height'=>true],
    'div' => [],
    'span'=> [],
    'p'=>[],
    'pre'=>[],
    'code'=>[],
    'blockquote'=>[],
    'ul'=>[],
    'ol'=>[],
    'li'=>[],
    'h1'=>[],
    'h2'=>[],
    'h3'=>[],
    'b'=>[],
    'strong'=>[],
    'i'=>[],
    'em'=>[],
    'u'=>[],
    's'=>[],
    'br'=>[],
  ];

  $dom = new DOMDocument('1.0', 'UTF-8');
  libxml_use_internal_errors(true);
  // Wrap in a container so we can reliably extract innerHTML later.
  $dom->loadHTML('<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><div id="__wrap__">'.$html.'</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
  libxml_clear_errors();

  $wrap = $dom->getElementById('__wrap__');
  if (!$wrap) return '';

  $removeNode = function(DOMNode $node) use (&$removeNode) {
    if ($node->parentNode) $node->parentNode->removeChild($node);
  };

  $isSafeUrl = function(string $url): bool {
    $url = trim($url);
    if ($url === '') return false;
    // disallow javascript:, data: (except images? keep it simple: disallow)
    if (preg_match('~^\s*(javascript|data):~i', $url)) return false;
    // allow http(s) absolute, or site-relative, or relative
    if (preg_match('~^https?://~i', $url)) return true;
    if (str_starts_with($url, '//')) return false; // protocol-relative: meh
    if (str_starts_with($url, '/')) return true;
    return true;
  };

  // Walk all elements
  $nodes = [];
  $walker = new RecursiveIteratorIterator(
    new RecursiveDOMIterator($wrap),
    RecursiveIteratorIterator::SELF_FIRST
  );
  foreach ($walker as $node) {
    if ($node instanceof DOMElement) $nodes[] = $node;
  }

  foreach ($nodes as $el) {
    $tag = strtolower($el->tagName);

    // Drop dangerous tags entirely
    if (in_array($tag, ['script','style','iframe','object','embed','link','meta'], true)) {
      $removeNode($el);
      continue;
    }

    if (!isset($allowed[$tag])) {
      // Replace unknown element with its text content
      $text = $dom->createTextNode($el->textContent ?? '');
      if ($el->parentNode) $el->parentNode->replaceChild($text, $el);
      continue;
    }

    // Clean attributes
    $keep = $allowedAttr[$tag] ?? [];
    if ($el->hasAttributes()) {
      $toRemove = [];
      foreach ($el->attributes as $attr) {
        $name = strtolower($attr->name);
        if (!isset($keep[$name])) $toRemove[] = $attr->name;
      }
      foreach ($toRemove as $n) $el->removeAttribute($n);
    }

    if ($tag === 'a') {
      $href = (string)$el->getAttribute('href');
      if (!$isSafeUrl($href)) {
        // turn into span
        $span = $dom->createElement('span');
        $span->nodeValue = $el->textContent ?? '';
        if ($el->parentNode) $el->parentNode->replaceChild($span, $el);
        continue;
      }
      // Ensure rel/target
      $el->setAttribute('target', '_blank');
      $el->setAttribute('rel', 'nofollow ugc noopener');
    }

    if ($tag === 'img') {
      $src = (string)$el->getAttribute('src');
      if (!$isSafeUrl($src)) {
        $removeNode($el);
        continue;
      }
      // basic: prevent huge inline sizes
      $el->removeAttribute('style');
      $el->setAttribute('loading', 'lazy');
    }
  }

  // Extract innerHTML of wrap
  $out = '';
  foreach ($wrap->childNodes as $child) {
    $out .= $dom->saveHTML($child);
  }

  // normalize: trim and keep length sane
  $out = trim($out);
  if (strlen($out) > 200000) $out = substr($out, 0, 200000);
  return $out;
}

function arc_render_richtext(string $html): string {
  // render-time sanitize as a second line of defense
  return arc_sanitize_richtext($html);
}

/**
 * Recursive DOM iterator helper.
 */
class RecursiveDOMIterator implements RecursiveIterator {
  private DOMNode $node;
  private int $position = 0;

  public function __construct(DOMNode $node) {
    $this->node = $node;
  }

  public function current(): mixed {
    return $this->node->childNodes->item($this->position);
  }

  public function key(): mixed {
    return $this->position;
  }

  public function next(): void {
    $this->position++;
  }

  public function rewind(): void {
    $this->position = 0;
  }

  public function valid(): bool {
    return $this->position < $this->node->childNodes->length;
  }

  public function hasChildren(): bool {
    $cur = $this->current();
    return $cur instanceof DOMNode && $cur->hasChildNodes();
  }

  public function getChildren(): ?\RecursiveIterator {
    return new self($this->current());
  }
}
