<?php
declare(strict_types=1);

if (!function_exists('client_ip')) {
function client_ip(): string {
  // basic real-ip support behind reverse proxies
  $keys = ['HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'];
  foreach ($keys as $k) {
    if (!empty($_SERVER[$k])) {
      $v = (string)$_SERVER[$k];
      if ($k === 'HTTP_X_FORWARDED_FOR') {
        $v = trim(explode(',', $v)[0]);
      }
      return $v;
    }
  }
  return '';
}
}

function user_agent(): string {
  return (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
}

function arc_log(string $action, ?string $object_type = null, ?int $object_id = null, array $meta = []): void {
  if (!function_exists('db')) return;
  try {
    $pdo = db();
    $pfx = table_prefix();
    $tbl = $pfx . 'logs';
    // if table doesn't exist yet, just skip
    $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($tbl));
    if (!$stmt || !$stmt->fetch()) return;

    $u = function_exists('current_user') ? current_user() : null;
    $uid = $u ? (int)$u['id'] : null;
    $uname = $u ? (string)$u['username'] : null;

    $ip = client_ip();
    $ua = user_agent();
    $metaJson = $meta ? json_encode($meta, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null;

    $sql = "INSERT INTO {$tbl} (user_id, username, action, object_type, object_id, ip, user_agent, meta, created_at)
            VALUES (:user_id, :username, :action, :object_type, :object_id, :ip, :ua, :meta, NOW())";
    $st = $pdo->prepare($sql);
    $st->execute([
      ':user_id' => $uid,
      ':username' => $uname,
      ':action' => $action,
      ':object_type' => $object_type,
      ':object_id' => $object_id,
      ':ip' => $ip,
      ':ua' => $ua,
      ':meta' => $metaJson,
    ]);
  } catch (Throwable $e) {
    // never block page render because of logging
  }
}

/**
 * Localize an action name for display in admin logs.
 */
function arc_log_action_label(string $action): string {
  $action = trim($action);
  if ($action === '') return '';
  if (function_exists('t')) {
    $k = 'log_' . $action;
    $v = t($k);
    if ($v !== $k) return $v;
  }
  return $action;
}
