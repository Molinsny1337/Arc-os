<?php
declare(strict_types=1);

function install_schema(PDO $pdo, string $pfx): void {
  $prefix = $pfx;

  // 兼容最严格 MySQL：DATETIME 不设默认值，插入/更新时用 NOW()
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL,
    display_name VARCHAR(64) NULL,
    email VARCHAR(191) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user','admin','superadmin') NOT NULL DEFAULT 'user',
    is_verified TINYINT(1) NOT NULL DEFAULT 0,
    verify_token VARCHAR(64) NULL,
    can_post TINYINT(1) NOT NULL DEFAULT 0,
    avatar VARCHAR(255) NULL,
    notify_likes TINYINT(1) NOT NULL DEFAULT 0,
    notify_profile_comments TINYINT(1) NOT NULL DEFAULT 0,
    is_banned TINYINT(1) NOT NULL DEFAULT 0,
    banned_reason VARCHAR(255) NULL,
    banned_by INT UNSIGNED NULL,
    banned_at DATETIME NULL,
    banned_until DATETIME NULL,
    cover_url VARCHAR(255) NULL,
    cover_pos_x TINYINT UNSIGNED NULL,
    cover_pos_y TINYINT UNSIGNED NULL,
    user_title VARCHAR(80) NULL,
    about_text TEXT NULL,
    location VARCHAR(120) NULL,
    website VARCHAR(190) NULL,
    signature TEXT NULL,
    allow_profile_posts TINYINT(1) NOT NULL DEFAULT 1,
    show_followers TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    last_active DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_username (username),
    UNIQUE KEY uniq_email (email)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}posts (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    author_id INT UNSIGNED NULL,
    type VARCHAR(16) NOT NULL DEFAULT 'forum',
        forum_id INT UNSIGNED NULL,
    prefix_id INT UNSIGNED NULL,
    is_sticky TINYINT(1) NOT NULL DEFAULT 0,
    is_locked TINYINT(1) NOT NULL DEFAULT 0,
    is_featured TINYINT(1) NOT NULL DEFAULT 0,
    reply_count INT UNSIGNED NOT NULL DEFAULT 0,
    view_count INT UNSIGNED NOT NULL DEFAULT 0,
    last_post_at DATETIME NULL,
    last_post_user_id INT UNSIGNED NULL,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(191) NOT NULL,
    excerpt TEXT NULL,
    content MEDIUMTEXT NOT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    deleted_by INT UNSIGNED NULL,
    deleted_at DATETIME NULL,
    delete_reason VARCHAR(255) NULL,
    status ENUM('draft','published') NOT NULL DEFAULT 'draft',
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    review_state VARCHAR(16) NOT NULL DEFAULT 'pending',
    review_note TEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    last_active DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_slug_type (slug, type),
    KEY idx_status_created (status, created_at),
    KEY idx_type_created (type, created_at),
    KEY idx_author (author_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}links (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    label VARCHAR(100) NOT NULL,
    url VARCHAR(255) NOT NULL,
    target VARCHAR(20) NOT NULL DEFAULT '_self',
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    last_active DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_sort (sort_order)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}profile_comments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  profile_user_id INT UNSIGNED NOT NULL,
  author_id INT UNSIGNED NOT NULL,
  content TEXT NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_profile_created (profile_user_id, created_at),
  KEY idx_author_created (author_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // 主题/文章评论（论坛帖也用同一套）
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}post_comments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    post_id INT UNSIGNED NOT NULL,
    author_id INT UNSIGNED NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'visible',
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    deleted_by INT UNSIGNED NULL,
    deleted_at DATETIME NULL,
    delete_reason VARCHAR(255) NULL,
    edit_count INT UNSIGNED NOT NULL DEFAULT 0,
    last_edit_at DATETIME NULL,
    last_edit_by INT UNSIGNED NULL,
    ip_hash CHAR(64) NULL,
    position INT UNSIGNED NULL,
    PRIMARY KEY (id),
    KEY idx_post_created (post_id, created_at),
    KEY idx_author_created (author_id, created_at),
    KEY idx_post_position (post_id, position)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}post_likes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_post_user (post_id, user_id),
  KEY idx_post_created (post_id, created_at),
  KEY idx_user_created (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");


  
  // 用户审核请求（改名/改头像）
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}review_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    req_type ENUM('username','avatar') NOT NULL,
    payload LONGTEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    review_note TEXT NULL,
    reviewed_by INT UNSIGNED NULL,
    reviewed_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_status_created (status, created_at),
    KEY idx_user_type (user_id, req_type, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NULL,
    username VARCHAR(64) NULL,
    action VARCHAR(64) NOT NULL,
    object_type VARCHAR(32) NULL,
    object_id INT UNSIGNED NULL,
    ip VARCHAR(64) NULL,
    user_agent VARCHAR(255) NULL,
    meta LONGTEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user_time (user_id, created_at),
    KEY idx_action_time (action, created_at),
    KEY idx_obj (object_type, object_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}settings (
    k VARCHAR(64) NOT NULL,
    v TEXT NULL,
    PRIMARY KEY (k)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  // [ADDON] user follow system table (safe inside installer schema)
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}user_follows (
    follower_id INT NOT NULL,
    followee_id INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, followee_id),
    KEY idx_followee (followee_id),
    KEY idx_follower (follower_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // [ADDON] profile visitors table (safe inside installer schema)
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}profile_visits (
    visited_user_id INT NOT NULL,
    visitor_id INT NOT NULL,
    visit_date DATE NOT NULL,
    visited_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (visited_user_id, visitor_id, visit_date),
    KEY idx_visited_at (visited_at),
    KEY idx_visitor (visitor_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");




  // [HOTFIX] Install extra tables added after initial schema.
  arc_install_schema_extras($pdo, $pfx);
}



  // Forums
  

// [HOTFIX] Prevent schema.php from executing DDL before installer has a PDO connection.
function arc_install_schema_extras(PDO $pdo, string $pfx): void {
  $prefix = $pfx;

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}forums (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    parent_id INT UNSIGNED NULL,
    title VARCHAR(191) NOT NULL,
    slug VARCHAR(191) NOT NULL,
    description TEXT NULL,
    display_order INT NOT NULL DEFAULT 0,
    thread_count INT UNSIGNED NOT NULL DEFAULT 0,
    message_count INT UNSIGNED NOT NULL DEFAULT 0,
    last_post_at DATETIME NULL,
    last_post_id INT UNSIGNED NULL,
    last_post_user_id INT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_slug (slug),
    KEY idx_parent_order (parent_id, display_order),
    KEY idx_lastpost (last_post_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Alerts
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}alerts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    from_user_id INT UNSIGNED NULL,
    type VARCHAR(32) NOT NULL,
    object_type VARCHAR(32) NOT NULL,
    object_id BIGINT UNSIGNED NOT NULL,
    data TEXT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user_read_id (user_id, is_read, id),
    KEY idx_user_id (user_id, id),
    KEY idx_created_at (created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");


// Conversations (private messages)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}conversations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NULL,
  creator_id INT UNSIGNED NOT NULL,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  last_message_at DATETIME NULL,
  last_message_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_creator (creator_id, id),
  KEY idx_last (last_message_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}conversation_participants (
  conversation_id BIGINT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  last_read_message_id BIGINT UNSIGNED NULL,
  is_muted TINYINT(1) NOT NULL DEFAULT 0,
  is_left TINYINT(1) NOT NULL DEFAULT 0,
  joined_at DATETIME NOT NULL,
  PRIMARY KEY (conversation_id, user_id),
  KEY idx_user (user_id, conversation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}conversation_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  conversation_id BIGINT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  message MEDIUMTEXT NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_conv_id (conversation_id, id),
  KEY idx_user (user_id, id),
  FULLTEXT KEY ft_message (message)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Reactions (emoji-like)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}post_reactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  reaction VARCHAR(16) NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_post_user_reaction (post_id, user_id, reaction),
  KEY idx_post (post_id, id),
  KEY idx_user (user_id, id),
  KEY idx_reaction (reaction, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Attachments
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}post_attachments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  mime VARCHAR(128) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  is_image TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_post (post_id, id),
  KEY idx_user (user_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Trophies / badges (lightweight)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}trophies (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NOT NULL,
  description TEXT NULL,
  points INT NOT NULL DEFAULT 0,
  icon VARCHAR(255) NULL,
  criteria_json TEXT NULL,
  display_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_points (points, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}user_trophies (
  user_id INT UNSIGNED NOT NULL,
  trophy_id INT UNSIGNED NOT NULL,
  awarded_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, trophy_id),
  KEY idx_trophy (trophy_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Profile posts (XF-like wall)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}profile_posts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  profile_user_id INT UNSIGNED NOT NULL,
  author_id INT UNSIGNED NOT NULL,
  message MEDIUMTEXT NOT NULL,
  comment_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_profile (profile_user_id, id),
  KEY idx_author (author_id, id),
  FULLTEXT KEY ft_message (message)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}profile_post_comments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  profile_post_id BIGINT UNSIGNED NOT NULL,
  author_id INT UNSIGNED NOT NULL,
  message MEDIUMTEXT NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_post (profile_post_id, id),
  KEY idx_author (author_id, id),
  FULLTEXT KEY ft_message (message)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Identity groups (for paid entitlements, etc.)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}groups (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(64) NOT NULL,
  name VARCHAR(191) NOT NULL,
  is_paid TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_slug (slug),
  KEY idx_paid (is_paid, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}user_groups (
  user_id INT UNSIGNED NOT NULL,
  group_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, group_id),
  KEY idx_group (group_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

// Tickets (feedback / support)
$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}tickets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  subject VARCHAR(191) NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  last_message_at DATETIME NULL,
  last_message_by ENUM('user','admin') NULL,
  closed_at DATETIME NULL,
  closed_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_user_updated (user_id, updated_at),
  KEY idx_status_updated (status, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

$pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}ticket_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id BIGINT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  is_staff TINYINT(1) NOT NULL DEFAULT 0,
  message MEDIUMTEXT NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ticket_id (ticket_id, id),
  KEY idx_user_id (user_id, id),
  FULLTEXT KEY ft_message (message)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Tags / bookmarks / watches
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_tags (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tag VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_tag (tag)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_content_tags (
    tag_id BIGINT UNSIGNED NOT NULL,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (tag_id, content_type, content_id),
    KEY idx_content (content_type, content_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_bookmarks (
    user_id BIGINT UNSIGNED NOT NULL,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, content_type, content_id),
    KEY idx_content (content_type, content_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_thread_watches (
    user_id BIGINT UNSIGNED NOT NULL,
    thread_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, thread_id),
    KEY idx_thread (thread_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_forum_watches (
    user_id BIGINT UNSIGNED NOT NULL,
    forum_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, forum_id),
    KEY idx_forum (forum_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Prefixes
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_thread_prefixes (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    css_class VARCHAR(64) NULL,
    display_order INT NOT NULL DEFAULT 0,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_order (display_order)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Read state
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_thread_reads (
    user_id BIGINT UNSIGNED NOT NULL,
    thread_id BIGINT UNSIGNED NOT NULL,
    last_read_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, thread_id),
    KEY idx_thread (thread_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_forum_reads (
    user_id BIGINT UNSIGNED NOT NULL,
    forum_id BIGINT UNSIGNED NOT NULL,
    last_read_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, forum_id),
    KEY idx_forum (forum_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Editor drafts + attachments
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_drafts (
    draft_key VARCHAR(190) NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    bbcode MEDIUMTEXT NULL,
    attachments_json TEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (draft_key),
    KEY idx_user (user_id, updated_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_attachment_data (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_hash VARCHAR(64) NULL,
    mime VARCHAR(128) NOT NULL,
    size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    width INT UNSIGNED NULL,
    height INT UNSIGNED NULL,
    thumb_path VARCHAR(255) NULL,
    thumb_width INT UNSIGNED NULL,
    thumb_height INT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user (user_id, id),
    KEY idx_hash (file_hash)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_attachments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    data_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    temp_key VARCHAR(190) NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_data (data_id),
    KEY idx_content (content_type, content_id),
    KEY idx_temp (temp_key)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_mention_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    from_user_id INT UNSIGNED NOT NULL,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user (user_id, id),
    KEY idx_content (content_type, content_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Reports (moderation)
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_reports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    content_type VARCHAR(32) NOT NULL,
    content_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    reason VARCHAR(255) NOT NULL,
    details TEXT NULL,
    status ENUM('open','closed') NOT NULL DEFAULT 'open',
    handled_by INT UNSIGNED NULL,
    handled_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_status (status, id),
    KEY idx_content (content_type, content_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Emoji packs
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_emojis (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    shortcode VARCHAR(64) NOT NULL,
    unicode VARCHAR(64) NULL,
    image_path VARCHAR(255) NULL,
    category VARCHAR(64) NULL,
    width INT UNSIGNED NULL,
    height INT UNSIGNED NULL,
    is_sticker TINYINT(1) NOT NULL DEFAULT 0,
    display_order INT NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_shortcode (shortcode),
    KEY idx_category (category, display_order)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_emoji_packs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    slug VARCHAR(64) NOT NULL,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    display_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_slug (slug),
    KEY idx_order (display_order)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_emoji_pack_items (
    pack_id BIGINT UNSIGNED NOT NULL,
    emoji_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (pack_id, emoji_id),
    KEY idx_emoji (emoji_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Mail queue
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_mail_queue (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    to_email VARCHAR(191) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    html_body MEDIUMTEXT NULL,
    text_body MEDIUMTEXT NULL,
    status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    last_error TEXT NULL,
    created_at DATETIME NOT NULL,
    sent_at DATETIME NULL,
    last_attempt_at DATETIME NULL,
    next_attempt_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_status_created (status, created_at),
    KEY idx_attempts (attempts, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_mail_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    queue_id BIGINT UNSIGNED NULL,
    to_email VARCHAR(191) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL,
    error TEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_status_created (status, created_at),
    KEY idx_queue (queue_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Analytics events
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_analytics_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    created_at DATETIME NOT NULL,
    path VARCHAR(255) NOT NULL,
    route_type VARCHAR(32) NOT NULL,
    user_id INT UNSIGNED NULL,
    session_id VARCHAR(128) NOT NULL,
    ip_hash CHAR(64) NOT NULL,
    ua_hash CHAR(64) NOT NULL,
    referrer VARCHAR(255) NULL,
    is_bot TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_created (created_at),
    KEY idx_route (route_type, created_at),
    KEY idx_session (session_id, created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // User profile layout prefs
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}user_profile_prefs (
    user_id INT UNSIGNED NOT NULL,
    layout_json TEXT NULL,
    css_vars TEXT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Discord OAuth bindings
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_user_discord (
    user_id INT UNSIGNED NOT NULL,
    discord_user_id VARCHAR(32) NOT NULL,
    discord_username VARCHAR(100) NOT NULL,
    discord_discriminator VARCHAR(10) NULL,
    discord_avatar VARCHAR(100) NULL,
    discord_email VARCHAR(191) NULL,
    access_token_enc TEXT NOT NULL,
    refresh_token_enc TEXT NOT NULL,
    token_expires_at DATETIME NULL,
    connected_at DATETIME NOT NULL,
    last_sync_at DATETIME NULL,
    PRIMARY KEY (user_id),
    UNIQUE KEY uniq_discord_user (discord_user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_webhook_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    event VARCHAR(64) NOT NULL,
    status VARCHAR(20) NOT NULL,
    error TEXT NULL,
    response_snippet TEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_event_created (event, created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_discord_role_map (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_id VARCHAR(32) NOT NULL,
    group_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_role_group (role_id, group_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_discord_sync_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    status VARCHAR(20) NOT NULL,
    error TEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user_created (user_id, created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  // Profile data
  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_user_profile (
    user_id INT UNSIGNED NOT NULL,
    location VARCHAR(120) NULL,
    website VARCHAR(190) NULL,
    about_me_bbcode MEDIUMTEXT NULL,
    signature_bbcode MEDIUMTEXT NULL,
    cover_path VARCHAR(255) NULL,
    privacy_json TEXT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_profile_fields (
    field_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    field_type VARCHAR(20) NOT NULL,
    field_choices_json TEXT NULL,
    display_order INT NOT NULL DEFAULT 0,
    editable TINYINT(1) NOT NULL DEFAULT 1,
    show_on_profile TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (field_id),
    KEY idx_display (display_order)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_user_field_values (
    user_id INT UNSIGNED NOT NULL,
    field_id INT UNSIGNED NOT NULL,
    value TEXT NULL,
    PRIMARY KEY (user_id, field_id),
    KEY idx_field (field_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_profile_posts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    author_user_id INT UNSIGNED NOT NULL,
    message_bbcode MEDIUMTEXT NOT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_user (user_id, id),
    KEY idx_author (author_user_id, id),
    FULLTEXT KEY ft_message (message_bbcode)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_profile_post_comments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    profile_post_id BIGINT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    message_bbcode MEDIUMTEXT NOT NULL,
    is_deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_post (profile_post_id, id),
    KEY idx_user (user_id, id),
    FULLTEXT KEY ft_message (message_bbcode)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_user_follow (
    follower_id INT UNSIGNED NOT NULL,
    followed_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (follower_id, followed_id),
    KEY idx_followed (followed_id, follower_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_user_ignore (
    user_id INT UNSIGNED NOT NULL,
    ignored_user_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, ignored_user_id),
    KEY idx_ignored (ignored_user_id, user_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

  $pdo->exec("CREATE TABLE IF NOT EXISTS {$prefix}xf_profile_visitors (
    user_id INT UNSIGNED NOT NULL,
    visitor_user_id INT UNSIGNED NOT NULL,
    visited_at DATETIME NOT NULL,
    PRIMARY KEY (user_id, visitor_user_id),
    KEY idx_visited (visited_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

}
