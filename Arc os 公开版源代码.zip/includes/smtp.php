<?php
declare(strict_types=1);

/**
 * Minimal SMTP sender using fsockopen + AUTH LOGIN.
 * Supports STARTTLS (tls) or none.
 * Good enough for verification emails.
 */

function smtp_send(string $host, int $port, string $user, string $pass, string $fromEmail, string $fromName, string $toEmail, string $subject, string $body, string $enc='tls'): bool {
  return smtp_send_message($host, $port, $user, $pass, $fromEmail, $fromName, $toEmail, $subject, $body, $body, '', $enc);
}

/**
 * Send HTML + text via SMTP using AUTH LOGIN.
 */
function smtp_send_message(
  string $host,
  int $port,
  string $user,
  string $pass,
  string $fromEmail,
  string $fromName,
  string $toEmail,
  string $subject,
  string $htmlBody,
  string $textBody,
  string $replyTo = '',
  string $enc = 'tls'
): bool {
  $timeout = 15;
  $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
  if (!$fp) return false;
  stream_set_timeout($fp, $timeout);

  $read = function() use ($fp): string {
    $data = '';
    while (!feof($fp)) {
      $line = fgets($fp, 515);
      if ($line === false) break;
      $data .= $line;
      if (preg_match('/^\d{3}\s/', $line)) break;
    }
    return $data;
  };
  $write = function(string $cmd) use ($fp): void { fwrite($fp, $cmd . "\r\n"); };
  $codeOk = function(string $resp, array $ok): bool {
    $code = (int)substr(trim($resp), 0, 3);
    return in_array($code, $ok, true);
  };

  if (!$codeOk($read(), [220])) { fclose($fp); return false; }
  $write("EHLO localhost");
  if (!$codeOk($read(), [250])) { fclose($fp); return false; }

  if ($enc === 'tls') {
    $write("STARTTLS");
    if (!$codeOk($read(), [220])) { fclose($fp); return false; }
    if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { fclose($fp); return false; }
    $write("EHLO localhost");
    if (!$codeOk($read(), [250])) { fclose($fp); return false; }
  }

  if ($user !== '') {
    $write("AUTH LOGIN");
    if (!$codeOk($read(), [334])) { fclose($fp); return false; }
    $write(base64_encode($user));
    if (!$codeOk($read(), [334])) { fclose($fp); return false; }
    $write(base64_encode($pass));
    if (!$codeOk($read(), [235])) { fclose($fp); return false; }
  }

  $write("MAIL FROM:<{$fromEmail}>");
  if (!$codeOk($read(), [250])) { fclose($fp); return false; }

  $write("RCPT TO:<{$toEmail}>");
  if (!$codeOk($read(), [250, 251])) { fclose($fp); return false; }

  $write("DATA");
  if (!$codeOk($read(), [354])) { fclose($fp); return false; }

  $boundary = 'arc-smtp-' . bin2hex(random_bytes(6));
  $headers = [];
  $headers[] = "From: " . ($fromName !== '' ? sprintf('\"%s\" <%s>', addslashes($fromName), $fromEmail) : $fromEmail);
  $headers[] = "To: <{$toEmail}>";
  $headers[] = "Subject: " . str_replace(["\r", "\n"], '', $subject);
  $headers[] = "MIME-Version: 1.0";
  $headers[] = "Content-Type: multipart/alternative; boundary=\"{$boundary}\"";
  if ($replyTo !== '') $headers[] = "Reply-To: {$replyTo}";

  $parts = [];
  $parts[] = "--{$boundary}";
  $parts[] = "Content-Type: text/plain; charset=UTF-8";
  $parts[] = "Content-Transfer-Encoding: base64\r\n";
  $parts[] = chunk_split(base64_encode($textBody));
  $parts[] = "--{$boundary}";
  $parts[] = "Content-Type: text/html; charset=UTF-8";
  $parts[] = "Content-Transfer-Encoding: base64\r\n";
  $parts[] = chunk_split(base64_encode($htmlBody));
  $parts[] = "--{$boundary}--";

  $msg = implode("\r\n", $headers) . "\r\n\r\n" . implode("\r\n", $parts) . "\r\n.";
  fwrite($fp, $msg . "\r\n");
  if (!$codeOk($read(), [250])) { fclose($fp); return false; }

  $write("QUIT");
  fclose($fp);
  return true;
}
