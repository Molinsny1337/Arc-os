<?php
declare(strict_types=1);

function arc_create_alert(int $user_id, int $from_user_id, string $type, string $object_type, int $object_id, array $data = []): void {
  if ($user_id <= 0) return;
  if ($from_user_id > 0 && $user_id === $from_user_id) return;
  try {
    $pdo = db();
    $pfx = table_prefix();
    $json = $data ? json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
    $pdo->prepare("INSERT INTO {$pfx}alerts (user_id, from_user_id, type, object_type, object_id, data, is_read, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, 0, NOW())")->execute([$user_id, $from_user_id, $type, $object_type, $object_id, $json]);
  } catch (Throwable $e) {}
}

function arc_alert_unread_count(int $user_id): int {
  try {
    $pdo = db();
    $pfx = table_prefix();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}alerts WHERE user_id=? AND is_read=0");
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
  } catch (Throwable $e) { return 0; }
}

function arc_mark_alerts_read(int $user_id, ?int $max_id = null): void {
  try {
    $pdo = db();
    $pfx = table_prefix();
    if ($max_id !== null) {
      $pdo->prepare("UPDATE {$pfx}alerts SET is_read=1 WHERE user_id=? AND id<=?")->execute([$user_id, $max_id]);
    } else {
      $pdo->prepare("UPDATE {$pfx}alerts SET is_read=1 WHERE user_id=?")->execute([$user_id]);
    }
  } catch (Throwable $e) {}
}

function arc_list_alerts(int $user_id, int $limit = 80): array {
  try {
    $pdo = db();
    $pfx = table_prefix();
    $stmt = $pdo->prepare("SELECT a.*, u.username AS from_username, u.avatar AS from_avatar
                           FROM {$pfx}alerts a
                           LEFT JOIN {$pfx}users u ON u.id = a.from_user_id
                           WHERE a.user_id=?
                           ORDER BY a.id DESC
                           LIMIT {$limit}");
    $stmt->execute([$user_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as &$r) {
      $r['data_arr'] = [];
      if (!empty($r['data']) && is_string($r['data'])) {
        $tmp = json_decode($r['data'], true);
        if (is_array($tmp)) $r['data_arr'] = $tmp;
      }
    }
    unset($r);
    return $rows;
  } catch (Throwable $e) { return []; }
}
