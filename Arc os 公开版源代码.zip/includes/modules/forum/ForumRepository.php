<?php
declare(strict_types=1);

namespace ArcOS\Modules\Forum;

use PDO;
use Throwable;

final class ForumRepository {
  public function __construct(private PDO $pdo, private string $pfx) {}

  public function fetchNodes(): array {
    $sql = "SELECT f.id, f.parent_id, f.title, f.slug, f.description, f.display_order, f.thread_count, f.message_count,
      f.last_post_at, f.last_post_user_id, u.username AS last_post_username,
      p.title AS last_post_title, p.slug AS last_post_slug
      FROM {$this->pfx}forums f
      LEFT JOIN {$this->pfx}users u ON u.id = f.last_post_user_id
      LEFT JOIN {$this->pfx}posts p ON p.id = f.last_post_id
      ORDER BY f.parent_id IS NOT NULL, f.parent_id ASC, f.display_order ASC, f.id ASC";
    try {
      $stmt = $this->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  public function fetchForum(int $id): ?array {
    try {
      $stmt = $this->pdo->prepare("SELECT * FROM {$this->pfx}forums WHERE id=? LIMIT 1");
      $stmt->execute([$id]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      return is_array($row) ? $row : null;
    } catch (Throwable $e) {
      return null;
    }
  }

  public function fetchLatestThreads(int $limit = 12): array {
    try {
      $stmt = $this->pdo->prepare("SELECT p.id, p.title, p.slug, p.excerpt, p.created_at, p.reply_count, p.view_count, p.forum_id,
        p.last_post_at, p.last_post_user_id,
        f.title AS forum_title,
        u.username AS author_username, u.avatar AS author_avatar,
        lu.username AS last_post_username
        FROM {$this->pfx}posts p
        LEFT JOIN {$this->pfx}forums f ON f.id = p.forum_id
        LEFT JOIN {$this->pfx}users u ON u.id = p.author_id
        LEFT JOIN {$this->pfx}users lu ON lu.id = p.last_post_user_id
        WHERE p.type='forum' AND p.status='published'
        ORDER BY COALESCE(p.last_post_at, p.created_at) DESC
        LIMIT ?");
      $stmt->bindValue(1, $limit, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  public function fetchLatestMembers(int $limit = 6): array {
    try {
      $stmt = $this->pdo->prepare("SELECT id, username, display_name, avatar, created_at
        FROM {$this->pfx}users
        ORDER BY id DESC
        LIMIT ?");
      $stmt->bindValue(1, $limit, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  public function fetchStats(): array {
    $stats = [
      'threads_total' => 0,
      'replies_total' => 0,
      'members_total' => 0,
      'threads_today' => 0,
      'replies_today' => 0,
      'members_today' => 0,
    ];
    try {
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}posts WHERE type='forum' AND status='published'");
      $stmt->execute();
      $stats['threads_total'] = (int)($stmt->fetchColumn() ?: 0);
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}post_comments");
      $stmt->execute();
      $stats['replies_total'] = (int)($stmt->fetchColumn() ?: 0);
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}users");
      $stmt->execute();
      $stats['members_total'] = (int)($stmt->fetchColumn() ?: 0);
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}posts WHERE type='forum' AND status='published' AND DATE(created_at)=CURDATE()");
      $stmt->execute();
      $stats['threads_today'] = (int)($stmt->fetchColumn() ?: 0);
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}post_comments WHERE DATE(created_at)=CURDATE()");
      $stmt->execute();
      $stats['replies_today'] = (int)($stmt->fetchColumn() ?: 0);
      $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM {$this->pfx}users WHERE DATE(created_at)=CURDATE()");
      $stmt->execute();
      $stats['members_today'] = (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {
      return $stats;
    }
    return $stats;
  }

  public function fetchPopularNodes(int $limit = 6): array {
    try {
      $stmt = $this->pdo->prepare("SELECT f.id, f.parent_id, f.title, f.slug, f.description, f.thread_count, f.message_count,
        f.last_post_at, f.last_post_user_id, u.username AS last_post_username,
        p.title AS last_post_title, p.slug AS last_post_slug
        FROM {$this->pfx}forums f
        LEFT JOIN {$this->pfx}users u ON u.id = f.last_post_user_id
        LEFT JOIN {$this->pfx}posts p ON p.id = f.last_post_id
        ORDER BY (f.thread_count + f.message_count) DESC, f.last_post_at DESC
        LIMIT ?");
      $stmt->bindValue(1, $limit, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }
}
