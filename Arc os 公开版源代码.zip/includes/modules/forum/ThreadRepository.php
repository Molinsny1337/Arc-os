<?php
declare(strict_types=1);

namespace ArcOS\Modules\Forum;

use PDO;
use Throwable;

final class ThreadRepository {
  public function __construct(private PDO $pdo, private string $pfx) {}

  public function fetchByForum(int $forumId, string $sort, int $page, int $perPage, array $filters = [], int $userId = 0): array {
    $sortKey = $this->normalizeSort($sort);
    $offset = max(0, ($page - 1) * $perPage);

    $orderBy = match ($sortKey) {
      'created' => 'p.created_at DESC',
      'replies' => 'p.reply_count DESC',
      'views' => 'p.view_count DESC',
      default => 'COALESCE(p.last_post_at, p.created_at) DESC',
    };

    $params = [];
    $joins = '';
    $where = "WHERE p.type='forum' AND p.status='published' AND p.is_deleted=0 AND p.forum_id=?";
    $params[] = $forumId;

    $prefixId = isset($filters['prefix']) ? (int)$filters['prefix'] : 0;
    if ($prefixId > 0) {
      $where .= " AND p.prefix_id=?";
      $params[] = $prefixId;
    }

    $tag = isset($filters['tag']) ? trim((string)$filters['tag']) : '';
    if ($tag !== '') {
      $joins .= " INNER JOIN {$this->pfx}xf_content_tags ct ON ct.content_type='thread' AND ct.content_id=p.id
        INNER JOIN {$this->pfx}xf_tags tg ON tg.id=ct.tag_id AND tg.tag=?";
      $params[] = $tag;
    }

    $readFilter = strtolower(trim((string)($filters['read'] ?? '')));
    if ($userId > 0 && in_array($readFilter, ['unread', 'read'], true)) {
      $joins .= " LEFT JOIN {$this->pfx}xf_thread_reads tr ON tr.user_id=" . (int)$userId . " AND tr.thread_id=p.id";
      if ($readFilter === 'unread') {
        $where .= " AND (tr.last_read_at IS NULL OR COALESCE(p.last_post_at, p.created_at) > tr.last_read_at)";
      } else {
        $where .= " AND tr.last_read_at IS NOT NULL AND COALESCE(p.last_post_at, p.created_at) <= tr.last_read_at";
      }
    }

    if (!empty($filters['watching']) && $userId > 0) {
      $joins .= " INNER JOIN {$this->pfx}xf_thread_watches tw ON tw.thread_id=p.id AND tw.user_id=" . (int)$userId;
    }

    $sql = "SELECT p.id, p.title, p.slug, p.created_at, p.reply_count, p.view_count, p.is_sticky, p.is_locked,
        p.last_post_at, p.last_post_user_id, p.prefix_id,
        px.title AS prefix, px.css_class AS prefix_css,
        u.id AS author_id, u.username AS author_username, u.avatar AS author_avatar,
        lu.username AS last_post_username,
        GROUP_CONCAT(DISTINCT t.tag ORDER BY t.tag SEPARATOR ',') AS tags
      FROM {$this->pfx}posts p
      LEFT JOIN {$this->pfx}xf_thread_prefixes px ON px.id = p.prefix_id
      LEFT JOIN {$this->pfx}users u ON u.id = p.author_id
      LEFT JOIN {$this->pfx}users lu ON lu.id = p.last_post_user_id
      LEFT JOIN {$this->pfx}xf_content_tags ct2 ON ct2.content_type='thread' AND ct2.content_id=p.id
      LEFT JOIN {$this->pfx}xf_tags t ON t.id=ct2.tag_id
      {$joins}
      {$where}
      GROUP BY p.id
      ORDER BY p.is_sticky DESC, {$orderBy}
      LIMIT ? OFFSET ?";

    try {
      $stmt = $this->pdo->prepare($sql);
      $i = 1;
      foreach ($params as $param) {
        if (is_int($param)) $stmt->bindValue($i++, $param, PDO::PARAM_INT);
        else $stmt->bindValue($i++, $param, PDO::PARAM_STR);
      }
      $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
      $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }

  public function countByForum(int $forumId, array $filters = [], int $userId = 0): int {
    $params = [];
    $joins = '';
    $where = "WHERE p.type='forum' AND p.status='published' AND p.is_deleted=0 AND p.forum_id=?";
    $params[] = $forumId;

    $prefixId = isset($filters['prefix']) ? (int)$filters['prefix'] : 0;
    if ($prefixId > 0) {
      $where .= " AND p.prefix_id=?";
      $params[] = $prefixId;
    }

    $tag = isset($filters['tag']) ? trim((string)$filters['tag']) : '';
    if ($tag !== '') {
      $joins .= " INNER JOIN {$this->pfx}xf_content_tags ct ON ct.content_type='thread' AND ct.content_id=p.id
        INNER JOIN {$this->pfx}xf_tags tg ON tg.id=ct.tag_id AND tg.tag=?";
      $params[] = $tag;
    }

    $readFilter = strtolower(trim((string)($filters['read'] ?? '')));
    if ($userId > 0 && in_array($readFilter, ['unread', 'read'], true)) {
      $joins .= " LEFT JOIN {$this->pfx}xf_thread_reads tr ON tr.user_id=" . (int)$userId . " AND tr.thread_id=p.id";
      if ($readFilter === 'unread') {
        $where .= " AND (tr.last_read_at IS NULL OR COALESCE(p.last_post_at, p.created_at) > tr.last_read_at)";
      } else {
        $where .= " AND tr.last_read_at IS NOT NULL AND COALESCE(p.last_post_at, p.created_at) <= tr.last_read_at";
      }
    }

    if (!empty($filters['watching']) && $userId > 0) {
      $joins .= " INNER JOIN {$this->pfx}xf_thread_watches tw ON tw.thread_id=p.id AND tw.user_id=" . (int)$userId;
    }

    try {
      $stmt = $this->pdo->prepare("SELECT COUNT(DISTINCT p.id) FROM {$this->pfx}posts p {$joins} {$where}");
      $stmt->execute($params);
      return (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {
      return 0;
    }
  }

  private function normalizeSort(string $sort): string {
    $sort = strtolower(trim($sort));
    $allowed = ['last_reply', 'created', 'replies', 'views'];
    if (!in_array($sort, $allowed, true)) return 'last_reply';
    return $sort;
  }
}
