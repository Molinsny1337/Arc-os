<?php
declare(strict_types=1);

namespace ArcOS\Modules\Forum;

use PDO;
use Throwable;

final class PostRepository {
  public function __construct(private PDO $pdo, private string $pfx) {}

  public function fetchThreadBySlug(string $slug): ?array {
    $sql = "SELECT p.id, p.title, p.content, p.created_at, p.updated_at, p.slug, p.author_id, p.forum_id,
        p.is_sticky, p.is_locked, p.is_deleted, p.reply_count, p.view_count, p.last_post_at, p.last_post_user_id,
        p.reviewed_by, p.reviewed_at, p.prefix_id,
        f.title AS forum_title,
        px.title AS prefix_title, px.css_class AS prefix_css,
        u.username AS author_username, u.display_name AS author_display_name, u.avatar AS author_avatar, u.user_title AS author_user_title,
        u.role AS author_role,
        u.id AS author_user_id, u.is_banned AS author_is_banned, u.banned_until AS author_banned_until, u.created_at AS author_created_at,
        up.signature_bbcode AS author_signature,
        du.discord_username AS author_discord_username, du.discord_discriminator AS author_discord_discriminator,
        r.username AS reviewer_username
      FROM {$this->pfx}posts p
      LEFT JOIN {$this->pfx}forums f ON f.id = p.forum_id
      LEFT JOIN {$this->pfx}xf_thread_prefixes px ON px.id = p.prefix_id
      LEFT JOIN {$this->pfx}users u ON u.id = p.author_id
      LEFT JOIN {$this->pfx}xf_user_profile up ON up.user_id = u.id
      LEFT JOIN {$this->pfx}xf_user_discord du ON du.user_id = u.id
      LEFT JOIN {$this->pfx}users r ON r.id = p.reviewed_by
      WHERE p.slug = ? AND p.type='forum' AND p.status='published' LIMIT 1";
    try {
      $stmt = $this->pdo->prepare($sql);
      $stmt->execute([$slug]);
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      return is_array($row) ? $row : null;
    } catch (Throwable $e) {
      return null;
    }
  }

  public function fetchComments(int $postId, int $page = 1, int $perPage = 20, bool $includeDeleted = false): array {
    $offset = max(0, ($page - 1) * $perPage);
    $whereDeleted = $includeDeleted ? '' : 'AND c.is_deleted=0';
    $whereStatus = $includeDeleted ? '' : "AND c.status='visible'";
    try {
      $stmt = $this->pdo->prepare("SELECT c.*, u2.username AS author_username, u2.display_name AS author_display_name,
          u2.avatar AS author_avatar, u2.user_title AS author_user_title, u2.created_at AS author_created_at,
          u2.role AS author_role,
          u2.is_banned AS author_is_banned, u2.banned_until AS author_banned_until,
          up.signature_bbcode AS author_signature,
          du.discord_username AS author_discord_username, du.discord_discriminator AS author_discord_discriminator
        FROM {$this->pfx}post_comments c
        JOIN {$this->pfx}users u2 ON u2.id=c.author_id
        LEFT JOIN {$this->pfx}xf_user_profile up ON up.user_id = u2.id
        LEFT JOIN {$this->pfx}xf_user_discord du ON du.user_id = u2.id
        WHERE c.post_id=? {$whereDeleted} {$whereStatus}
        ORDER BY COALESCE(c.position, 0) ASC, c.created_at ASC, c.id ASC
        LIMIT ? OFFSET ?");
      $stmt->bindValue(1, $postId, PDO::PARAM_INT);
      $stmt->bindValue(2, $perPage, PDO::PARAM_INT);
      $stmt->bindValue(3, $offset, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
      return [];
    }
  }
}
