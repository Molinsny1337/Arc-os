<?php
declare(strict_types=1);

/**
 * Simple ticket system:
 * - User can create tickets and reply (feedback)
 * - Admin can reply and close/reopen
 */

function arc_ticket_subject_normalize(string $subject): string {
  $subject = trim(preg_replace('/\\s+/u', ' ', $subject) ?? '');
  if (mb_strlen($subject, 'UTF-8') > 191) $subject = mb_substr($subject, 0, 191, 'UTF-8');
  return $subject;
}

function arc_ticket_message_normalize(string $html): string {
  $html = arc_sanitize_richtext((string)$html);
  if (strlen($html) > 200000) $html = substr($html, 0, 200000);
  return $html;
}

function arc_ticket_get(int $ticketId): ?array {
  if ($ticketId <= 0) return null;
  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';
  $st = $pdo->prepare("SELECT * FROM {$t} WHERE id=? LIMIT 1");
  $st->execute([$ticketId]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  return $row ?: null;
}

/**
 * @return array<int, array<string,mixed>>
 */
function arc_ticket_messages(int $ticketId): array {
  if ($ticketId <= 0) return [];
  $pdo = db();
  $pfx = table_prefix();
  $tm = $pfx . 'ticket_messages';
  $tu = $pfx . 'users';
  $st = $pdo->prepare("SELECT m.*, u.username AS author_username
    FROM {$tm} m
    LEFT JOIN {$tu} u ON u.id = m.user_id
    WHERE m.ticket_id=?
    ORDER BY m.id ASC");
  $st->execute([$ticketId]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/**
 * @return array<int, array<string,mixed>>
 */
function arc_user_tickets(int $userId, int $limit = 50, int $offset = 0): array {
  if ($userId <= 0) return [];
  $limit = max(1, min(200, $limit));
  $offset = max(0, $offset);
  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';
  $st = $pdo->prepare("SELECT * FROM {$t} WHERE user_id=? ORDER BY updated_at DESC, id DESC LIMIT {$limit} OFFSET {$offset}");
  $st->execute([$userId]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/**
 * @return array{items: array<int, array<string,mixed>>, total:int}
 */
function arc_admin_ticket_list(?string $status = 'open', int $limit = 50, int $offset = 0): array {
  $limit = max(1, min(200, $limit));
  $offset = max(0, $offset);
  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';
  $tu = $pfx . 'users';

  $where = [];
  $args = [];
  if ($status === 'open' || $status === 'closed') {
    $where[] = "t.status=?";
    $args[] = $status;
  }
  $sqlWhere = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

  $total = 0;
  try {
    $st = $pdo->prepare("SELECT COUNT(*) c FROM {$t} t {$sqlWhere}");
    $st->execute($args);
    $total = (int)($st->fetchColumn() ?: 0);
  } catch (Throwable $e) { $total = 0; }

  $st = $pdo->prepare("SELECT t.*, u.username AS ticket_username
    FROM {$t} t
    LEFT JOIN {$tu} u ON u.id = t.user_id
    {$sqlWhere}
    ORDER BY t.updated_at DESC, t.id DESC
    LIMIT {$limit} OFFSET {$offset}");
  $st->execute($args);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  return ['items' => $rows, 'total' => $total];
}

function arc_ticket_create(int $userId, string $subject, string $messageHtml): int {
  if ($userId <= 0) throw new RuntimeException('Bad user.');
  $subject = arc_ticket_subject_normalize($subject);
  $messageHtml = arc_ticket_message_normalize($messageHtml);
  if ($subject === '' || trim(strip_tags($messageHtml)) === '') throw new RuntimeException(t('fill_all'));

  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';
  $tm = $pfx . 'ticket_messages';

  $pdo->beginTransaction();
  try {
    $pdo->prepare("INSERT INTO {$t} (user_id, subject, status, created_at, updated_at, last_message_at, last_message_by)
      VALUES (?, ?, 'open', NOW(), NOW(), NOW(), 'user')")
      ->execute([$userId, $subject]);
    $ticketId = (int)$pdo->lastInsertId();

    $pdo->prepare("INSERT INTO {$tm} (ticket_id, user_id, is_staff, message, created_at)
      VALUES (?, ?, 0, ?, NOW())")
      ->execute([$ticketId, $userId, $messageHtml]);

    $pdo->commit();
    return $ticketId;
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }
}

function arc_ticket_add_message(int $ticketId, ?int $userId, bool $isStaff, string $messageHtml): void {
  if ($ticketId <= 0) throw new RuntimeException('Bad ticket.');
  $messageHtml = arc_ticket_message_normalize($messageHtml);
  if (trim(strip_tags($messageHtml)) === '') throw new RuntimeException(t('fill_all'));

  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';
  $tm = $pfx . 'ticket_messages';

  $pdo->beginTransaction();
  try {
    $pdo->prepare("INSERT INTO {$tm} (ticket_id, user_id, is_staff, message, created_at)
      VALUES (?, ?, ?, ?, NOW())")
      ->execute([$ticketId, $userId, $isStaff ? 1 : 0, $messageHtml]);

    $pdo->prepare("UPDATE {$t}
      SET updated_at=NOW(), last_message_at=NOW(), last_message_by=?
      WHERE id=?")
      ->execute([$isStaff ? 'admin' : 'user', $ticketId]);

    $pdo->commit();
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }
}

function arc_ticket_set_status(int $ticketId, string $status, ?int $staffUserId = null): void {
  if ($ticketId <= 0) throw new RuntimeException('Bad ticket.');
  if (!in_array($status, ['open','closed'], true)) throw new RuntimeException('Bad status.');

  $pdo = db();
  $pfx = table_prefix();
  $t = $pfx . 'tickets';

  if ($status === 'closed') {
    $pdo->prepare("UPDATE {$t} SET status='closed', closed_at=NOW(), closed_by=?, updated_at=NOW() WHERE id=?")
      ->execute([$staffUserId, $ticketId]);
  } else {
    $pdo->prepare("UPDATE {$t} SET status='open', closed_at=NULL, closed_by=NULL, updated_at=NOW() WHERE id=?")
      ->execute([$ticketId]);
  }
}

function arc_ticket_user_can_view(array $ticket, ?array $user): bool {
  if (!$user) return false;
  if (in_array((string)($user['role'] ?? ''), ['admin','superadmin'], true)) return true;
  return (int)($ticket['user_id'] ?? 0) === (int)($user['id'] ?? 0);
}

