<?php
declare(strict_types=1);

if (!function_exists('str_starts_with')) {
  function str_starts_with(string $haystack, string $needle): bool {
    return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
  }
}

if (!function_exists('str_contains')) {
  function str_contains(string $haystack, string $needle): bool {
    return $needle === '' || strpos($haystack, $needle) !== false;
  }
}

/**
 * 初始化：
 * - BASE_PATH 用于站点部署在子目录时的相对路径
 * - 如果已安装：加载 config/db/auth
 */

/**
 * 计算 BASE_PATH（支持 / 子目录部署，且不会在 /admin 下被误判）
 * 规则：用项目根目录相对于 DOCUMENT_ROOT 的物理路径来推导 URL path。
 */
$docRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
$docRootReal = $docRoot ? realpath($docRoot) : false;
$projectRoot = realpath(__DIR__ . '/..'); // includes/.. => project root

$basePath = '';
if ($docRootReal && $projectRoot && str_starts_with($projectRoot, $docRootReal)) {
  $rel = substr($projectRoot, strlen($docRootReal));
  $rel = str_replace("\\\\", "/", $rel);
  $basePath = rtrim($rel, '/');
  if ($basePath === '/') $basePath = '';
}

if (!defined('BASE_PATH')) { define('BASE_PATH', $basePath); }

// Admin entry path (for custom admin URLs)
if (!defined('ADMIN_PATH')) {
  $cfgFile = __DIR__ . '/config.php';
  if (is_file($cfgFile)) {
    $cfg = require $cfgFile;
    if (is_array($cfg) && !empty($cfg['admin_path'])) {
      $ap = strtolower(trim((string)$cfg['admin_path']));
      if (preg_match('/^[a-z0-9_-]{3,32}$/', $ap)) {
        define('ADMIN_PATH', $ap);
      }
    }
  }
}

// Block direct /admin/* access when a custom admin entry file exists.
if (!defined('ADMIN_ENTRY')) {
  $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
  $adminPath = defined('ADMIN_PATH') ? (string)ADMIN_PATH : '';
  if ($adminPath !== '') {
    $entryFile = __DIR__ . '/../' . $adminPath . '.php';
    if (is_file($entryFile) && str_starts_with($script, BASE_PATH . '/admin/')) {
      http_response_code(404);
      exit('Not Found');
    }
  }
}

// ---------------------------------------------------------------------------
// Session hardening
//
// Problem this fixes:
// - After deleting site code and reinstalling, browser may still hold a session cookie.
// - PHP sessions are stored outside the project (e.g. /tmp). Old session data can survive.
// - If we keep the default session cookie name, the new site can "inherit" the old login.
//
// Solution:
// - Generate a per-install secret (app_key) during install.
// - Derive a unique session cookie name from that secret.
// - Add a server-side signature bound to (session_id + app_key).
//
// This makes old cookies useless after reinstall.

if (!function_exists('arc_is_https')) {
function arc_is_https(): bool {
  if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
  if (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) return true;
  if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
  return false;
}
}

if (!function_exists('arc_session_configure_and_start')) {
function arc_session_configure_and_start(): void {
  $cfgFile = __DIR__ . '/config.php';
  $appKey = '';
  if (is_file($cfgFile)) {
    $cfg = require $cfgFile;
    if (is_array($cfg) && !empty($cfg['app_key'])) {
      $appKey = (string)$cfg['app_key'];
    }
  }

  if ($appKey !== '' && !defined('APP_KEY')) {
    define('APP_KEY', $appKey);
  }

  // If session is already active (e.g. some pages include bootstrap.php first),
  // we still validate/refresh the signature so old sessions from pre-APP_KEY
  // versions can't silently persist.
  if (session_status() === PHP_SESSION_ACTIVE) {
    if (defined('APP_KEY') && APP_KEY !== '') {
      $expected = hash_hmac('sha256', session_id(), APP_KEY);
      $sig = $_SESSION['_sig'] ?? null;
      if (!is_string($sig) || !hash_equals($sig, $expected)) {
        $_SESSION = [];
        @session_regenerate_id(true);
      }
      $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
    }
    return;
  }

  // Per-install session cookie name
  if ($appKey !== '') {
    $name = 'ARCOSSESSID_' . substr(hash('sha256', $appKey), 0, 12);
    @session_name($name);
  }

  // Prefer project-local session store so deleting the project wipes sessions.
  $sessDir = realpath(__DIR__ . '/../storage') ?: (__DIR__ . '/../storage');
  $sessPath = $sessDir . '/sessions';
  if (!is_dir($sessPath)) {
    @mkdir($sessPath, 0700, true);
  }
  if (is_dir($sessPath) && is_writable($sessPath)) {
    @session_save_path($sessPath);
  }

  // Cookie flags
  $secure = arc_is_https();
  @ini_set('session.use_only_cookies', '1');
  @ini_set('session.use_strict_mode', '1');
  @ini_set('session.cookie_httponly', '1');
  @ini_set('session.cookie_secure', $secure ? '1' : '0');
  // PHP < 7.3: cookie_samesite not supported in array form, keep ini fallback
  @ini_set('session.cookie_samesite', 'Lax');

  // PHP 7.3+: set cookie params explicitly
  if (function_exists('session_set_cookie_params')) {
    $params = session_get_cookie_params();
    $path = $params['path'] ?? '/';
    // Always at least / so logout works across routes
    if (!$path) $path = '/';
    @session_set_cookie_params([
      'lifetime' => 0,
      'path' => $path,
      'domain' => $params['domain'] ?? '',
      'secure' => $secure,
      'httponly' => true,
      'samesite' => 'Lax',
    ]);
  }

  session_start();

  // Bind session to APP_KEY to invalidate old sessions after reinstall
  if (defined('APP_KEY') && APP_KEY !== '') {
    $expected = hash_hmac('sha256', session_id(), APP_KEY);
    $sig = $_SESSION['_sig'] ?? null;
    // If signature is missing OR mismatched, reset. This intentionally logs out
    // old sessions created before we introduced the signing mechanism.
    if (!is_string($sig) || !hash_equals($sig, $expected)) {
      $_SESSION = [];
      @session_regenerate_id(true);
    }
    $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
  }
}
}

arc_session_configure_and_start();

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/richtext.php';

// 基础安全头（防止被 iframe 钓鱼、嗅探等）
if (function_exists('arc_send_security_headers')) {
  arc_send_security_headers();
}

$installed = function_exists('is_installed') ? is_installed() : file_exists(__DIR__ . '/config.php');
if ($installed) {
  require_once __DIR__ . '/db.php';
  require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/alerts.php';
require_once __DIR__ . '/mentions.php';
require_once __DIR__ . '/reactions.php';
require_once __DIR__ . '/attachments.php';
require_once __DIR__ . '/trophies.php';
require_once __DIR__ . '/groups.php';
require_once __DIR__ . '/conversations.php';
require_once __DIR__ . '/tickets.php';
require_once __DIR__ . '/log.php';
require_once __DIR__ . '/turnstile.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/services/Crypto.php';
require_once __DIR__ . '/services/LicenseApiClient.php';
require_once __DIR__ . '/services/LicenseService.php';
require_once __DIR__ . '/services/FeatureGate.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/services/AnalyticsService.php';
require_once __DIR__ . '/migrate.php';
// Initialize language early
lang();
  // auto-migrate schema/settings
  if (function_exists('arc_migrate')) { arc_migrate(); }

  // License state init + scheduled recheck (non-blocking)
  try {
    if (class_exists('ArcOS\\Services\\LicenseService')) {
      ArcOS\Services\LicenseService::loadLocalState();
      ArcOS\Services\LicenseService::maybeScheduleRecheck();
    }
  } catch (Throwable $e) {}

  // Keep admin entry routes in sync (non-fatal).
  try {
    if (defined('ADMIN_ENTRY') && function_exists('arc_update_admin_entry_file')) {
      arc_update_admin_entry_file();
    }
  } catch (Throwable $e) {}

  // One-time install continuation login:
  // After writing a fresh config/app_key, sessions are invalidated (by design).
  // To keep the "install -> next step" flow smooth, we allow a short-lived
  // install cookie to log in the newly created admin exactly once.
  try {
    if (!current_user() && !empty($_COOKIE['arc_install'] ?? '')) {
      $token = (string)($_COOKIE['arc_install'] ?? '');
      if (preg_match('/^[a-f0-9]{64}$/i', $token)) {
        $expectedHash = hash('sha256', $token);
        $dbHash = (string)get_setting('install_token_hash', '');
        $exp = (int)get_setting('install_token_expires', '0');
        $adminId = (int)get_setting('install_admin_id', '1');
        if ($dbHash !== '' && $exp > 0 && time() <= $exp && hash_equals($dbHash, $expectedHash)) {
          // log in
          @session_regenerate_id(true);
          refresh_session_user($adminId);
          if (defined('APP_KEY') && APP_KEY !== '') {
            $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
          }
          // consume token
          delete_setting('install_token_hash');
          delete_setting('install_token_expires');
          delete_setting('install_admin_id');
        }
      }
      // always clear client cookie (valid or not)
      @setcookie('arc_install', '', time() - 3600, '/');
    }
  } catch (Throwable $e) {}

  // update last_active for online status (5 min window)
  try {
    $u = current_user();
    if ($u) {
      $pdo = db();
      $pfx = table_prefix();
      $pdo->prepare("UPDATE {$pfx}users SET last_active = NOW() WHERE id = ?")->execute([(int)$u['id']]);
    }
  } catch (Throwable $e) {}

  // analytics (best-effort)
  try {
    if (class_exists('ArcOS\\Services\\AnalyticsService')) {
      ArcOS\Services\AnalyticsService::recordFromRequest(db(), table_prefix());
    }
  } catch (Throwable $e) {}

}


// is_installed() may already be provided by includes/bootstrap.php for pre-install pages.
// Guard to avoid "Cannot redeclare" fatals when both bootstrap.php and init.php are loaded.
if (!function_exists('is_installed')) {
  function is_installed(): bool {
    return file_exists(__DIR__ . '/config.php');
  }
}

function require_installed(): void {
  if (!is_installed()) {
    redirect(url('install.php'));
  }
}
