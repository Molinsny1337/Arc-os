<?php
declare(strict_types=1);

function current_user(): ?array {
  if (empty($_SESSION['user_id'])) return null;
    $u = [
    'id' => (int)($_SESSION['user_id']),
    'role' => (string)($_SESSION['role'] ?? 'user'),
    'username' => (string)($_SESSION['username'] ?? ''),
    'display_name' => (string)($_SESSION['display_name'] ?? ''),
    'email' => (string)($_SESSION['email'] ?? ''),
    'is_verified' => (int)($_SESSION['is_verified'] ?? 0),
    'can_post' => (int)($_SESSION['can_post'] ?? 0),
    'avatar' => (string)($_SESSION['avatar'] ?? ''),
    'notify_likes' => (int)($_SESSION['notify_likes'] ?? 0),
    'notify_profile_comments' => (int)($_SESSION['notify_profile_comments'] ?? 0),
    'is_banned' => (int)($_SESSION['is_banned'] ?? 0),
    'banned_until' => (string)($_SESSION['banned_until'] ?? ''),
    'banned_reason' => (string)($_SESSION['banned_reason'] ?? ''),
  ];
  if (in_array(($u['role'] ?? ''), ['admin','superadmin'], true)) { $u['can_post'] = 1; $u['is_verified'] = 1; }
  return $u;
}

function is_admin(): bool {
  $u = current_user();
  return $u && in_array(($u['role'] ?? ''), ['admin','superadmin'], true);
}


function is_banned_user(?array $u = null): bool {
  if ($u === null) $u = current_user();
  if (!$u) return false;
  // 管理员/站长不受封禁逻辑影响（避免把自己锁死）
  if (in_array((string)($u['role'] ?? ''), ['admin','superadmin'], true)) return false;
  if ((int)($u['is_banned'] ?? 0) !== 1) return false;
  $until = trim((string)($u['banned_until'] ?? ''));
  if ($until === '') return true;
  $ts = strtotime($until);
  if ($ts === false) return true;
  return $ts > time();
}

function require_not_banned(): void {
  $u = current_user();
  if ($u && is_banned_user($u)) {
    http_response_code(403);
    exit(t('banned_cannot_action'));
  }
}

function refresh_session_user(?int $userId = null): void {
  if ($userId === null) {
    $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
  }
  if ($userId <= 0) return;

  $pdo = db();
  $pfx = table_prefix();
  $stmt = $pdo->prepare("SELECT id, username, display_name, email, role, is_verified, can_post, avatar, notify_likes, notify_profile_comments, is_banned, banned_until, banned_reason FROM {$pfx}users WHERE id=? LIMIT 1");
  $stmt->execute([$userId]);
  $row = $stmt->fetch();
  if (!$row) return;

  $_SESSION['user_id'] = (int)$row['id'];
  $_SESSION['username'] = (string)$row['username'];
  $_SESSION['display_name'] = (string)($row['display_name'] ?? '');
  $_SESSION['email'] = (string)$row['email'];
  $_SESSION['role'] = (string)$row['role'];
  $_SESSION['is_verified'] = (int)$row['is_verified'];
  $_SESSION['can_post'] = (int)$row['can_post'];
  $_SESSION['avatar'] = (string)($row['avatar'] ?? '');
  $_SESSION['notify_likes'] = (int)($row['notify_likes'] ?? 0);
  $_SESSION['notify_profile_comments'] = (int)($row['notify_profile_comments'] ?? 0);
  if (in_array(($row['role'] ?? ''), ['admin','superadmin'], true)) { $_SESSION['can_post'] = 1; $_SESSION['is_verified'] = 1; }
}

function login_attempt(string $usernameOrEmail, string $password, ?string $requireRole = null): bool {
  $id = trim($usernameOrEmail);
  if ($id === '') return false;

  $pdo = db();
  $pfx = table_prefix();

  $stmt = $pdo->prepare("SELECT id, username, display_name, email, password_hash, role, is_verified, can_post, avatar, notify_likes, notify_profile_comments, is_banned, banned_until, banned_reason
    FROM {$pfx}users
    WHERE username = ? OR email = ?
    LIMIT 1");
  $stmt->execute([$id, $id]);
  $row = $stmt->fetch();
  if (!$row) return false;

  if (!password_verify($password, (string)$row['password_hash'])) return false;

  if ($requireRole && ($row['role'] ?? '') !== $requireRole) return false;

  // Prevent session fixation
  @session_regenerate_id(true);

  $_SESSION['user_id'] = (int)$row['id'];
  $_SESSION['username'] = (string)$row['username'];
  $_SESSION['display_name'] = (string)($row['display_name'] ?? '');
  $_SESSION['email'] = (string)$row['email'];
  $_SESSION['role'] = (string)$row['role'];
  $_SESSION['is_verified'] = (int)$row['is_verified'];
  $_SESSION['can_post'] = (int)$row['can_post'];
  $_SESSION['avatar'] = (string)($row['avatar'] ?? '');
  $_SESSION['notify_likes'] = (int)($row['notify_likes'] ?? 0);
  $_SESSION['notify_profile_comments'] = (int)($row['notify_profile_comments'] ?? 0);
  if (in_array(($row['role'] ?? ''), ['admin','superadmin'], true)) { $_SESSION['can_post'] = 1; $_SESSION['is_verified'] = 1; }

  // Refresh session signature bound to APP_KEY
  if (defined('APP_KEY') && APP_KEY !== '') {
    $_SESSION['_sig'] = hash_hmac('sha256', session_id(), APP_KEY);
  }

  return true;
}

function logout_now(): void {
  $_SESSION = [];
  if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
      $params["path"], $params["domain"],
      $params["secure"], $params["httponly"]
    );
  }
  session_destroy();
}

function require_admin(): void {
  if (!is_admin()) {
    $next = function_exists('admin_url') ? admin_url('index') : url('admin/index.php');
    $login = function_exists('admin_url') ? admin_url('login') : url('admin/login.php');
    redirect($login . '?next=' . urlencode($next));
  }
}


if (!function_exists('is_superadmin')) {
function is_superadmin(): bool {
  $u = current_user();
  return $u && (($u['role'] ?? '') === 'superadmin');
}
}


if (!function_exists('require_login')) {
function require_login(): void {
  if (!current_user()) {
    header('Location: ' . (function_exists('url') ? url('login.php') : '/login.php'));
    exit;
  }
}
}



if (!function_exists('require_superadmin')) {
function require_superadmin(): void {
  require_login();
  if (!is_superadmin()) {
    http_response_code(403);
    exit('Forbidden');
  }
}
}
