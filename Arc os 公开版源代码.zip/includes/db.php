<?php
declare(strict_types=1);

function config(): array {
  $cfgPath = __DIR__ . '/config.php';
  $cfg = [];
  if (is_file($cfgPath)) {
    $loaded = require $cfgPath;
    if (is_array($loaded)) $cfg = $loaded;
  }

  // Env overrides (helps on shared hosting / containers)
  $envMap = [
    'host' => ['ARC_DB_HOST', 'DB_HOST', 'MYSQL_HOST'],
    'port' => ['ARC_DB_PORT', 'DB_PORT', 'MYSQL_PORT'],
    'name' => ['ARC_DB_NAME', 'DB_NAME', 'MYSQL_DATABASE'],
    'user' => ['ARC_DB_USER', 'DB_USER', 'MYSQL_USER'],
    'pass' => ['ARC_DB_PASS', 'DB_PASS', 'MYSQL_PASSWORD', 'MYSQL_ROOT_PASSWORD'],
    'prefix' => ['ARC_DB_PREFIX', 'DB_PREFIX'],
  ];
  foreach ($envMap as $key => $names) {
    foreach ($names as $n) {
      $v = getenv($n);
      if ($v === false) continue;
      $v = trim((string)$v);
      if ($v === '') continue;
      $cfg[$key] = $v;
      break;
    }
  }

  return $cfg;
}

/**
 * Best-effort DB connector.
 * Returns null when DB is unreachable or credentials are wrong.
 * Caches the first connection failure to avoid repeated slow attempts.
 */
function db_try(): ?PDO {
  static $pdo = null;
  static $err = null;

  if ($pdo instanceof PDO) return $pdo;
  if ($err instanceof Throwable) return null;

  $cfg = config();
  $hostRaw = (string)($cfg['host'] ?? 'localhost');
  $host = $hostRaw;
  $port = (int)($cfg['port'] ?? 0);
  if ($port <= 0 && preg_match('/^(.+):(\\d{2,5})$/', $hostRaw, $m)) {
    $host = (string)$m[1];
    $port = (int)$m[2];
  }
  $name = (string)($cfg['name'] ?? '');
  $user = (string)($cfg['user'] ?? '');
  $pass = (string)($cfg['pass'] ?? '');
  $charset = 'utf8mb4';

  // If config is incomplete, treat as "not installed" instead of crashing.
  if (trim($name) === '' || trim($user) === '') return null;

  $portPart = $port > 0 ? (";port={$port}") : '';
  $dsn = "mysql:host={$host}{$portPart};dbname={$name};charset={$charset}";
  try {
    $pdo = new PDO($dsn, $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ]);
  } catch (Throwable $e) {
    $err = $e;
    return null;
  }

  // Optional: set timezone (best-effort)
  try { $pdo->exec("SET time_zone = '+00:00'"); } catch (Throwable $e) {}

  return $pdo;
}

function db(): PDO {
  $pdo = db_try();
  if ($pdo instanceof PDO) return $pdo;
  throw new RuntimeException('Database connection failed. Check includes/config.php and DB credentials.');
}

function table_prefix(): string {
  $cfg = config();
  $p = $cfg['prefix'] ?? 'wp_';
  // Prevent weird prefixes
  if (!preg_match('/^[A-Za-z0-9_]+$/', (string)$p)) $p = 'wp_';
  return (string)$p;
}

function get_setting(string $key, ?string $default = null): ?string {
  $pdo = db_try();
  if (!$pdo) return $default;
  $pfx = table_prefix();
  try {
    $stmt = $pdo->prepare("SELECT v FROM {$pfx}settings WHERE k = ? LIMIT 1");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    if (!$row) return $default;
    return (string)$row['v'];
  } catch (Throwable $e) {
    return $default;
  }
}

function set_setting(string $key, string $value): void {
  $pdo = db_try();
  if (!$pdo) return;
  $pfx = table_prefix();
  $stmt = $pdo->prepare("INSERT INTO {$pfx}settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v=VALUES(v)");
  $stmt->execute([$key, $value]);
}

function delete_setting(string $key): void {
  $pdo = db_try();
  if (!$pdo) return;
  $pfx = table_prefix();
  try {
    $stmt = $pdo->prepare("DELETE FROM {$pfx}settings WHERE k = ?");
    $stmt->execute([$key]);
  } catch (Throwable $e) {
    // ignore
  }
}
