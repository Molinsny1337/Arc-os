<?php
declare(strict_types=1);

/**
 * Arc OS database migrations (compat-first).
 *
 * - Avoid JSON columns (some MySQL/MariaDB servers do not support it)
 * - Avoid DATETIME default values that can fail under strict SQL modes
 * - Safe to run on every request
 */

function arc_table_exists(PDO $pdo, string $table): bool {
  $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
  $row = $stmt ? $stmt->fetchColumn() : false;
  return (bool)$row;
}

function arc_column_exists(PDO $pdo, string $table, string $column): bool {
  try {
    $stmt = $pdo->query("SHOW COLUMNS FROM `{$table}`");
    while ($stmt && ($r = $stmt->fetch(PDO::FETCH_ASSOC))) {
      if (($r['Field'] ?? '') === $column) return true;
    }
  } catch (Throwable $e) {
    return false;
  }
  return false;
}

function arc_index_exists(PDO $pdo, string $table, string $index): bool {
  try {
    $stmt = $pdo->query("SHOW INDEX FROM `{$table}`");
    while ($stmt && ($r = $stmt->fetch(PDO::FETCH_ASSOC))) {
      if (($r['Key_name'] ?? '') === $index) return true;
    }
  } catch (Throwable $e) {
    return false;
  }
  return false;
}

function arc_add_column(PDO $pdo, string $table, string $column, string $definitionSql): void {
  if (!arc_column_exists($pdo, $table, $column)) {
    $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN {$definitionSql}");
  }
}

function arc_add_index(PDO $pdo, string $table, string $index, string $columnsSql): void {
  if (!arc_index_exists($pdo, $table, $index)) {
    $pdo->exec("CREATE INDEX `{$index}` ON `{$table}` ({$columnsSql})");
  }
}

function arc_setting_default(string $key, string $value): void {
  $cur = get_setting($key, null);
  if ($cur === null) {
    set_setting($key, $value);
  }
}

function arc_migrate(): void {
  if (!function_exists('is_installed') || !is_installed()) return;
  $pdo = db();
  $pfx = table_prefix();

  $tUsers    = $pfx . 'users';
  $tPosts    = $pfx . 'posts';
  $tComments = $pfx . 'comments';
  $tPostComments = $pfx . 'post_comments';
  $tPostLikes    = $pfx . 'post_likes';
  $tSettings = $pfx . 'settings';
  $tLogs     = $pfx . 'logs';
  // [HOTFIX] Ensure posts.type exists (used by indexes and forum/page routing)
  arc_add_column($pdo, $tPosts, 'type', "`type` VARCHAR(16) NOT NULL DEFAULT 'forum'");


  // Logs table (no JSON; meta is LONGTEXT)
  if (!arc_table_exists($pdo, $tLogs)) {
    $pdo->exec("CREATE TABLE `{$tLogs}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `user_id` INT UNSIGNED NULL,
      `username` VARCHAR(190) NULL,
      `action` VARCHAR(80) NOT NULL,
      `object_type` VARCHAR(40) NULL,
      `object_id` INT UNSIGNED NULL,
      `ip` VARCHAR(64) NULL,
      `user_agent` VARCHAR(255) NULL,
      `meta` LONGTEXT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_user_id` (`user_id`),
      KEY `idx_action` (`action`),
      KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  // Post comments (forum + page)
  if (!arc_table_exists($pdo, $tPostComments)) {
    $pdo->exec("CREATE TABLE `{$tPostComments}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `post_id` INT UNSIGNED NOT NULL,
      `author_id` INT UNSIGNED NOT NULL,
      `content` TEXT NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_post_created` (`post_id`, `created_at`),
      KEY `idx_author_created` (`author_id`, `created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  // Post likes
  if (!arc_table_exists($pdo, $tPostLikes)) {
    $pdo->exec("CREATE TABLE `{$tPostLikes}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `post_id` INT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_post_user` (`post_id`,`user_id`),
      KEY `idx_post_created` (`post_id`, `created_at`),
      KEY `idx_user_created` (`user_id`, `created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  // Users table small forward-compat columns
  if (arc_table_exists($pdo, $tUsers)) {
    arc_add_column($pdo, $tUsers, 'role', "`role` VARCHAR(20) NOT NULL DEFAULT 'user'");
    arc_add_column($pdo, $tUsers, 'display_name', "`display_name` VARCHAR(64) NULL");
    arc_add_column($pdo, $tUsers, 'avatar', "`avatar` VARCHAR(255) NULL");
    arc_add_column($pdo, $tUsers, 'last_active', "`last_active` DATETIME NULL");
    arc_add_column($pdo, $tUsers, 'notify_likes', "`notify_likes` TINYINT(1) NOT NULL DEFAULT 0");
    arc_add_column($pdo, $tUsers, 'notify_profile_comments', "`notify_profile_comments` TINYINT(1) NOT NULL DEFAULT 0");

    // Banned system
    arc_add_column($pdo, $tUsers, 'is_banned', "`is_banned` TINYINT(1) NOT NULL DEFAULT 0");
    arc_add_column($pdo, $tUsers, 'banned_reason', "`banned_reason` VARCHAR(255) NULL");
    arc_add_column($pdo, $tUsers, 'banned_by', "`banned_by` INT UNSIGNED NULL");
    arc_add_column($pdo, $tUsers, 'banned_at', "`banned_at` DATETIME NULL");
    arc_add_column($pdo, $tUsers, 'banned_until', "`banned_until` DATETIME NULL");


    
    // XenForo-like profile fields (cover/about) - ADD ONLY
    arc_add_column($pdo, $tUsers, 'cover_url', "`cover_url` VARCHAR(255) NULL");
    arc_add_column($pdo, $tUsers, 'cover_pos_x', "`cover_pos_x` TINYINT UNSIGNED NULL");
    arc_add_column($pdo, $tUsers, 'cover_pos_y', "`cover_pos_y` TINYINT UNSIGNED NULL");
    arc_add_column($pdo, $tUsers, 'user_title', "`user_title` VARCHAR(80) NULL");
    arc_add_column($pdo, $tUsers, 'about_text', "`about_text` TEXT NULL");
    arc_add_column($pdo, $tUsers, 'location', "`location` VARCHAR(120) NULL");
    arc_add_column($pdo, $tUsers, 'website', "`website` VARCHAR(190) NULL");
    arc_add_column($pdo, $tUsers, 'signature', "`signature` TEXT NULL");
    arc_add_column($pdo, $tUsers, 'allow_profile_posts', "`allow_profile_posts` TINYINT(1) NOT NULL DEFAULT 1");
    arc_add_column($pdo, $tUsers, 'show_followers', "`show_followers` TINYINT(1) NOT NULL DEFAULT 1");

// Ensure there is at least one superadmin. Default: first user becomes owner.
    try {
      $cnt = (int)$pdo->query("SELECT COUNT(*) FROM `{$tUsers}` WHERE role='superadmin'")->fetchColumn();
      if ($cnt <= 0) {
        // Promote user #1 if exists.
        $pdo->exec("UPDATE `{$tUsers}` SET role='superadmin', can_post=1, is_verified=1 WHERE id=1");
      }
    } catch (Throwable $e) {
      // ignore
    }
  }

  // Settings defaults for SMTP + Turnstile + notifications
  if (arc_table_exists($pdo, $tSettings)) {
    arc_setting_default('site_title', 'Arc OS');
    arc_setting_default('site_tagline', '大道至简 · 类苹果风格动?· PHP + MySQL');
    arc_setting_default('home_intro', '大道至简 · 类苹果风格动?· PHP + MySQL');
    arc_setting_default('smtp_enabled', '0');
    arc_setting_default('smtp_host', '');
    arc_setting_default('smtp_port', '587');
    arc_setting_default('smtp_user', '');
    arc_setting_default('smtp_pass', '');
    arc_setting_default('smtp_secure', 'tls');
    arc_setting_default('mail_from', 'no-reply@example.com');
    arc_setting_default('mail_from_name', 'Arc OS');
    arc_setting_default('mail_mode', 'mail');
    arc_setting_default('smtp_enc', 'tls');
    arc_setting_default('smtp_from', '');
    arc_setting_default('smtp_from_name', 'Arc OS');
    arc_setting_default('smtp_pass_enc', '');
    arc_setting_default('smtp_reply_to', '');
    arc_setting_default('analytics_enabled', '1');
    arc_setting_default('analytics_bot_keywords', 'bot,spider,crawl,slurp,facebookexternalhit,telegrambot');
    arc_setting_default('analytics_dedupe_window', '60');
    arc_setting_default('discord_client_id', '');
    arc_setting_default('discord_client_secret_enc', '');
    arc_setting_default('discord_redirect_uri', '');
    arc_setting_default('discord_allow_register', '1');
    arc_setting_default('discord_webhook_enabled', '0');
    arc_setting_default('discord_webhook_url_enc', '');
    arc_setting_default('discord_webhook_event_new_thread', '1');
    arc_setting_default('discord_webhook_event_new_post', '1');
    arc_setting_default('discord_webhook_event_report_created', '1');
    arc_setting_default('discord_webhook_event_moderation_queue', '1');
    arc_setting_default('discord_webhook_event_user_registered', '1');
    arc_setting_default('discord_guild_id', '');
    arc_setting_default('discord_bot_token_enc', '');
    arc_setting_default('discord_show_in_members', '0');
    arc_setting_default('profile_posts_enabled', '1');
    arc_setting_default('profile_visitors_enabled', '1');
    arc_setting_default('profile_media_enabled', '1');
    arc_setting_default('profile_signatures_enabled', '1');
    arc_setting_default('profile_fields_enabled', '1');


    arc_setting_default('turnstile_enabled', '0');
    arc_setting_default('turnstile_site_key', '');
    arc_setting_default('turnstile_secret_key', '');
    arc_setting_default('turnstile_on_login', '1');
    arc_setting_default('turnstile_on_register', '1');
    arc_setting_default('turnstile_on_admin', '1');
    arc_setting_default('turnstile_on_post', '1');
    arc_setting_default('turnstile_on_comment', '1');


    arc_setting_default('notify_admin_new_user', '1');
    arc_setting_default('notify_admin_new_post', '1');

    // --- 审核中心（用户改?改头?发帖审核?--
    arc_setting_default('review_user_changes', '1'); // 1=用户改名/头像需审核
    arc_setting_default('review_posts', '1');
    arc_setting_default('review_first_post', '1');
    arc_setting_default('max_links_per_post', '6');
    arc_setting_default('max_links_per_comment', '6');
    arc_setting_default('login_fail_limit', '5');
    arc_setting_default('login_fail_window', '900');
    arc_setting_default('enable_reports', '1');
    arc_setting_default('post_rate_limit', '3');
    arc_setting_default('post_rate_window', '60');
    arc_setting_default('reply_rate_limit', '6');
    arc_setting_default('reply_rate_window', '60');
// --- ?C?????a????1 ---
arc_setting_default('forum_bg_image', '');
arc_setting_default('forum_bg_opacity', '0.22');
arc_setting_default('forum_bg_blur', '10');
arc_setting_default('custom_css', '');

// --- 开?API（基础?--
arc_setting_default('api_enabled', '0');
arc_setting_default('api_public_read', '1');
arc_setting_default('api_master_key', '');
arc_setting_default('api_entitlement_key', '');
// Appearance injections (admin-controlled)
arc_setting_default('custom_css', '');
arc_setting_default('custom_js', '');
arc_setting_default('custom_head_html', '');
    arc_setting_default('custom_footer_html', '');
    arc_setting_default('click_effect', 'none');
    arc_setting_default('audit_enabled', '0');




  // --- 审核中心：用户审核请求表 ---
  $tReview = $pfx . 'review_requests';
  if (!arc_table_exists($pdo, $tReview)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tReview}` (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT UNSIGNED NOT NULL,
        req_type ENUM('username','avatar') NOT NULL,
        payload LONGTEXT NULL,
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        review_note TEXT NULL,
        reviewed_by INT UNSIGNED NULL,
        reviewed_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY idx_status_created (status, created_at),
        KEY idx_user_type (user_id, req_type, status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {
      // ignore
    }
  }

  // --- 发帖审核状态字段（允许拒绝/备注?--
  $tPosts = $pfx . 'posts';
  if (arc_table_exists($pdo, $tPosts)) {
    if (!arc_column_exists($pdo, $tPosts, 'review_state')) {
      try {
        $pdo->exec("ALTER TABLE `{$tPosts}` ADD COLUMN review_state VARCHAR(16) NOT NULL DEFAULT 'pending' AFTER reviewed_at");
        // best-effort backfill
        $pdo->exec("UPDATE `{$tPosts}` SET review_state = CASE WHEN status='published' THEN 'approved' ELSE 'pending' END");
      } catch (Throwable $e) {
        // ignore
      }
    }
    if (!arc_column_exists($pdo, $tPosts, 'review_note')) {
      try {
        $pdo->exec("ALTER TABLE `{$tPosts}` ADD COLUMN review_note TEXT NULL AFTER review_state");
      } catch (Throwable $e) {
        // ignore
      }
    }
  }
  }

  // [ADDON] user follow system table (inside arc_migrate)
  try {
    $pdo->exec("
      CREATE TABLE IF NOT EXISTS `{$pfx}user_follows` (
        `follower_id` INT NOT NULL,
        `followee_id` INT NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`follower_id`, `followee_id`),
        KEY `idx_followee` (`followee_id`),
        KEY `idx_follower` (`follower_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
  } catch (Throwable $e) {
    // ignore
  }

  // [ADDON] profile visitors table
  try {
    $pdo->exec("
      CREATE TABLE IF NOT EXISTS `{$pfx}profile_visits` (
        `visited_user_id` INT NOT NULL,
        `visitor_id` INT NOT NULL,
        `visit_date` DATE NOT NULL,
        `visited_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`visited_user_id`, `visitor_id`, `visit_date`),
        KEY `idx_visited_at` (`visited_at`),
        KEY `idx_visitor` (`visitor_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
  } catch (Throwable $e) {
    // ignore
  }



// [ADDON] Forums + alerts (MySQL 8.4+)
$tForums = "{$pfx}forums";
if (!arc_table_exists($pdo, $tForums)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tForums}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `parent_id` INT UNSIGNED NULL,
      `title` VARCHAR(191) NOT NULL,
      `slug` VARCHAR(191) NOT NULL,
      `description` TEXT NULL,
      `display_order` INT NOT NULL DEFAULT 0,
      `thread_count` INT UNSIGNED NOT NULL DEFAULT 0,
      `message_count` INT UNSIGNED NOT NULL DEFAULT 0,
      `last_post_at` DATETIME NULL,
      `last_post_id` INT UNSIGNED NULL,
      `last_post_user_id` INT UNSIGNED NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_slug` (`slug`),
      KEY `idx_parent_order` (`parent_id`, `display_order`),
      KEY `idx_lastpost` (`last_post_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Seed default forums if empty
try {
  $cnt = (int)$pdo->query("SELECT COUNT(*) FROM {$tForums}")->fetchColumn();
  if ($cnt === 0) {
    $stmt = $pdo->prepare("INSERT INTO {$tForums} (parent_id, title, slug, description, display_order, created_at)
                           VALUES (NULL, ?, ?, ?, 0, NOW())");
    $stmt->execute(['General', 'general', 'General discussion']);
    $stmt->execute(['Arc OS', 'arc-os', 'Arc OS development']);
  }
} catch (Throwable $e) {}

// posts table upgrades for forum threads
$tPosts = "{$pfx}posts";
arc_add_column($pdo, $tPosts, 'forum_id', "`forum_id` INT UNSIGNED NULL");
arc_add_column($pdo, $tPosts, 'is_sticky', "`is_sticky` TINYINT(1) NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'is_locked', "`is_locked` TINYINT(1) NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'reply_count', "`reply_count` INT UNSIGNED NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'view_count', "`view_count` INT UNSIGNED NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'last_post_at', "`last_post_at` DATETIME NULL");
arc_add_column($pdo, $tPosts, 'last_post_user_id', "`last_post_user_id` INT UNSIGNED NULL");
arc_add_column($pdo, $tPosts, 'prefix_id', "`prefix_id` INT UNSIGNED NULL");
arc_add_column($pdo, $tPosts, 'is_featured', "`is_featured` TINYINT(1) NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'is_deleted', "`is_deleted` TINYINT(1) NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'deleted_by', "`deleted_by` INT UNSIGNED NULL");
arc_add_column($pdo, $tPosts, 'deleted_at', "`deleted_at` DATETIME NULL");
arc_add_column($pdo, $tPosts, 'delete_reason', "`delete_reason` VARCHAR(255) NULL");
arc_add_column($pdo, $tPosts, 'edit_count', "`edit_count` INT UNSIGNED NOT NULL DEFAULT 0");
arc_add_column($pdo, $tPosts, 'last_edit_at', "`last_edit_at` DATETIME NULL");
arc_add_column($pdo, $tPosts, 'last_edit_by', "`last_edit_by` INT UNSIGNED NULL");

// post_comments soft-delete + updated_at
$tPostComments = "{$pfx}post_comments";
if (arc_table_exists($pdo, $tPostComments)) {
  arc_add_column($pdo, $tPostComments, 'updated_at', "`updated_at` DATETIME NULL");
  arc_add_column($pdo, $tPostComments, 'status', "`status` VARCHAR(16) NOT NULL DEFAULT 'visible'");
  arc_add_column($pdo, $tPostComments, 'is_deleted', "`is_deleted` TINYINT(1) NOT NULL DEFAULT 0");
  arc_add_column($pdo, $tPostComments, 'deleted_by', "`deleted_by` INT UNSIGNED NULL");
  arc_add_column($pdo, $tPostComments, 'deleted_at', "`deleted_at` DATETIME NULL");
  arc_add_column($pdo, $tPostComments, 'delete_reason', "`delete_reason` VARCHAR(255) NULL");
  arc_add_column($pdo, $tPostComments, 'edit_count', "`edit_count` INT UNSIGNED NOT NULL DEFAULT 0");
  arc_add_column($pdo, $tPostComments, 'last_edit_at', "`last_edit_at` DATETIME NULL");
  arc_add_column($pdo, $tPostComments, 'last_edit_by', "`last_edit_by` INT UNSIGNED NULL");
  arc_add_column($pdo, $tPostComments, 'ip_hash', "`ip_hash` CHAR(64) NULL");
  arc_add_column($pdo, $tPostComments, 'position', "`position` INT UNSIGNED NULL");
  arc_add_index($pdo, $tPostComments, 'idx_post_position', "`post_id`, `position`");
}

// Alerts table
$tAlerts = "{$pfx}alerts";
if (!arc_table_exists($pdo, $tAlerts)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tAlerts}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `user_id` INT UNSIGNED NOT NULL,
      `from_user_id` INT UNSIGNED NULL,
      `type` VARCHAR(32) NOT NULL,
      `object_type` VARCHAR(32) NOT NULL,
      `object_id` BIGINT UNSIGNED NOT NULL,
      `data` TEXT NULL,
      `is_read` TINYINT(1) NOT NULL DEFAULT 0,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_user_read_id` (`user_id`, `is_read`, `id`),
      KEY `idx_user_id` (`user_id`, `id`),
      KEY `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}


// ===== XenForo-ish expansions (aggressive) =====
// Conversations
$tConv = "{$pfx}conversations";
if (!arc_table_exists($pdo, $tConv)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tConv}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `title` VARCHAR(191) NULL,
      `creator_id` INT UNSIGNED NOT NULL,
      `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
      `last_message_at` DATETIME NULL,
      `last_message_id` BIGINT UNSIGNED NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_creator` (`creator_id`, `id`),
      KEY `idx_last` (`last_message_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tConvP = "{$pfx}conversation_participants";
if (!arc_table_exists($pdo, $tConvP)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tConvP}` (
      `conversation_id` BIGINT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `last_read_message_id` BIGINT UNSIGNED NULL,
      `is_muted` TINYINT(1) NOT NULL DEFAULT 0,
      `is_left` TINYINT(1) NOT NULL DEFAULT 0,
      `joined_at` DATETIME NOT NULL,
      PRIMARY KEY (`conversation_id`, `user_id`),
      KEY `idx_user` (`user_id`, `conversation_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tConvM = "{$pfx}conversation_messages";
if (!arc_table_exists($pdo, $tConvM)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tConvM}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `conversation_id` BIGINT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `message` MEDIUMTEXT NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_conv_id` (`conversation_id`, `id`),
      KEY `idx_user` (`user_id`, `id`),
      FULLTEXT KEY `ft_message` (`message`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Reactions
$tRe = "{$pfx}post_reactions";
if (!arc_table_exists($pdo, $tRe)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tRe}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `post_id` INT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `reaction` VARCHAR(16) NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_post_user_reaction` (`post_id`, `user_id`, `reaction`),
      KEY `idx_post` (`post_id`, `id`),
      KEY `idx_user` (`user_id`, `id`),
      KEY `idx_reaction` (`reaction`, `id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Attachments
$tAtt = "{$pfx}post_attachments";
if (!arc_table_exists($pdo, $tAtt)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tAtt}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `post_id` INT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `original_name` VARCHAR(255) NOT NULL,
      `stored_name` VARCHAR(255) NOT NULL,
      `mime` VARCHAR(128) NOT NULL,
      `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
      `is_image` TINYINT(1) NOT NULL DEFAULT 0,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_post` (`post_id`, `id`),
      KEY `idx_user` (`user_id`, `id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Editor drafts + attachments (XF-style)
$tDrafts = "{$pfx}xf_drafts";
if (!arc_table_exists($pdo, $tDrafts)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tDrafts}` (
      `draft_key` VARCHAR(190) NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
      `bbcode` MEDIUMTEXT NULL,
      `attachments_json` TEXT NULL,
      `created_at` DATETIME NOT NULL,
      `updated_at` DATETIME NOT NULL,
      PRIMARY KEY (`draft_key`),
      KEY `idx_user` (`user_id`, `updated_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tAttData = "{$pfx}xf_attachment_data";
if (!arc_table_exists($pdo, $tAttData)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tAttData}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `user_id` INT UNSIGNED NOT NULL,
      `file_name` VARCHAR(255) NOT NULL,
      `file_path` VARCHAR(255) NOT NULL,
      `file_hash` VARCHAR(64) NULL,
      `mime` VARCHAR(128) NOT NULL,
      `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
      `width` INT UNSIGNED NULL,
      `height` INT UNSIGNED NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_user` (`user_id`, `id`),
      KEY `idx_hash` (`file_hash`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}
if (arc_table_exists($pdo, $tAttData)) {
  arc_add_column($pdo, $tAttData, 'thumb_path', "`thumb_path` VARCHAR(255) NULL");
  arc_add_column($pdo, $tAttData, 'thumb_width', "`thumb_width` INT UNSIGNED NULL");
  arc_add_column($pdo, $tAttData, 'thumb_height', "`thumb_height` INT UNSIGNED NULL");
}

$tAtts = "{$pfx}xf_attachments";
if (!arc_table_exists($pdo, $tAtts)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tAtts}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `data_id` BIGINT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
      `temp_key` VARCHAR(190) NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_data` (`data_id`),
      KEY `idx_content` (`content_type`, `content_id`),
      KEY `idx_temp` (`temp_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tMention = "{$pfx}xf_mention_log";
if (!arc_table_exists($pdo, $tMention)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tMention}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `user_id` INT UNSIGNED NOT NULL,
      `from_user_id` INT UNSIGNED NOT NULL,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_user` (`user_id`, `id`),
      KEY `idx_content` (`content_type`, `content_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Tags / bookmarks / watches
$tTags = "{$pfx}xf_tags";
if (!arc_table_exists($pdo, $tTags)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tTags}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `tag` VARCHAR(100) NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_tag` (`tag`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tContentTags = "{$pfx}xf_content_tags";
if (!arc_table_exists($pdo, $tContentTags)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tContentTags}` (
      `tag_id` BIGINT UNSIGNED NOT NULL,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`tag_id`, `content_type`, `content_id`),
      KEY `idx_content` (`content_type`, `content_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tBookmarks = "{$pfx}xf_bookmarks";
if (!arc_table_exists($pdo, $tBookmarks)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tBookmarks}` (
      `user_id` BIGINT UNSIGNED NOT NULL,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `content_type`, `content_id`),
      KEY `idx_content` (`content_type`, `content_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tThreadWatch = "{$pfx}xf_thread_watches";
if (!arc_table_exists($pdo, $tThreadWatch)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tThreadWatch}` (
      `user_id` BIGINT UNSIGNED NOT NULL,
      `thread_id` BIGINT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `thread_id`),
      KEY `idx_thread` (`thread_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tForumWatch = "{$pfx}xf_forum_watches";
if (!arc_table_exists($pdo, $tForumWatch)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tForumWatch}` (
      `user_id` BIGINT UNSIGNED NOT NULL,
      `forum_id` BIGINT UNSIGNED NOT NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `forum_id`),
      KEY `idx_forum` (`forum_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Prefixes
$tPrefixes = "{$pfx}xf_thread_prefixes";
if (!arc_table_exists($pdo, $tPrefixes)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tPrefixes}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `title` VARCHAR(100) NOT NULL,
      `css_class` VARCHAR(64) NULL,
      `display_order` INT NOT NULL DEFAULT 0,
      `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_order` (`display_order`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Read state
$tThreadReads = "{$pfx}xf_thread_reads";
if (!arc_table_exists($pdo, $tThreadReads)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tThreadReads}` (
      `user_id` BIGINT UNSIGNED NOT NULL,
      `thread_id` BIGINT UNSIGNED NOT NULL,
      `last_read_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `thread_id`),
      KEY `idx_thread` (`thread_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tForumReads = "{$pfx}xf_forum_reads";
if (!arc_table_exists($pdo, $tForumReads)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tForumReads}` (
      `user_id` BIGINT UNSIGNED NOT NULL,
      `forum_id` BIGINT UNSIGNED NOT NULL,
      `last_read_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `forum_id`),
      KEY `idx_forum` (`forum_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Reports
$tReports = "{$pfx}xf_reports";
if (!arc_table_exists($pdo, $tReports)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tReports}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `content_type` VARCHAR(32) NOT NULL,
      `content_id` BIGINT UNSIGNED NOT NULL,
      `user_id` INT UNSIGNED NOT NULL,
      `reason` VARCHAR(255) NOT NULL,
      `details` TEXT NULL,
      `status` ENUM('open','closed') NOT NULL DEFAULT 'open',
      `handled_by` INT UNSIGNED NULL,
      `handled_at` DATETIME NULL,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_status` (`status`, `id`),
      KEY `idx_content` (`content_type`, `content_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Emoji packs
$tEmojis = "{$pfx}xf_emojis";
if (!arc_table_exists($pdo, $tEmojis)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tEmojis}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `shortcode` VARCHAR(64) NOT NULL,
      `unicode` VARCHAR(64) NULL,
      `image_path` VARCHAR(255) NULL,
      `category` VARCHAR(64) NULL,
      `width` INT UNSIGNED NULL,
      `height` INT UNSIGNED NULL,
      `is_sticker` TINYINT(1) NOT NULL DEFAULT 0,
      `display_order` INT NOT NULL DEFAULT 0,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_shortcode` (`shortcode`),
      KEY `idx_category` (`category`, `display_order`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tEmojiPacks = "{$pfx}xf_emoji_packs";
if (!arc_table_exists($pdo, $tEmojiPacks)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tEmojiPacks}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `title` VARCHAR(100) NOT NULL,
      `slug` VARCHAR(64) NOT NULL,
      `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
      `display_order` INT NOT NULL DEFAULT 0,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uniq_slug` (`slug`),
      KEY `idx_order` (`display_order`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

$tEmojiItems = "{$pfx}xf_emoji_pack_items";
if (!arc_table_exists($pdo, $tEmojiItems)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tEmojiItems}` (
      `pack_id` BIGINT UNSIGNED NOT NULL,
      `emoji_id` BIGINT UNSIGNED NOT NULL,
      PRIMARY KEY (`pack_id`, `emoji_id`),
      KEY `idx_emoji` (`emoji_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Trophies
$tTro = "{$pfx}trophies";
if (!arc_table_exists($pdo, $tTro)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tTro}` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `title` VARCHAR(191) NOT NULL,
      `description` TEXT NULL,
      `points` INT NOT NULL DEFAULT 0,
      `icon` VARCHAR(255) NULL,
      `criteria_json` TEXT NULL,
      `display_order` INT NOT NULL DEFAULT 0,
      `created_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_points` (`points`, `id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}
arc_add_column($pdo, $tTro, 'criteria_json', "`criteria_json` TEXT NULL");
arc_add_column($pdo, $tTro, 'display_order', "`display_order` INT NOT NULL DEFAULT 0");

$tUT = "{$pfx}user_trophies";
if (!arc_table_exists($pdo, $tUT)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tUT}` (
      `user_id` INT UNSIGNED NOT NULL,
      `trophy_id` INT UNSIGNED NOT NULL,
      `awarded_at` DATETIME NOT NULL,
      PRIMARY KEY (`user_id`, `trophy_id`),
      KEY `idx_trophy` (`trophy_id`, `user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

// Profile posts (XF wall)
$tPP = "{$pfx}profile_posts";
if (!arc_table_exists($pdo, $tPP)) {
  try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tPP}` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `profile_user_id` INT UNSIGNED NOT NULL,
      `author_id` INT UNSIGNED NOT NULL,
      `message` MEDIUMTEXT NOT NULL,
      `comment_count` INT UNSIGNED NOT NULL DEFAULT 0,
      `created_at` DATETIME NOT NULL,
      `updated_at` DATETIME NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_profile` (`profile_user_id`, `id`),
      KEY `idx_author` (`author_id`, `id`),
      FULLTEXT KEY `ft_message` (`message`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
  } catch (Throwable $e) {}
}

  $tPPC = "{$pfx}profile_post_comments";
  if (!arc_table_exists($pdo, $tPPC)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tPPC}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `profile_post_id` BIGINT UNSIGNED NOT NULL,
        `author_id` INT UNSIGNED NOT NULL,
        `message` MEDIUMTEXT NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_post` (`profile_post_id`, `id`),
        KEY `idx_author` (`author_id`, `id`),
        FULLTEXT KEY `ft_message` (`message`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // Profile system (new XF-like tables)
  $tXProfile = "{$pfx}xf_user_profile";
  if (!arc_table_exists($pdo, $tXProfile)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXProfile}` (
        `user_id` INT UNSIGNED NOT NULL,
        `location` VARCHAR(120) NULL,
        `website` VARCHAR(190) NULL,
        `about_me_bbcode` MEDIUMTEXT NULL,
        `signature_bbcode` MEDIUMTEXT NULL,
        `cover_path` VARCHAR(255) NULL,
        `privacy_json` TEXT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXFields = "{$pfx}xf_profile_fields";
  if (!arc_table_exists($pdo, $tXFields)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXFields}` (
        `field_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(100) NOT NULL,
        `field_type` VARCHAR(20) NOT NULL,
        `field_choices_json` TEXT NULL,
        `display_order` INT NOT NULL DEFAULT 0,
        `editable` TINYINT(1) NOT NULL DEFAULT 1,
        `show_on_profile` TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (`field_id`),
        KEY `idx_display` (`display_order`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXFieldValues = "{$pfx}xf_user_field_values";
  if (!arc_table_exists($pdo, $tXFieldValues)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXFieldValues}` (
        `user_id` INT UNSIGNED NOT NULL,
        `field_id` INT UNSIGNED NOT NULL,
        `value` TEXT NULL,
        PRIMARY KEY (`user_id`, `field_id`),
        KEY `idx_field` (`field_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXProfilePosts = "{$pfx}xf_profile_posts";
  if (!arc_table_exists($pdo, $tXProfilePosts)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXProfilePosts}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NOT NULL,
        `author_user_id` INT UNSIGNED NOT NULL,
        `message_bbcode` MEDIUMTEXT NOT NULL,
        `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`, `id`),
        KEY `idx_author` (`author_user_id`, `id`),
        FULLTEXT KEY `ft_message` (`message_bbcode`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXProfileComments = "{$pfx}xf_profile_post_comments";
  if (!arc_table_exists($pdo, $tXProfileComments)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXProfileComments}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `profile_post_id` BIGINT UNSIGNED NOT NULL,
        `user_id` INT UNSIGNED NOT NULL,
        `message_bbcode` MEDIUMTEXT NOT NULL,
        `is_deleted` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_post` (`profile_post_id`, `id`),
        KEY `idx_user` (`user_id`, `id`),
        FULLTEXT KEY `ft_message` (`message_bbcode`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXFollow = "{$pfx}xf_user_follow";
  if (!arc_table_exists($pdo, $tXFollow)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXFollow}` (
        `follower_id` INT UNSIGNED NOT NULL,
        `followed_id` INT UNSIGNED NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`follower_id`, `followed_id`),
        KEY `idx_followed` (`followed_id`, `follower_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXIgnore = "{$pfx}xf_user_ignore";
  if (!arc_table_exists($pdo, $tXIgnore)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXIgnore}` (
        `user_id` INT UNSIGNED NOT NULL,
        `ignored_user_id` INT UNSIGNED NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`, `ignored_user_id`),
        KEY `idx_ignored` (`ignored_user_id`, `user_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tXVisitors = "{$pfx}xf_profile_visitors";
  if (!arc_table_exists($pdo, $tXVisitors)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tXVisitors}` (
        `user_id` INT UNSIGNED NOT NULL,
        `visitor_user_id` INT UNSIGNED NOT NULL,
        `visited_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`, `visitor_user_id`),
        KEY `idx_visited` (`visited_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // Discord tables
  $tDiscord = "{$pfx}xf_user_discord";
  if (!arc_table_exists($pdo, $tDiscord)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tDiscord}` (
        `user_id` INT UNSIGNED NOT NULL,
        `discord_user_id` VARCHAR(32) NOT NULL,
        `discord_username` VARCHAR(100) NOT NULL,
        `discord_discriminator` VARCHAR(10) NULL,
        `discord_avatar` VARCHAR(100) NULL,
        `discord_email` VARCHAR(191) NULL,
        `access_token_enc` TEXT NOT NULL,
        `refresh_token_enc` TEXT NOT NULL,
        `token_expires_at` DATETIME NULL,
        `connected_at` DATETIME NOT NULL,
        `last_sync_at` DATETIME NULL,
        PRIMARY KEY (`user_id`),
        UNIQUE KEY `uniq_discord_user` (`discord_user_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tWebhook = "{$pfx}xf_webhook_log";
  if (!arc_table_exists($pdo, $tWebhook)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tWebhook}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `event` VARCHAR(64) NOT NULL,
        `status` VARCHAR(20) NOT NULL,
        `error` TEXT NULL,
        `response_snippet` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_event_created` (`event`, `created_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tRoleMap = "{$pfx}xf_discord_role_map";
  if (!arc_table_exists($pdo, $tRoleMap)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tRoleMap}` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `role_id` VARCHAR(32) NOT NULL,
        `group_id` INT UNSIGNED NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_role_group` (`role_id`, `group_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tSyncLog = "{$pfx}xf_discord_sync_log";
  if (!arc_table_exists($pdo, $tSyncLog)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tSyncLog}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NOT NULL,
        `status` VARCHAR(20) NOT NULL,
        `error` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user_created` (`user_id`, `created_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // Identity groups (for paid entitlements, etc.)
  $tG = "{$pfx}groups";
  if (!arc_table_exists($pdo, $tG)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tG}` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `slug` VARCHAR(64) NOT NULL,
        `name` VARCHAR(191) NOT NULL,
        `is_paid` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_slug` (`slug`),
        KEY `idx_paid` (`is_paid`, `id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tUG = "{$pfx}user_groups";
  if (!arc_table_exists($pdo, $tUG)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tUG}` (
        `user_id` INT UNSIGNED NOT NULL,
        `group_id` INT UNSIGNED NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`, `group_id`),
        KEY `idx_group` (`group_id`, `user_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // Seed a default paid group
  if (arc_table_exists($pdo, $tG)) {
    try {
      $stmt = $pdo->prepare("SELECT id FROM `{$tG}` WHERE slug='paid' LIMIT 1");
      $stmt->execute();
      $exists = (int)($stmt->fetchColumn() ?: 0);
      if ($exists <= 0) {
        $pdo->prepare("INSERT INTO `{$tG}` (slug, name, is_paid, created_at, updated_at) VALUES ('paid', 'Paid', 1, NOW(), NOW())")->execute();
      }
    } catch (Throwable $e) {}
  }

  // Tickets (feedback / support)
  $tTickets = "{$pfx}tickets";
  if (!arc_table_exists($pdo, $tTickets)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tTickets}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NOT NULL,
        `subject` VARCHAR(191) NOT NULL,
        `status` ENUM('open','closed') NOT NULL DEFAULT 'open',
        `last_message_at` DATETIME NULL,
        `last_message_by` ENUM('user','admin') NULL,
        `closed_at` DATETIME NULL,
        `closed_by` INT UNSIGNED NULL,
        `created_at` DATETIME NOT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user_updated` (`user_id`, `updated_at`),
        KEY `idx_status_updated` (`status`, `updated_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  $tTM = "{$pfx}ticket_messages";
  if (!arc_table_exists($pdo, $tTM)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tTM}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `ticket_id` BIGINT UNSIGNED NOT NULL,
        `user_id` INT UNSIGNED NULL,
        `is_staff` TINYINT(1) NOT NULL DEFAULT 0,
        `message` MEDIUMTEXT NOT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_ticket_id` (`ticket_id`, `id`),
        KEY `idx_user_id` (`user_id`, `id`),
        FULLTEXT KEY `ft_message` (`message`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }


  // Mail queue
  $tMail = "{$pfx}xf_mail_queue";
  if (!arc_table_exists($pdo, $tMail)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tMail}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `to_email` VARCHAR(191) NOT NULL,
        `subject` VARCHAR(255) NOT NULL,
        `html_body` MEDIUMTEXT NULL,
        `text_body` MEDIUMTEXT NULL,
        `status` ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
        `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
        `last_error` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        `sent_at` DATETIME NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status_created` (`status`, `created_at`),
        KEY `idx_attempts` (`attempts`, `status`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }
  if (arc_table_exists($pdo, $tMail)) {
    arc_add_column($pdo, $tMail, 'last_attempt_at', "`last_attempt_at` DATETIME NULL");
    arc_add_column($pdo, $tMail, 'next_attempt_at', "`next_attempt_at` DATETIME NULL");
  }

  // Mail log
  $tMailLog = "{$pfx}xf_mail_log";
  if (!arc_table_exists($pdo, $tMailLog)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tMailLog}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `queue_id` BIGINT UNSIGNED NULL,
        `to_email` VARCHAR(191) NOT NULL,
        `subject` VARCHAR(255) NOT NULL,
        `status` VARCHAR(20) NOT NULL,
        `error` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status_created` (`status`, `created_at`),
        KEY `idx_queue` (`queue_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // Analytics events
  $tAnalytics = "{$pfx}xf_analytics_events";
  if (!arc_table_exists($pdo, $tAnalytics)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tAnalytics}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `created_at` DATETIME NOT NULL,
        `path` VARCHAR(255) NOT NULL,
        `route_type` VARCHAR(32) NOT NULL,
        `user_id` INT UNSIGNED NULL,
        `session_id` VARCHAR(128) NOT NULL,
        `ip_hash` CHAR(64) NOT NULL,
        `ua_hash` CHAR(64) NOT NULL,
        `referrer` VARCHAR(255) NULL,
        `is_bot` TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        KEY `idx_created` (`created_at`),
        KEY `idx_route` (`route_type`, `created_at`),
        KEY `idx_session` (`session_id`, `created_at`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }

  // User profile prefs
  $tProfilePrefs = "{$pfx}user_profile_prefs";
  if (!arc_table_exists($pdo, $tProfilePrefs)) {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$tProfilePrefs}` (
        `user_id` INT UNSIGNED NOT NULL,
        `layout_json` TEXT NULL,
        `css_vars` TEXT NULL,
        `updated_at` DATETIME NOT NULL,
        PRIMARY KEY (`user_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {}
  }


}



