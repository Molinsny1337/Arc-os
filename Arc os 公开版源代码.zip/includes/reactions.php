<?php
declare(strict_types=1);

function arc_reaction_types(): array {
  return [
    'like' => ['label'=>'赞','emoji'=>'👍'],
    'love' => ['label'=>'爱心','emoji'=>'❤️'],
    'laugh' => ['label'=>'哈哈','emoji'=>'😂'],
    'wow' => ['label'=>'惊讶','emoji'=>'😮'],
    'sad' => ['label'=>'难过','emoji'=>'😢'],
    'angry' => ['label'=>'生气','emoji'=>'😡'],
  ];
}

function arc_reaction_summary(PDO $pdo, string $pfx, int $postId): array {
  try {
    $stmt = $pdo->prepare("SELECT reaction, COUNT(*) c FROM {$pfx}post_reactions WHERE post_id=? GROUP BY reaction");
    $stmt->execute([$postId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $out = [];
    foreach ($rows as $r) $out[(string)$r['reaction']] = (int)$r['c'];
    return $out;
  } catch (Throwable $e) {
    return [];
  }
}

function arc_user_reactions(PDO $pdo, string $pfx, int $postId, int $userId): array {
  try {
    $stmt = $pdo->prepare("SELECT reaction FROM {$pfx}post_reactions WHERE post_id=? AND user_id=?");
    $stmt->execute([$postId, $userId]);
    $rows = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];
    return array_values(array_unique(array_map('strval', $rows)));
  } catch (Throwable $e) {
    return [];
  }
}
