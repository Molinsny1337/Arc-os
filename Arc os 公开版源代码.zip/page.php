<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$slug = trim((string)($_GET['slug'] ?? ''));
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$pdo = db();
$pfx = table_prefix();

// Back-compat: allow ?id=123 then redirect to canonical slug URL.
if ($slug === '' && $id > 0) {
  $st = $pdo->prepare("SELECT slug FROM {$pfx}posts WHERE id=? AND type='page' LIMIT 1");
  $st->execute([$id]);
  $rowSlug = (string)($st->fetchColumn() ?: '');
  if ($rowSlug !== '') redirect(url('page.php?slug=' . urlencode($rowSlug)));
}

if ($slug === '') {
  http_response_code(404);
  $title = t('not_found');
  include __DIR__ . '/partials/page_top.php';
  echo '<main class="wrap"><header class="hero reveal-group"><h1 class="reveal">' . e(t('not_found')) . '</h1></header></main>';
  include __DIR__ . '/partials/page_bottom.php';
  exit;
}

$me = current_user();
$isAdmin = function_exists('is_admin') ? is_admin() : false;

if ($isAdmin) {
  $stmt = $pdo->prepare("SELECT id, title, content, created_at, status FROM {$pfx}posts WHERE slug=? AND type='page' LIMIT 1");
  $stmt->execute([$slug]);
} else {
  $stmt = $pdo->prepare("SELECT id, title, content, created_at, status FROM {$pfx}posts WHERE slug=? AND type='page' AND status='published' LIMIT 1");
  $stmt->execute([$slug]);
}
$page = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

if (!$page) {
  http_response_code(404);
  $title = t('not_found');
} else {
  $title = (string)$page['title'];
  arc_log('view_page', 'page', (int)$page['id']);
}

include __DIR__ . '/partials/page_top.php';
?>

<main class="wrap">
  <header class="hero reveal-group">
    <h1 class="reveal"><?= e($page ? (string)$page['title'] : t('not_found')) ?></h1>
    <?php if ($page): ?>
      <p class="reveal"><?= e((string)$page['created_at']) ?><?php if (!empty($page['status']) && $page['status'] !== 'published'): ?> · <?= e((string)$page['status']) ?><?php endif; ?></p>
    <?php endif; ?>
  </header>

  <section class="section reveal-group">
    <div class="card reveal">
      <?= $page ? arc_render_richtext((string)$page['content']) : ('<a data-transition="off" href="' . e(url('index.php')) . '">' . e(t('home')) . '</a>') ?>
    </div>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>

