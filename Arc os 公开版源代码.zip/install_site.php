<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

if (!is_installed()) {
  redirect(url('install.php'));
}

if (!is_admin()) {
  // 只有管理员 / 超管可以访问站点设置向导
  redirect(url('index.php'));
}

$err = '';
$configText = '';
$pdo = db();
$prefix = table_prefix();

// 读取当前设置（若不存在则给默认）
$siteName       = get_setting('site_name', 'Arc OS');
$homeTitle      = get_setting('home_title', $siteName);
$homeSubtitle   = get_setting('home_subtitle', '');
$homeTagline    = get_setting('home_tagline', t('default_home_tagline'));
$transitionText = get_setting('transition_text', t('default_transition_text'));
$siteIcon       = get_setting('site_icon', '');
$home_typewriter_enabled = get_setting('home_typewriter_enabled', '1') === '1';
$home_type_speed_ms = (string)get_setting('home_type_speed_ms', '42');
$canFavicon = class_exists('ArcOS\\Services\\FeatureGate') ? ArcOS\Services\FeatureGate::enabled('favicon') : false;

$u = current_user();
$admin_display_name = '';
if ($u) {
  $admin_display_name = trim((string)($u['display_name'] ?? ''));
  if ($admin_display_name === '') $admin_display_name = (string)($u['username'] ?? '');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $siteName       = trim($_POST['site_name'] ?? $siteName);
  $homeTitle      = trim($_POST['home_title'] ?? $homeTitle);
  $homeSubtitle   = trim($_POST['home_subtitle'] ?? $homeSubtitle);
  $homeTagline    = trim($_POST['home_tagline'] ?? $homeTagline);
  $transitionText = trim($_POST['transition_text'] ?? $transitionText);
  $admin_display_name = trim((string)($_POST['admin_display_name'] ?? $admin_display_name));

  $home_typewriter_enabled = isset($_POST['home_typewriter_enabled']);
  $speed = (int)($_POST['home_type_speed_ms'] ?? $home_type_speed_ms);
  if ($speed < 10) $speed = 10;
  if ($speed > 500) $speed = 500;
  $home_type_speed_ms = (string)$speed;


  try {
    // 站点图标上传（可选）
    if (!empty($_FILES['site_icon']['tmp_name'] ?? '') && is_uploaded_file($_FILES['site_icon']['tmp_name'])) {
      if (!$canFavicon && class_exists('ArcOS\\Services\\FeatureGate')) {
        ArcOS\Services\FeatureGate::deny('favicon');
      }
      if ($canFavicon) {
        $tmp = (string)($_FILES['site_icon']['tmp_name'] ?? '');
        $name = (string)($_FILES['site_icon']['name'] ?? '');
        $ext = function_exists('detect_upload_image_ext') ? detect_upload_image_ext($tmp, $name) : '';
        if (in_array($ext, ['jpg','png','gif','webp','ico'], true)) {
          $upDir = __DIR__ . '/uploads';
          if (!is_dir($upDir)) @mkdir($upDir, 0755, true);
          $fname = 'icon_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
          $dest = $upDir . '/' . $fname;
          if (@move_uploaded_file($tmp, $dest)) {
            $siteIcon = 'uploads/' . $fname;
          }
        }
      }
    }

    $stmtS = $pdo->prepare("INSERT INTO {$prefix}settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v=VALUES(v)");
    $stmtS->execute(['site_name', $siteName]);
    $stmtS->execute(['home_title', $homeTitle]);
    $stmtS->execute(['home_subtitle', $homeSubtitle]);
    $stmtS->execute(['home_tagline', $homeTagline]);
    $stmtS->execute(['transition_text', $transitionText]);
    $stmtS->execute(['home_typewriter_enabled', $home_typewriter_enabled ? '1' : '0']);
    $stmtS->execute(['home_type_speed_ms', (string)$home_type_speed_ms]);
    if ($siteIcon !== '') { $stmtS->execute(['site_icon', $siteIcon]); }
    $stmtS->execute(['setup_complete', '1']);

    // 管理员显示名称（账号与展示名分离）
    if ($admin_display_name !== '' && $u) {
      if (mb_strlen($admin_display_name, 'UTF-8') > 32 || preg_match('/\s/u', $admin_display_name)) {
        throw new RuntimeException(t('invalid_display_name'));
      }
      $stmtU = $pdo->prepare("UPDATE {$prefix}users SET display_name=?, updated_at=NOW() WHERE id=?");
      $stmtU->execute([$admin_display_name, (int)$u['id']]);
      // 同步 session
      refresh_session_user((int)$u['id']);
      $u = current_user();
    }

    $adminName = $u ? (function_exists('display_name_of') ? display_name_of($u) : ((string)($u['username'] ?? 'admin'))) : 'admin';

    // 完成后：水波纹过渡进入后台
    $adminHome = function_exists('admin_url') ? admin_url('index') : url('admin/index.php');
    redirect(url('transition.php') . '?hello=' . urlencode($adminName) . '&msg=' . urlencode($siteName) . '&to=' . urlencode($adminHome));
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php $title = t('site_setup') . ' · ' . site_name(); include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <div class="overlay">
    <div class="overlay-card">
      <div class="title"><?= e(t('saving')) ?></div>
      <div class="sub"><?= e(t('please_wait')) ?></div>
    </div>
  </div>
  <?php include __DIR__ . '/partials/nav.php'; ?>
  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('site_basic_info')) ?></h1>
      <p class="reveal"><?= e(t('site_setup_sub')) ?></p>
    </header>

    <?php if ($err): ?>
      <div class="alert reveal"><?= e($err) ?></div>
    <?php endif; ?>

    <section class="reveal-group">
      <form class="form reveal" method="post" enctype="multipart/form-data" data-overlay="1">
        <div class="field">
          <label class="label"><?= e(t('site_name')) ?></label>
          <input class="input" name="site_name" value="<?= e($siteName) ?>" required />
        </div>

        <div class="field">
          <label class="label"><?= e(t('admin_display_name')) ?></label>
          <input class="input" name="admin_display_name" value="<?= e($admin_display_name) ?>" placeholder="<?= e(t('display_name_placeholder')) ?>" />
          <div class="note"><?= e(t('admin_display_name_note')) ?></div>
        </div>

        <div class="field">
          <label class="label"><?= e(t('home_title')) ?></label>
          <input class="input" name="home_title" value="<?= e($homeTitle) ?>" />
        </div>

        <div class="field">
          <label class="label"><?= e(t('home_subtitle')) ?></label>
          <input class="input" name="home_subtitle" value="<?= e($homeSubtitle) ?>" placeholder="<?= e(t('optional')) ?>" />
        </div>

        <div class="field">
          <label class="label"><?= e(t('home_slogan')) ?></label>
          <input class="input" name="home_tagline" value="<?= e($homeTagline) ?>" />
        </div>

        <div class="field">
          <label class="label" style="display:flex;gap:10px;align-items:center;">
            <input type="checkbox" name="home_typewriter_enabled" <?= $home_typewriter_enabled ? 'checked' : '' ?> />
            <?= e(t('home_typewriter')) ?>
          </label>
          <div class="note"><?= e(t('home_typewriter_note')) ?></div>
        </div>

        <div class="field">
          <label class="label"><?= e(t('home_type_speed')) ?></label>
          <input class="input" name="home_type_speed_ms" value="<?= e($home_type_speed_ms) ?>" type="number" min="10" max="500" />
          <div class="note"><?= e(t('home_type_speed_note')) ?></div>
        </div>

        <div class="field">
          <label class="label"><?= e(t('transition_text')) ?></label>
          <input class="input" name="transition_text" value="<?= e($transitionText) ?>" placeholder="<?= e(t('default_transition_text')) ?>" />
        </div>

        <div class="field">
          <label class="label"><?= e(t('site_icon')) ?> (favicon, <?= e(t('optional')) ?>)</label>
          <?php if ($canFavicon): ?>
            <input class="input" type="file" name="site_icon" accept=".png,.jpg,.jpeg,.gif,.webp,.ico,.svg" />
            <?php if ($siteIcon): ?>
              <div class="note"><?= e(t('current')) ?>：<code><?= e($siteIcon) ?></code></div>
            <?php endif; ?>
          <?php else: ?>
            <div class="note">Custom favicon is available in Pro/Business.</div>
          <?php endif; ?>
        </div>

        <button class="btn" type="submit"><?= e(t('finish_setup')) ?></button>
      </form>
    </section>
  </main>

  <script src="<?= e(url('assets/app.js')) ?>"></script>
</body>
</html>
