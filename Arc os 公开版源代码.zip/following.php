<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

require_once __DIR__ . '/includes/profile_xf.php';
require_once __DIR__ . '/includes/services/ProfileService.php';

$me = current_user();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
  http_response_code(404);
  exit(t('missing_user_id'));
}

$pdo = db();
$pfx = table_prefix();

$cols = function_exists('arc_user_table_columns') ? arc_user_table_columns() : [];
$avatarCol = isset($cols['avatar']) ? 'avatar' : (isset($cols['avatar_url']) ? 'avatar_url' : '');
$titleCol = isset($cols['user_title']) ? 'user_title' : '';

$select = "id, username, role";
if ($avatarCol !== '') $select .= ", `{$avatarCol}` AS avatar";
if ($titleCol !== '') $select .= ", `{$titleCol}` AS user_title";

$st = $pdo->prepare("SELECT {$select} FROM {$pfx}users WHERE id=? LIMIT 1");
$st->execute([$id]);
$u = $st->fetch(PDO::FETCH_ASSOC);
if (!$u) {
  http_response_code(404);
  exit(t('user_not_found'));
}

// Privacy: show followers list (applies to following list too)
$privacy = ArcOS\Services\ProfileService::privacy(
  ArcOS\Services\ProfileService::getProfile($pdo, $pfx, $id)
);
if (!(bool)($privacy['show_followers'] ?? true) && (!$me || (int)$me['id'] !== (int)$id) && !is_admin()) {
  http_response_code(403);
  exit(t('permission_denied'));
}

$limit = 30;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

$st = $pdo->prepare("
  SELECT {$select}
  FROM {$pfx}xf_user_follow f
  JOIN {$pfx}users u ON u.id = f.followed_id
  WHERE f.follower_id = ?
  ORDER BY f.created_at DESC
  LIMIT ? OFFSET ?
");
$st->bindValue(1, $id, PDO::PARAM_INT);
$st->bindValue(2, $limit, PDO::PARAM_INT);
$st->bindValue(3, $offset, PDO::PARAM_INT);
$st->execute();
$list = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

$st = $pdo->prepare("SELECT COUNT(*) FROM {$pfx}xf_user_follow WHERE follower_id=?");
$st->execute([$id]);
$total = (int)$st->fetchColumn();
$total_pages = max(1, (int)ceil($total / $limit));

function role_label(?string $r): string {
  $r = (string)$r;
  if ($r === 'superadmin' || $r === 'owner') return t('role_owner');
  if ($r === 'admin') return t('role_admin');
  return t('role_user');
}

$title = sprintf(t('following_of'), (string)$u['username']);
$__need_glass = true;
include __DIR__ . '/partials/page_top.php';
?>

<main class="container" style="max-width: 980px; padding:16px 0;">
  <div class="xf-side-block">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;gap:12px;flex-wrap:wrap">
      <h1 style="margin:0;font-size:20px;"><?= e(sprintf(t('following_of'), (string)$u['username'])) ?></h1>
      <a class="btn" data-transition="1" href="<?= e(url('user.php?id=' . (int)$u['id'])) ?>"><?= e(t('back_profile')) ?></a>
    </div>

    <div class="xf-follow-list" style="margin-top:12px;">
      <?php if (!$list): ?>
        <div class="muted"><?= e(t('empty_here')) ?></div>
      <?php endif; ?>

          <?php foreach ($list as $row): ?>
        <div class="xf-follow-row">
          <a class="xf-follow-avatar" href="<?= e(url('user.php?id=' . (int)$row['id'])) ?>">
            <img src="<?= e(arc_avatar_url(!empty($row['avatar']) ? (string)$row['avatar'] : '')) ?>" alt="">
          </a>
          <div class="xf-follow-main">
            <div class="xf-follow-top">
              <a class="xf-follow-name" href="<?= e(url('user.php?id=' . (int)$row['id'])) ?>"><?= e((string)$row['username']) ?></a>
              <span class="xf-badge"><?= e(role_label($row['role'] ?? 'user')) ?></span>
            </div>
            <?php if (!empty($row['user_title'])): ?>
              <div class="xf-follow-title"><?= e((string)$row['user_title']) ?></div>
            <?php endif; ?>
          </div>

          <?php if ($me && (int)$me['id'] !== (int)$row['id']): ?>
            <form method="post" action="<?= e(url('follow.php')) ?>" class="xf-follow-action">
              <?= csrf_field() ?>
              <input type="hidden" name="user_id" value="<?= (int)$row['id'] ?>">
              <input type="hidden" name="action" value="toggle">
              <button class="btn btn-sm" type="submit"><?= e(t('follow_toggle')) ?></button>
            </form>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if ($total_pages > 1): ?>
      <div class="xf-pager">
        <?php for ($p=1; $p<=$total_pages; $p++): ?>
          <a class="<?= $p===$page ? 'active' : '' ?>" href="<?= e(url('following.php?id='.(int)$id.'&page='.$p)) ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
