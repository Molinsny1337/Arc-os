<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$me = current_user();
if (!$me) redirect(url('login.php?next=' . urlencode(url('conversations.php'))));
require_not_banned();

$pdo = db();
$pfx = table_prefix();

$rows = [];
try {
  $stmt = $pdo->prepare("SELECT c.*
    FROM {$pfx}conversations c
    JOIN {$pfx}conversation_participants cp ON cp.conversation_id=c.id
    WHERE cp.user_id=? AND cp.is_left=0
    ORDER BY COALESCE(c.last_message_at, c.created_at) DESC, c.id DESC
    LIMIT 50");
  $stmt->execute([(int)$me['id']]);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $rows = [];
}

$title = site_name() . ' - ' . t('conversations');
$__need_glass = true;
?>
<?php include __DIR__ . '/partials/page_top.php'; ?>

<main class="wrap">
  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e(t('conversations')) ?></h1>
      <p class="reveal"><?= e(t('conversations_sub')) ?></p>
    </div>
    <div class="card glass xf-hero-card reveal" style="display:flex;align-items:center;justify-content:center">
      <a class="btn" href="<?= e(url('conversation_new.php')) ?>"><?= e(t('new_conversation')) ?></a>
    </div>
  </header>

  <section class="section reveal-group">
    <div class="card glass reveal">
      <?php if (!$rows): ?>
        <div class="muted"><?= e(t('no_data')) ?></div>
      <?php else: ?>
        <div class="xf-stack">
          <?php foreach ($rows as $c): ?>
            <?php
              $cid = (int)($c['id'] ?? 0);
              $label = trim((string)($c['title'] ?? ''));
              if ($label === '') $label = t('conversation') . ' #' . $cid;
              $when = (string)($c['last_message_at'] ?? $c['created_at'] ?? '');
            ?>
            <a class="xf-conv-row" href="<?= e(url('conversation.php?id=' . $cid)) ?>">
              <span class="xf-avatar" aria-hidden="true">C</span>
              <div style="min-width:0">
                <div class="xf-thread-title"><?= e($label) ?></div>
                <?php if ($when !== ''): ?><div class="xf-meta"><?= e(t('updated')) ?>: <?= e($when) ?></div><?php endif; ?>
              </div>
              <div class="xf-stats">#<?= $cid ?></div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
