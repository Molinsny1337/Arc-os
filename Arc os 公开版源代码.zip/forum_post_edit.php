<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();

require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';

$perm = new ArcOS\Services\Permission();
$me = current_user();
$meId = (int)($me['id'] ?? 0);

$pdo = db();
$pfx = table_prefix();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  redirect(url('forum.php'));
}

$stmt = $pdo->prepare("SELECT id, title, content, slug, author_id, forum_id, is_locked FROM {$pfx}posts WHERE id=? AND type='forum' LIMIT 1");
$stmt->execute([$id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) {
  redirect(url('forum.php'));
}

$authorId = (int)($post['author_id'] ?? 0);
$canEdit = $perm->can($me, 'edit_own_post') && $authorId === $meId;
if (!$canEdit && !is_admin()) {
  http_response_code(403);
  exit('Forbidden');
}

$error = '';
$success = '';
$formTitle = (string)($post['title'] ?? '');
$formContent = (string)($post['content'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_post();
  require_csrf();
  require_not_banned();

  $formTitle = trim((string)($_POST['title'] ?? ''));
  $formContent = ArcOS\Services\BbCode::normalize((string)($_POST['content'] ?? ''));

  try {
    if ($formTitle === '') throw new RuntimeException(t('title_required'));
    if (trim(strip_tags($formContent)) === '') throw new RuntimeException(t('content_required'));

    $plain = ArcOS\Services\BbCode::plainText($formContent);
    $plain = trim(preg_replace('/\s+/', ' ', $plain) ?? '');
    $ex = mb_substr($plain, 0, 80, 'UTF-8');

    $stmt = $pdo->prepare("UPDATE {$pfx}posts
      SET title=?, content=?, excerpt=?, updated_at=NOW(), edit_count=edit_count+1, last_edit_at=NOW(), last_edit_by=?
      WHERE id=? AND type='forum'");
    $stmt->execute([$formTitle, $formContent, $ex, $meId, $id]);

    $pdo->prepare("DELETE FROM {$pfx}xf_content_tags WHERE content_type='thread' AND content_id=?")
      ->execute([$id]);
    $tags = ArcOS\Services\MentionService::extractTags($formContent);
    ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'thread', $id, $tags);
    ArcOS\Services\MentionService::syncMentions($pdo, $pfx, $meId, 'thread', $id, $formContent);

    $success = t('saved');
  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}

$title = t('edit') . ' - ' . site_name();
$__need_editor = true;
$__need_glass = true;
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap xf-apple">
    <header class="hero xf-hero reveal-group">
      <div>
        <h1 class="reveal"><?= e(t('edit')) ?></h1>
        <p class="reveal"><?= e((string)($post['title'] ?? '')) ?></p>
      </div>
      <div class="card glass xf-hero-card reveal">
        <a class="btn" href="<?= e(url('forum_post.php?slug=' . urlencode((string)($post['slug'] ?? '')))) ?>"><?= e(t('back')) ?></a>
      </div>
    </header>

    <?php if ($success): ?><div class="notice success reveal"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice danger reveal"><?= e($error) ?></div><?php endif; ?>

    <section class="section reveal-group">
      <form class="form glass reveal" method="post">
        <?= csrf_field() ?>
        <div class="field">
          <label class="label"><?= e(t('title')) ?></label>
          <input class="input" name="title" value="<?= e($formTitle) ?>" required />
        </div>
        <div class="field">
          <label class="label"><?= e(t('content')) ?></label>
          <?php
            $content_name = 'content';
            $initial_value = $formContent;
            $mode = 'thread';
            $attachments_enabled = true;
            $placeholder = t('content_placeholder');
            $content_id = (int)$id;
            $draft_key = 'thread_edit_' . (int)$id . '_' . $meId;
            include __DIR__ . '/partials/editor/editor_widget.php';
          ?>
        </div>
        <button class="btn primary" type="submit"><?= e(t('save')) ?></button>
      </form>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
