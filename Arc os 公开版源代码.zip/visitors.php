<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_once __DIR__ . '/includes/services/ProfileService.php';

if (function_exists('get_setting') && get_setting('profile_visitors_enabled', '1') !== '1') {
  http_response_code(403);
  exit('Visitors disabled');
}

$pdo = db();
$pfx = table_prefix();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0 && isset($_GET['u'])) $id = (int)$_GET['u'];

$stmt = $pdo->prepare("SELECT id, username, role, avatar FROM `{$pfx}users` WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$u) {
  http_response_code(404);
  exit(t('user_not_found'));
}

$privacy = ArcOS\Services\ProfileService::privacy(
  ArcOS\Services\ProfileService::getProfile($pdo, $pfx, (int)$u['id'])
);
if (!(bool)($privacy['show_visitors'] ?? true) && (!current_user() || (int)current_user()['id'] !== (int)$u['id']) && !is_admin()) {
  http_response_code(403);
  exit(t('permission_denied'));
}

$visitors = [];
try {
  $st = $pdo->prepare("SELECT pv.visitor_id, pv.visited_at, uu.username, uu.avatar, uu.role
                       FROM `{$pfx}xf_profile_visitors` pv
                       JOIN `{$pfx}users` uu ON uu.id = pv.visitor_user_id
                       WHERE pv.user_id=?
                       ORDER BY pv.visited_at DESC
                       LIMIT 60");
  $st->execute([(int)$u['id']]);
  $visitors = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $visitors = [];
}

$title = sprintf(t('recent_visitors_of'), (string)$u['username']);
$__need_glass = true;
include __DIR__ . '/partials/page_top.php';
?>

<main class="container" style="padding:16px 0;">
  <div class="card glass" style="max-width:860px;margin:0 auto">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
      <div>
        <h1 style="margin:0;font-size:22px"><?= e(t('recent_visitors')) ?></h1>
        <div style="margin-top:6px;color:rgba(0,0,0,.55)"><?= e(sprintf(t('recent_visitors_sub'), (string)$u['username'])) ?></div>
      </div>
      <a class="btn" data-transition="1" href="<?= e(url('user.php?id='.(int)$u['id'])) ?>"><?= e(t('back_profile')) ?></a>
    </div>

    <div style="height:14px"></div>

    <?php if (empty($visitors)): ?>
      <div class="empty"><?= e(t('no_visitors')) ?></div>
    <?php else: ?>
      <div class="xf-visit-page">
        <?php foreach ($visitors as $vv): ?>
          <a class="xf-visit-row" data-transition="1" href="<?= e(url('user.php?id='.(int)$vv['visitor_id'])) ?>">
            <span class="xf-visit-avatar lg">
              <?php if (!empty($vv['avatar'])): ?>
                <img src="<?= e(arc_avatar_url((string)$vv['avatar'])) ?>" alt="" />
              <?php else: ?>
                <span class="t"><?= e(mb_strtoupper(mb_substr((string)$vv['username'], 0, 1))) ?></span>
              <?php endif; ?>
            </span>
            <span class="name"><?= e((string)$vv['username']) ?></span>
            <span class="date"><?= e((string)$vv['visited_at']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
