<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$slug = trim((string)($_GET['slug'] ?? ''));
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$pdo = db();
$pfx = table_prefix();

// Back-compat: allow ?id=123 then redirect to canonical slug URL.
if ($slug === '' && $id > 0) {
  $st = $pdo->prepare("SELECT slug, type FROM {$pfx}posts WHERE id=? AND status='published' LIMIT 1");
  $st->execute([$id]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if ($row && !empty($row['slug'])) {
    $type = (string)($row['type'] ?? 'forum');
    if ($type === 'forum') redirect(url('forum_post.php?slug=' . urlencode((string)$row['slug'])));
    if ($type === 'page') redirect(url('page.php?slug=' . urlencode((string)$row['slug'])));
  }
}

if ($slug !== '') {
  $stmt = $pdo->prepare("SELECT id, slug, type, status FROM {$pfx}posts WHERE slug=? LIMIT 1");
  $stmt->execute([$slug]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($row && (string)($row['status'] ?? '') === 'published') {
    $type = (string)($row['type'] ?? '');
    if ($type === 'forum') {
      redirect(url('forum_post.php?slug=' . urlencode((string)$row['slug'])));
    }
    if ($type === 'page') {
      redirect(url('page.php?slug=' . urlencode((string)$row['slug'])));
    }
  }
}

http_response_code(404);
$title = t('not_found');

$langCode = lang();
?>
<!doctype html>
<html lang="<?= e($langCode) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap">
    <header class="hero reveal-group">
      <h1 class="reveal"><?= e(t('not_found')) ?></h1>
      <p class="reveal"><?= e(t('post_missing')) ?></p>
    </header>

    <section class="section reveal-group">
      <div class="card reveal">
        <a data-transition="off" href="<?= e(url('forum.php')) ?>"><?= e(t('back_forum')) ?></a>
      </div>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
