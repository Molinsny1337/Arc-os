<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();

$me = current_user();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0 && isset($_GET['u'])) $id = (int)$_GET['u'];
if ($id <= 0 && $me) $id = (int)$me['id'];
if ($id <= 0) { http_response_code(400); exit(t('bad_user_id')); }

$pdo = db();
$pfx = table_prefix();

$stmt = $pdo->prepare("SELECT id, username, avatar FROM {$pfx}users WHERE id=? LIMIT 1");
$stmt->execute([$id]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$u) { http_response_code(404); exit(t('user_not_found')); }

$points = function_exists('trophy_total_points') ? trophy_total_points($pdo, $pfx, (int)$u['id']) : 0;
$items = function_exists('trophy_list_for_user') ? trophy_list_for_user($pdo, $pfx, (int)$u['id'], 200) : [];

$title = site_name() . ' · ' . t('trophies') . ' · ' . (string)($u['username'] ?? '');
?>
<?php include __DIR__ . '/partials/page_top.php'; ?>

<main class="wrap">
  <header class="hero reveal-group">
    <h1 class="reveal"><?= e(t('trophies')) ?></h1>
    <p class="reveal"><?= e((string)($u['username'] ?? '')) ?> · <?= (int)$points ?> <?= e(t('points')) ?></p>
  </header>

  <section class="section reveal-group">
    <div class="card reveal">
      <?php if (!$items): ?>
        <div class="muted"><?= e(t('none')) ?></div>
      <?php else: ?>
        <div class="trophy-grid">
          <?php foreach ($items as $tr): ?>
            <div class="trophy">
              <div class="trophy-title"><?= e((string)($tr['title'] ?? '')) ?></div>
              <div class="trophy-desc"><?= e((string)($tr['description'] ?? '')) ?></div>
              <div class="muted" style="margin-top:8px;font-size:12px;">
                <?= (int)($tr['points'] ?? 0) ?> <?= e(t('points')) ?>
                <?php if (!empty($tr['awarded_at'])): ?> · <?= e(substr((string)$tr['awarded_at'], 0, 10)) ?><?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>

