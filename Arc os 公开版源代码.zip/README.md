# Apple Ripple PHP Blog (Pro / Minimal)

特点：
- PHP + MySQL，一键安装（类似 WP）：访问 /install.php 填数据库信息即可
- 独立过渡页 transition.php：黑底白字 + 中心/点击位置水波纹露出白色，结束进入目标页（白底黑字）
- 登录成功过渡文案：transition.php?hello=用户名 → 显示「你好 用户名」
- 顶部导航链接来自数据库（后台可管理）
- 点击站内链接：音效 + 自动走过渡页（JS 拦截，水波纹从点击位置开始；可用 data-transition="off" 禁用）
- 前台滚动 reveal 动画：Apple 风（位移 + 透明 + 克制缓动）
- 后台：文章管理 + 导航链接管理（大道至简）

部署：
1) 上传解压到站点目录（支持子目录）
2) 创建 MySQL 数据库和用户，并授予权限
3) 浏览器访问 /install.php，填写信息，点 Install

安全建议：
- 安装完成后可以删除 install.php（可选）
- includes/config.php 保存 DB 信息，请确保服务器权限合理

入口：
- 前台：/index.php
- 过渡页：/transition.php
- 后台：/admin/index.php


## Admin UI
- Dashboard/Posts/Links 使用更接近 WP 的布局（侧边栏 + 表格 + 操作按钮）
- 轻微入场动画（不影响性能）


## Registration & Forum
- /register.php 注册（邮箱验证）
- /verify.php?token=... 验证邮箱
- /forum.php 论坛
- 管理员：/admin/users.php 审核用户发帖权限；/admin/settings.php 可关闭验证/审核要求


## vNext (Aggressive)
- Forums nodes, thread tools
- Alerts + @mentions
- Conversations (private messages)
- Reactions (emoji)
- Attachments
- Trophies
- What's new feed
- Member list
- Profile posts wall
