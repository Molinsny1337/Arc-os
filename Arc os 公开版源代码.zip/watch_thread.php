<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_post();
require_csrf();
require_not_banned();

require_once __DIR__ . '/includes/services/WatchService.php';

$me = current_user();
$meId = (int)($me['id'] ?? 0);
$id = (int)($_POST['id'] ?? 0);
$back = $_SERVER['HTTP_REFERER'] ?? url('forum.php');
if ($id <= 0) redirect($back);

$pdo = db();
$pfx = table_prefix();
ArcOS\Services\WatchService::toggleThread($pdo, $pfx, $meId, $id);

redirect($back);
