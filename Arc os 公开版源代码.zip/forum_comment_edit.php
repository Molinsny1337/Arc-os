<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();

require_once __DIR__ . '/includes/services/Permission.php';
require_once __DIR__ . '/includes/services/BbCode.php';
require_once __DIR__ . '/includes/services/MentionService.php';

$perm = new ArcOS\Services\Permission();
$me = current_user();
$meId = (int)($me['id'] ?? 0);

$pdo = db();
$pfx = table_prefix();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect(url('forum.php'));

$stmt = $pdo->prepare("SELECT c.id, c.content, c.author_id, c.post_id, p.slug, p.is_locked
  FROM {$pfx}post_comments c
  JOIN {$pfx}posts p ON p.id=c.post_id
  WHERE c.id=? LIMIT 1");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) redirect(url('forum.php'));

$authorId = (int)($row['author_id'] ?? 0);
$canEdit = $perm->can($me, 'edit_own_post') && $authorId === $meId;
if (!$canEdit && !is_admin()) {
  http_response_code(403);
  exit('Forbidden');
}

$error = '';
$success = '';
$formContent = (string)($row['content'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  require_post();
  require_csrf();
  require_not_banned();

  $formContent = ArcOS\Services\BbCode::normalize((string)($_POST['content'] ?? ''));

  try {
    if (trim(strip_tags($formContent)) === '') throw new RuntimeException(t('content_required'));

    $stmt = $pdo->prepare("UPDATE {$pfx}post_comments
      SET content=?, updated_at=NOW(), edit_count=edit_count+1, last_edit_at=NOW(), last_edit_by=?
      WHERE id=?");
    $stmt->execute([$formContent, $meId, $id]);

    $pdo->prepare("DELETE FROM {$pfx}xf_content_tags WHERE content_type='post_comment' AND content_id=?")
      ->execute([$id]);
    $tags = ArcOS\Services\MentionService::extractTags($formContent);
    ArcOS\Services\MentionService::syncTags($pdo, $pfx, 'post_comment', $id, $tags);
    ArcOS\Services\MentionService::syncMentions($pdo, $pfx, $meId, 'post_comment', $id, $formContent);

    $success = t('saved');
  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}

$title = t('edit') . ' - ' . site_name();
$__need_editor = true;
$__need_glass = true;
?>
<!doctype html>
<html lang="<?= e(lang()) ?>">
<head>
  <?php include __DIR__ . '/partials/head.php'; ?>
</head>
<body>
  <?php include __DIR__ . '/partials/nav.php'; ?>

  <main class="wrap xf-apple">
    <header class="hero xf-hero reveal-group">
      <div>
        <h1 class="reveal"><?= e(t('edit')) ?></h1>
        <p class="reveal"><?= e(t('reply')) ?></p>
      </div>
      <div class="card glass xf-hero-card reveal">
        <a class="btn" href="<?= e(url('forum_post.php?slug=' . urlencode((string)($row['slug'] ?? '')))) ?>"><?= e(t('back')) ?></a>
      </div>
    </header>

    <?php if ($success): ?><div class="notice success reveal"><?= e($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice danger reveal"><?= e($error) ?></div><?php endif; ?>

    <section class="section reveal-group">
      <form class="form glass reveal" method="post">
        <?= csrf_field() ?>
        <div class="field">
          <label class="label"><?= e(t('content')) ?></label>
          <?php
            $content_name = 'content';
            $initial_value = $formContent;
            $mode = 'post';
            $attachments_enabled = true;
            $placeholder = t('comment');
            $content_id = (int)$id;
            $draft_key = 'comment_edit_' . (int)$id . '_' . $meId;
            include __DIR__ . '/partials/editor/editor_widget.php';
          ?>
        </div>
        <button class="btn primary" type="submit"><?= e(t('save')) ?></button>
      </form>
    </section>
  </main>

  <?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
