<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require_installed();
require_login();
require_not_banned();

$me = current_user();
$alerts = arc_list_alerts((int)$me['id'], 80);
$max_id = $alerts ? (int)$alerts[0]['id'] : null;
if ($max_id) arc_mark_alerts_read((int)$me['id'], $max_id);

$title = t('notifications');
$__need_glass = true;
include __DIR__ . '/partials/page_top.php';
?>

<main class="wrap">
  <header class="hero xf-hero reveal-group">
    <div>
      <h1 class="reveal"><?= e(t('notifications')) ?></h1>
    </div>
    <div class="card glass xf-hero-card reveal">
      <div class="xf-meta"><?= e(t('notifications')) ?>: <?= count($alerts) ?></div>
    </div>
  </header>

  <section class="section reveal-group">
    <div class="card glass reveal">

    <?php if (!$alerts): ?>
      <div class="muted"><?= e(t('no_notifications')) ?></div>
    <?php else: ?>
      <div class="xf-stack">
      <?php foreach ($alerts as $a):
        $from = $a['from_username'] ?: t('system');
        $data = $a['data_arr'] ?? [];
        $when = (string)$a['created_at'];
        $rowTitle = '';
        $rowUrl = url('index.php');

        if ($a['type'] === 'reply' && $a['object_type'] === 'thread') {
          $rowTitle = sprintf(t('alert_reply_thread'), $from);
          $rowUrl = url('forum_post.php?id=' . (int)$a['object_id']);
        } elseif ($a['type'] === 'like' && $a['object_type'] === 'thread') {
          $rowTitle = sprintf(t('alert_like_thread'), $from);
          $rowUrl = url('forum_post.php?id=' . (int)$a['object_id']);
        } elseif ($a['type'] === 'like' && $a['object_type'] === 'post') {
          $rowTitle = sprintf(t('alert_like_post'), $from);
          $postId = (int)$a['object_id'];
          $rowUrl = url('forum_post.php?id=' . $postId);
          try {
            $pdo = db();
            $pfx = table_prefix();
            $stmt = $pdo->prepare("SELECT slug, type FROM {$pfx}posts WHERE id=? LIMIT 1");
            $stmt->execute([$postId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
              $type = (string)($row['type'] ?? '');
              if ($type === 'page') {
                $rowUrl = url('page.php?slug=' . urlencode((string)$row['slug']));
              } else {
                $rowUrl = url('forum_post.php?slug=' . urlencode((string)$row['slug']));
              }
            }
          } catch (Throwable $e) {}
        } elseif ($a['type'] === 'follow') {
          $rowTitle = sprintf(t('alert_follow'), $from);
          $rowUrl = url('user.php?id=' . (int)($a['from_user_id'] ?? 0));
        } elseif ($a['type'] === 'mention') {
          $rowTitle = sprintf(t('alert_mention'), $from);
          if (!empty($data['url'])) $rowUrl = (string)$data['url'];
        } else {
          $rowTitle = sprintf(t('alert_generic'), $from);
        }
      ?>
        <a class="xf-alert-row" href="<?= e($rowUrl) ?>" data-transition="on">
          <span class="xf-avatar" aria-hidden="true">
            <?php if (!empty($a['from_avatar'])): ?>
              <img src="<?= e((string)$a['from_avatar']) ?>" alt="">
            <?php else: ?>
              <span><?= e(mb_strtoupper(mb_substr((string)$from, 0, 1))) ?></span>
            <?php endif; ?>
          </span>
          <div style="min-width:0">
            <div class="xf-thread-title" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($rowTitle) ?></div>
            <div class="xf-meta"><?= e($when) ?></div>
          </div>
          <div class="xf-stats"><?= e(t('view')) ?></div>
        </a>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
    </div>
  </section>
</main>

<?php include __DIR__ . '/partials/page_bottom.php'; ?>
