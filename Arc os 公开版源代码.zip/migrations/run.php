<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/init.php';
require_installed();

$pdo = db();
$pfx = table_prefix();

$ensure = $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}migrations (
  id VARCHAR(190) NOT NULL PRIMARY KEY,
  applied_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$ensure->execute();

if (PHP_SAPI !== 'cli') {
  $me = current_user();
  if (!$me || !is_admin()) {
    http_response_code(403);
    exit('Forbidden');
  }
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('POST required');
  }
  require_csrf();
}

$applied = [];
$stmt = $pdo->prepare("SELECT id FROM {$pfx}migrations");
$stmt->execute();
foreach ($stmt->fetchAll(PDO::FETCH_COLUMN, 0) as $id) {
  $applied[(string)$id] = true;
}

$files = glob(__DIR__ . DIRECTORY_SEPARATOR . '[0-9][0-9][0-9]_*.php') ?: [];
 sort($files);

foreach ($files as $file) {
  $migration = require $file;
  if (!is_array($migration) || empty($migration['id']) || !is_callable($migration['up'])) {
    continue;
  }
  $id = (string)$migration['id'];
  if (isset($applied[$id])) continue;

  $migration['up']($pdo, $pfx);
  $ins = $pdo->prepare("INSERT INTO {$pfx}migrations (id, applied_at) VALUES (?, NOW())");
  $ins->execute([$id]);
}

if (PHP_SAPI === 'cli') {
  echo "migrations complete\n";
} else {
  echo "migrations complete";
}