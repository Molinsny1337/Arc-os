<?php
declare(strict_types=1);

return [
  'id' => '001_xf_extras',
  'up' => function(PDO $pdo, string $pfx): void {
    $collation = 'utf8mb4_0900_ai_ci';
    try {
      $st = $pdo->prepare('SELECT 1 FROM INFORMATION_SCHEMA.COLLATIONS WHERE COLLATION_NAME=?');
      $st->execute([$collation]);
      if (!$st->fetchColumn()) $collation = 'utf8mb4_general_ci';
    } catch (Throwable $e) {
      $collation = 'utf8mb4_general_ci';
    }

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_tags (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      tag VARCHAR(100) NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uniq_tag (tag)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_content_tags (
      tag_id BIGINT UNSIGNED NOT NULL,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (tag_id, content_type, content_id),
      KEY idx_content (content_type, content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_bookmarks (
      user_id BIGINT UNSIGNED NOT NULL,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, content_type, content_id),
      KEY idx_content (content_type, content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_thread_watches (
      user_id BIGINT UNSIGNED NOT NULL,
      thread_id BIGINT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, thread_id),
      KEY idx_thread (thread_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_forum_watches (
      user_id BIGINT UNSIGNED NOT NULL,
      forum_id BIGINT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, forum_id),
      KEY idx_forum (forum_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();
  },
];