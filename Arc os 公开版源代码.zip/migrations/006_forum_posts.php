<?php
declare(strict_types=1);

return [
  'id' => '006_forum_posts',
  'up' => function(PDO $pdo, string $pfx): void {
    $colExists = function(string $table, string $col) use ($pdo): bool {
      try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `{$table}`");
        while ($stmt && ($r = $stmt->fetch(PDO::FETCH_ASSOC))) {
          if (($r['Field'] ?? '') === $col) return true;
        }
      } catch (Throwable $e) {}
      return false;
    };
    $idxExists = function(string $table, string $idx) use ($pdo): bool {
      try {
        $stmt = $pdo->query("SHOW INDEX FROM `{$table}`");
        while ($stmt && ($r = $stmt->fetch(PDO::FETCH_ASSOC))) {
          if (($r['Key_name'] ?? '') === $idx) return true;
        }
      } catch (Throwable $e) {}
      return false;
    };

    $tPosts = $pfx . 'posts';
    if ($colExists($tPosts, 'edit_count') === false) {
      $pdo->exec("ALTER TABLE `{$tPosts}` ADD COLUMN `edit_count` INT UNSIGNED NOT NULL DEFAULT 0");
    }
    if ($colExists($tPosts, 'last_edit_at') === false) {
      $pdo->exec("ALTER TABLE `{$tPosts}` ADD COLUMN `last_edit_at` DATETIME NULL");
    }
    if ($colExists($tPosts, 'last_edit_by') === false) {
      $pdo->exec("ALTER TABLE `{$tPosts}` ADD COLUMN `last_edit_by` INT UNSIGNED NULL");
    }

    $tComments = $pfx . 'post_comments';
    if ($colExists($tComments, 'status') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `status` VARCHAR(16) NOT NULL DEFAULT 'visible'");
    }
    if ($colExists($tComments, 'edit_count') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `edit_count` INT UNSIGNED NOT NULL DEFAULT 0");
    }
    if ($colExists($tComments, 'last_edit_at') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `last_edit_at` DATETIME NULL");
    }
    if ($colExists($tComments, 'last_edit_by') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `last_edit_by` INT UNSIGNED NULL");
    }
    if ($colExists($tComments, 'ip_hash') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `ip_hash` CHAR(64) NULL");
    }
    if ($colExists($tComments, 'position') === false) {
      $pdo->exec("ALTER TABLE `{$tComments}` ADD COLUMN `position` INT UNSIGNED NULL");
    }
    if (!$idxExists($tComments, 'idx_post_position')) {
      $pdo->exec("CREATE INDEX `idx_post_position` ON `{$tComments}` (`post_id`, `position`)");
    }

    $tAtt = $pfx . 'xf_attachment_data';
    if ($colExists($tAtt, 'thumb_path') === false) {
      $pdo->exec("ALTER TABLE `{$tAtt}` ADD COLUMN `thumb_path` VARCHAR(255) NULL");
    }
    if ($colExists($tAtt, 'thumb_width') === false) {
      $pdo->exec("ALTER TABLE `{$tAtt}` ADD COLUMN `thumb_width` INT UNSIGNED NULL");
    }
    if ($colExists($tAtt, 'thumb_height') === false) {
      $pdo->exec("ALTER TABLE `{$tAtt}` ADD COLUMN `thumb_height` INT UNSIGNED NULL");
    }
  },
];
