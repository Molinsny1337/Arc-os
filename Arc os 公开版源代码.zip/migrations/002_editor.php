<?php
declare(strict_types=1);

return [
  'id' => '002_editor',
  'up' => function(PDO $pdo, string $pfx): void {
    $collation = 'utf8mb4_0900_ai_ci';
    try {
      $st = $pdo->prepare('SELECT 1 FROM INFORMATION_SCHEMA.COLLATIONS WHERE COLLATION_NAME=?');
      $st->execute([$collation]);
      if (!$st->fetchColumn()) $collation = 'utf8mb4_general_ci';
    } catch (Throwable $e) {
      $collation = 'utf8mb4_general_ci';
    }

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_drafts (
      draft_key VARCHAR(190) NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
      bbcode MEDIUMTEXT NULL,
      attachments_json TEXT NULL,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (draft_key),
      KEY idx_user (user_id, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_attachment_data (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id INT UNSIGNED NOT NULL,
      file_name VARCHAR(255) NOT NULL,
      file_path VARCHAR(255) NOT NULL,
      file_hash VARCHAR(64) NULL,
      mime VARCHAR(128) NOT NULL,
      size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
      width INT UNSIGNED NULL,
      height INT UNSIGNED NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_user (user_id, id),
      KEY idx_hash (file_hash)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_attachments (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      data_id BIGINT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
      temp_key VARCHAR(190) NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_data (data_id),
      KEY idx_content (content_type, content_id),
      KEY idx_temp (temp_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_mention_log (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id INT UNSIGNED NOT NULL,
      from_user_id INT UNSIGNED NOT NULL,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_user (user_id, id),
      KEY idx_content (content_type, content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();
  },
];