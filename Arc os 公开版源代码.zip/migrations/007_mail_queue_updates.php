<?php
declare(strict_types=1);

return [
  'id' => '007_mail_queue_updates',
  'up' => function(PDO $pdo, string $pfx): void {
    $queue = $pfx . 'xf_mail_queue';
    try {
      $cols = [];
      $stmt = $pdo->query("SHOW COLUMNS FROM `{$queue}`");
      while ($stmt && ($row = $stmt->fetch(PDO::FETCH_ASSOC))) {
        $cols[(string)($row['Field'] ?? '')] = true;
      }
      if (!isset($cols['last_attempt_at'])) {
        $pdo->exec("ALTER TABLE `{$queue}` ADD COLUMN `last_attempt_at` DATETIME NULL");
      }
      if (!isset($cols['next_attempt_at'])) {
        $pdo->exec("ALTER TABLE `{$queue}` ADD COLUMN `next_attempt_at` DATETIME NULL");
      }
    } catch (Throwable $e) {
      // ignore
    }

    $log = $pfx . 'xf_mail_log';
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$log}` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `queue_id` BIGINT UNSIGNED NULL,
        `to_email` VARCHAR(191) NOT NULL,
        `subject` VARCHAR(255) NOT NULL,
        `status` VARCHAR(20) NOT NULL,
        `error` TEXT NULL,
        `created_at` DATETIME NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status_created` (`status`, `created_at`),
        KEY `idx_queue` (`queue_id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {
      // ignore
    }
  },
];
