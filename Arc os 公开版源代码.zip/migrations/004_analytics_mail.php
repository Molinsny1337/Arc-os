<?php
declare(strict_types=1);

return [
  'id' => '004_analytics_mail',
  'up' => function(PDO $pdo, string $pfx): void {
    $collation = 'utf8mb4_0900_ai_ci';
    try {
      $st = $pdo->prepare('SELECT 1 FROM INFORMATION_SCHEMA.COLLATIONS WHERE COLLATION_NAME=?');
      $st->execute([$collation]);
      if (!$st->fetchColumn()) $collation = 'utf8mb4_general_ci';
    } catch (Throwable $e) {
      $collation = 'utf8mb4_general_ci';
    }

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_mail_queue (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      to_email VARCHAR(191) NOT NULL,
      subject VARCHAR(255) NOT NULL,
      html_body MEDIUMTEXT NULL,
      text_body MEDIUMTEXT NULL,
      status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
      attempts INT UNSIGNED NOT NULL DEFAULT 0,
      last_error TEXT NULL,
      created_at DATETIME NOT NULL,
      sent_at DATETIME NULL,
      PRIMARY KEY (id),
      KEY idx_status_created (status, created_at),
      KEY idx_attempts (attempts, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_analytics_events (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      created_at DATETIME NOT NULL,
      path VARCHAR(255) NOT NULL,
      route_type VARCHAR(32) NOT NULL,
      user_id INT UNSIGNED NULL,
      session_id VARCHAR(128) NOT NULL,
      ip_hash CHAR(64) NOT NULL,
      ua_hash CHAR(64) NOT NULL,
      referrer VARCHAR(255) NULL,
      is_bot TINYINT(1) NOT NULL DEFAULT 0,
      PRIMARY KEY (id),
      KEY idx_created (created_at),
      KEY idx_route (route_type, created_at),
      KEY idx_session (session_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}user_profile_prefs (
      user_id INT UNSIGNED NOT NULL,
      layout_json TEXT NULL,
      css_vars TEXT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();
  },
];
