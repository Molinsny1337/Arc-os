<?php
declare(strict_types=1);

return [
  'id' => '005_discord_profile',
  'up' => function(PDO $pdo, string $pfx): void {
    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_user_discord (
      user_id INT UNSIGNED NOT NULL,
      discord_user_id VARCHAR(32) NOT NULL,
      discord_username VARCHAR(100) NOT NULL,
      discord_discriminator VARCHAR(10) NULL,
      discord_avatar VARCHAR(100) NULL,
      discord_email VARCHAR(191) NULL,
      access_token_enc TEXT NOT NULL,
      refresh_token_enc TEXT NOT NULL,
      token_expires_at DATETIME NULL,
      connected_at DATETIME NOT NULL,
      last_sync_at DATETIME NULL,
      PRIMARY KEY (user_id),
      UNIQUE KEY uniq_discord_user (discord_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_webhook_log (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      event VARCHAR(64) NOT NULL,
      status VARCHAR(20) NOT NULL,
      error TEXT NULL,
      response_snippet TEXT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_event_created (event, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_discord_role_map (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      role_id VARCHAR(32) NOT NULL,
      group_id INT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uniq_role_group (role_id, group_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_discord_sync_log (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id INT UNSIGNED NOT NULL,
      status VARCHAR(20) NOT NULL,
      error TEXT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_user_created (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_user_profile (
      user_id INT UNSIGNED NOT NULL,
      location VARCHAR(120) NULL,
      website VARCHAR(190) NULL,
      about_me_bbcode MEDIUMTEXT NULL,
      signature_bbcode MEDIUMTEXT NULL,
      cover_path VARCHAR(255) NULL,
      privacy_json TEXT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_profile_fields (
      field_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      title VARCHAR(100) NOT NULL,
      field_type VARCHAR(20) NOT NULL,
      field_choices_json TEXT NULL,
      display_order INT NOT NULL DEFAULT 0,
      editable TINYINT(1) NOT NULL DEFAULT 1,
      show_on_profile TINYINT(1) NOT NULL DEFAULT 1,
      PRIMARY KEY (field_id),
      KEY idx_display (display_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_user_field_values (
      user_id INT UNSIGNED NOT NULL,
      field_id INT UNSIGNED NOT NULL,
      value TEXT NULL,
      PRIMARY KEY (user_id, field_id),
      KEY idx_field (field_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_profile_posts (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id INT UNSIGNED NOT NULL,
      author_user_id INT UNSIGNED NOT NULL,
      message_bbcode MEDIUMTEXT NOT NULL,
      is_deleted TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_user (user_id, id),
      KEY idx_author (author_user_id, id),
      FULLTEXT KEY ft_message (message_bbcode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_profile_post_comments (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      profile_post_id BIGINT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      message_bbcode MEDIUMTEXT NOT NULL,
      is_deleted TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_post (profile_post_id, id),
      KEY idx_user (user_id, id),
      FULLTEXT KEY ft_message (message_bbcode)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_user_follow (
      follower_id INT UNSIGNED NOT NULL,
      followed_id INT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (follower_id, followed_id),
      KEY idx_followed (followed_id, follower_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_user_ignore (
      user_id INT UNSIGNED NOT NULL,
      ignored_user_id INT UNSIGNED NOT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, ignored_user_id),
      KEY idx_ignored (ignored_user_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_profile_visitors (
      user_id INT UNSIGNED NOT NULL,
      visitor_user_id INT UNSIGNED NOT NULL,
      visited_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, visitor_user_id),
      KEY idx_visited (visited_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;")->execute();

    // Extend trophies with criteria fields (best-effort)
    try {
      $pdo->prepare("ALTER TABLE {$pfx}trophies ADD COLUMN criteria_json TEXT NULL")->execute();
    } catch (Throwable $e) {}
    try {
      $pdo->prepare("ALTER TABLE {$pfx}trophies ADD COLUMN display_order INT NOT NULL DEFAULT 0")->execute();
    } catch (Throwable $e) {}
  },
];
