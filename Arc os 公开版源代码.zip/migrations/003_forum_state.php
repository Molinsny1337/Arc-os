<?php
declare(strict_types=1);

return [
  'id' => '003_forum_state',
  'up' => function(PDO $pdo, string $pfx): void {
    $collation = 'utf8mb4_0900_ai_ci';
    try {
      $st = $pdo->prepare('SELECT 1 FROM INFORMATION_SCHEMA.COLLATIONS WHERE COLLATION_NAME=?');
      $st->execute([$collation]);
      if (!$st->fetchColumn()) $collation = 'utf8mb4_general_ci';
    } catch (Throwable $e) {
      $collation = 'utf8mb4_general_ci';
    }

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_thread_prefixes (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      title VARCHAR(100) NOT NULL,
      css_class VARCHAR(64) NULL,
      display_order INT NOT NULL DEFAULT 0,
      is_enabled TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_order (display_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_thread_reads (
      user_id BIGINT UNSIGNED NOT NULL,
      thread_id BIGINT UNSIGNED NOT NULL,
      last_read_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, thread_id),
      KEY idx_thread (thread_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_forum_reads (
      user_id BIGINT UNSIGNED NOT NULL,
      forum_id BIGINT UNSIGNED NOT NULL,
      last_read_at DATETIME NOT NULL,
      PRIMARY KEY (user_id, forum_id),
      KEY idx_forum (forum_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_reports (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      content_type VARCHAR(32) NOT NULL,
      content_id BIGINT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      reason VARCHAR(255) NOT NULL,
      details TEXT NULL,
      status ENUM('open','closed') NOT NULL DEFAULT 'open',
      handled_by INT UNSIGNED NULL,
      handled_at DATETIME NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY idx_status (status, id),
      KEY idx_content (content_type, content_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_emojis (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      shortcode VARCHAR(64) NOT NULL,
      unicode VARCHAR(64) NULL,
      image_path VARCHAR(255) NULL,
      category VARCHAR(64) NULL,
      width INT UNSIGNED NULL,
      height INT UNSIGNED NULL,
      is_sticker TINYINT(1) NOT NULL DEFAULT 0,
      display_order INT NOT NULL DEFAULT 0,
      PRIMARY KEY (id),
      UNIQUE KEY uniq_shortcode (shortcode),
      KEY idx_category (category, display_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_emoji_packs (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      title VARCHAR(100) NOT NULL,
      slug VARCHAR(64) NOT NULL,
      is_enabled TINYINT(1) NOT NULL DEFAULT 1,
      display_order INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uniq_slug (slug),
      KEY idx_order (display_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_emoji_pack_items (
      pack_id BIGINT UNSIGNED NOT NULL,
      emoji_id BIGINT UNSIGNED NOT NULL,
      PRIMARY KEY (pack_id, emoji_id),
      KEY idx_emoji (emoji_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();
  },
];
