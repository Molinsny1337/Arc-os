<?php
declare(strict_types=1);

return [
  'id' => '008_license_state',
  'up' => function(PDO $pdo, string $pfx): void {
    $table = $pfx . 'arc_license_state';
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS `{$table}` (
        `id` INT UNSIGNED NOT NULL,
        `site_id` CHAR(36) NOT NULL,
        `domain_bound` VARCHAR(255) NOT NULL,
        `tier` VARCHAR(16) NOT NULL DEFAULT 'free',
        `features_json` TEXT NULL,
        `license_blob` MEDIUMTEXT NULL,
        `account_token_enc` TEXT NULL,
        `refresh_token_enc` TEXT NULL,
        `last_check_at` DATETIME NULL,
        `next_check_at` DATETIME NULL,
        `expires_at` DATETIME NULL,
        `grace_until` DATETIME NULL,
        `status` VARCHAR(16) NOT NULL DEFAULT 'invalid',
        PRIMARY KEY (`id`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    } catch (Throwable $e) {
      // ignore
    }
  },
];
