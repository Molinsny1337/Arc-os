<?php
declare(strict_types=1);

return [
  'id' => '003_layout_settings',
  'up' => function(PDO $pdo, string $pfx): void {
    $collation = 'utf8mb4_0900_ai_ci';
    try {
      $st = $pdo->prepare('SELECT 1 FROM INFORMATION_SCHEMA.COLLATIONS WHERE COLLATION_NAME=?');
      $st->execute([$collation]);
      if (!$st->fetchColumn()) $collation = 'utf8mb4_general_ci';
    } catch (Throwable $e) {
      $collation = 'utf8mb4_general_ci';
    }

    $pdo->prepare("CREATE TABLE IF NOT EXISTS {$pfx}xf_layout_settings (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id INT UNSIGNED NULL,
      scope VARCHAR(16) NOT NULL DEFAULT 'global',
      page_key VARCHAR(64) NOT NULL,
      layout_json LONGTEXT NOT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      UNIQUE KEY uniq_scope_page (scope, page_key),
      KEY idx_user (user_id, page_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE={$collation}")->execute();
  },
];